--
-- PostgreSQL database dump
--

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg12+1)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: llacie_annotators; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_annotators (
    id bigint NOT NULL,
    username character varying(255) NOT NULL,
    password text,
    admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.llacie_annotators OWNER TO llacie;

--
-- Name: llacie_annotators_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_annotators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_annotators_id_seq OWNER TO llacie;

--
-- Name: llacie_annotators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_annotators_id_seq OWNED BY public.llacie_annotators.id;


--
-- Name: llacie_cohorts; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_cohorts (
    id bigint NOT NULL,
    "FK_episode_id" bigint NOT NULL,
    "infectionCriteria" boolean DEFAULT true NOT NULL,
    "excl_ST0_combined" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.llacie_cohorts OWNER TO llacie;

--
-- Name: llacie_cohorts_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_cohorts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_cohorts_id_seq OWNER TO llacie;

--
-- Name: llacie_cohorts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_cohorts_id_seq OWNED BY public.llacie_cohorts.id;


--
-- Name: llacie_episode_labels; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_episode_labels (
    id bigint NOT NULL,
    "FK_note_feature_id" bigint,
    "FK_episode_id" bigint NOT NULL,
    "FK_strategy_id" bigint,
    "FK_task_id" bigint NOT NULL,
    task_name character varying(255) NOT NULL,
    label_name text NOT NULL,
    label_value numeric(10,8),
    line_number bigint,
    "FK_human_annotator" character varying(255),
    CONSTRAINT llacie_episode_labels_either_strategy_or_human CHECK ((("FK_strategy_id" IS NOT NULL) OR ("FK_human_annotator" IS NOT NULL)))
);


ALTER TABLE public.llacie_episode_labels OWNER TO llacie;

--
-- Name: llacie_episode_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_episode_labels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_episode_labels_id_seq OWNER TO llacie;

--
-- Name: llacie_episode_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_episode_labels_id_seq OWNED BY public.llacie_episode_labels.id;


--
-- Name: llacie_episodes; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_episodes (
    id bigint NOT NULL,
    "patientID" character varying(40) NOT NULL,
    "admitPatientEncounterID" bigint NOT NULL,
    "dcPatientEncounterID" bigint NOT NULL,
    "startDTS" timestamp with time zone
);


ALTER TABLE public.llacie_episodes OWNER TO llacie;

--
-- Name: llacie_episodes_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_episodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_episodes_id_seq OWNER TO llacie;

--
-- Name: llacie_episodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_episodes_id_seq OWNED BY public.llacie_episodes.id;


--
-- Name: llacie_note_features; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_note_features (
    id bigint NOT NULL,
    "FK_note_id" bigint NOT NULL,
    feature_name character varying(255) NOT NULL,
    "FK_note_section_id" bigint,
    "FK_strategy_id" bigint NOT NULL,
    llm_output_raw text NOT NULL,
    feature_value text,
    feature_updated timestamp with time zone NOT NULL,
    strategy_runtime numeric(12,5)
);


ALTER TABLE public.llacie_note_features OWNER TO llacie;

--
-- Name: llacie_note_features_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_note_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_note_features_id_seq OWNER TO llacie;

--
-- Name: llacie_note_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_note_features_id_seq OWNED BY public.llacie_note_features.id;


--
-- Name: llacie_note_sections; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_note_sections (
    id bigint NOT NULL,
    "FK_note_id" bigint NOT NULL,
    section_name character varying(40) NOT NULL,
    section_value text,
    "FK_strategy_id" bigint NOT NULL,
    last_updated timestamp with time zone
);


ALTER TABLE public.llacie_note_sections OWNER TO llacie;

--
-- Name: llacie_note_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_note_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_note_sections_id_seq OWNER TO llacie;

--
-- Name: llacie_note_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_note_sections_id_seq OWNED BY public.llacie_note_sections.id;


--
-- Name: llacie_notes; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_notes (
    id bigint NOT NULL,
    "FK_episode_id" bigint NOT NULL,
    "NoteID" bigint NOT NULL,
    "PatientEncounterID" bigint NOT NULL,
    "InpatientNoteTypeDSC" character varying(255) DEFAULT 'H&P'::character varying NOT NULL,
    "CurrentAuthorID" character varying(30),
    "AuthorServiceDSC" character varying(255),
    "AuthorProviderTypeDSC" character varying(255),
    "CreateDTS" timestamp with time zone,
    "DateOfServiceDTS" timestamp with time zone,
    "LastFiledDTS" timestamp with time zone,
    "EDWLastModifiedDTS" timestamp with time zone,
    "NoteFiledDTS" timestamp with time zone,
    "ContactDateRealNBR" numeric(8,2),
    "NoteCSNID" bigint,
    note_text text
);


ALTER TABLE public.llacie_notes OWNER TO llacie;

--
-- Name: llacie_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_notes_id_seq OWNER TO llacie;

--
-- Name: llacie_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_notes_id_seq OWNED BY public.llacie_notes.id;


--
-- Name: llacie_strategies; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_strategies (
    id bigint NOT NULL,
    "FK_task_id" bigint NOT NULL,
    name character varying(255) NOT NULL,
    "desc" text,
    version character varying(255) NOT NULL,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llacie_strategies OWNER TO llacie;

--
-- Name: llacie_strategies_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_strategies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_strategies_id_seq OWNER TO llacie;

--
-- Name: llacie_strategies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_strategies_id_seq OWNED BY public.llacie_strategies.id;


--
-- Name: llacie_tasks; Type: TABLE; Schema: public; Owner: llacie
--

CREATE TABLE public.llacie_tasks (
    id bigint NOT NULL,
    output_type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "desc" text
);


ALTER TABLE public.llacie_tasks OWNER TO llacie;

--
-- Name: llacie_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: llacie
--

CREATE SEQUENCE public.llacie_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.llacie_tasks_id_seq OWNER TO llacie;

--
-- Name: llacie_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: llacie
--

ALTER SEQUENCE public.llacie_tasks_id_seq OWNED BY public.llacie_tasks.id;


--
-- Name: llacie_annotators id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_annotators ALTER COLUMN id SET DEFAULT nextval('public.llacie_annotators_id_seq'::regclass);


--
-- Name: llacie_cohorts id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_cohorts ALTER COLUMN id SET DEFAULT nextval('public.llacie_cohorts_id_seq'::regclass);


--
-- Name: llacie_episode_labels id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels ALTER COLUMN id SET DEFAULT nextval('public.llacie_episode_labels_id_seq'::regclass);


--
-- Name: llacie_episodes id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episodes ALTER COLUMN id SET DEFAULT nextval('public.llacie_episodes_id_seq'::regclass);


--
-- Name: llacie_note_features id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_features ALTER COLUMN id SET DEFAULT nextval('public.llacie_note_features_id_seq'::regclass);


--
-- Name: llacie_note_sections id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_sections ALTER COLUMN id SET DEFAULT nextval('public.llacie_note_sections_id_seq'::regclass);


--
-- Name: llacie_notes id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_notes ALTER COLUMN id SET DEFAULT nextval('public.llacie_notes_id_seq'::regclass);


--
-- Name: llacie_strategies id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_strategies ALTER COLUMN id SET DEFAULT nextval('public.llacie_strategies_id_seq'::regclass);


--
-- Name: llacie_tasks id; Type: DEFAULT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_tasks ALTER COLUMN id SET DEFAULT nextval('public.llacie_tasks_id_seq'::regclass);


--
-- Data for Name: llacie_annotators; Type: TABLE DATA; Schema: public; Owner: llacie
--



--
-- Data for Name: llacie_cohorts; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (1, 1, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (2, 2, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (3, 3, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (4, 4, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (5, 5, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (6, 6, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (7, 7, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (8, 8, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (9, 9, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (10, 10, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (11, 11, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (12, 12, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (13, 13, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (14, 14, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (15, 15, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (16, 16, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (17, 17, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (18, 18, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (19, 19, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (20, 20, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (21, 21, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (22, 22, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (23, 23, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (24, 24, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (25, 25, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (26, 26, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (27, 27, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (28, 28, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (29, 29, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (30, 30, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (31, 31, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (32, 32, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (33, 33, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (34, 34, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (35, 35, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (36, 36, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (37, 37, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (38, 38, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (39, 39, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (40, 40, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (41, 41, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (42, 42, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (43, 43, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (44, 44, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (45, 45, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (46, 46, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (47, 47, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (48, 48, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (49, 49, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (50, 50, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (51, 51, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (52, 52, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (53, 53, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (54, 54, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (55, 55, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (56, 56, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (57, 57, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (58, 58, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (59, 59, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (60, 60, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (61, 61, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (62, 62, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (63, 63, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (64, 64, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (65, 65, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (66, 66, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (67, 67, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (68, 68, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (69, 69, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (70, 70, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (71, 71, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (72, 72, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (73, 73, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (74, 74, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (75, 75, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (76, 76, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (77, 77, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (78, 78, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (79, 79, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (80, 80, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (81, 81, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (82, 82, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (83, 83, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (84, 84, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (85, 85, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (86, 86, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (87, 87, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (88, 88, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (89, 89, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (90, 90, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (91, 91, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (92, 92, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (93, 93, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (94, 94, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (95, 95, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (96, 96, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (97, 97, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (98, 98, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (99, 99, true, false);
INSERT INTO public.llacie_cohorts (id, "FK_episode_id", "infectionCriteria", "excl_ST0_combined") VALUES (100, 100, true, false);


--
-- Data for Name: llacie_episode_labels; Type: TABLE DATA; Schema: public; Owner: llacie
--



--
-- Data for Name: llacie_episodes; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (1, 'T98434120783', 98434120783, 98434120783, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (2, 'T60661386493', 60661386493, 60661386493, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (3, 'T52497935781', 52497935781, 52497935781, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (4, 'T20539529704', 20539529704, 20539529704, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (5, 'T20430289792', 20430289792, 20430289792, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (6, 'T69581812629', 69581812629, 69581812629, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (7, 'T97738540490', 97738540490, 97738540490, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (8, 'T70710239527', 70710239527, 70710239527, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (9, 'T50196317731', 50196317731, 50196317731, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (10, 'T83755820021', 83755820021, 83755820021, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (11, 'T96193705092', 96193705092, 96193705092, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (12, 'T37142384425', 37142384425, 37142384425, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (13, 'T70148484267', 70148484267, 70148484267, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (14, 'T72881543976', 72881543976, 72881543976, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (15, 'T25481031640', 25481031640, 25481031640, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (16, 'T67634736269', 67634736269, 67634736269, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (17, 'T37769248665', 37769248665, 37769248665, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (18, 'T65869176080', 65869176080, 65869176080, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (19, 'T84826071984', 84826071984, 84826071984, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (20, 'T88379319666', 88379319666, 88379319666, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (21, 'T40152264630', 40152264630, 40152264630, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (22, 'T38603008904', 38603008904, 38603008904, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (23, 'T43867340583', 43867340583, 43867340583, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (24, 'T10225620358', 10225620358, 10225620358, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (25, 'T92996718023', 92996718023, 92996718023, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (26, 'T76482833548', 76482833548, 76482833548, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (27, 'T91447658882', 91447658882, 91447658882, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (28, 'T73270670196', 73270670196, 73270670196, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (29, 'T38589555007', 38589555007, 38589555007, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (30, 'T30018603567', 30018603567, 30018603567, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (31, 'T20051851129', 20051851129, 20051851129, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (32, 'T93228055429', 93228055429, 93228055429, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (33, 'T53423001714', 53423001714, 53423001714, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (34, 'T68441991029', 68441991029, 68441991029, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (35, 'T65239534408', 65239534408, 65239534408, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (36, 'T24315574657', 24315574657, 24315574657, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (37, 'T34551248420', 34551248420, 34551248420, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (38, 'T12077099065', 12077099065, 12077099065, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (39, 'T95546043852', 95546043852, 95546043852, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (40, 'T10527253250', 10527253250, 10527253250, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (41, 'T82339259222', 82339259222, 82339259222, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (42, 'T55591271667', 55591271667, 55591271667, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (43, 'T81603227618', 81603227618, 81603227618, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (44, 'T66398765634', 66398765634, 66398765634, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (45, 'T61238613706', 61238613706, 61238613706, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (46, 'T36061499778', 36061499778, 36061499778, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (47, 'T46166091990', 46166091990, 46166091990, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (48, 'T66419809395', 66419809395, 66419809395, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (49, 'T22577729310', 22577729310, 22577729310, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (50, 'T88544154944', 88544154944, 88544154944, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (51, 'T55082209061', 55082209061, 55082209061, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (52, 'T50342540620', 50342540620, 50342540620, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (53, 'T87629439609', 87629439609, 87629439609, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (54, 'T82216014707', 82216014707, 82216014707, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (55, 'T40643573055', 40643573055, 40643573055, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (56, 'T97572935027', 97572935027, 97572935027, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (57, 'T61645398223', 61645398223, 61645398223, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (58, 'T89385289676', 89385289676, 89385289676, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (59, 'T80679713961', 80679713961, 80679713961, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (60, 'T62740491806', 62740491806, 62740491806, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (61, 'T46856543738', 46856543738, 46856543738, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (62, 'T14884979831', 14884979831, 14884979831, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (63, 'T24979281618', 24979281618, 24979281618, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (64, 'T96269039595', 96269039595, 96269039595, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (65, 'T23644092566', 23644092566, 23644092566, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (66, 'T69508600176', 69508600176, 69508600176, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (67, 'T97968021955', 97968021955, 97968021955, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (68, 'T77785832224', 77785832224, 77785832224, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (69, 'T75325652810', 75325652810, 75325652810, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (70, 'T23897679986', 23897679986, 23897679986, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (71, 'T25332600647', 25332600647, 25332600647, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (72, 'T28948901188', 28948901188, 28948901188, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (73, 'T18597492476', 18597492476, 18597492476, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (74, 'T46429751289', 46429751289, 46429751289, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (75, 'T41260837596', 41260837596, 41260837596, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (76, 'T25180260459', 25180260459, 25180260459, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (77, 'T59949125785', 59949125785, 59949125785, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (78, 'T43835184434', 43835184434, 43835184434, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (79, 'T72840360570', 72840360570, 72840360570, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (80, 'T77435497885', 77435497885, 77435497885, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (81, 'T43016647224', 43016647224, 43016647224, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (82, 'T24986201085', 24986201085, 24986201085, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (83, 'T85174402248', 85174402248, 85174402248, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (84, 'T57257157860', 57257157860, 57257157860, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (85, 'T32230500492', 32230500492, 32230500492, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (86, 'T12680457646', 12680457646, 12680457646, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (87, 'T76591484048', 76591484048, 76591484048, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (88, 'T10626072533', 10626072533, 10626072533, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (89, 'T88882927178', 88882927178, 88882927178, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (90, 'T96535159240', 96535159240, 96535159240, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (91, 'T14965032931', 14965032931, 14965032931, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (92, 'T23868081900', 23868081900, 23868081900, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (93, 'T66484486724', 66484486724, 66484486724, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (94, 'T46299007126', 46299007126, 46299007126, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (95, 'T61732488894', 61732488894, 61732488894, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (96, 'T33707928009', 33707928009, 33707928009, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (97, 'T75956140538', 75956140538, 75956140538, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (98, 'T74752567173', 74752567173, 74752567173, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (99, 'T69569725915', 69569725915, 69569725915, '2025-11-19 06:07:13.035833+00');
INSERT INTO public.llacie_episodes (id, "patientID", "admitPatientEncounterID", "dcPatientEncounterID", "startDTS") VALUES (100, 'T41443257973', 41443257973, 41443257973, '2025-11-19 06:07:13.035833+00');


--
-- Data for Name: llacie_note_features; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_note_features (id, "FK_note_id", feature_name, "FK_note_section_id", "FK_strategy_id", llm_output_raw, feature_value, feature_updated, strategy_runtime) VALUES (1, 1, 'presenting_sx', 1, 2, '["Fever", "Erythema", "Warmth", "Purulent drainage", "Line pain", "Chills", "Mild fever", "Low-grade fever"]', 'Fever
Erythema
Warmth
Purulent drainage
Line pain
Chills
Mild fever
Low-grade fever', '2025-11-19 06:09:24.471687+00', 49.62431);
INSERT INTO public.llacie_note_features (id, "FK_note_id", feature_name, "FK_note_section_id", "FK_strategy_id", llm_output_raw, feature_value, feature_updated, strategy_runtime) VALUES (2, 2, 'presenting_sx', 2, 2, '["Worsening dysuria", "Cloudy urine", "Suprapubic pressure", "Chills", "Burning on urination", "Low-grade fever", "N/V", "Dull R flank ache", "Radiating to groin"]', 'Worsening dysuria
Cloudy urine
Suprapubic pressure
Chills
Burning on urination
Low-grade fever
N/V
Dull R flank ache
Radiating to groin', '2025-11-19 06:09:24.478352+00', 49.62431);


--
-- Data for Name: llacie_note_sections; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (1, 1, 'hpi_short', '35yo M with h/o ESRD on hemodialysis via right femoral tunneled catheter (placed 3/12/3083), HTN, CKD‑5, and recent admission for urosepsis (09/02/3084) p/w fever, dysuria, and altered mental status. He was treated with IV cefepime 48 h, completed 7‑day course, and was discharged home on 09/09/3084 with a plan for outpatient dialysis. Since discharge, he notes progressive erythema, warmth, and purulent drainage at the catheter exit site over the past 48 h. He reports mild low‑grade fever (T max 100.4 °F) and chills, but denies rigors, chest pain, SOB, or new cough. He has missed two dialysis sessions (09/14 and 09/18) because of line pain and concerns about infection. He attempted self‑care with over‑the‑counter bacitracin ointment, no improvement. No recent travel. No known sick contacts. He presents to the ED after his dialysis nurse advised urgent evaluation.', 1, '2025-11-19 06:07:14.616099+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (2, 2, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 48), BPH, recent prostatitis p/w N/V/D and R flank pain now presents w/ 2‑day hx of worsening dysuria, cloudy urine, suprapubic pressure and chills. Pt reports first noticed burning on urination yesterday morning after a night shift at the warehouse; he drank 2‑3 cans of energy drink, no water. Yesterday night he developed low‑grade fever (T 38.2°C) and chills, then today woke with N/V and a dull R flank ache radiating to the groin. He denies any recent catheterization, sexual activity, or new sexual partners. Pt was seen at urgent care 3 days ago for “UTI” and was given a 5‑day course of TMP‑SMX; he only took 2 doses before stopping due to GI upset. He now reports that symptoms have progressed despite the partial course. No flank tenderness on exam reported by pt, but he feels “pressure”. He denies hematuria, dyschezia, or back pain. No recent travel, no sick contacts.', 1, '2025-11-19 06:07:14.617084+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (3, 3, 'hpi_short', '58yo M with h/o IV drug use (last use 3 mo ago), chronic HCV (treated, RNA neg), severe MR (post‑repair 2019), CKD‑3 (baseline Cr 1.6), and recent left‑foot cellulitis p/w erythema, pain, and purulent drainage, now presents w/ 5‑day hx of intermittent fevers up to 102.4°F, night sweats, rigors, progressive dyspnea on exertion, and a new harsh holosystolic murmur radiating to the axilla noted by his primary care doc on 06/04. He reports associated fatigue, anorexia, weight loss ~4 lb, and occasional pleuritic chest pain left side. Denies cough, hemoptysis, abdominal pain, dysuria, or recent dental work. He was seen at an outside urgent care on 06/02, received a single dose of IM ceftriaxone and was discharged with instructions to follow up. Since then symptoms have worsened, he now feels “light‑headed” when standing. He reports occasional palpitations but no syncope. No recent travel. No known sick contacts. He admits to occasional alcohol (2‑3 beers/week) and denies tobacco now (quit 2 yr ago).', 1, '2025-11-19 06:07:14.617573+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (4, 4, 'hpi_short', '58yo M with h/o HFrEF (EF 30%), CAD s/p PCI 3055, CKD3, HTN, DM2 (A1c 8.7%), and recent URI p/w cough now presents w/ progressive dyspnea x4 days, orthopnea (2 pillows), PND, and 2+ LE pitting edema to mid‑shin. Pt reports that 2 days ago he was seen at an outside ED (St. Mercy) where CXR showed pulmonary vascular congestion, BNP 1120 pg/mL, and he was given IV furosemide 40 mg bolus then 20 mg q8h. He was discharged home on oral furosemide 40 mg BID, metolazone 5 mg daily, and told to follow‑up. Since discharge, dyspnea has worsened, now dyspneic at rest, O2 sat 88% on RA, HR 112, BP 158/92. Denies chest pain, palpitations, fever, cough, or leg pain. No recent travel. Pt admits to occasional “cheese” binge and 2‑3 beers nightly.', 1, '2025-11-19 06:07:14.618042+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (5, 5, 'hpi_short', '58yo F w/ h/o T2DM (A1c 8.9%), CKD stage 3, HTN, and recent UTI p/w 3‑day hx of non‑localizing fever, chills, night sweats, and generalized fatigue. She reports Tmax 102.4°F at home yesterday, associated with mild headache and diffuse myalgias. Denies cough, dyspnea, chest pain, dysuria, abdominal pain, rash, or focal neuro deficits. She was seen at an outside urgent care 2 days ago, received a single dose of PO cefpodoxime 200 mg and was discharged with instructions to follow‑up. Symptoms persisted and she now presents to our ED after a syncopal episode while standing in her kitchen; she reports brief light‑headedness but no loss of consciousness. No recent travel, no known sick contacts. She lives with husband, works part‑time as a school cafeteria aide, and reports occasional alcohol (1‑2 drinks/week) and no tobacco use. She has been non‑compliant with her insulin regimen for the past week due to “forgetting” and has been taking metformin 500 mg BID only.', 1, '2025-11-19 06:07:14.618513+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (6, 6, 'hpi_short', '58yo F w/ h/o HTN, CKD stage 3 (baseline Cr 1.6), DM2 (A1c 8.9%), recent prostatitis‑like episode (actually cystitis) p/w N/V/D and R flank pain 3 days ago. She presented to an outside ED on 01/23/3093 with temp 38.9°C, dysuria, urgency, suprapubic tenderness. UA showed +leukocyte esterase, nitrites, WBC 45/hpf. CT abdomen/pelvis negative for obstruction. Treated with PO ceftriaxone 500 mg BID and discharged after 6 h observation with instructions to complete 5‑day course. Since discharge, symptoms have worsened: now has persistent burning on voiding, increased frequency (Q1‑2 h), lower abdominal cramping, chills, and a new onset of mild left flank dullness. She reports no flank tenderness on exam at home, no gross hematuria, no flank mass. She denies recent sexual activity, new sexual partners, or use of spermicides. She reports compliance with meds but missed the last dose of ceftriaxone due to nausea. She also notes that she has been drinking 2‑3 glasses of water daily, but increased caffeine intake over past week. She denies recent travel, sick contacts, or catheter use. She presents now for re‑evaluation and admission for possible complicated UTI/pyelonephritis given CKD and persistent fever.', 1, '2025-11-19 06:07:14.618954+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (7, 7, 'hpi_short', '26yo M with h/o cholecystectomy 2 wk ago (lap, uncomplicated), T2DM (A1c 8.1%), HTN, and recent PICC line placement for TPN now p/w fever up to 39.4°C, rigors, localized pain and erythema over right mid‑clavicular line. Pt reports line was placed 10 days post‑op, used for TPN for 7 days, removed 4 days ago after TPN completion. Since removal, he notes “red spot” that has enlarged, now tender, with serous drainage. He denies SOB, cough, chest pain, dysuria, or abdominal pain. He reports mild nausea but no vomiting, no diarrhea. He took acetaminophen at home with minimal relief. He was seen in the ED 2 days ago; vitals: T 38.9°C, HR 112, BP 128/78, RR 20, SpO2 98% RA. Labs then showed WBC 14.2, CRP 12.5 mg/dL. Blood cultures drawn, pending. He was discharged on oral cefpodoxime 200 mg BID pending results, but symptoms worsened, prompting return. He denies recent travel, sick contacts, or animal exposure. No known drug allergies.', 1, '2025-11-19 06:07:14.61939+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (8, 8, 'hpi_short', '58yo M with h/o T2DM (A1c 8.7%), CKD stage 3, HTN, and recent plantar ulcer p/w erythema, warmth, swelling of RLE presents to ED after 2 days of progressive pain and expanding erythema from mid‑calf to ankle. Pt reports the ulcer began after a minor foot trauma while gardening 5 days ago; he self‑treated with OTC bacitracin and kept foot dry. Yesterday he noted increasing redness, throbbing pain, low‑grade fever (T 100.4 °F at home) and difficulty ambulating. Went to urgent care on 12/07/3070, received PO clindamycin 300 mg q8h and ibuprofen, but symptoms worsened, now with streaking erythema up the posterior calf and a tender, indurated area ~12 × 8 cm. Denies dysuria, SOB, chest pain, N/V, or recent travel. No known sick contacts. No prior similar episodes. Review of outside records shows WBC 13.2 K/µL, CRP 12 mg/dL. Pt was given a dose of IV ceftriaxone in urgent care and transferred for IV antibiotics and possible imaging.', 1, '2025-11-19 06:07:14.619832+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (9, 9, 'hpi_short', '35yo M with h/o T2DM (A1c 8.7% 06/2025), obesity (BMI 34), prior left leg cellulitis 2022, and chronic venous insufficiency p/w acute left lower leg swelling, erythema, warmth, and throbbing pain x 3 days. Patient reports a minor scrape on the medial shin while gardening 4 days ago, initially brushed off, but over the past 48 hrs the area became increasingly red, now extending from the ankle to mid‑calf with a well‑demarcated, raised border. He noted feverish chills, subjective fever up to 101°F, and malaise. Went to urgent care on 07/15/3050, was given oral clindamycin 300 mg q6h and instructed to elevate leg; after 24 hrs symptoms worsened, new purulent drainage noted, and he now has difficulty ambulating. Denies shortness of breath, chest pain, dysuria, or recent travel. No known sick contacts. No prior MRSA colonization.

Outside Hospital Course: Urgent care labs showed WBC 13.2 K/µL, CRP 12 mg/dL. No imaging performed. Patient received one dose of PO clindamycin then left.', 1, '2025-11-19 06:07:14.620525+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (10, 10, 'hpi_short', '45yo M with severe COPD (GOLD D, home O2 2Lpm qhs), chronic bronchiectasis, and 30‑pack‑yr smoking hx (quit 5 y ago) presents w/ 3‑day worsening dyspnea, productive cough now yellow‑green sputum (~150 mL/d), low‑grade fever (Tmax 38.2 °C at home). He reports using albuterol MDI q2h with minimal relief, and his nightly nocturnal O2 requirement increased from 2 L to 4 L. Denies chest pain, palpitations, calf pain, or recent travel. He was seen at an urgent care 2 days ago, given a 5‑day course of azithro 500 mg PO daily which he completed; symptoms progressed despite therapy. He reports recent exposure to a neighbor with “bad cold” 1 wk ago. No prior hospitalizations for COPD exacerbation in past year, but had one admission 3 yrs ago requiring NPPV. He uses home inhalers: albuterol 90 µg MDI 2‑4 puffs q4h PRN, tiotropium 18 µg inhaled daily, and a rescue nebulizer (ipratropium/albuterol) at home. He also uses a portable O2 concentrator. He denies recent steroid use.', 1, '2025-11-19 06:07:14.620944+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (11, 11, 'hpi_short', '29yo M with h/o mild intermittent asthma (SABA PRN), HTN (lisinopril 10 mg daily), recent URI p/w 5‑day productive cough, fever up to 102.4°F, pleuritic chest pain, SOB on exertion, and fatigue. Symptoms began 5 days ago after a weekend camping trip; he reports exposure to smoke from campfire and a roommate with “cold” symptoms. He self‑treated with ibuprofen and guaifenesin, but cough worsened, now producing yellow‑green sputum. Yesterday he presented to the outside ED (St. Mercy Hospital) where vitals were T 101.8°F, HR 112, RR 22, SpO2 94% RA. Labs showed WBC 14.2 K with left shift, CRP 12 mg/dL. CXR demonstrated right lower lobe infiltrate. He received 1 L NS, IV ceftriaxone 1 g, and azithromycin 500 mg, then was transferred for higher‑level care. He denies chest pain radiating, orthopnea, PND, leg swelling, hemoptysis, recent travel, or sick contacts beyond roommate. No known drug allergies. He reports occasional alcohol (2‑3 beers/week) and denies tobacco or illicit drug use.', 1, '2025-11-19 06:07:14.621764+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (12, 12, 'hpi_short', '31yo M with h/o moderate COPD (GOLD II), HTN, and recent URI p/w worsening dyspnea, hypoxemia, and hypercapnia without fever. Patient reports 3‑day history of increasing shortness of breath that began after a weekend camping trip where he was exposed to cold, damp air and did not use his rescue inhaler until yesterday. He notes a dry cough, no sputum, denies chest pain, fever, chills, or rigors. Yesterday night he felt “air hunger,” was unable to speak full sentences, and his wife called EMS. EMS noted RR 32, SpO2 84% on RA, placed on non‑rebreather 15L, and transported to ED. In ED ABG showed pH 7.28, PaCO2 68, PaO2 55 on 15L O2. He was placed on BiPAP with improvement to SpO2 92% but remains tachypneic. He denies recent travel, sick contacts, or known COVID‑19 exposure. Home meds include tiotropium inhaler daily, albuterol PRN, lisinopril 10 mg daily, and low‑dose aspirin. He reports good compliance with inhalers but ran out of albuterol two days ago. No prior intubations. No known drug allergies.', 1, '2025-11-19 06:07:14.622223+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (13, 13, 'hpi_short', '58yo F with h/o COPD (GOLD 2), HTN, DM2 (A1c 8.1%), recent URI p/w 5d of productive cough, fever (Tmax 102.4°F), SOB on exertion, pleuritic chest pain, and fatigue. She reports that 6 days ago she began feeling “scratchy” in the throat after a weekend visit to her granddaughter’s birthday party where she was in a crowded indoor space. Over the next 48 h she developed a low‑grade fever and a dry cough that progressed to a thick, yellow‑green sputum. Yesterday she noted worsening shortness of breath, now at rest, and a new sharp pain on the right lower chest that worsens with deep breaths. She denies hemoptysis, wheezing, orthopnea, PND, leg swelling, recent travel, or known sick contacts. She took ibuprofen 400 mg q6h at home with minimal relief. She presents to the ED after EMS transport; EMS noted HR 112, RR 24, SpO2 91% on room air, BP 138/78. In the ED she received 2 L NS, albuterol nebulizer, and a dose of IV ceftriaxone 1 g. CXR showed right lower lobe infiltrate. She was placed on supplemental O₂ 2 L NC en route to floor.', 1, '2025-11-19 06:07:14.622691+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (14, 14, 'hpi_short', '38yo M with h/o HIV (CD4 420, VL undetectable), prior syphilis (treated), and recent unprotected anal intercourse presents w/ a 5‑day history of a painful ulcer on the distal penile shaft, associated dysuria, and mild urethral discharge. Pt reports the lesion began as a papule, rapidly ulcerated with a raised indurated border and a serosanguinous base. Denies fever, chills, rash, or lymphadenopathy. Pt notes 2 episodes of watery diarrhea last week, thought to be travel‑related (trip to Luna City 2 weeks ago). He was seen at an urgent care 3 days ago, given a single dose of ceftriaxone for presumed gonorrhea, but symptoms persisted. Pt reports occasional “bumps” on the groin but no overt swelling. No prior episodes of similar lesions. Pt admits to recent use of recreational methamphetamine and occasional binge drinking (≈6 drinks per occasion).', 1, '2025-11-19 06:07:14.623157+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (15, 15, 'hpi_short', '36yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, HTN, CKD‑3, and recent admission for cellulitis of R lower extremity p/w erythema, swelling, and low‑grade fever. Discharged 5 days ago on PO clindamycin 300 mg q8h, instructed to keep foot elevated, wound care daily. Since discharge, patient notes progressive worsening: increasing throbbing pain, now 8/10 at rest, blackening of distal hallux extending to mid‑metatarsal, foul smelling drainage, fevers up to 101.5°F at home, chills, nausea. Denies new trauma. Reports that foot became “cold” yesterday, now “doesn’t feel” the tip. He tried OTC ibuprofen with minimal relief. No recent travel. Works as a warehouse supervisor, spends long periods on feet. No known drug allergies. He presents to ED by EMS after wife called due to concern for gangrene.', 1, '2025-11-19 06:07:14.623578+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (16, 16, 'hpi_short', '58yo M with h/o severe COPD (GOLD D, home O2 2Lpm qhs), chronic bronchiectasis, HTN, and prior tobacco use (40 pack‑yr, quit 5y ago) presents from urgent care with worsening dyspnea x4 days, productive cough now greenish sputum, low‑grade fever 100.4°F, and pleuritic chest pain R side. He reports that his baseline dyspnea is 2‑3 L/min O2, but today he needed 4 L/min to keep sats >90% and felt “out of breath” at rest. He used his rescue inhaler (albuterol/ipratropium) q2h with minimal relief, and increased his oral prednisone (started 30 mg PO daily 3 days ago by his PCP) but symptoms progressed. Denies recent travel, sick contacts, or known COVID exposure. He was seen 2 weeks ago for a COPD flare, received a 5‑day course of azithromycin and prednisone taper, completed without issue. He reports occasional nighttime wheeze, but no orthopnea, PND, or leg swelling. No chest pain radiating, no palpitations. He has been compliant with inhalers (tiotropium daily, fluticasone/salmeterol BID) and O2. He states he “feels like I’m drowning” and came to ED after EMS found RR 28, HR 112, BP 138/78, SpO2 84% on 4 L O2.', 1, '2025-11-19 06:07:14.624004+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (17, 17, 'hpi_short', '58yo M with h/o HTN, DM2 (A1c 8.4%), CKD3, recent laparoscopic right hemicolectomy p/w SSI. Patient underwent uncomplicated laparoscopic right hemicolectomy for adenocarcinoma of the ascending colon on 03/20/3062 at outside facility. Post‑op course initially uneventful, discharged home on POD 3 with standard analgesics and oral antibiotics (ciprofloxacin 500 mg BID). On POD 9 (04/01/3062) he noted increasing erythema, warmth, and serosanguinous drainage from the midline port site. He reports low‑grade fevers up to 38.2 °C, chills, and worsening pain rated 7/10, especially with movement. He tried to self‑manage with OTC acetaminophen and ibuprofen, but symptoms progressed. No nausea, vomiting, or change in bowel habits. No recent travel. No known sick contacts. He presented to the ED of this hospital at 04/02/3062 04:45, where vitals showed HR 112, BP 138/84, RR 22, Temp 38.4 °C, SpO2 96% RA. Physical exam noted a 6 cm incision with surrounding erythema, induration, and purulent drainage. Labs drawn, wound cultures obtained, and CT abdomen/pelvis with contrast performed showing fluid collection adjacent to the anastomosis suggestive of localized abscess. He was started on IV ceftriaxone and metronidazole in the ED and admitted for IV antibiotics, possible IR drainage, and wound care.', 1, '2025-11-19 06:07:14.624423+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (18, 18, 'hpi_short', '40yo M with h/o T2DM (A1c 8.7%), HTN, CKD stage 3 (eGFR 48), and recent right foot cellulitis p/w erythema, swelling, low‑grade fever now presents with 3‑day history of non‑localizing fever up to 39.4°C, chills, night sweats, diffuse myalgias and generalized fatigue. Patient reports that fever started abruptly on 08/08 after completing a 7‑day course of oral clindamycin for cellulitis; he felt “hot all the time” and woke up sweating. Denies cough, dyspnea, chest pain, dysuria, abdominal pain, rash, or focal joint pain. He notes mild headache and occasional nausea but no vomiting or diarrhea. He went to urgent care on 08/09; vitals showed T 38.9°C, HR 112, BP 138/84, RR 18, SpO2 97% RA. Labs then showed WBC 13.2, Cr 1.4 (baseline 1.2). He was given IV ceftriaxone and sent home with instructions to follow‑up. Over the next 48 h symptoms persisted, now with new mild confusion and decreased oral intake. Family brought him to ED where he was found febrile 39.2°C, tachycardic 118, BP 132/78, RR 20, SpO2 95% on room air. Physical exam in ED noted mild scleral icterus, no focal tenderness, lungs clear, heart regular, abdomen soft, no CVA tenderness. No obvious source of infection identified on exam or bedside US. He was admitted for further work‑up of FUO (fever of unknown origin) and possible sepsis.', 1, '2025-11-19 06:07:14.624892+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (19, 19, 'hpi_short', '58yo M with h/o IVDU (heroin, 3‑yr), chronic HCV (RNA+, untreated), COPD s/p tobacco, and prior MRSA SSTI p/w cellulitis now presents w/ 3‑day hx of low‑grade fevers (T max 38.9°C), rigors, and progressive erythema/edema of left forearm. Pt reports injecting heroin into left antecubital fossa 2 days ago using a reused needle; noted “hard spot” that became painful, red, and warm. Denies SOB, chest pain, N/V/D. Pt says he slept on couch, used “street” antibiotics (amoxicillin) with no relief. Yesterday he went to urgent care, got PO clindamycin 300 mg q8h, but swelling worsened, now with fluctuance and foul odor. Pt was EMS‑ed to ED. In ED vitals: T 38.7°C, HR 112, BP 118/72, RR 22, SpO2 96% RA. Labs: WBC 15.2, ANC 12.1, CRP 12.4 mg/dL. Blood cultures drawn. Bedside US shows 3 cm fluid collection. Started IV vancomycin 1 g q12h and cefepime 2 g q8h. Pt reports last heroin use 2 days ago, last methadone dose 5 days ago, denies alcohol binge. Pt is currently homeless, lives in shelter, no stable housing. He is aware of HCV but never treated. No recent travel. No known sick contacts.', 1, '2025-11-19 06:07:14.625312+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (20, 20, 'hpi_short', '58yo M with h/o COPD (GOLD II), HTN, CKD stage 3 (baseline Cr 1.4), anemia of chronic disease, and recent hospitalization for UTI now p/w progressive malaise, anorexia, and failure to thrive w/o fever. Pt reports 6‑week history of generalized fatigue, low energy, and 8‑lb weight loss despite unchanged diet. Denies chills, night sweats, cough, dyspnea at rest, chest pain, GI bleed, or dysuria. He notes occasional light‑headedness when standing, but no syncope. He was discharged from outside hospital 2 days ago after 5‑day course of IV ceftriaxone for E. coli UTI; cultures were negative on discharge, but he feels “still not getting better.” Pt states he has been sleeping 10‑12 h/night but still feels “exhausted.” No recent travel, no sick contacts. He lives alone, uses a walker for ambulation due to COPD dyspnea on exertion. He stopped his home inhalers (tiotropium) a week ago because he thought they made him sleepy. He continues metoprolol 50 mg daily, lisinopril 20 mg daily, and ferrous sulfate 325 mg PO BID. He denies alcohol, tobacco (quit 5 yr ago), or illicit drug use.', 1, '2025-11-19 06:07:14.625754+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (21, 21, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2% 03/01/3085), PAD s/p fem‑pop bypass 3079, CKD‑3, HTN, and recent cellulitis of R lower extremity p/w worsening pain, edema, and black necrotic tip of 2nd toe. Patient reports that 5 days ago he noticed a small blister on the dorsal aspect of the right 2nd toe after a minor scrape while gardening. He cleaned it with over‑the‑counter antiseptic, but over the next 48 h the area became erythematous, swollen, and increasingly painful to light touch. Yesterday he awoke with a “burning” sensation radiating up the forefoot, and the distal tip turned dark, now black, with foul odor. He denies fevers, chills, or systemic symptoms, but reports mild dyspnea on exertion (climbing two flights of stairs) and occasional orthopnea. He has been non‑compliant with his insulin regimen for the past week due to “forgetting” and has been taking only metformin 500 mg BID. He has been smoking 1 pack/day for 35 y, drinks socially (2‑3 beers/week). He presented to an urgent care on 03/16/3085 where a wound culture was taken (pending) and he was given oral clindamycin 300 mg QID and instructed to follow‑up. Pain persisted, and on 03/18/3085 the toe became black; EMS was called and he was brought to the ED. In the ED he was tachycardic (HR 112), BP 138/78, RR 22, SpO2 96% RA, T 38.2 °C. Labs showed leukocytosis (WBC 14.8 K), CRP 12 mg/dL, and a serum lactate 2.4 mmol/L. Bedside Doppler demonstrated absent pulses distal to the mid‑tarsal region. Vascular surgery was consulted and recommended admission for possible wet gangrene and urgent debridement. Patient is now on IV cefazolin 1 g q8h, insulin drip, and analgesia.', 1, '2025-11-19 06:07:14.626182+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (22, 22, 'hpi_short', '41yo M with h/o T2DM (A1c 9.8%), PAD, HTN, CKD‑3, and recent plantar ulcer p/w worsening pain, edema, foul odor, and black necrotic tissue of the right forefoot. Patient reports that the ulcer began ~3 weeks ago after stepping on a nail at work; he initially cleaned it at home, applied OTC ointment, and continued to bear weight. Over the past 5 days pain escalated to 9/10, foot became dusky, then black, with increasing swelling up the leg. He noted foul smelling drainage and low‑grade fevers (T 38.2 °C) at home, but did not seek care until today when EMS was called by his wife after he could not ambulate. EMS noted HR 112, BP 138/84, RR 22, SpO2 96% RA, and a warm, erythematous right foot with crepitus. He was given 1 L NS en route, placed on high‑flow O₂, and transported to ED. In the ED he received IV cefazolin 1 g q8h, labs drawn, and a bedside Doppler showed absent pulses distal to the mid‑tarsal region. Orthopedic surgery was consulted and recommended transfer for possible emergent debridement. He denies chest pain, SOB, dysuria, or recent travel. No known sick contacts.', 1, '2025-11-19 06:07:14.62665+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (23, 23, 'hpi_short', '58yo M with uncontrolled HIV/AIDS (CD4 78, VL 215,000), chronic HCV (treated), CKD‑3 (eGFR 42), HTN, and remote PCP‑nonadherent, presents from outside ED with 5‑day history of low‑grade fevers (Tmax 101.4°F), worsening dyspnea on exertion, and a productive cough now yellow‑green sputum. Pt reports “feeling like I’m drowning” after climbing two flights of stairs at work (warehouse loading dock). Denies chest pain, palpitations, PND, orthopnea. Reports recent weight loss ~8 lb over 2 weeks, night sweats, and diffuse myalgias. He was admitted to County Hospital 3 days ago for presumed PCP pneumonia; received ceftriaxone 2 g q24h and azithro 500 mg PO x5, but symptoms progressed after discharge. He also notes intermittent diarrhea and abdominal cramping, no blood. No recent travel, no known TB exposure. Admits occasional IV heroin use (last use 2 weeks ago) and daily tobacco (1 ppd) and binge alcohol (≈6 drinks/week).', 1, '2025-11-19 06:07:14.62747+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (24, 24, 'hpi_short', '58yo F w/ h/o HTN, T2DM (A1c 8.6% 02/3092), CKD stage 3, and remote cholecystectomy p/w progressive dyspnea, productive cough (yellow‑green sputum), subjective fevers, chills, and pleuritic chest pain for the past 4 days. Pt reports onset after a weekend trip to the coastal resort where she attended a family reunion; denies recent travel outside the region. Initially self‑treated with OTC acetaminophen and ibuprofen, thought it was a “cold”. On day 2 she developed low‑grade fever (max 38.3°C) and cough became more productive; visited urgent care on 09/13/3092 where a rapid strep test was negative, chest X‑ray read as “possible infiltrate” and she was prescribed azithromycin 500 mg PO daily x3 days and albuterol inhaler PRN. She completed the azithromycin course but symptoms worsened, with increased sputum volume, dyspnea at rest, and new onset fatigue. On 09/16/3092 she presented to the ED of the regional medical center. Vitals in ED: T 38.9°C, HR 112, RR 24, BP 138/78, SpO2 91% on RA. Labs showed WBC 16.2 K with left shift, lactate 2.1 mmol/L, procalcitonin 1.8 ng/mL. CXR demonstrated a right lower lobe consolidation with air bronchograms. She received 2 L NS, ceftriaxone 1 g IV q24h, and azithromycin 500 mg IV q24h. After 6 h she remained tachypneic, required 2 L NC to maintain SpO2 > 94%, and was transferred to our facility for continued management and possible ICU evaluation. On arrival to our floor she is alert, oriented x3, appears mildly uncomfortable, and reports “feeling like I can’t catch my breath”.', 1, '2025-11-19 06:07:14.627894+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (25, 25, 'hpi_short', '58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), chronic low back pain s/p L4‑L5 discectomy 2015, and recent admission for UTI (04/28/3078) p/w dysuria and fever now presents with acute exacerbation of lumbar pain. Patient reports sharp, constant 7/10 pain radiating to left buttock, worsened by standing >10 min and flexion, partially relieved by lying supine and ibuprofen. He notes new numbness over the dorsum of the left foot and occasional tingling in the big toe since yesterday. Denies bowel/bladder incontinence, saddle anesthesia, or recent trauma. He was discharged from outside hospital on 04/30 after 3 days IV ceftriaxone, completed oral ciprofloxacin 5 days ago, and was told to follow up with PCP. Since discharge he has been ambulating more, but pain escalated after a weekend gardening session where he lifted a 30‑lb pot. He tried OTC naproxen 500 mg BID with minimal relief, and used a heating pad intermittently. No recent weight loss, fevers, or night sweats. He reports occasional alcohol (1‑2 beers/week) and denies tobacco or illicit drug use. He is concerned about possible disc herniation recurrence and wants imaging.', 1, '2025-11-19 06:07:14.628311+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (26, 26, 'hpi_short', '35yo M with h/o recurrent UTIs (last 2 yr), neurogenic bladder secondary to sacral chordoma resection (2019), and intermittent self‑catheterization presents to ED w/ 2‑day history of worsening dysuria, cloudy urine, suprapubic tenderness, and low‑grade fevers up to 38.6°C. Pt reports N/V x1 episode yesterday, no flank pain, no gross hematuria. He notes increased catheterization frequency to q4h over past 48 h because of decreased urine output. Denies recent sexual activity, new sexual partners, or recent travel. He was seen 3 days ago at an urgent care where a dipstick showed +leukocyte esterase and +nitrites; he was prescribed TMP‑SMX 800/160 mg BID but stopped after 1 dose due to nausea. Pt reports compliance with clean intermittent catheterization (CIC) technique taught by rehab, but admits occasional missed hand‑washing. No known drug allergies.

Outside Hospital Course: Transferred from community ED after CT abdomen/pelvis showed no obstruction, but noted mild bladder wall thickening. Received 1 L NS, acetaminophen 650 mg PO, and a dose of IV ceftriaxone 1 g. Blood cultures drawn, urine sent for culture and sensitivity.', 1, '2025-11-19 06:07:14.628864+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (27, 27, 'hpi_short', '58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2 × 10⁶ copies/mL), chronic HCV (genotype 1a, untreated), prior PCP pneumonia (2 y ago), and remote TB (treated 1998) presents from the ED with 10‑day history of intermittent fevers up to 39.4 °C, night sweats soaking sheets, worsening dyspnea on exertion, and a new diffuse, crampy abdominal pain radiating to the RLQ. He reports a 12‑kg weight loss over the past month despite a reported appetite of “fair”. He was seen 3 days ago at an outside urgent care where a rapid HIV test was positive (known baseline) and a chest X‑ray showed bilateral interstitial infiltrates; he was given azithromycin 500 mg PO daily and discharged with instructions to follow up. Since then, symptoms have progressed, now with cough productive of scant yellow sputum, and occasional non‑bloody diarrhea. He denies chest pain, orthopnea, PND, dysuria, or focal neurologic deficits. He reports poor adherence to his ART regimen (tenofovir/emtricitabine/efavirenz) for the past 6 weeks due to nausea and “feeling too sick to take meds”. He also admits to occasional IV heroin use (last use 4 days ago) and daily smoking (1 pack). No recent travel, no known TB contacts.', 1, '2025-11-19 06:07:14.629354+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (28, 28, 'hpi_short', '58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), COPD (GOLD B), and remote colon cancer s/p resection (2018) p/w 8‑wk history of worsening malaise, anorexia, and failure to thrive. Denies fever, chills, night sweats, cough, dyspnea at rest, chest pain, abdominal pain, N/V/D, dysuria or change in bowel habits. He reports a 12‑lb (5.4 kg) unintentional weight loss despite unchanged diet, increased fatigue limiting ADLs (needs assistance to get out of bed). He notes occasional light‑headedness when standing, but no syncope. Review of recent labs from outside hospital (09/15/3060) showed mild normocytic anemia (Hgb 11.2) and hypoalbuminemia (3.2 g/dL). He was seen at an urgent care 2 weeks ago, given a short course of azithromycin for presumed bronchitis – no improvement. No recent travel, sick contacts, or known exposures. He lives alone in an assisted‑living apartment, receives meals on wheels. He reports occasional alcohol (1‑2 beers/week) and denies tobacco or illicit drug use. He has not been to the gym in months due to fatigue. He is concerned about “just getting older” but wants evaluation for possible underlying cause (malignancy vs. chronic disease progression).', 1, '2025-11-19 06:07:14.6298+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (29, 29, 'hpi_short', '27yo M with h/o mild intermittent asthma (SABA PRN), recent travel to Luna City for a tech conference, now p/w 3‑day history of non‑localizing fever up to 102.4°F, chills, diffuse myalgias, and generalized fatigue. He reports that the fever started abruptly on 12/01/3092 while he was still in transit; he denied any cough, SOB, chest pain, dysuria, GI upset, or rash. He took ibuprofen 400 mg PO q6h with minimal relief. He also noted a mild headache and occasional light‑headedness when standing. No known sick contacts; airport exposure noted. He presented to the ED after a telehealth visit where a rapid COVID‑19 antigen test was negative. In the ED vitals: T 101.9°F, HR 112, BP 118/74, RR 20, SpO2 98% RA. Labs showed mild leukocytosis (WBC 11.2 K) with neutrophil predominance, CRP 6.8 mg/dL. Blood cultures drawn, chest X‑ray unremarkable. He was given 1 L NS, acetaminophen 650 mg PO, and observed. He remains febrile on the floor (T 101.2°F) and is being admitted for further work‑up of FUO (fever of unknown origin).', 1, '2025-11-19 06:07:14.630279+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (30, 30, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (baseline Cr 1.6), recent prostatitis p/w N/V/D and R flank pain now presents with 2‑day history of worsening dysuria, urgency, suprapubic pressure and chills. He reports dark amber urine, occasional gross hematuria, and a low‑grade fever up to 101.4°F at home. Yesterday he went to urgent care where a UA showed +leukocyte esterase, nitrites positive, WBC 45/hpf; he was given a single dose of IM ceftriaxone and instructed to start oral ciprofloxacin 500 mg BID, but he stopped after one dose because of nausea and vomiting. He now feels “more sick,” with fatigue, decreased oral intake, and mild right flank tenderness. Denies recent catheterization, recent sexual activity, or new sexual partners. No known drug allergies. He was admitted from home after EMS called due to fever 102°F and hypotension 98/58 mmHg in the field; EMS gave 1 L NS en route. He is currently on 2 L O₂ via nasal cannula, SpO₂ 96% on room air prior to O₂. He reports prior UTIs in 2025 and 2028 treated with TMP‑SMX, and a history of recurrent prostatitis treated with fluoroquinolones. He lives alone, works as a freelance IT consultant, occasional alcohol (2‑3 beers/week), never smoker.', 1, '2025-11-19 06:07:14.63075+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (31, 31, 'hpi_short', '58yo M with h/o HIV (well controlled, CD4 540, VL <20), chronic hepatitis C (treated, SVR), prior chlamydia (treated 2022), now p/w 3‑day history of copious yellow‑green urethral discharge, burning dysuria, suprapubic tenderness, and mild fever (~38.2°C). Patient reports increased sexual activity over past month with multiple new male partners; reports inconsistent condom use. Denies penile lesions, testicular swelling, or hematuria. He noticed the discharge after a night of unprotected oral sex and anal intercourse 2 days ago. He tried OTC phenazopyridine with minimal relief. No recent travel. He presented to urgent care on 12/13 where a rapid NAAT for gonorrhea/chlamydia was pending; he was given a single dose of ceftriaxone 250 mg IM and instructed to follow up. Symptoms worsened, prompting ED visit and subsequent admission for IV antibiotics and evaluation for possible disseminated gonococcal infection (DGI). He also reports mild arthralgias in knees and wrists but no rash. No nausea, vomiting, or diarrhea. He is adherent to HAART (bictegravir/emtricitabine/tenofovir alafenamide) and HCV regimen (sofosbuvir/velpatasvir) with good tolerance.', 1, '2025-11-19 06:07:14.63118+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (32, 32, 'hpi_short', '39yo M with uncontrolled HIV/AIDS (CD4 45, VL 1.2 ×10⁶ copies/mL) s/p multiple ART failures, non‑adherent to efavirenz/tenofovir/emtricitabine for past 6 mo, now presents w/ 2‑wk hx of low‑grade fevers (T 38‑38.5 °C), worsening dyspnea on exertion, dry cough, and 15‑lb unintentional weight loss. He reports new oral white plaques for 5 days, dysphagia to solids, and night sweats. He was discharged from outside hospital 4 days ago after a 5‑day course of oral TMP‑SMX for presumed PCP pneumonia; symptoms improved briefly then recurred. He denies chest pain, hemoptysis, or recent travel. He reports occasional IV drug use (last use 3 mo ago) and inconsistent condom use. He lives alone, works as a freelance IT consultant, and has no reliable transportation. He reports missing his ART doses because of “feeling sick” and “not wanting to take more pills.”', 1, '2025-11-19 06:07:14.631602+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (77, 77, 'hpi_short', '58yo M with h/o HTN, DM2 (A1c 8.7%), CKD stage 3, recent laparoscopic cholecystectomy (post‑op day 7) p/w erythema, warmth, serosanguinous drainage from RUQ port site, low‑grade fever 38.2°C, chills, N/V x1 day. Pt reports incision was fine first 3 days, then started to ooze thin yellow fluid on POD 5, now thicker purulent material with foul odor. Denies SOB, chest pain, dysuria. Pt took ibuprofen at home, no antibiotics. Presented to ED after wife noted increasing swelling and foul smell. In ED vitals: T 38.2, HR 112, BP 138/78, RR 20, SpO2 96% RA. Labs drawn, CT abdomen/pelvis showed fluid collection superficial to fascia, no intra‑abdominal abscess. Started on IV cefazolin 1 g q8h, wound cultures obtained. Pt now on telemetry for tachyarrhythmia risk due to HTN/DM.', 1, '2025-11-19 06:07:14.653921+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (33, 33, 'hpi_short', '58yo F with h/o T2DM (A1c 9.4% 03/3085), PAD (bilateral fem‑pop stents 3079), CKD‑3 (eGFR 48), and recent cellulitis of left lower extremity presents w/ progressive left foot pain and swelling that began 3 days ago after a minor “scrape” while gardening. She reports the area became increasingly painful, throbbing, and now has black, necrotic tips on the 2nd–4th toes with a foul, “rotting” odor. She denies any trauma beyond the scrape, denies fevers, chills, or rigors. She notes that the pain is constant, 8/10 at rest, worsens with elevation, and is partially relieved by over‑the‑counter ibuprofen which she stopped after 2 doses due to GI upset. She was seen at an urgent care 2 days ago; they prescribed oral clindamycin 300 mg q6h and instructed her to keep the foot elevated. She took 2 doses then stopped because of nausea. Over the past 24 h the discoloration spread proximally to the mid‑foot, the skin is now mottled, and she reports new tingling and numbness distal to the lesion. She has a history of poor glycemic control and admits to occasional non‑adherence to insulin (last dose 18 h ago). She reports a prior episode of “foot ulcer” 2 years ago that healed after debridement. No recent travel, no known sick contacts. She works part‑time as a librarian, lives with husband, no tobacco, occasional wine (1‑2 glasses/week), denies illicit drugs.', 1, '2025-11-19 06:07:14.632035+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (34, 34, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 48), recent urethral stricture dilation p/w dysuria, urgency, N/V/D and low‑grade fever. Patient reports 3‑day history of burning on urination, suprapubic pressure, and chills that began after a Foley was removed on 09/26/3066 following a brief admission for left ureteral stone. He notes cloudy urine with occasional gross hematuria, and now a Tmax of 38.9 °C (102 °F) measured at home. Denies flank pain, but reports mild left flank tenderness on palpation. No recent sexual activity, no new sexual partners. He took OTC acetaminophen with minimal relief. No prior UTIs documented, but has a history of recurrent prostatitis treated with ciprofloxacin 2 years ago. He was discharged from the outside hospital on 09/27/3066 with a 5‑day course of TMP‑SMX; he stopped meds after 2 days because of nausea. He now presents to our ED for worsening symptoms.', 1, '2025-11-19 06:07:14.632705+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (35, 35, 'hpi_short', 'Evelyn Hartwell is a 33 y/o F with h/o mild intermittent asthma (last exacerbation 2019), obesity (BMI 34), and GERD who presents with acute worsening dyspnea over the past 48 hrs leading to respiratory failure requiring non‑invasive ventilation. She reports that 2 days ago she began feeling “tight in the chest” after a long shift as a night‑shift security guard; she noted increased work of breathing, tachypnea to 28‑30 bpm, and inability to speak full sentences. Denies fever, chills, cough, sputum production, chest pain, palpitations, or recent sick contacts. She did not take her albuterol inhaler because she thought it was “just stress”. Yesterday she went to an urgent care where she was given a trial of nebulized albuterol and oral steroids; O2 sat remained 84 % on room air, so she was placed on 2 L NC and transferred by EMS to our facility for further management of acute hypoxemic respiratory failure. EMS report notes initial RR 34, HR 112, BP 138/78, SpO2 78 % on RA, improved to 90 % on 15 L non‑rebreather. No fever documented. She reports occasional nocturnal GERD symptoms, no recent travel, no known COVID‑19 exposure. She is a never smoker, drinks socially (1‑2 drinks/week), no illicit drug use.', 1, '2025-11-19 06:07:14.633752+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (36, 36, 'hpi_short', '38yo M with h/o HTN, CKD‑3, chronic low back pain (CLBP) s/p L4‑L5 microdiscectomy 4 mo ago, now p/w worsening axial low back pain radiating to left buttock and posterior thigh, associated with numbness L5 distribution, intermittent LE weakness, low‑grade fevers (T max 38.2 °C) and N/V x2 d. He reports that pain began 2 days ago after lifting a 30 lb box at work (warehouse). Initially “sharp” and 7/10, now constant 9/10, worsened by standing >10 min, partially relieved by lying supine with pillows. He took ibuprofen 600 mg q6h PRN with minimal relief, and his home gabapentin 300 mg tid. Yesterday he presented to urgent care where a lumbar spine MRI was obtained showing new L3‑L4 disc protrusion with mild central canal stenosis and edema of the paraspinal muscles. Labs drawn there showed WBC 13.2 K/µL, CRP 12 mg/L. He was given IV ketorolac and discharged with a prescription for oral oxycodone 5 mg q4h PRN and instructions to follow up with orthopedics. Over the night pain escalated, he became febrile, and developed new urinary hesitancy. EMS brought him to the ED where vitals were HR 112, BP 138/84, RR 22, SpO2 96% RA, Temp 38.4 °C. He was placed on telemetry, given IV morphine 4 mg, and a CT lumbar spine was ordered (no acute fracture). He was admitted for pain control, evaluation of possible postoperative infection, and further work‑up of new neurologic deficits.', 1, '2025-11-19 06:07:14.634166+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (37, 37, 'hpi_short', '58yo M with h/o HIV (CD4 420, VL undetectable), chronic HCV (treated), prior syphilis (treated 2018), and recent unprotected intercourse p/w painful penile ulcer, dysuria, and low‑grade fever. Pt reports that 4 days ago he noticed a 1 cm shallow ulcer on the distal glans, erythematous base, serous discharge. Denies trauma. Yesterday developed dysuria, urinary frequency, and chills. Pt was seen at urgent care 2 days ago, given empiric doxy 100 mg BID for presumed urethritis, but symptoms worsened. Pt reports multiple partners over past month, including a new male partner who was diagnosed with primary syphilis 1 week ago. Pt admits occasional methamphetamine use, last use 3 days ago, and drinks socially (≈4 drinks/week). No known drug allergies. No prior episodes of similar lesions.', 1, '2025-11-19 06:07:14.634642+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (38, 38, 'hpi_short', '58yo M with h/o HFrEF (EF 35% on echo 06/3069), CAD s/p PCI 02/3068, HTN, CKD stage 3, DM2 (A1c 8.7%), and recent admission for decompensated HF 12/02/3069 now presents w/ progressive SOB x5 days, NYHA class III→IV, PND 2×/night, orthopnea requiring 3 pillows, +2 LE edema up to mid‑calf, weight gain ~7 lb despite diuretic compliance. Pt reports “feeling like my heart is pounding” and occasional chest pressure but denies acute chest pain. He was discharged 12/02 after IV furosemide 40 mg q8h, transitioned to oral bumetanide 2 mg daily, metoprolol succinate 100 mg daily, lisinopril 20 mg daily, and spironolactone 25 mg daily. Since discharge, he has been taking meds as prescribed but noted that urine output has decreased and his ankles are more swollen. He also reports a low‑grade fever 100.2 °F yesterday, mild cough, no sputum. No recent travel, no sick contacts. He denies alcohol binge, tobacco (quit 2010), illicit drugs.', 1, '2025-11-19 06:07:14.635068+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (39, 39, 'hpi_short', '29yo M with h/o recurrent prostatitis (most recent episode 3 wks ago, treated with IV levofloxacin → oral ciprofloxacin) now p/w worsening dysuria, urinary frequency, urgency, low back pain, chills, N/V. Symptoms began 48 h ago after completing a 7‑day course of ciprofloxacin prescribed by urgent care; he reports “nothing helped,” now has temperature spikes to 38.9 °C, HR 112, feels “very shaky.” He denies flank tenderness on exam but notes dull ache in lower back radiating to right groin. He was seen at the urgent care on 01/03/3074, given a repeat ciprofloxacin 500 mg BID, but returned to ED when fever persisted and urine became cloudy. He reports prior admission 12/20/3073 for acute bacterial prostatitis, received 48 h IV levofloxacin then discharged on oral levofloxacin 750 mg daily for 10 days; completed that course 5 days ago. No recent catheterization, no recent travel, no sick contacts. Denies alcohol >2 drinks/week, no tobacco, no illicit drugs.', 1, '2025-11-19 06:07:14.635473+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (40, 40, 'hpi_short', '34yo F with h/o morbid obesity (BMI 42), DM2 (A1c 8.7%), HTN, and recent laparoscopic cholecystectomy p/w erythema, serosanguinous drainage, low‑grade fever, and increasing pain over the RUQ incision site. Patient was discharged from outside hospital 3 days ago after uncomplicated cholecystectomy; received peri‑op cefazolin 1 g q8h and was told to follow up in 2 weeks. On POD #5 she noted mild erythema around the port site, which she attributed to “minor irritation.” Over the past 24 h the erythema expanded to ~6 cm, now warm, tender, with thick yellow‑green purulent ooze. She reports subjective chills, temperature at home 38.2 °C, and pain 7/10, worse with movement. Denies nausea, vomiting, dysuria, or new abdominal pain beyond the incision. No recent travel, no sick contacts. She presented to the ED at 19:45, vitals: T 38.4 °C, HR 112, BP 138/84, RR 20, SpO2 97% RA. Labs drawn, wound swab obtained. Started on IV cefazolin 1 g q8h in ED. She was admitted for IV antibiotics, wound care, and possible imaging to rule out deeper infection.', 1, '2025-11-19 06:07:14.635908+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (41, 41, 'hpi_short', '58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2M), chronic HCV (treated), CKD stage 3, and recent PCP pneumonia p/w fever, cough, SOB, and new pruritic maculopapular rash. Pt reports 2 wk of low‑grade fevers (T max 38.9°C) and worsening shortness of breath on exertion. Yesterday he noted a non‑blanching rash starting on trunk then spreading to extremities, associated with itching and occasional chills. He was seen at an outside urgent care 5 days ago, given oral azithro 500 mg daily x3d for presumed atypical pneumonia; symptoms persisted. Pt admits missing several doses of his ART (BIC/FTC/TAF) over past month due to nausea and vomiting. He also reports 2 episodes of non‑bloody, non‑mucoid diarrhea last week. No recent travel, no known TB exposure, no sick contacts. He lives alone, works part‑time as a freelance IT consultant, and reports occasional IV drug use (last use 3 mo ago). He denies alcohol >2 drinks/week, tobacco never. He presents to ED after EMS transport; vitals on arrival: T 38.6 °C, HR 112, RR 24, BP 118/72, SpO2 92% on RA. Labs drawn, CXR performed. Pt appears ill, diaphoretic, with diffuse rash.', 1, '2025-11-19 06:07:14.636795+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (42, 42, 'hpi_short', '58yo M with h/o T2DM (A1c 8.7%), HTN, CKD stage 3 (eGFR 48), and recent URI p/w 5‑day history of productive cough, pleuritic chest pain, fevers up to 102.4°F, and progressive SOB. Symptoms began 06/24 after returning from a weekend trip to the coastal resort of New Avalon where he attended a family reunion. Denies recent travel outside the region, but reports exposure to several grandchildren who had “cold” symptoms. He initially self‑treated with OTC acetaminophen and azithromycin prescribed by his urgent‑care clinic on 06/25; however, cough worsened, sputum turned rust‑colored, and he noted new night sweats. On 06/27 he presented to the outside ED at Harborview Medical Center where CXR showed right lower lobe infiltrate, labs revealed WBC 14.2 with left shift, procalcitonin 1.8 ng/mL. He received 1 L NS, ceftriaxone 1 g q24h, and was placed on supplemental O₂ 2 L NC. He was discharged home on 06/28 with oral levofloxacin 750 mg daily for 5 days, instructed to follow‑up if no improvement. Over the night he became increasingly dyspneic, SpO₂ dropped to 88% on room air, and he called EMS. EMS noted HR 112, RR 28, BP 138/84, O₂ 92% on 4 L NC. He was transported to our facility, where he was placed on 6 L NC with SpO₂ 96% and transferred to the floor.', 1, '2025-11-19 06:07:14.637213+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (43, 43, 'hpi_short', '58yo M with h/o HIV/AIDS (CD4 78, VL 1.2M), chronic HCV (treated), CKD stage 3, HTN, and recent PCP pneumonia p/w cough, SOB, night sweats, now presents w/ 5‑day hx of high‑grade fevers (T up to 39.8°C), worsening dyspnea on exertion, diffuse myalgias, and marked fatigue. Pt reports that 2 weeks ago he was discharged from outside hospital after 7‑day course of IV cefepime for PCP (TMP‑SMX stopped early due to rash). Since discharge he has been non‑adherent to ART (Biktarvy missed >50% doses) and to TMP‑SMX prophylaxis. He notes new onset of oral thrush, dysphagia to solids, and occasional non‑bloody diarrhea. Denies chest pain, palpitations, leg swelling, or recent travel. He reports drinking 2–3 beers daily, occasional marijuana, no tobacco. He lives in a group home, works part‑time as a janitor, and has multiple sexual partners; last condom‑protected encounter 3 weeks ago. He was seen in the ED 3 days ago where labs showed leukocytosis (WBC 14.2), Cr 1.8, and CXR with diffuse interstitial infiltrates; he was given IV ceftriaxone and discharged with oral levofloxacin. Symptoms have progressed despite antibiotics. He now feels “like he can’t get out of bed,” with orthostatic dizziness. No recent surgeries.', 1, '2025-11-19 06:07:14.63762+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (44, 44, 'hpi_short', '45yo M with h/o IVDU (heroin, last use 2 d ago), chronic HCV (RNA+), COPD (GOLD II), and recent right thigh cellulitis/abscess p/w fever, chills, dyspnea, and progressive swelling. Pt reports that 5 d ago he noticed a painful, erythematous nodule on the anterolateral right thigh after injecting heroin into the area; he self‑drained a small amount of purulent fluid at home, applied over‑the‑counter ointment, and continued using the same site. Over the past 48 h he developed high‑grade fevers (T up to 39.8 °C), rigors, SOB on exertion, and the thigh became increasingly tender, fluctuant, and now has a foul‑smelling drainage. He denies chest pain, palpitations, cough, or recent travel. He reports occasional alcohol use (2‑3 beers/week) and denies tobacco (quit 3 y ago). He was seen at an urgent care 2 d ago, received a single IM dose of ceftriaxone and was discharged with oral clindamycin; symptoms have not improved. He presents to the ED for further evaluation.

ED Course (summarized):
Vitals on arrival: T 39.4 °C, HR 112, BP 118/72, RR 22, SpO2 94% RA. Labs showed WBC 18.2 K with left shift, CRP 12 mg/dL, lactic acid 2.8 mmol/L. Blood cultures drawn x2. CT thigh with contrast demonstrated a 5 cm rim‑enhancing fluid collection within the subcutaneous tissue, no deep fascial involvement. Empiric IV vancomycin and cefepime started. Pt was admitted for IV antibiotics, possible incision & drainage, and evaluation for endocarditis given IVDU history.', 1, '2025-11-19 06:07:14.638055+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (45, 45, 'hpi_short', '36yo M with h/o MVC 5d ago s/p ORIF of right femur (plate & screws) now p/w increasing erythema, warmth, and serosanguinous drainage from the incision site. Pt reports low‑grade fevers up to 38.3°C since POD #3, chills intermittent, and increasing pain despite oral acetaminophen 650 mg q6h. He was discharged from community hospital on POD #2 with a 5‑day course of cephalexin 500 mg PO q6h; he completed 3 doses then stopped when drainage worsened. No known drug allergies. No prior wound complications. He denies SOB, chest pain, dysuria, or GI symptoms. He notes that the dressing was changed at home on POD #4 and now appears saturated with yellow‑green fluid. He reports mild nausea but no vomiting. He works as a freelance carpenter, lives alone, and has limited support; he came to ED because pain is now 8/10 at rest and he feels “feverish”.', 1, '2025-11-19 06:07:14.638458+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (46, 46, 'hpi_short', '58yo F with h/o HFrEF (EF 32% on echo 03/3061), CAD s/p PCI to RCA 02/3060, HTN, CKD stage 3, and recent admission for decompensated HF 03/28/3061 now presents with 5‑day history of worsening SOB, NYHA class III→IV, dyspnea on minimal ambulation, 2‑L of PND nightly, and 2+ pitting edema to mid‑calves. She reports that she was discharged 2 weeks ago after a 4‑day stay for acute on chronic HF; at discharge she was on furosemide 40 mg PO BID, carvedilol 12.5 mg BID, lisinopril 20 mg daily, and spironolactone 25 mg daily. Since discharge she has been non‑adherent to diuretics due to “feeling light‑headed” and has been drinking 2‑3 glasses of wine nightly. She denies chest pain, palpitations, fever, cough, or recent travel. She notes a 4‑lb weight gain despite restricting salt, and her urine output has decreased to <1 L/24 h. She was seen in the ED 04/19/3061 where vitals showed HR 112, BP 138/78, RR 22, SpO2 92% on RA, and a bedside echo suggested EF 30% with moderate mitral regurg. She was given IV furosemide 40 mg with modest diuresis and then transferred to our floor for further management.', 1, '2025-11-19 06:07:14.638908+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (47, 47, 'hpi_short', '35yo M with h/o T2DM (A1c 8.6%), CKD stage 3 (eGFR 48), recent discharge from outside hospital (02/25/3050) after treatment for uncomplicated cystitis now p/w persistent low‑grade fever (T 38.2‑38.7°C), chills, fatigue, mild frontal headache, no localized pain. Denies cough, dyspnea, chest pain, SOB, N/V/D, dysuria, flank pain, rash. Reports that after discharge he was on oral ciprofloxacin 500 mg BID, completed 5 days, but fever persisted and he felt “worse” on day 3 post‑discharge. He went to urgent care on 02/27, got a CBC (WBC 12.4 K) and was told to go to ED for further eval. In ED vitals: T 38.5 °C, HR 112, BP 128/78, RR 20, SpO2 98% RA. Labs showed leukocytosis with left shift, mild AKI (Cr 1.6 from baseline 1.3). Blood cultures drawn, urinalysis negative for nitrites/leukocyte esterase. CXR read as “clear lungs, no infiltrates.” He was given 1 L NS, acetaminophen 650 mg PO, and started on IV ceftriaxone 1 g q24h and vancomycin 1 g q12h pending cultures. He was admitted for continued work‑up of FUO (fever of unknown origin) and possible sepsis.', 1, '2025-11-19 06:07:14.639718+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (48, 48, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 45), BPH, recent prostatitis p/w N/V/D and R flank pain now presents with 3‑day history of worsening dysuria, cloudy urine, suprapubic pressure and chills. Pt reports that 2 weeks ago he was discharged from an outside facility after a 4‑day stay for an uncomplicated ureteral stone that required ureteroscopy and stent placement. Post‑op course was uneventful, stent was removed 5 days ago, but he notes that urine has been “smelly” and “burning” since then. Yesterday he developed fever to 38.9°C (102°F) at home, associated with rigors and mild nausea. He denies flank tenderness now, no gross hematuria, no recent sexual activity, no new meds. He has been taking his home metformin 500 mg BID, lisinopril 20 mg daily, and tamsulosin 0.4 mg nightly. He tried OTC phenazopyridine with minimal relief. He presents to the ED after his wife called EMS because of persistent fever and confusion (felt “foggy”). In the ED vitals: T 38.7°C, HR 112, BP 138/78, RR 22, SpO2 96% RA. Labs drawn, UA positive for leukocyte esterase, nitrites, WBC 45/hpf. Blood cultures obtained. He was started on IV ceftriaxone 1 g q24h and admitted for urosepsis work‑up.', 1, '2025-11-19 06:07:14.640169+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (49, 49, 'hpi_short', '58yo M with h/o ESRD on hemodialysis (AVF left arm), CKD‑5, HTN, DM2 (A1c 8.7%), CAD s/p PCI 3065, and recent admission for urosepsis now p/w erythema, warmth, and purulent drainage from his tunneled femoral dialysis catheter placed 3 weeks ago. Patient reports that 2 days ago he noticed increasing redness extending ~4 cm around the exit site, mild pain on movement, and a yellow‑green discharge that is foul smelling. He denies fevers, chills, or rigors but notes low‑grade temp at home (max 100.2°F). He has been dialyzing via the line daily; last session yesterday was uneventful. He tried to clean the site with sterile wipes, but drainage persisted and increased. He presented to the ED after his dialysis nurse noted the change and called EMS. In the ED he was afebrile, HR 102, BP 138/84, RR 20, SpO2 96% RA. Labs showed WBC 14.2 K with left shift, CRP 12 mg/dL. Blood cultures drawn from catheter and peripheral line grew MRSA (preliminary). He was started on vancomycin 1 g IV q12h and line lock with heparin. He was transferred to floor for line removal and further management.', 1, '2025-11-19 06:07:14.640582+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (50, 50, 'hpi_short', 'Samuel Whitaker is a 28‑year‑old male with uncontrolled HIV/AIDS (diagnosed 2005, last CD4 78 cells/µL, VL 1.2 × 10⁶ copies/mL) who presents with 10‑day history of low‑grade fevers (T max 38.9 °C), drenching night sweats, worsening dyspnea on exertion, dry cough, and a 7‑kg weight loss. He reports increasing fatigue, occasional pleuritic chest discomfort, and new onset mild headache. He admits to poor adherence to his antiretroviral regimen (efavirenz/tenofovir/emtricitabine) over the past 3 months and has not taken his TMP‑SMX prophylaxis during that time. He was evaluated at an outside urgent care 5 days ago, given a course of azithromycin for presumed “bronchitis,” but symptoms progressed. He was transferred to our ED by EMS after a syncopal episode at home; EMS noted O₂ sat 86 % on room air, HR 118, RR 28. In the ED he was placed on 2 L NC, started on high‑flow O₂, and a bronchoscopy with BAL was performed (pending). CXR showed diffuse bilateral interstitial infiltrates. He was given a dose of IV methylprednisolone 125 mg and TMP‑SMX 15 mg/kg q6h (IV) pending diagnosis. He denies chest pain radiating to arm, orthopnea, PND, leg swelling, dysuria, or recent travel. No known sick contacts. He lives in a group home for adults with HIV; reports occasional marijuana use, denies alcohol or other illicit drugs.', 1, '2025-11-19 06:07:14.641022+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (51, 51, 'hpi_short', '28yo M with h/o HFrEF (EF 32% on echo 03/3096), CAD s/p PCI to RCA 02/3095, HTN, CKD stage 3 (baseline Cr 1.4), and recent admission for decompensated HF 12/3095 p/w SOB, now presents to ED with 5‑day history of worsening dyspnea on exertion, 2‑night orthopnea, 1‑L PND, and 2+ pitting edema to mid‑calves. He reports that he “just can’t catch his breath” after climbing a single flight of stairs, and has been sleeping propped up on three pillows. Denies chest pain, palpitations, fever, cough, or recent viral prodrome. He missed his furosemide dose on day 3 of his prior discharge because he ran out of meds and was “too busy”. He has been drinking 2‑3 beers nightly, no tobacco, occasional marijuana. He tried over‑the‑counter diuretics (furosemide 20 mg PO) at home with minimal relief. No recent travel.', 1, '2025-11-19 06:07:14.641434+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (52, 52, 'hpi_short', '58yo M with uncontrolled HIV/AIDS (CD4 78, VL 215,000), chronic HCV (treated), COPD (GOLD III), and prior PCP pneumonia presents w/ 7‑day hx of worsening dyspnea, fever up to 102.4°F, night sweats, and a productive cough now yellow‑green sputum. Pt reports that 3 days ago he was seen at an outside urgent care where a CXR was read as “possible infiltrate” and he was given azithro 500 mg PO daily x3 days – no improvement. Since then he has had increasing SOB at rest, orthopnea, and a new pleuritic chest pain left lower chest. Denies chest pressure, palpitations, or leg swelling. Pt admits to missing several doses of his ART (Bictegravir/Emtricitabine/Tenofovir) over the past month due to “feeling too sick to swallow pills.” He also reports recent binge drinking (≈6 beers daily) and occasional crack cocaine use (last use 2 days ago). He lives alone in a low‑income housing complex, works part‑time as a handyman, and has limited social support. He was brought by EMS after a syncopal episode at home; EMS noted HR 112, RR 28, SpO2 86% on RA, BP 98/58. In the ED he received 2 L NS, O2 4 L NC (Sat 94%). Labs showed leukocytosis 15.2 K, lactate 2.1, creatinine 1.4 (baseline 1.0), and ABG with pH 7.32, pCO2 48, HCO3‑ 24. CXR: left lower lobe consolidation with right mid‑lung infiltrates. CT chest pending. Pt was placed on telemetry and admitted for severe community‑acquired pneumonia, possible sepsis, and HIV non‑adherence.', 1, '2025-11-19 06:07:14.641894+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (53, 53, 'hpi_short', '58yo F with h/o HTN, CKD stage 3 (baseline Cr 1.6), COPD (GOLD B), and remote colon CA s/p resection (2019) p/w 3‑mo history of worsening fatigue, anorexia, and 12‑lb unintentional weight loss. Denies fever, chills, night sweats, cough, dyspnea at rest, chest pain, abdominal pain, N/V/D, or change in bowel habits. She reports “just feeling like I’m getting older” and has been unable to finish a full meal for >4 weeks. Home BP meds (lisinopril 20 mg daily) and inhaler (tiotropium) taken as prescribed. Two weeks ago she was seen at an outside urgent care for mild dehydration; received 1 L NS and was told to increase oral fluids. Since then she has had intermittent dizziness on standing, but no syncope. No recent travel, sick contacts, or new meds. She was admitted from home after her daughter noted progressive decline and called EMS; vitals on arrival: T 36.8 °C, HR 96, RR 18, BP 118/72, SpO2 96% RA.', 1, '2025-11-19 06:07:14.642592+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (54, 54, 'hpi_short', '58yo M with h/o IVDU (heroin, 3‑yr), chronic HCV (RNA+, untreated), COPD (GOLD 2), and prior MSSA cellulitis p/w recurrent abscesses, now presents w/ 3‑day hx of worsening right forearm pain, erythema, and swelling after recent “shoot‑up” in that arm. Pt reports injecting “speedball” (heroin + cocaine) into the antecubital fossa 2 days ago, noted increasing pain, low‑grade fever (T max 38.6 °C) and chills. Yesterday he noticed purulent drainage from a small opening over the volar forearm. Denies SOB, chest pain, cough, N/V/D. Pt states he has been using a shared needle, no recent medical care, last seen PCP 6 mo ago. He tried OTC ibuprofen with minimal relief. In the ED he was febrile 38.9 °C, HR 112, BP 118/72, RR 22, SpO₂ 96% RA. Labs showed WBC 15.2 K with left shift, CRP 12 mg/dL. Blood cultures drawn, bedside US showed a 3 cm hypoechoic collection. He was given 1 L NS, IV vancomycin 1 g bolus, and ceftriaxone 2 g. He was admitted for IV antibiotics, possible incision & drainage, and ID evaluation.', 1, '2025-11-19 06:07:14.643005+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (55, 55, 'hpi_short', '58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2 × 10⁶ copies), chronic HCV (treated, SVR), CKD‑3b, and HTN presents from outside ED after 5‑day prodrome of low‑grade fevers, night sweats, non‑productive cough, and worsening dyspnea on exertion. Pt reports that 2 weeks ago he was seen at community clinic for “flu‑like” symptoms, given OTC benzonatate and ibuprofen, but symptoms progressed. He now notes new diffuse myalgias, anorexia, and a 6‑kg weight loss over the past month. He denies chest pain, palpitations, orthopnea, PND, or leg swelling. He reports occasional “buzzing” in his head and blurred vision for the past 3 days. He was brought by EMS after a syncopal episode at home; EMS noted HR 112, BP 94/58, RR 24, SpO₂ 88% on RA, and gave 2 L NS with modest improvement. In the ED, labs showed leukocytosis (WBC 14.2, neutrophil 84%), creatinine 2.1 mg/dL (baseline 1.8), lactate 3.1 mmol/L, and a CXR with diffuse interstitial infiltrates. Blood cultures drawn, started on cefepime, azithro, and IV fluids. Pt was placed on HFNC 30 L/min, FiO₂ 0.45, with SpO₂ now 94%. He is now admitted for further work‑up of possible opportunistic infection (PJP vs CMV vs TB) and for management of HIV‑related complications.', 1, '2025-11-19 06:07:14.64341+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (56, 56, 'hpi_short', '58yo M with h/o HTN, HLD, HFpEF (EF 45% on echo 06/15/3064), CKD‑3 (baseline Cr 1.4), DM2 (A1c 8.1%) and recent ADMIT 07/20/3064 for decompensated HF presents today with 3‑day history of progressive dyspnea on exertion, orthopnea to 2 pillows, paroxysmal nocturnal dyspnea x2 nights, and 2+ pitting edema to mid‑calf bilaterally. He reports 4‑5 L of water intake per day, recent NSAID use for knee pain (ibuprofen 400 mg TID for 5 days). Denies chest pain, palpitations, fever, cough, hemoptysis, syncope. He was discharged from outside hospital on oral furosemide 40 mg daily and carvedilol 12.5 mg BID, but stopped furosemide on day 2 because “felt light‑headed”. Since then weight gain ~5 lb, SOB worsened. He came to ED after wife noted increasing swelling and shortness of breath while climbing stairs. In ED vitals: HR 112, RR 22, BP 138/78, SpO2 92% RA, Temp 36.8 °C. Labs: BNP 1120 pg/mL, Cr 1.6, K 4.9. CXR: bilateral interstitial edema, small pleural effusions. Received IV furosemide 40 mg push, then 20 mg q6h, with modest diuresis. He was transferred to our floor for continued diuresis and optimization of GDMT.', 1, '2025-11-19 06:07:14.643824+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (57, 57, 'hpi_short', '58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), DM2 (A1c 8.9%), recent prostatitis p/w N/V/D, R flank pain, now presents w/ 2‑day hx of worsening dysuria, urgency, suprapubic pressure, and chills. Patient reports that 5 days ago he was discharged from an outside hospital where he was treated for acute prostatitis with IV ceftriaxone 2 g q24h x 3 days then switched to PO levofloxacin 750 mg daily; he completed 5 of 7 planned days before symptoms recurred. Since discharge he has been drinking plenty of water, but urine has become cloudy and foul smelling. He notes new onset of mild left flank tenderness, low‑grade fever at home ( Tmax 101.3°F ), and occasional nausea without vomiting. Denies hematuria, recent sexual activity, or new catheterization. He tried OTC phenazopyridine with minimal relief. No recent travel.', 1, '2025-11-19 06:07:14.644224+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (58, 58, 'hpi_short', '58yo M with h/o T2DM (A1c 8.7%), CKD stage 3 (eGFR 45), HTN, PAD s/p fem‑pop stent 3065, and recent left foot ulcer p/w cellulitis now presents w/ acute onset RLE erythema, warmth, edema, and throbbing pain for 72 hrs. Pt reports that 4 days ago he sustained a minor abrasion while gardening, noted a small puncture but no bleeding. Overnight the area became increasingly red, now ~12 cm diameter, with ill‑defined margins, streaking up the calf. He denies fevers, chills, SOB, chest pain, dysuria. He took OTC ibuprofen 400 mg q6h with minimal relief. Pt was seen at urgent care 2 days ago, prescribed cephalexin 500 mg PO q6h, but compliance uncertain due to recent travel to his sister’s house (overnight stay, no known sick contacts). This morning he noted worsening pain, difficulty ambulating, and a low‑grade fever at home (T 100.2 °F). EMS was called by his wife; vitals on EMS arrival: T 38.3 °C, HR 112, BP 138/78, RR 22, SpO2 96% RA. Pt was transported to ED, where labs showed WBC 14.2 K, CRP 12 mg/dL, ESR 48 mm/hr. Bedside US of RLE showed subcutaneous edema, no abscess. He was given IV cefazolin 1 g q8h and admitted for IV antibiotics and monitoring for possible progression to necrotizing infection.', 1, '2025-11-19 06:07:14.644635+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (59, 59, 'hpi_short', '62yo F with h/o CKD stage 3 (baseline Cr 1.8), HTN, T2DM (A1c 8.6% 02/3085), and recent admission for left lower extremity cellulitis (03/15/3085‑03/20/3085) now presents with 4‑day history of erythema, warmth, and purulent drainage from her peripherally inserted central catheter (PICC) in the left basilic vein. Patient reports that the line was placed during her cellulitis admission for IV vancomycin. She was discharged on oral doxycycline 100 mg BID and line was to remain in place for outpatient infusion of ertapenem. Since discharge she has noted increasing pain (8/10), swelling, and a yellow‑green ooze that stains her clothing. She denies fever, chills, rigors, shortness of breath, chest pain, or new cough. She tried to clean the site with over‑the‑counter antiseptic wipes, but drainage persists. She reports occasional low‑grade fevers at home (max 100.4 °F) but did not measure. She denies recent travel, sick contacts, or animal exposures. She has been compliant with insulin glargine 30 U nightly and metformin 500 mg BID. She reports no recent changes in diet or activity.', 1, '2025-11-19 06:07:14.645375+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (60, 60, 'hpi_short', '34yo M with h/o HIV/AIDS (diagnosed 2015, CD4 78, VL 2.5e5, non‑adherent to ART) presents w/ 10‑day hx of low‑grade fevers (T max 39.2°C), worsening dyspnea on exertion, dry cough, and new oral white plaques. Pt reports 15‑lb weight loss over past month, night sweats, and intermittent nausea. He was discharged 2 weeks ago from outside hospital after treatment for PCP pneumonia; completed 7 days of oral TMP‑SMX but stopped due to GI upset. Since discharge he has not taken any ART or prophylaxis. He notes increased shortness of breath over past 48 h, now at rest, SpO2 90% on room air. Denies chest pain, hemoptysis, recent travel, or known TB exposure. He lives in a group home, reports occasional marijuana use, no alcohol, and multiple male sexual partners with inconsistent condom use. No recent vaccinations.', 1, '2025-11-19 06:07:14.645784+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (61, 61, 'hpi_short', '53yo M with h/o CKD stage 3 (baseline Cr 1.8 mg/dL), HTN, DM2 (A1c 8.4%), recent admission for septic arthritis of left knee (treated 06/10‑06/15) now presents w/ 4‑day history of progressive erythema, warmth, and pain around his right mid‑forearm peripherally inserted central catheter (PICC) placed 2 weeks ago for IV antibiotics. Pt reports low‑grade fevers up to 100.8 °F, chills, and foul‑smelling yellow drainage that started 48 h ago. He notes the line dressing became damp and he had to change it himself at home; after that the site became more painful and he began to notice “little pus” oozing. Denies new trauma, recent travel, or sick contacts. He was discharged from outside hospital on 06/15 after 5 days of IV cefazolin via PICC; completed 2 days of oral amoxicillin‑clavulanate at home before presenting. He reports compliance with wound care instructions but admits occasional “slipping” of the dressing. No SOB, chest pain, abdominal pain, N/V/D.', 1, '2025-11-19 06:07:14.646203+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (62, 62, 'hpi_short', '58yo M with h/o HFrEF (EF 32% on 06/01/3063 echo), CAD s/p PCI 2019, HTN, CKD3, DM2 (A1c 8.7% 02/3064), and recent admission for decompensated HF (04/28/3064 – 05/04/3064) p/w progressive dyspnea on exertion, orthopnea, PND, 2+ LE edema. Discharged on furosemide 40 mg PO BID, carvedilol 12.5 mg BID, lisinopril 20 mg daily, spironolactone 25 mg daily, and sacubitril/valsartan 97/103 mg BID. Since discharge, he reports worsening SOB after climbing a single flight of stairs, now needing 2 pillows, and new 1+ pitting edema to mid‑calf bilaterally. Denies chest pain, palpitations, fever, cough, or recent travel. He missed his furosemide dose on 06/15 due to “forgetting” and has been drinking 2–3 beers nightly. No recent weight loss. He presents from home via EMS after wife called for “breathing trouble.” EMS notes HR 112, RR 24, SpO2 88% RA, BP 158/92, given 40 mg IV furosemide en route with modest improvement.', 1, '2025-11-19 06:07:14.646634+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (63, 63, 'hpi_short', '72yo F with h/o COPD (GOLD II), CKD‑3 (baseline Cr 1.6), anemia of chronic disease, major depressive disorder s/p SSRI therapy, and recent 12 lb weight loss over 6 weeks presents for progressive malaise, anorexia, and generalized weakness. Pt reports that 2 months ago she began feeling “run down,” with low energy, occasional light‑headedness on standing, and a loss of appetite. She has been eating <½ of meals, mostly crackers and tea, and has unintentionally lost ~12 lb (BMI now 18.2). Denies fever, chills, night sweats, cough, dyspnea at rest, chest pain, abdominal pain, N/V/D, dysuria, or recent falls. No new meds. She was seen at an urgent care 1 week ago; labs showed mild normocytic anemia (Hgb 10.2) and BUN/Cr 28/1.7; she was advised to increase oral intake and follow‑up with PCP, but symptoms worsened. She lives alone in an apartment, uses a walker for ambulation, and has limited social support. Family reports she has become “quiet” and “doesn’t get out of bed.” No recent travel, sick contacts, or known COVID‑19 exposure. No alcohol, tobacco (quit 15 yr ago), no illicit drugs.', 1, '2025-11-19 06:07:14.647052+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (64, 64, 'hpi_short', '34yo M with h/o T2DM (A1c 9.8% recent), HTN, CKD‑3, peripheral neuropathy, and prior left hallux ulcer p/w worsening left foot infection over the past 5 days. Patient reports a “small sore” that he noticed after a minor cut while gardening 7 days ago. Initially painless, but over the last 48 h he noted increasing erythema extending to the mid‑foot, foul smelling drainage, throbbing pain despite “taking ibuprofen”. He also developed low‑grade fevers (T max 38.3 °C) and chills. He went to an urgent care clinic on 12/09 where he was prescribed oral clindamycin 300 mg TID and instructed to keep the wound clean. No improvement; on 12/11 he presented to St. Orion Hospital ED. There he was febrile (T 38.9 °C), tachycardic (HR 112), BP 138/78, RR 22, SpO2 96% RA. Labs showed WBC 15.2 K, CRP 12 mg/dL. X‑ray of the left foot showed soft‑tissue swelling, no obvious fracture. He was started on IV cefazolin 1 g q8h and admitted to the orthopedic service. Orthopedic consult on 12/12 recommended MRI, which demonstrated marrow edema of the 2nd metatarsal consistent with early osteomyelitis. He was transferred to our facility for higher‑level care and possible surgical debridement. He denies recent travel, sick contacts, or new medications. No known drug allergies.', 1, '2025-11-19 06:07:14.647464+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (65, 65, 'hpi_short', '69yo M with uncontrolled HIV/AIDS (CD4 78 cells/µL, VL 250 k copies/mL), chronic HCV (RNA + ), CKD‑3 (eGFR 42 mL/min), HTN, and recent PCP pneumonia p/w fever, SOB, productive cough. Patient reports that 4 weeks ago he began feeling “run down,” lost appetite, and dropped ~15 lb despite no change in diet. Two weeks ago he developed low‑grade fevers (T 38.2‑38.7 °C) and a dry cough that progressed to purulent sputum (yellow‑green). Over the past 48 h he noted worsening dyspnea on minimal exertion, orthopnea, and chills. He denies chest pain, palpitations, hemoptysis, or recent travel. He reports poor adherence to his ART regimen (tenofovir/lamivudine/dolutegravir) for the past 3 months due to homelessness and lack of pharmacy access. He also admits to intermittent IV heroin use (last use 5 days ago) and smoking 1 pack/day for 30 years. He was seen at an urgent care 2 days ago, given azithromycin 500 mg PO daily x3 days, but symptoms worsened, prompting ED presentation. In the ED he was tachypneic (RR 28), tachycardic (HR 112), febrile (T 38.9 °C), O2 sat 88 % on RA, requiring 2 L NC. Labs showed leukocytosis (WBC 14.2 ×10⁹/L, neutrophils 84 %), anemia (Hgb 9.8 g/dL), creatinine 1.8 mg/dL (baseline 1.5). CXR demonstrated bilateral diffuse interstitial infiltrates. Given CD4 <100, PJP was high on differential; bronchoscopy with BAL was ordered. He was started on IV cefepime, TMP‑SMX, and methylprednisolone 40 mg q8h. He was admitted for further work‑up and management of opportunistic infection, sepsis, and ART non‑adherence.', 1, '2025-11-19 06:07:14.647893+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (66, 66, 'hpi_short', '42yo M with h/o IV drug use (last use 2 mo ago), chronic HCV (RNA+), prior MRSA SSTI, now p/w 3 days of intermittent high‑grade fevers (Tmax 103°F), chills, night sweats, progressive SOB on exertion, and new onset left‑sided chest discomfort. Pt reports a harsh, new systolic murmur heard yesterday while at home. Denies cough, hemoptysis, abdominal pain, N/V/D. Pt was seen at County General on 01/13/3067 for fever; blood cultures drawn (pre‑antibiotic), CXR normal, started on IV vancomycin 1 g q12h and transferred for possible endocarditis. At our facility, vitals on arrival: T 101.8°F, HR 112, BP 118/72, RR 22, SpO2 94% on RA. Pt appears ill, diaphoretic, but alert. No focal neuro deficits. Review of systems otherwise negative.', 1, '2025-11-19 06:07:14.648346+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (67, 67, 'hpi_short', '29yo F w/ hx intermittent asthma (SABA PRN), recent URTI 5d ago now p/w productive cough w/ yellow sputum, subjective fevers up to 102°F, chills, pleuritic chest pain R side, SOB on exertion. Pt reports she was seen at urgent care 3d ago, given azithro 500 mg PO daily x3 and albuterol inhaler, but symptoms progressed, now w/ increased work of breathing, tachypnea, and fatigue. Denies hemoptysis, orthopnea, PND, leg swelling. Pt traveled to coastal resort 10d ago, stayed in hotel, no known sick contacts. No recent COVID‑19 exposure. Pt states she stopped her inhaler after 2 days because felt better, but now feels “tight chest”. In ED vitals: T 101.8°F, HR 112, RR 24, BP 118/72, SpO2 92% RA. Labs showed WBC 14.2 with left shift, CRP 12.5 mg/dL. CXR read LLL infiltrate. Pt was started on ceftriaxone 1 g IV q24h and continued azithro, but after 12h still febrile, so admitted for IV antibiotics, telemetry, and further work‑up.', 1, '2025-11-19 06:07:14.64877+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (68, 68, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 45), BPH, recent prostatitis p/w N/V/D and R flank pain. Patient reports 3‑day history of worsening dysuria, cloudy urine, urgency and suprapubic pressure. Yesterday night he noted fever to 101.8°F, chills, and a single episode of emesis. He denies any recent sexual activity, new sexual partners, or condom use. He says he completed a 5‑day course of ciprofloxacin for prostatitis 2 weeks ago, but stopped early because of GI upset. He went to urgent care 2 days ago, was given nitrofurantoin 100 mg BID but stopped after 2 doses due to nausea. He now presents to ED after a friend called EMS because his temp spiked to 103°F at home. He also notes mild right flank tenderness, no CVA tenderness, no gross hematuria. He has a history of intermittent urinary retention secondary to BPH, uses tamsulosin 0.4 mg daily. He reports baseline creatinine ~1.6 mg/dL, baseline glucose 180‑200 mg/dL. He is compliant with insulin glargine 30 U qHS and metformin 500 mg BID (held on admission). He denies cough, SOB, chest pain, GI bleed, or recent travel. He lives with wife, works as a forklift operator in a warehouse, no recent hospitalizations other than the prostatitis episode. He drinks 2‑3 beers/week, never smoked, no illicit drugs.', 1, '2025-11-19 06:07:14.649399+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (69, 69, 'hpi_short', '58yo M with h/o COPD (GOLD stage III, chronic bronchitis phenotype), HTN, and remote 20‑pack‑yr smoking (quit 5 y ago) p/w worsening dyspnea, productive cough, and low‑grade fever x3 days. He reports a change from his baseline “white frothy” sputum to thick yellow‑green sputum, increased work of breathing, and use of accessory muscles. Yesterday he self‑administered albuterol MDI q4h PRN with minimal relief, and took 2 L O₂ at home via nasal cannula (baseline 2 L). He denies chest pain, palpitations, calf pain, or recent travel. He was seen at an urgent care 2 days ago, given a 5‑day course of azithromycin which he completed, but symptoms progressed. EMS was called this morning after he became unable to speak full sentences; vitals on scene: HR 112, RR 28, SpO₂ 84% on 2 L O₂, BP 138/78. He was placed on non‑rebreather 15 L en route and brought to ED where he was placed on BiPAP (IPAP 12, EPAP 5). Labs showed mild leukocytosis, ABG with pH 7.32, PaCO₂ 58 mmHg, PaO₂ 68 mmHg on 15 L O₂. CXR demonstrated hyperinflated lungs with bibasilar infiltrates. He was started on IV methylprednisolone 60 mg q12h, nebulized ipratropium‑albuterol q4h, and ceftriaxone 1 g q24h. He was admitted for COPD exacerbation with possible bacterial superinfection.', 1, '2025-11-19 06:07:14.649901+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (70, 70, 'hpi_short', '58yo M with h/o HTN, T2DM (A1c 8.7% 02/3078), CKD stage 3, and remote cellulitis p/w left lower leg cellulitis 2 y ago, now presents w/ 3‑day history of progressive right forearm pain, swelling, and warmth. Patient reports that 4 days ago he sustained a minor laceration while chopping wood (sharp edge of a hand‑saw) on his right forearm; he cleaned it with water and soap, applied over‑the‑counter bacitracin, but noted increasing redness and a “stinging” sensation. Yesterday he noted the area became tense, with a “tight” feeling, and he started having low‑grade fevers (T max 38.2 °C) and chills. He went to urgent care on 05/28/3079 where a rapid strep test was negative; they gave him a 5‑day course of cephalexin 500 mg PO q6h and instructed to return if worsening. He took 2 doses, then stopped due to nausea. Over the past 24 h the swelling extended proximally to the elbow, the skin is now erythematous, indurated, and tender to light touch. He denies any drainage, bullae, or lymphangitic streaks. No recent travel, no known sick contacts, no animal bites. He works as a carpenter, frequently uses his hands, and reports that his gloves were soaked in water during the incident. He denies IV drug use. He reports mild dyspnea on exertion (climbing stairs) but attributes to deconditioning. He is afebrile now (T 36.9 °C) but feels “ill”.', 1, '2025-11-19 06:07:14.65032+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (71, 71, 'hpi_short', '58yo M with h/o HTN, HLD, T2DM (A1c 8.1%), CKD stage 3, and recent right‑sided CAP p/w SOB, pleuritic chest pain, and chills. He was seen at an urgent care 2 days ago, given azithro 500 mg PO x5d, but symptoms progressed. Yesterday night he developed fever 39.4 °C (103 °F), chills, and a “rusty” sputum. He reports increased dyspnea on exertion, now at rest, and a non‑productive cough earlier that turned productive this morning. Denies orthopnea, PND, leg swelling, or calf pain. No recent travel; works as a construction foreman, lives with wife and two teenage kids. He quit smoking 5 y ago (20 pack‑yr hx). No known drug allergies. He took his home meds (lisinopril, atorvastatin, metformin, insulin glargine) up until this morning; missed insulin dose yesterday due to nausea. He presented to the ED at 14:20, where vitals showed HR 112, RR 24, SpO2 92% RA, BP 138/78. Labs: WBC 16.2 K with left shift, procalcitonin 1.8 ng/mL, lactate 1.9 mmol/L. CXR: LLL infiltrate, possible consolidation. Started on IV cefepime 2 g q8h, azithro 500 mg IV q24h, and supplemental O₂ 2 L NC. He was admitted for inpatient management of community‑acquired pneumonia with possible sepsis.', 1, '2025-11-19 06:07:14.651105+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (72, 72, 'hpi_short', '58yo F with h/o HFrEF (EF 30% on echo 04/3090), CAD s/p PCI to RCA 06/3088, HTN, CKD stage 3, and chronic atrial fibrillation on warfarin, presents w/ progressive dyspnea x5 days, now SOB at rest, 2‑LPM O2 required to keep sats >92%. Reports worsening PND, 2‑night awakenings, and 2++ pitting edema to mid‑calves. Denies chest pain, fever, cough, hemoptysis. She was discharged from outside hospital 03/3091 after treatment for acute decompensated HF; was on IV furosemide 40 mg q8h, transitioned to oral bumetanide 2 mg daily, but stopped meds after discharge due to “feeling better”. Over past 48 h she resumed fluid intake (≈3 L/day) and noted weight gain ~4 lb. No recent travel, no sick contacts. Home meds were held for 2 days prior to admission. In ED vitals: HR 112 (irregular), BP 158/92, RR 24, SpO2 88% on RA, Temp 36.8 °C. Labs: BNP 1120 pg/mL, creatinine 1.8 mg/dL (baseline 1.4). CXR: bilateral interstitial edema, Kerley B lines. Started on IV furosemide 80 mg bolus, then infusion 10 mg/h, and nitroglycerin drip. Cardiology consulted; plan for diuresis and possible inotrope.', 1, '2025-11-19 06:07:14.651748+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (73, 73, 'hpi_short', '58yo M with h/o IV drug use (last use 2 mo ago), chronic HCV (treated), CKD stage 3, and recent left knee arthroplasty p/w 3 wk of intermittent fevers, rigors, new murmur, and progressive SOB. He reports low‑grade fevers (T max 101.5°F) daily, night sweats, and a sharp, pleuritic chest pain that started 5 days ago. Denies cough, hemoptysis, or recent travel. He was seen at an outside urgent care 10 days ago for a “possible skin infection” on his forearm; was prescribed TMP‑SMX but stopped after 2 days due to nausea. Since then, he has noticed increasing fatigue, mild palpitations, and a new holosystolic murmur heard at the left lower sternal border. He reports occasional dark urine and mild ankle edema. No known drug allergies. He was transferred from a community ED where blood cultures were drawn (2/4 positive for gram‑positive cocci in chains) and a transthoracic echo showed a 1.2 cm mobile vegetation on the mitral valve with mild regurgitation. He was started on IV vancomycin and ceftriaxone in the ED, but his blood pressure dropped to 92/58 mmHg, prompting transfer for higher level care.', 1, '2025-11-19 06:07:14.652257+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (74, 74, 'hpi_short', '62yo M with h/o T2DM (A1c 9.4% 2mo ago), PAD s/p fem‑pop bypass 2018, CKD‑3, HTN, and prior left toe amputation (2020) p/w worsening left forefoot gangrene. Pt reports that 5 days ago he noticed a blackened area on the plantar aspect of the left 2nd toe that progressed to involve the entire forefoot. He describes throbbing pain 8/10, worse with elevation, partially relieved by OTC ibuprofen. Yesterday he noted foul, malodorous drainage and a low‑grade fever (T 100.2 °F) at home. He went to an outside ED (St. Mercy) where labs showed WBC 16.2, CRP 12.4, and foot X‑ray suggested possible osteomyelitis of the 2nd metatarsal. He received one dose of IV cefazolin and was transferred for definitive care and possible surgical debridement. Pt denies chest pain, SOB, dysuria, or recent trauma. He reports compliance with insulin glargine 30 U nightly and lisinopril 20 mg daily, but admits occasional missed doses of metformin due to poor appetite.

ED Course (outside):

Vitals on arrival: T 100.2 °F, HR 112, BP 138/78, RR 22, SpO2 96% RA. Received 1 L NS, cefazolin 1 g IV, and analgesia with morphine 4 mg IV. Foot exam: black necrotic tissue extending from distal 2nd toe to mid‑forefoot, edema, erythema, foul drainage. No palpable pulses distal to the ankle. Vascular US showed monophasic flow in posterior tibial artery.

He was placed on broad‑spectrum antibiotics (piperacillin‑tazobactam 4.5 g q6h) and transferred.', 1, '2025-11-19 06:07:14.652665+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (75, 75, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD3 (eGFR 45), HTN, COPD s/p tobacco cessation 5 y ago, and recent discharge from outside hospital (03/20/3054) for uncomplicated UTI now presents w/ 3‑day history of non‑localizing fever up to 39.4°C, rigors, diffuse myalgias and fatigue. Patient reports that after completing a 5‑day course of oral ciprofloxacin he felt “better” but on day 2 post‑therapy he developed low‑grade fevers again, now higher, associated with night sweats. Denies cough, dyspnea, chest pain, dysuria, abdominal pain, nausea/vomiting, diarrhea, rash, or focal pain. No recent travel, no known sick contacts. He notes that his home glucose logs have been 180‑250 mg/dL despite usual metformin/glipizide regimen. He has been drinking water but feels “dehydrated”. No change in mental status.

Patient was seen in the ED of this facility at 20:15, where vitals showed T 38.9°C, HR 112, BP 138/78, RR 22, SpO2 95% on RA. Labs drawn showed leukocytosis with left shift, mild AKI on top of CKD, and hyperglycemia. Blood cultures and urinalysis were obtained. Empiric IV ceftriaxone 1 g q24h and IV normal saline bolus were started. He was admitted for further work‑up of fever of unknown origin (FUO) and possible sepsis.', 1, '2025-11-19 06:07:14.653095+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (76, 76, 'hpi_short', '68yo M with h/o HTN, HLD, HFrEF (EF 30%), CKD stage 3, and recent URI p/w cough now presents with worsening dyspnea, orthopnea (2 pillows), PND, and 2+ pitting edema to mid‑calves for 3 days. Pt reports that 2 days ago he was seen at an urgent care where he received oral furosemide 40 mg and azithro for presumed bronchitis; symptoms minimally improved. This morning he awoke feeling “tight” in chest, unable to climb a flight of stairs without stopping, and noted weight gain of ~4 lb since yesterday. Denies chest pain, palpitations, fever, chills, syncope, or calf pain. No recent travel, no sick contacts. He reports compliance with metoprolol 100 mg daily, lisinopril 20 mg daily, and furosemide 40 mg BID at home. He has been restricting fluids but admits to “a few glasses of water” each night.', 1, '2025-11-19 06:07:14.653501+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (78, 78, 'hpi_short', '31yo M with h/o laparoscopic cholecystectomy 10 days ago (post‑op day #10) now presents w/ erythema, serosanguinous drainage, and throbbing pain at RUQ port site. Pt reports that incision was clean on POD #3, but over the past 48 h he noted increasing warmth, purulent yellow‑green discharge, and low‑grade fevers up to 100.8°F (38.2°C) measured at home. Denies SOB, chest pain, N/V/D, or abdominal distention. Pt states he has been taking ibuprofen 600 mg q6h PRN for pain, but relief minimal. He stopped his prophylactic cefazolin 24 h ago per discharge instructions. No recent travel. He visited urgent care on POD #7 for mild wound irritation; they prescribed topical bacitracin and told him to monitor. Since then symptoms have progressed despite topical therapy. Pt reports mild fatigue, but no chills, rigors, or night sweats. He is afebrile on arrival (36.9°C) but appears uncomfortable, guarding the incision when palpated.', 1, '2025-11-19 06:07:14.65433+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (79, 79, 'hpi_short', '40yo M with h/o T2DM (A1c 8.7%), HTN, CKD‑3, recent prostatitis p/w dysuria, urgency, nocturia, mild suprapubic tenderness, N/V/D and low‑grade fever x3 days. Pt reports that 5 days ago he completed a 10‑day course of ciprofloxacin for presumed UTI prescribed by his PCP; symptoms improved briefly then recurred with worsening pain and now occasional hematuria. He denies flank pain, chills, rigors, or recent catheterization. Pt states he had a similar episode 2 yr ago that resolved with TMP‑SMX. He went to urgent care 2 days ago, was given a PO levofloxacin 500 mg daily, but stopped after 2 doses because of GI upset. He now presents to ED after a febrile episode (T 38.3 °C) at home and worsening dysuria.', 1, '2025-11-19 06:07:14.654789+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (80, 80, 'hpi_short', '58yo M with h/o T2DM (A1c 9.1% 03/15/3095), HTN, CKD stage 3, and recent PICC line removal p/w cellulitis of R forearm presents to ED after 2 days of progressive swelling, warmth, and throbbing pain. Pt reports the area started as a small “red spot” after a minor laceration while gardening 48 h ago, then rapidly expanded to involve the entire distal forearm and dorsal hand. He notes feverish chills, subjective fever up to 101°F, and malaise. Denies any trauma beyond the initial scratch, no known bites, no IV drug use. He took OTC ibuprofen 400 mg q6h with minimal relief. Pt was seen at an urgent care 24 h ago, prescribed cephalexin 500 mg PO q6h, but compliance poor due to nausea; he stopped meds after one dose. In the ED, vitals: T 38.9 °C, HR 112, BP 138/84, RR 22, SpO2 97% RA. Labs showed WBC 15.2 K with left shift, CRP 12 mg/dL. Bedside US of the forearm showed subcutaneous edema, no abscess. Pt was given IV cefazolin 1 g q8h and admitted for IV antibiotics and close monitoring.', 1, '2025-11-19 06:07:14.655201+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (81, 81, 'hpi_short', '38yo M with h/o T2DM (A1c 8.7%), HTN, and recent prostatitis p/w dysuria, urgency, nocturia, suprapubic tenderness, N/V/D and mild left flank discomfort. Symptoms began 4 days ago after a weekend camping trip; he reports “burning” on urination, cloudy urine, and intermittent chills. He self‑started ibuprofen 400 mg PO q6h and a 5‑day course of ciprofloxacin 500 mg BID prescribed by his urgent‑care clinic 2 days ago, but reports worsening pain and now a Tmax of 38.4 °C (101.1 °F) at home. Denies gross hematuria, penile discharge, or recent sexual partners. He was seen at an outside ED on 04/22/3087 where a UA showed WBC 45/hpf, nitrites positive, and a non‑contrast CT abdomen/pelvis was negative for stones. He was discharged on oral levofloxacin 750 mg daily for 7 days and instructed to follow up with urology. He returned to the ED because pain persisted, now with new left flank “pressure” and a single episode of vomiting. No travel, no known sick contacts.', 1, '2025-11-19 06:07:14.655611+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (82, 82, 'hpi_short', '28yo M with h/o multiple unprotected sexual encounters (M/F) over past 2 mo, recent onset of purulent urethral discharge, burning dysuria, mild suprapubic discomfort, and low grade fever (~38.2°C) presents to ED. Pt reports that symptoms began 3 days ago after a weekend “hook‑up” with a new partner; initially noted clear discharge that became yellow‑green and thick. Denies hematuria, testicular pain, or rash. Pt tried OTC phenazopyridine with minimal relief. He also notes mild fatigue and occasional chills but no nausea/vomiting. No prior history of STIs; last STI screen 1 yr ago was negative. Pt reports occasional marijuana use, denies tobacco or alcohol. No recent travel. He was evaluated at an urgent care 1 day ago, given a presumptive dose of azithromycin for presumed chlamydia; symptoms persisted, prompting ED visit. In ED, vitals: T 38.2°C, HR 96, BP 122/78, RR 18, SpO2 99% RA. Labs drawn, urine NAAT pending. Physical exam notable for copious yellow‑green urethral discharge on gentle expression, mild penile erythema, no lesions. No inguinal adenopathy. Abdomen soft, non‑tender. No CVA tenderness.', 1, '2025-11-19 06:07:14.656012+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (83, 83, 'hpi_short', '58yo M with h/o HTN, DM2 (A1c 8.7%), CKD‑3, recent Foley removal p/w dysuria, urgency, suprapubic tenderness, chills, N/V. Symptoms began ~48 h ago after discharge from outside acute care where he was treated for a complicated UTI/prostatitis. He reports 3‑4 episodes of burning on voiding per day, cloudy urine with occasional gross hematuria, low‑grade fever now up to 38.9 °C, chills, left flank discomfort. He completed 3 days of ciprofloxacin 500 mg BID but stopped due to nausea and vomiting; no other antibiotics since. He was admitted to a skilled‑nursing facility 5 days ago after a fall, had indwelling Foley for 7 days, removed 2 days prior to symptom onset. Denies recent sexual activity, no known sick contacts, no travel. Reports nocturia x3, mild lower abdominal cramping, and new‑onset mild confusion. He states he has been drinking ~2 cups of water daily, no alcohol or illicit drug use.', 1, '2025-11-19 06:07:14.65642+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (84, 84, 'hpi_short', '25yo M w/ hx of prior chlamydia (treated 2y ago) and HSV‑1 oral, now presents w/ 4‑day hx of painful ulcer on glans penis + copious yellow‑green urethral discharge, dysuria, and mild suprapubic discomfort. Denies fever, chills, N/V, or rash elsewhere. Reports unprotected vaginal intercourse 5 days ago with a new partner (female, age 23) who also reports recent “sores”. He also had oral sex with another partner 2 weeks ago. He took OTC ibuprofen x2 days with minimal relief. Went to urgent care 2 days ago, was given a single dose of cefixime and told to follow‑up; symptoms worsened, prompting ED visit where a rapid HIV test was negative and a NAAT was pending. In ED he was given PO doxy 100 mg BID and topical acyclovir cream, but discharge persisted. He now presents for admission for IV antibiotics, definitive STI work‑up, and pain control. No known drug allergies. No recent hospitalizations.', 1, '2025-11-19 06:07:14.657309+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (85, 85, 'hpi_short', '58yo M with h/o HIV (CD4 420, VL undetectable), prior chlamydia (treated 2y ago), and recent unprotected intercourse p/w urethral discharge, dysuria, and mild suprapubic pain. Symptoms began ~48 h ago after a weekend trip to the coast where he had 3 sexual partners (2 female, 1 male) and reported condom breakage with one partner. He notes a thin, yellowish discharge that is worse with erection, burning on urination, and occasional low‑grade fever (max 100.4°F). Denies flank pain, hematuria, or rash. He self‑started OTC phenazopyridine with minimal relief. Presented to ED after worsening discharge and new mild inguinal lymphadenopathy. Vitals in ED: T 38.2 °C, HR 102, BP 128/76, RR 18, SpO2 98% RA. Labs drawn, urine NAAT pending. Physical exam in ED noted erythematous urethral meatus with discharge, tender bilateral inguinal nodes. No oral lesions. He was given ceftriaxone 250 mg IM and azithromycin 1 g PO per CDC STD protocol and admitted for observation and further work‑up given HIV status and concern for possible gonococcal infection with possible disseminated disease.', 1, '2025-11-19 06:07:14.657721+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (86, 86, 'hpi_short', '58yo M with h/o COPD (GOLD D, home O2 2Lpm qhs), HTN, chronic atrial fibrillation on apixaban, and remote 30‑pack‑yr smoking (quit 5 y ago) presents w/ 3‑day worsening dyspnea, productive cough w/ thick yellow sputum, low‑grade fever (Tmax 38.2 °C at home) and mild pleuritic chest pain on left side. Pt reports that his baseline dyspnea is 2‑3 L/min O2 at rest, but over the past 48 h he has required 4 L/min to stay >90% sat, and now feels “unable to catch his breath” even at rest. Denies recent travel, sick contacts, or change in inhaler technique. He was seen at an urgent care 2 days ago, given a short course of oral steroids (prednisone 40 mg x5 d) and instructed to increase albuterol/ipratropium q4h PRN; compliance uncertain. Yesterday night he noted “bubbles” in sputum and woke up coughing profusely, prompting EMS call. EMS noted RR 28, HR 112, SpO2 84% on room air, placed on non‑rebreather 15 L, and transported to ED. In ED, ABG showed pH 7.32, PaCO2 58 mmHg, PaO2 58 mmHg on 15 L NRB; started on BiPAP, IV methylpred 40 mg q8h, and ceftriaxone 1 g q24h + azithro 500 mg q24h. Chest X‑ray read as “bilateral hyperinflation with new right lower lobe infiltrate”. Pt reports chronic use of tiotropium inhaler daily, albuterol PRN, and occasional oral steroids. No recent hospitalizations.', 1, '2025-11-19 06:07:14.658355+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (87, 87, 'hpi_short', '48yo M with h/o COPD (GOLD 3, chronic bronchitis), HTN, prior 30‑pack‑yr smoker (quit 5 y ago) p/w 3 d worsening dyspnea, productive cough now thick yellow sputum, low‑grade fever (~38.2 °C), pleuritic chest pain R side, and mild ankle edema. Symptoms began after a cold front; he used albuterol inhaler PRN with minimal relief. Yesterday he presented to urgent care, received oral steroids (prednisone 40 mg PO x5 d) and azithromycin 500 mg x1 d, but dyspnea progressed, O2 sat dropped to 86 % on room air, prompting EMS call. EMS gave 2 L O2, nebulized albuterol/ipratropium, and transported to ED. In ED vitals: T 38.4 °C, HR 112, RR 24, BP 138/78, SpO2 88 % on RA. CXR showed hyperinflated lungs with bibasilar infiltrates. Labs: WBC 14.2 K, CRP 8.5 mg/dL. He was placed on non‑rebreather, started on IV methylpred 40 mg q8h, and admitted for COPD exacerbation with possible bacterial infection. He denies chest pain at rest, palpitations, calf pain, recent travel, or sick contacts. No recent steroid bursts beyond today.', 1, '2025-11-19 06:07:14.658815+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (88, 88, 'hpi_short', '58yo M with h/o chronic hepatitis C (treated), IV drug use (heroin, last use 2 days ago), prior IE (aortic valve) s/p valve replacement 3 y ago, and COPD presents to ED w/ 3‑day hx of progressive right forearm pain, swelling, erythema, and low‑grade fever up to 38.7 °C. Pt reports injecting heroin into right antecubital fossa daily for past 6 months; last injection was “just before bed” 2 days ago and he noticed a “big bump” that turned red and painful. Over the past 24 h he’s had chills, night sweats, nausea, and decreased appetite. Denies SOB, chest pain, cough, dysuria, or recent travel. He was seen at an urgent care 1 day ago, given oral clindamycin, but symptoms worsened, prompting ED visit. In ED vitals: T 38.9 °C, HR 112, BP 118/72, RR 22, SpO2 96% RA. Labs showed leukocytosis 15.2 K, CRP 12 mg/dL. Bedside US of forearm showed a 3 cm hypoechoic collection suggestive of abscess. He was started on IV vancomycin and cefepime, and surgical consult placed for possible I&D.', 1, '2025-11-19 06:07:14.659236+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (89, 89, 'hpi_short', '68yo M with h/o COPD (GOLD D, home O2 2Lpm), HTN, DM2 (A1c 8.1%), chronic bronchitis, and prior intubation 2 y ago, presents w/ acute worsening dyspnea x3 days. Pt reports “can’t catch my breath” after climbing a single flight of stairs, now at rest. Sputum turned thick yellow‑green, volume ↑ to ~30 mL/qh, associated with low‑grade fever (Tmax 38.2 °C at home) and pleuritic chest pain R lower lobe. Denies hemoptysis. Pt was seen at outside ED 08/02/3052, received albuterol/ipratropium nebulizers, IV methylpred 40 mg, and a dose of ceftriaxone 1 g. CXR read “possible right lower lobe infiltrate vs atelectasis.” He was discharged on oral levofloxacin 750 mg daily and prednisone 40 mg PO daily with plan to follow‑up, but symptoms progressed, prompting return. Pt reports compliance with home O2 2 Lpm nocturnally, now using 4 Lpm continuously. No recent travel. No known sick contacts.', 1, '2025-11-19 06:07:14.659647+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (90, 90, 'hpi_short', '58yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, CKD stage 3, HTN, and prior left transmetatarsal amputation p/w R foot ulcer now s/p 2 wk of worsening erythema, foul drainage, and throbbing pain radiating to the calf. Patient reports the ulcer began as a small blister after a minor abrasion while gardening 3 weeks ago. He self‑treated with OTC bacitracin and kept the foot in a sandal. Over the past 5 days the area became increasingly red, swollen, and now has yellow‑green exudate. He notes low‑grade fevers up to 38.2°C at home, chills, and a new onset of malaise. Denies any recent travel, sick contacts, or new footwear. He was seen at an urgent care on 07/15; wound cultures were taken and he was prescribed oral clindamycin 300 mg q6h and instructed to follow‑up. He took 2 doses then stopped due to GI upset. He presented to the ED on 07/20 because pain became intolerable, he could no longer bear weight, and the swelling extended to the mid‑calf. In the ED vitals: T 38.4°C, HR 112, BP 138/78, RR 22, SpO2 96% RA. Labs showed WBC 14.2, CRP 12.5 mg/dL. Bedside Doppler revealed absent dorsalis pedis pulses on the right. X‑ray of the foot showed soft‑tissue swelling without osteolysis. He was started on IV vancomycin and cefepime, received 1 L NS, and was admitted for IV antibiotics, possible surgical debridement, and glycemic optimization.', 1, '2025-11-19 06:07:14.660071+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (91, 91, 'hpi_short', '58yo M with h/o HTN, CKD stage 3 (eGFR 48), chronic low back pain s/p L4‑L5 discectomy 2019, and recent UTI treated with ciprofloxacin presents w/ acute exacerbation of lumbar pain radiating to left buttock and posterior thigh. Patient reports “sharp, burning” pain that started 3 days ago after lifting a 30 lb box at work (warehouse associate). Initially intermittent, now constant, 8/10 at rest, 10/10 with ambulation. Denies any recent trauma, falls, or MVC. Reports new numbness in left great toe, occasional tingling in L5 dermatome, but no weakness. He notes that pain is partially relieved by lying supine and worsened by standing or sitting >30 min. He took ibuprofen 600 mg q6h PRN with minimal relief, and used his home baclofen 10 mg tid, also minimal effect. He went to an urgent care on 09/14; they gave a steroid tapere (prednisone 20 mg x5 days) and ordered plain X‑ray which was read as “degenerative changes, no acute fracture.” Pain persisted, so he presented to ED. In ED vitals: T 37.2 °C, HR 102, RR 20, BP 148/86, SpO2 97% RA. Labs: WBC 9.8, Cr 1.4 (baseline 1.3), BUN 22. CT lumbar spine without contrast showed L4‑L5 disc protrusion with mild central canal stenosis, no fracture. No epidural abscess. He was given IV ketorolac 30 mg q6h and morphine 2 mg q2h PRN, with modest relief. He was admitted for pain control, possible epidural steroid injection, and further work‑up of possible radiculopathy.', 1, '2025-11-19 06:07:14.660762+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (92, 92, 'hpi_short', '58yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, CKD stage 3, HTN, and prior left BKA presents w/ R foot infection x5d. Pt reports a 2cm ulcer on plantar aspect of R hallux that he noticed after a minor blister while gardening. Initially painless, but over past 48h drainage turned purulent, erythema spread to midfoot, increased warmth, throbbing pain worsened with ambulation. Pt admits he “skipped” insulin doses last week due to travel to sister’s house (out of state) and has been using OTC ibuprofen for pain. He was seen at an outside urgent care 2d ago, received a single dose of IM ceftriaxone and was told to follow up with PCP; PCP advised ED if worsening – which it did. Pt denies fever, chills, SOB, chest pain, dysuria, or new GI symptoms. No recent trauma, no known sick contacts. He reports baseline neuropathy in both feet, but this ulcer is new. He has been non‑compliant with wound care (no daily dressing changes) due to limited dexterity from diabetic neuropathy. He is currently on insulin glargine 30U qHS and lispro 8U TID PRN, metformin 1000mg BID, lisinopril 20mg daily, atorvastatin 40mg nightly, aspirin 81mg daily. No known drug allergies.

Outside Hospital Course: At urgent care, CBC showed WBC 12.3, CRP 8.2. He was given ceftriaxone 250mg IM and instructed to start oral TMP‑SMX if discharge. He left without antibiotics due to insurance issues. No imaging performed.', 1, '2025-11-19 06:07:14.661226+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (93, 93, 'hpi_short', '58yo M with h/o HTN, T2DM (A1c 8.1% 02/3077), CKD stage 3, and recent right‑sided CAP p/w fever, productive cough, SOB presents today after 5‑day course of oral azithro completed at outside urgent care. He reports that symptoms initially started 7 days ago with low‑grade fever (max 101°F) and a dry cough while he was on a business trip to New Berlin. Returned home, saw urgent care, was given azithro 500 mg PO daily x3 and albuterol inhaler PRN. Over the next 48 h cough became productive of yellow‑green sputum, dyspnea worsened to dyspnea on exertion (NYHA II), and he noted pleuritic chest pain left lower chest. He also reports chills, night sweats, and decreased appetite. Denies hemoptysis, wheezing, orthopnea, PND, leg swelling. No recent travel outside the region, no known sick contacts. He was evaluated in the ED of St. Mercy on 04/07/3078 where vitals showed T 38.9 °C, HR 112, RR 24, SpO2 92% RA, BP 138/78. Labs then: WBC 14.2 K with left shift, BMP normal, lactate 1.2. CXR showed left lower lobe infiltrate. He was given IV ceftriaxone 1 g q24h and azithro 500 mg IV q24h, plus 2 L NS. He was observed 12 h, but remained febrile and tachypneic, so was transferred to our facility for further management.', 1, '2025-11-19 06:07:14.661668+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (94, 94, 'hpi_short', '58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 48), HTN, and recent right knee arthroplasty (D+7) p/w non‑localizing fever x4 days. Pt reports Tmax 102.5°F at home, associated with chills, night sweats, diffuse myalgias, and mild headache. Denies cough, dyspnea, dysuria, abdominal pain, rash, or focal pain. He was discharged from an outside orthopedic hospital 2 days ago after uncomplicated TKA; received peri‑op cefazolin and was on PO cefdinir 300 mg BID for presumed SSI prophylaxis. Since discharge, he has been ambulating with walker, but feels “run down” and noted that his glucose has been 180‑210 mg/dL despite usual basal insulin glargine 30 U qd. He took acetaminophen 650 mg PRN with minimal relief. No recent travel, no known sick contacts. No change in diet or fluid intake.

ED Course (outside hospital): Vitals on arrival: T 101.8°F, HR 112, RR 20, BP 138/84, SpO2 98% RA. Labs: WBC 13.2 K/µL (neut 84%), Cr 1.4 mg/dL (baseline 1.2), lactate 1.2 mmol/L. CXR unremarkable. Blood cultures drawn, started on IV ceftriaxone 1 g q24h and vancomycin 1 g q12h. Transferred to our facility for continued care and orthopedic follow‑up.

Since transfer, fever persists (T 101‑102°F q6‑8h). Pt reports mild nausea, no vomiting. No new focal findings on exam.', 1, '2025-11-19 06:07:14.662141+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (95, 95, 'hpi_short', '58yo F with h/o HFrEF (EF 32% on echo 03/3054), CAD s/p PCI to RCA 02/3052, HTN, CKD stage 3, and recent admission for decompensated HF 12/10/3054 now presents with 2‑wk progressive SOB, NYHA class III→IV, PND 2‑3×/wk, orthopnea requiring 3 pillows, and 1+ pitting edema to mid‑calves. She reports “feeling like her heart is going to stop” after climbing a single flight of stairs. Denies chest pain, palpitations, syncope. She was discharged 20 days ago after 4‑day IV diuresis (furosemide 80 mg IV q8h) and transition to oral bumetanide 1 mg daily; she was instructed to weigh daily and limit fluids to 1.5 L. Since discharge she has been non‑adherent to fluid restriction (estimated intake ~2.5 L/day) and missed two doses of bumetanide due to “forgetting”. She also reports a recent upper respiratory infection 5 days ago with mild cough, no fever. No recent travel. No known sick contacts.', 1, '2025-11-19 06:07:14.662549+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (96, 96, 'hpi_short', '40yo M with h/o T2DM (A1c 9.1% 3mo ago), PAD, HTN, CKD stage 3, and recent ulcer on R great toe p/w worsening pain, edema, and blackening over 48h. Pt reports that 2 days ago he noticed a small ulcer on the plantar surface after a fall from a ladder at work; he cleaned it with water, applied OTC bacitracin, and kept it covered. Over the past 24h the area became increasingly painful, now throbbing, with foul odor. He also notes numbness distal to the ulcer, coldness of the foot, and difficulty moving the toes. Yesterday EMS was called by his wife when he could not bear weight; he was taken to outside hospital (St. Mercy) where bedside Doppler showed absent pulses in the right dorsalis pedis and posterior tibial arteries. He received IV cefazolin 1g q8h and was transferred for higher level care and possible surgical intervention. He denies fever, chills, chest pain, SOB, N/V/D, or recent travel. He reports compliance with insulin glargine 30U nightly and metformin 1000mg BID, but admits occasional missed doses due to foot pain. No known drug allergies.', 1, '2025-11-19 06:07:14.663263+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (97, 97, 'hpi_short', '58yo M with h/o HTN, T2DM (A1c 8.7%), CKD stage 3, obesity (BMI 34), and recent laparoscopic cholecystectomy p/w SSI presents w/ progressive erythema, purulent drainage, and increasing pain over the RUQ port site for 4 days. Pt reports that on POD #2 he noted mild serous ooze, was told it was normal. By POD #4 the drainage became thick, yellow-green, foul smelling, and the surrounding skin turned bright red, warm, and tender. He has low‑grade fevers up to 38.3°C at home, chills, and decreased appetite. Denies nausea, vomiting, abdominal distention, or changes in bowel habits. He was discharged from outside hospital on 06/05/3089 after an uncomplicated surgery; received a single dose of IV cefazolin intra‑op and was prescribed oral amoxicillin‑clavulanate 875/125 mg BID for 5 days, which he completed on 06/09/3089. He stopped meds on 06/09 due to “feeling better,” but symptoms worsened after. He presented to ED on 06/10/3089, vitals: T 38.2°C, HR 102, BP 138/84, RR 20, SpO2 98% RA. Labs showed WBC 14.2 with left shift. CT abdomen/pelvis with contrast demonstrated a 2.3 cm fluid collection adjacent to the right subcostal port site with surrounding fat stranding, no intra‑abdominal abscess. He was started on IV piperacillin‑tazobactam 4.5 g q6h and taken to OR for incision and drainage (I&D) on 06/10/3089. Intra‑op cultures grew mixed gram‑positive cocci; wound was loosely approximated with absorbable sutures, wound vac placed. Pt now admitted for IV antibiotics, wound monitoring, and glycemic control.', 1, '2025-11-19 06:07:14.663676+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (98, 98, 'hpi_short', '28yo M with h/o lumbar disc herniation (L4‑L5) s/p micro‑discectomy 2 y ago, chronic intermittent low back pain, presents w/ acute worsening of low back pain x 3 days. Pt reports a mechanical fall on 08/07/3076 while lifting a 30 lb box at work; landed on his right side, immediate “pop” sensation in low back, then progressive dull‑achy pain radiating down the posterior left thigh to the calf, numbness to the dorsum of the left foot, and difficulty ambulating >50 ft. Denies bowel or bladder incontinence, but notes occasional “pins‑and‑needles” in left foot when standing. Pt went to urgent care on 08/08/3076, received plain radiographs (read as “degenerative changes, no acute fracture”), prescribed ibuprofen 600 mg TID PRN and cyclobenzaprine 10 mg qHS. No relief, pain now 8/10 at rest, 10/10 with movement. Pt reports prior episodes of similar pain that resolved with rest and NSAIDs. No recent travel, no sick contacts.', 1, '2025-11-19 06:07:14.664371+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (99, 99, 'hpi_short', '58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), DM2 (A1c 8.7%), BPH, and recent Foley catheter placement p/w dysuria, urgency, suprapubic tenderness, and chills x 48h. Patient reports that 3 days ago he was discharged from an outside hospital after a 2‑day stay for elective TURP; Foley was removed on day 1 post‑op but re‑inserted on day 2 due to urinary retention. Since removal he has had burning on micturition, cloudy urine, and low‑grade fevers up to 38.4°C. Denies flank pain, hematuria, or incontinence. He took acetaminophen PRN with minimal relief. He reports increased urinary frequency (Q8‑10min) and nocturia x3. No recent sexual activity. No known drug allergies. He was given a 5‑day course of ciprofloxacin at discharge but stopped after 2 days because of nausea. He now presents to our ED for worsening symptoms. Vitals on arrival: T 38.6°C, HR 112, BP 138/78, RR 20, SpO2 97% RA. Physical exam noted suprapubic tenderness, no CVA tenderness. Labs drawn, UA sent, and renal US ordered.', 1, '2025-11-19 06:07:14.66486+00');
INSERT INTO public.llacie_note_sections (id, "FK_note_id", section_name, section_value, "FK_strategy_id", last_updated) VALUES (100, 100, 'hpi_short', '58yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, CKD stage 3, and prior left transmetatarsal amputation p/w R foot ulcer x2 wks, now worsening erythema, purulent drainage, foul odor, and mild fevers. Patient reports that ulcer began as a small blister after stepping on a construction nail 10 days ago while working on a roof repair. He initially self‑treated with OTC bacitracin and kept foot elevated. Over the past 48 h he noted increased swelling, throbbing pain radiating to the calf, and a temperature of 101.2 °F at home. He denied any recent travel, sick contacts, or new shoes. He presented to an outside urgent care on 10/28 where a wound culture was taken (results pending) and he was given a single dose of IM ceftriaxone and instructed to follow‑up. He left against medical advice because he felt “better” but the pain returned and the drainage became copious. EMS was called by his wife on 11/01 after she found the dressing soaked. In the ambulance he was noted to be tachycardic (HR 112) and mildly hypotensive (BP 98/62). He reports baseline insulin glargine 30 U nightly and lispro sliding scale, but admits he missed several doses over the past week due to “feeling too sick to inject.” He denies chest pain, SOB, dysuria, or GI symptoms.', 1, '2025-11-19 06:07:14.665277+00');


--
-- Data for Name: llacie_notes; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (1, 1, 98434120783, 98434120783, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
09/21/3084 11:26  

Patient: Marcus L. Whitaker  
DOB: 02/14/3049 (35 y/o)  
PCP: Dr. Elaine V. Kline, MD  

Chief Complaint: Redness and drainage from right femoral central line  

History of Present Illness:  
35yo M with h/o ESRD on hemodialysis via right femoral tunneled catheter (placed 3/12/3083), HTN, CKD‑5, and recent admission for urosepsis (09/02/3084) p/w fever, dysuria, and altered mental status. He was treated with IV cefepime 48 h, completed 7‑day course, and was discharged home on 09/09/3084 with a plan for outpatient dialysis. Since discharge, he notes progressive erythema, warmth, and purulent drainage at the catheter exit site over the past 48 h. He reports mild low‑grade fever (T max 100.4 °F) and chills, but denies rigors, chest pain, SOB, or new cough. He has missed two dialysis sessions (09/14 and 09/18) because of line pain and concerns about infection. He attempted self‑care with over‑the‑counter bacitracin ointment, no improvement. No recent travel. No known sick contacts. He presents to the ED after his dialysis nurse advised urgent evaluation.  

Past Medical History:  
• End‑stage renal disease (ESRD) – on hemodialysis (right femoral tunneled catheter)  
• Hypertension – on lisinopril 20 mg daily  
• Hyperlipidemia – on rosuvastatin 10 mg nightly  
• Remote cholecystectomy (04/3080)  

Past Surgical History:  
Procedure Laterality Date  
• Tunneled femoral catheter insertion Right 03/12/3083  
• Cholecystectomy — 04/15/3080  

Family History:  
Father – HTN, died MI at 62  
Mother – DM2, alive 68  
Sister – healthy  

Social History:  
Marital Status: Single, lives alone in apartment  
Employment: Warehouse supervisor, shift work  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Sexual activity: Heterosexual, monogamous, uses condoms intermittently  

Review of Systems:  
Constitutional – Positive for low‑grade fever, chills; negative for weight loss, night sweats.  
HEENT – Negative.  
Cardiovascular – Negative for chest pain, palpitations.  
Respiratory – Negative for cough, dyspnea.  
GI – Negative for nausea, vomiting, abdominal pain.  
GU – No dysuria now, prior UTI resolved.  
Musculoskeletal – Positive for right thigh tenderness at catheter site.  
Skin – Positive for erythema, purulent drainage at catheter exit; negative elsewhere.  
Neurologic – Negative.  
Psychiatric – Negative.  

Prior to Admission Medications:  
Medication Sig  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
epoetin alfa 4000 U SC weekly (dialysis)  
calcitriol 0.5 µg PO daily  
Sevelamer 800 mg PO TID with meals  

Allergies: No known drug allergies  

Physical Examination:  
Temperature: 38.2 °C (100.8 °F)  
Heart Rate: 102 bpm (range 60‑100)  
Respiratory Rate: 18 /min (12‑20)  
Blood Pressure: 148/86 mmHg (110‑140/70‑85)  
SpO₂: 96 % RA  

General: Alert, mildly ill‑appearing, in mild distress due to pain at line site.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: Right femoral catheter exit site with 4 × 5 cm area of erythema, induration, and purulent drainage; surrounding skin warm, tender to palpation. No fluctuance. No edema of lower extremities.  
Skin: No other rashes or lesions.  
Neurologic: AO×3, no focal deficits.  

Labs (drawn 09/21/3084):  
CBC – WBC 14.2 ×10⁹/L (neut 88 %), Hgb 10.1 g/dL, Plt 210 ×10⁹/L  
BMP – Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO₂ 22 mmol/L, BUN 48 mg/dL, Cr 7.2 mg/dL (baseline 6.8)  
CRP – 12.5 mg/dL (elevated)  
Blood cultures – x2 pending  
Catheter tip culture – sent to microbiology (Gram stain shows gram‑positive cocci in clusters)  

Imaging:  
Portable chest X‑ray – No infiltrates, cardiac silhouette normal.  
Ultrasound of right thigh – Subcutaneous fluid collection 3 cm deep adjacent to catheter, no abscess cavity identified.  

Assessment and Plan:  
58yo M with ESRD on femoral tunneled catheter presenting with line‑associated infection (likely Staph aureus) – sepsis risk.  

1. Line infection:  
   • Remove right femoral catheter under sterile technique now.  
   • Start empiric IV vancomycin 15 mg/kg q12h (adjust for Cr) + cefepime 2 g q8h pending cultures.  
   • Obtain repeat blood cultures q48h until clearance.  
   • Consult Vascular Surgery for possible new AV fistula creation; plan for temporary dialysis via right internal jugular non‑tunneled catheter if needed.  

2. Dialysis access:  
   • Hold scheduled outpatient dialysis until new access placed.  
   • Initiate emergent hemodialysis via temporary right IJ catheter today (IR).  

3. Supportive care:  
   • Antipyretics PRN acetaminophen 650 mg PO q6h PRN fever >38.5 °C.  
   • Maintain IV fluids NS 1 L bolus then 75 mL/hr.  
   • Continue lisinopril, rosuvastatin, epoetin, calcitriol as tolerated.  

4. Monitoring:  
   • Telemetry for arrhythmia surveillance (HR 102).  
   • Vitals q4h, labs q24h (CBC, BMP, CRP).  
   • Wound care team to assess exit site daily.  

5. Disposition:  
   • Admit to Medicine Service, floor, with infectious disease and nephrology co‑management.  
   • DVT prophylaxis: SQ enoxaparin 40 mg SC daily (unless contraindicated).  
   • Code Status: Full Code (Presumed).  

6. Education:  
   • Discuss line care, signs of infection, importance of timely dialysis.  
   • Arrange follow‑up with nephrology outpatient within 1 week after discharge.  

Prepared by:  
Dr. Nathaniel P. Hargrove, MD  
Hospitalist – Medicine Service  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (2, 2, 60661386493, 60661386493, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
12/27/3059 07:27  

Patient: Miguel Alvarez  
DOB: 03/14/3015  
MRN: 98765432  
PCP: Dr. Lucia Ramos, MD  

Chief Complaint: Dysuria, suprapubic pain, fever  

History of Present Illness:  
58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 48), BPH, recent prostatitis p/w N/V/D and R flank pain now presents w/ 2‑day hx of worsening dysuria, cloudy urine, suprapubic pressure and chills. Pt reports first noticed burning on urination yesterday morning after a night shift at the warehouse; he drank 2‑3 cans of energy drink, no water. Yesterday night he developed low‑grade fever (T 38.2°C) and chills, then today woke with N/V and a dull R flank ache radiating to the groin. He denies any recent catheterization, sexual activity, or new sexual partners. Pt was seen at urgent care 3 days ago for “UTI” and was given a 5‑day course of TMP‑SMX; he only took 2 doses before stopping due to GI upset. He now reports that symptoms have progressed despite the partial course. No flank tenderness on exam reported by pt, but he feels “pressure”. He denies hematuria, dyschezia, or back pain. No recent travel, no sick contacts.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2012, on insulin glargine 30U qHS and metformin 1000 mg BID  
• Chronic Kidney Disease – stage 3, baseline Cr 1.6 mg/dL  
• Benign Prostatic Hyperplasia – on tamsulosin 0.4 mg daily  
• Hypertension – on lisinopril 20 mg daily  
• Hyperlipidemia – on rosuvastatin 10 mg nightly  

Past Surgical History:  
• Appendectomy – 2008, laparoscopic  
• Right inguinal hernia repair – 2015, open mesh  

Family History:  
Father – HTN, died MI age 68  
Mother – DM2, alive 92  
Sister – breast CA, in remission  

Social History:  
Marital Status: Married, spouse works as teacher  
Children: 2 (ages 10, 13)  
Employment: Warehouse supervisor, shift work, occasional overtime  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 beers/week  
Illicit drugs: Denies  
Living situation: Owns home, lives with spouse and kids  
Travel: None recent  

Review of Systems:  
Constitutional: +fever, +chills, -weight loss, -night sweats  
HEENT: -SOB, -sore throat, -vision changes  
Cardiovascular: -chest pain, -palpitations, -edema  
Respiratory: -cough, -dyspnea, -wheezes  
GI: +N/V, -diarrhea, -abdominal pain (except suprapubic pressure)  
GU: +dysuria, +frequency, +urgency, +suprapubic pain, +flank pain, -hematuria, -incontinence  
Musculoskeletal: -myalgias, -arthralgias  
Neurologic: -headache, -dizziness, -syncope  
Skin: -rashes, -lesions  

Prior to Admission Medications:  
Medication                Sig  
metformin                 1000 mg PO BID  
insulin glargine          30 U SC qHS  
lisinopril                20 mg PO daily  
rosuvastatin              10 mg PO nightly  
tamsulosin                0.4 mg PO daily  
aspirin 81 mg EC          1 tablet PO daily  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Temperature: 38.4 °C (101.1 °F)  
Heart Rate: [90‑130] 112 bpm  
Respiratory Rate: [14‑22] 18 breaths/min  
Blood Pressure: (110‑150)/(60‑90) 138/78 mmHg  
SpO2: 96 % RA  

General: Alert, oriented x3, appears mildly ill, in mild distress from suprapubic tenderness.  
HEENT: Normocephalic, atraumatic, mucous membranes moist, oropharynx without erythema.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no rales, wheezes or rhonchi.  
Abdomen: Soft, mildly distended, suprapubic tenderness to palpation, no rebound, no guarding, bowel sounds normoactive.  
Genitourinary: No CVA tenderness, prostate not examined (patient declined DRE).  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neuro: Grossly non‑focal, AAOx3.  

Data/Results  

Laboratory Studies (drawn 12/27/3059):  
CBC: WBC 14.8 K/µL (neut 84%), Hgb 13.2 g/dL, Hct 39.5 %, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 28 mg/dL, Cr 1.8 mg/dL (baseline 1.6), Glucose 212 mg/dL  
CRP: 12 mg/dL (elevated)  
Procalcitonin: 0.45 ng/mL (moderately elevated)  
Urinalysis (dipstick): Leukocyte esterase +++, nitrite +, blood trace, protein 1+, glucose +  
Urine microscopy: WBC 45/hpf, RBC 5/hpf, bacteria many, casts none  

Microbiology:  
Urine culture sent – pending (specimen collected 12/27/3059)  

Imaging:  
Renal/bladder US (12/27/3059): No hydronephrosis, bladder wall mildly thickened, no stones.  

Assessment and Plan:  
58yo M with DM2, CKD3, BPH and recent incomplete TMP‑SMX course now presents with acute uncomplicated cystitis complicated by possible early pyelonephritis (R flank pain, fever, WBC 14.8). Plan:  

1. Antimicrobial Therapy – Start IV ceftriaxone 2 g q24h (adjusted for Cr) and oral ciprofloxacin 500 mg BID pending culture sensitivities. Hold TMP‑SMX.  
2. Diabetes – Continue insulin glargine; start sliding scale regular insulin qAC PRN for glucose >180. Hold metformin (eGFR <30).  
3. Renal – Monitor Cr q12h, maintain adequate hydration IV NS 125 mL/hr.  
4. BPH – Continue tamsulosin; consider Foley only if urinary retention develops.  
5. Pain – Acetaminophen 650 mg PO q6h PRN; avoid NSAIDs (CKD).  
6. Labs – Repeat CBC, BMP, CRP q24h; urine culture results in 48 h.  
7. VTE prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  
8. Diet – NPO initially for IV fluids, then advance to regular diet as tolerated.  
9. Education – Counsel on completing full antibiotic course, fluid intake >2 L/day, signs of worsening infection.  
10. Disposition – Admit to Med‑Surg floor, telemetry not required, monitor vitals q4h.  

Code Status: Full Code (Presumed)  

Attending: Dr. Rafael Mendoza, MD  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (3, 3, 52497935781, 52497935781, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION NOTE  
PATIENT: Elias M. Kline  
MRN: 84276109  
DOB: 02/14/3055  
PCP: Dr. Mara L. Voss, MD  

DATE OF ADMISSION: 06/08/3085  
TIME: 08:17  
ADMITTING ATTENDING: Dr. Rowan T. Havel, MD  
LOCATION: CARDIO01  
SERVICE: Hospital Medicine  

CHIEF COMPLAINT: Fever, chills, new murmur, SOB  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o IV drug use (last use 3 mo ago), chronic HCV (treated, RNA neg), severe MR (post‑repair 2019), CKD‑3 (baseline Cr 1.6), and recent left‑foot cellulitis p/w erythema, pain, and purulent drainage, now presents w/ 5‑day hx of intermittent fevers up to 102.4°F, night sweats, rigors, progressive dyspnea on exertion, and a new harsh holosystolic murmur radiating to the axilla noted by his primary care doc on 06/04. He reports associated fatigue, anorexia, weight loss ~4 lb, and occasional pleuritic chest pain left side. Denies cough, hemoptysis, abdominal pain, dysuria, or recent dental work. He was seen at an outside urgent care on 06/02, received a single dose of IM ceftriaxone and was discharged with instructions to follow up. Since then symptoms have worsened, he now feels “light‑headed” when standing. He reports occasional palpitations but no syncope. No recent travel. No known sick contacts. He admits to occasional alcohol (2‑3 beers/week) and denies tobacco now (quit 2 yr ago).  

ED COURSE:  
Vitals on arrival: T 101.9°F, HR 112, BP 118/72, RR 22, SpO2 94% RA. Physical exam notable for a grade 3/6 harsh holosystolic murmur at the LLSB, splinter hemorrhages on nail beds, and small Janeway lesions on palms. Labs: WBC 14.8 K/µL (neut 84%), Hgb 11.2 g/dL, Plt 210 K/µL, CRP 12.4 mg/dL, ESR 68 mm/hr, serum creatinine 1.8 mg/dL (eGFR 38 mL/min). Blood cultures x2 drawn, gram stain pending. TTE performed bedside shows mobile echo density on anterior mitral leaflet measuring 1.2 cm, moderate MR, and mild LV dysfunction (EF 48%). He was started on IV vancomycin 1 g q12h and cefepime 2 g q8h after cultures.  

He was transferred to the floor for further work‑up and management of presumed infective endocarditis.  

PAST MEDICAL HISTORY:  
• Chronic hepatitis C (treated, RNA negative)  
• Mitral valve repair (2019) – now s/p repair with residual MR  
• CKD‑3 (baseline Cr 1.5‑1.7)  
• Hypertension  
• IV drug use (last 3 mo)  

PAST SURGICAL HISTORY:  
• Appendectomy (2030)  
• Mitral valve repair (2019)  

MEDICATIONS PRIOR TO ADMISSION:  
lisinopril 20 mg PO daily  
amlodipine 10 mg PO daily  
furosemide 40 mg PO daily  
warfarin 5 mg PO daily (INR target 2‑3) – held on admission  
hydroxyzine 25 mg PO PRN itching  

ALLERGIES:  
No known drug allergies (NKDA)  

FAMILY HISTORY:  
Father – CAD, died 2075 at age 68  
Mother – HTN, alive 2090  
Brother – HCV, alive  

SOCIAL HISTORY:  
• Housing: lives alone in a studio apartment  
• Employment: freelance mechanic, intermittent work due to health  
• Substance use: IV heroin (last use 3 mo ago), alcohol 2‑3 beers/week, never smoked cigarettes (quit 2 yr ago)  
• Sexual activity: monogamous with partner, uses condoms inconsistently  

REVIEW OF SYSTEMS:  
Constitutional: fever, chills, night sweats, weight loss – positive; fatigue – positive; no recent travel.  
HEENT: mild sore throat past week, no visual changes.  
Cardiovascular: new murmur, palpitations – positive; chest pain – mild, pleuritic left side.  
Respiratory: dyspnea on exertion – positive; cough – negative; hemoptysis – negative.  
GI: anorexia, nausea – negative; abdominal pain – negative.  
GU: dysuria – negative; hematuria – negative.  
Musculoskeletal: Janeway lesions, splinter hemorrhages – positive.  
Neurologic: headache – negative; syncope – negative.  
Skin: petechiae on palms, Janeway lesions – positive.  
Psych: anxiety about illness – positive.  

PHYSICAL EXAMINATION:  
VITALS: T 101.6°F, HR 110, BP 116/70, RR 21, SpO2 93% RA, Weight 84 kg (185 lb).  
GENERAL: Ill‑appearing, diaphoretic, mild distress.  
HEENT: Normocephalic, oropharynx erythematous, no exudate.  
NECK: Supple, no JVD, no carotid bruits.  
CARDIOVASCULAR: Regular rhythm, grade 3/6 harsh holosystolic murmur LLSB radiating to axilla, S1,S2 normal, no gallops.  
RESPIRATORY: Clear to auscultation bilaterally, mild bibasilar crackles.  
ABDOMEN: Soft, non‑tender, no hepatosplenomegaly.  
EXTREMITIES: Warm, no edema, splinter hemorrhages on fingernails, Janeway lesions on palms.  
SKIN: No rashes other than noted lesions.  
NEURO: AO×3, CN II‑XII grossly intact, no focal deficits.  

LABS & IMAGING:  
CBC: WBC 14.8 K, Hgb 11.2 g/dL, Plt 210 K.  
BMP: Na 138, K 4.6, Cl 102, CO2 24, BUN 22, Cr 1.8, Glu 112.  
CRP 12.4 mg/dL, ESR 68 mm/hr.  
Blood cultures: pending (preliminary gram stain: gram‑positive cocci in clusters).  
TTE (bedside): Mobile vegetation 1.2 cm on anterior mitral leaflet, moderate MR, EF 48%, no pericardial effusion.  
Chest X‑ray: Mild interstitial infiltrates bilateral, no effusion.  

ASSESSMENT:  
58yo M with history of IV drug use, CKD‑3, and prior mitral valve repair now presents with fever, new murmur, peripheral stigmata, and TTE evidence of a 1.2 cm mitral valve vegetation consistent with infective endocarditis, likely MSSA or MRSA pending cultures. Hemodynamic status stable but early signs of heart failure (dyspnea, crackles).  

PLAN:  
1. Infective Endocarditis – empiric IV vancomycin 1 g q12h (target trough 15‑20 µg/mL) + cefepime 2 g q8h pending cultures. Adjust to nafcillin or oxacillin if MSSA confirmed; add rifampin if prosthetic material involvement suspected.  
2. Cardiology consult – for possible surgical evaluation (valve replacement) given vegetation size >1 cm and moderate MR.  
3. Infectious Diseases consult – antimicrobial stewardship, duration of therapy (minimum 6 weeks).  
4. Nephrology – monitor renal function; adjust vancomycin dosing per troughs.  
5. Hold warfarin; start therapeutic enoxaparin 1 mg/kg SC q12h for anticoagulation pending cardiology input.  
6. DVT prophylaxis – SQ low‑molecular‑weight heparin 40 mg SC daily (unless contraindicated).  
7. Fluid management – maintain euvolemia; monitor intake/output; consider diuretics if pulmonary edema worsens.  
8. Labs q24h: CBC, BMP, CRP, blood cultures until 2 sets negative.  
9. Imaging – repeat TEE within 48 h for better definition of vegetation and valve function.  
10. Education – discuss IV drug use cessation resources, arrange addiction counseling.  
11. Code status – Full Code (presumed).  
12. Diet – NPO initially for possible surgery, then advance as tolerated.  

Disposition: Admit to telemetry floor, continue close monitoring, pending consult recommendations.  

Signature:  
Rowan T. Havel, MD  
Hospitalist, Cardiology Service  
Pager 22458');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (4, 4, 20539529704, 20539529704, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
05/12/3064 00:39  

Patient: Marcus L. Whitaker  
DOB: 02/14/3002  
MRN: 98765432  
PCP: Dr. Elaine V. Kline, MD  

Chief Complaint: SOB, LE edema  

History of Present Illness:  
58yo M with h/o HFrEF (EF 30%), CAD s/p PCI 3055, CKD3, HTN, DM2 (A1c 8.7%), and recent URI p/w cough now presents w/ progressive dyspnea x4 days, orthopnea (2 pillows), PND, and 2+ LE pitting edema to mid‑shin. Pt reports that 2 days ago he was seen at an outside ED (St. Mercy) where CXR showed pulmonary vascular congestion, BNP 1120 pg/mL, and he was given IV furosemide 40 mg bolus then 20 mg q8h. He was discharged home on oral furosemide 40 mg BID, metolazone 5 mg daily, and told to follow‑up. Since discharge, dyspnea has worsened, now dyspneic at rest, O2 sat 88% on RA, HR 112, BP 158/92. Denies chest pain, palpitations, fever, cough, or leg pain. No recent travel. Pt admits to occasional “cheese” binge and 2‑3 beers nightly.  

Past Medical History:  
• HFrEF (diagnosed 3048)  
• CAD s/p PCI (LAD 3055)  
• Hypertension  
• Type 2 Diabetes Mellitus  
• CKD stage 3 (baseline Cr 1.6)  
• Hyperlipidemia  
• GERD  

Past Surgical History:  
Procedure Laterality Date  
• PCI – LAD – 05/03/3055  
• Cholecystectomy – – 09/12/3030  

Family History:  
Father – MI @ 58, HTN  
Mother – DM2, CKD5  
Brother – Alive, HTN  

Social History:  
Marital Status: Married  
Occupation: Truck driver (long hauls)  
Tobacco: Never smoker  
Alcohol: 2‑3 beers nightly, occasional wine  
Illicit Drugs: Denies  
Living Situation: Lives with spouse in single‑family home, owns a dog  

Review of Systems:  
Constitutional: +fatigue, -fever, -weight loss.  
Cardiovascular: +DOE, +orthopnea, +PND, -chest pain.  
Respiratory: +dyspnea at rest, -cough, -hemoptysis.  
GI: +GERD symptoms, -N/V, -abdominal pain.  
GU: -dysuria, -frequency.  
Neuro: -headache, -dizziness.  
Psych: -depression, -anxiety.  
Extremities: +2+ LE edema, -DVT hx.  

Medications Prior to Admission:  
furosemide 40 mg PO BID  
metolazone 5 mg PO daily  
lisinopril 20 mg PO daily  
metoprolol succinate 100 mg PO daily  
atorvastatin 40 mg PO nightly  
glipizide 10 mg PO BID  
insulin glargine 30 U SC qd  
omeprazole 20 mg PO daily  
aspirin 81 mg PO daily  

Allergies:  
No known drug allergies (NKDA).  

Physical Examination:  
Vital Signs:  
Temp 36.8 °C (98.2 °F)  
HR 112 (irregularly irregular)  
RR 22  
BP 158/92  
SpO2 88% RA → 94% on 2 L NC  
Weight 112 kg (247 lb)  

General: Alert, NAD, appears stated age, mild distress from dyspnea.  
HEENT: Normocephalic, PERRLA, mucous membranes moist.  
Neck: JVD present, no thyromegaly.  
Cardiovascular: Irregularly irregular rhythm, S1 S2 audible, S3 present, no murmurs.  
Respiratory: Bibasilar crackles up to mid‑lung fields, decreased breath sounds at bases, no wheezes.  
Abdomen: Soft, non‑tender, BS present, no hepatosplenomegaly.  
Extremities: 2+ pitting edema to mid‑shin bilaterally, warm, pulses 2+ dorsalis pedis.  
Skin: No rashes, no ulcerations.  
Neuro: AOx3, grossly non‑focal.  

Labs (drawn 05/12/3064):  
CBC: WBC 9.2, Hgb 13.1, Hct 39%, Plt 210.  
BMP: Na 138, K 5.1, Cl 102, CO2 22, BUN 28, Cr 1.8, Glu 162.  
BNP: 1120 pg/mL.  
Troponin I: 0.04 ng/mL (reference <0.03).  
HbA1c: 8.7% (from 03/3064).  
ABG on 2 L NC: pH 7.32, pCO2 48, pO2 68, HCO3‑ 24.  

Imaging:  
CXR 05/12/3064: Cardiomegaly, pulmonary venous congestion, interstitial edema, small bilateral pleural effusions.  
Echocardiogram (03/3064): LVEF 30%, LVEDD 6.2 cm, moderate MR, RV systolic pressure 45 mmHg.  

Assessment and Plan:  
58yo M with decompensated HFrEF (EF 30%) secondary to ischemic cardiomyopathy, CKD3, HTN, DM2, now presenting with acute pulmonary edema, refractory volume overload despite outpatient diuretics, and mild renal dysfunction.  

1. Acute decompensated HF:  
   - Start IV furosemide 80 mg bolus then continuous infusion 10 mg/hr, titrate to net negative 1‑1.5 L/24 h.  
   - Add IV metolazone 5 mg q24h if diuresis inadequate.  
   - Hold ACE‑I today (K 5.1, Cr 1.8).  
   - Continue beta‑blocker metoprolol 25 mg PO BID (hold if HR <60 or SBP <90).  
   - Initiate low‑dose IV nitroglycerin drip 10 mcg/min for preload reduction, titrate to SBP 110‑120.  
   - Supplemental O2 to maintain SpO2 >92%; consider non‑invasive ventilation if worsening.  
   - Monitor electrolytes q6h, renal function q12h.  

2. CKD stage 3:  
   - Adjust diuretic dosing, avoid nephrotoxic agents, monitor Cr and K.  

3. Diabetes:  
   - Hold glipizide, continue basal insulin glargine 30 U SC qd, add correctional insulin sliding scale qac.  

4. CAD s/p PCI:  
   - Continue aspirin 81 mg PO daily, hold clopidogrel (not on regimen).  
   - Statin atorvastatin 40 mg nightly continued.  

5. Hypertension:  
   - Continue lisinopril once renal function stabilizes and K <5.0.  

6. GERD:  
   - Continue omeprazole 20 mg PO daily.  

7. VTE prophylaxis:  
   - SQ enoxaparin 40 mg SC daily (hold if platelet <50k).  

8. Diet:  
   - Low‑sodium (<2 g/day), fluid restriction 1.5 L/day.  

9. Disposition:  
   - Admit to telemetry floor, monitor vitals, urine output, daily weights.  
   - Re‑evaluate for possible transition to oral diuretics in 48‑72 h.  

Code Status: Full Code (Presumed).  

Attending: Dr. Victor H. Larkin, MD  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (5, 5, 20430289792, 20430289792, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Elena Marquez
MRN: 98765432
DOB: 04/12/3029
PCP: Dr. Luis Ortega, MD

Date of Admission: 11/26/3057
Time of Admission: 02:25
Location: MED01
Attending Provider: Dr. Samantha Vale, MD

Chief Complaint: Fever, chills, malaise

History of Present Illness:
58yo F w/ h/o T2DM (A1c 8.9%), CKD stage 3, HTN, and recent UTI p/w 3‑day hx of non‑localizing fever, chills, night sweats, and generalized fatigue. She reports Tmax 102.4°F at home yesterday, associated with mild headache and diffuse myalgias. Denies cough, dyspnea, chest pain, dysuria, abdominal pain, rash, or focal neuro deficits. She was seen at an outside urgent care 2 days ago, received a single dose of PO cefpodoxime 200 mg and was discharged with instructions to follow‑up. Symptoms persisted and she now presents to our ED after a syncopal episode while standing in her kitchen; she reports brief light‑headedness but no loss of consciousness. No recent travel, no known sick contacts. She lives with husband, works part‑time as a school cafeteria aide, and reports occasional alcohol (1‑2 drinks/week) and no tobacco use. She has been non‑compliant with her insulin regimen for the past week due to “forgetting” and has been taking metformin 500 mg BID only.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2015
• Hypertension – diagnosed 2010
• Chronic Kidney Disease – stage 3 (baseline Cr 1.6 mg/dL)
• Hyperlipidemia
• Osteoarthritis – knees

Past Surgical History:
• Laparoscopic cholecystectomy – 04/15/3045
• Right total knee arthroplasty – 09/02/3049

Family History:
Mother – HTN, died of stroke at 78
Father – CAD, MI at 66
Sister – T2DM
No known hereditary cancer syndromes.

Social History:
Marital Status: Married
Occupation: School cafeteria aide (part‑time)
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit Drugs: Denies
Living Situation: Lives with husband in single‑family home
Transportation: Owns car

Medications Prior to Admission:
Metformin 500 mg PO BID
Lisinopril 20 mg PO daily
Amlodipine 10 mg PO daily
Atorvastatin 40 mg PO nightly
Insulin glargine 30 U SC qd (non‑adherent)
Furosemide 20 mg PO daily PRN edema
Vitamin D3 2000 IU PO daily

Allergies:
Penicillin – rash (hives)
No other known drug allergies.

Review of Systems:
Constitutional: Positive for fever, chills, night sweats, fatigue; negative for weight loss.
HEENT: Negative for sore throat, visual changes, ear pain.
Cardiovascular: Negative for chest pain, palpitations, edema.
Respiratory: Negative for cough, dyspnea, wheeze.
Gastrointestinal: Negative for nausea, vomiting, diarrhea, abdominal pain.
Genitourinary: Denies dysuria, flank pain.
Musculoskeletal: Diffuse myalgias, knee OA pain.
Neurologic: Negative for headache (except mild), dizziness (except syncopal prodrome), focal deficits.
Skin: No rash.
Psychiatric: No depression or anxiety reported.

Physical Examination:
Vital Signs: T 38.9 °C (102 °F), HR 112, RR 22, BP 138/84, SpO2 96% RA, Weight 82 kg (180 lb)
General: Appears ill, diaphoretic, in mild distress due to fever.
HEENT: Normocephalic, atraumatic, mucous membranes dry, oropharynx mildly erythematous, no exudate.
Neck: Supple, no lymphadenopathy, no JVD.
Cardiovascular: Regular rate, tachycardic, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, mild tachypnea, no rales or wheezes.
Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly.
Extremities: No edema, warm, pulses 2+ bilaterally.
Skin: No rash, no lesions, diaphoresis noted.
Neurologic: Alert, oriented x3, no focal deficits, gait normal.

Laboratory Data (drawn on 11/26/3057):
CBC: WBC 14.2 ×10^3/µL (neutrophils 84%), Hgb 12.1 g/dL, Hct 36%, Plt 312 ×10^3/µL
BMP: Na 138 mmol/L, K 4.5 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 22 mg/dL, Cr 1.8 mg/dL (baseline 1.6), Glucose 258 mg/dL
LFTs: AST 34 U/L, ALT 38 U/L, ALP 78 U/L, Total bili 0.9 mg/dL
CRP: 12.5 mg/dL (elevated)
Procalcitonin: 0.9 ng/mL
Lactate: 1.2 mmol/L
Urinalysis: Cloudy, WBC 15‑20/hpf, nitrites negative, leukocyte esterase +, glucose +, ketones trace.
Blood cultures: x2 drawn, pending.
Chest X‑ray: No infiltrates, cardiac silhouette normal.
Abdominal US (limited): No biliary dilation, kidneys normal size.

Assessment and Plan:
58yo F with T2DM, CKD3, HTN presenting with non‑localizing fever, leukocytosis, and possible urinary source vs. occult bacteremia. Differential includes UTI/pyelonephritis (despite lack of flank pain), early sepsis of unknown origin, diabetic ketoacidosis (glucose high but no anion gap acidosis), and drug‑induced fever (recent cefpodoxime unlikely). Plan:
1. Admit to Med floor, telemetry for cardiac monitoring given tachycardia.
2. Empiric IV antibiotics: Ceftriaxone 1 g q24h + Vancomycin dosed per PK (target trough 15‑20 µg/mL) pending cultures.
3. IV fluids: 0.9% NS 1 L bolus then maintenance 125 mL/hr; monitor input/output.
4. Diabetes management: Hold oral agents, start insulin sliding scale (IV regular insulin 0.1 U/kg q1h) and resume basal glargine at 20 U qd when glucose <200.
5. Renal: Adjust meds for Cr 1.8, hold furosemide, monitor electrolytes.
6. Fever work‑up: Blood cultures, repeat UA, consider CT abdomen/pelvis if no source after 48 h.
7. DVT prophylaxis: SQ enoxaparin 40 mg daily.
8. Continue home antihypertensives (lisinopril, amlodipine) unless hypotension develops.
9. Education: Discuss medication adherence, signs of worsening infection.
10. Consult Infectious Diseases if cultures grow resistant organism or no improvement by day 3.
Code Status: Full Code (Presumed)
Disposition: Anticipate 3‑5 day stay pending response to therapy.

Samantha Vale, MD
Attending Hospitalist
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (6, 6, 69581812629, 69581812629, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient:  Elena Marquez  
DOB: 03/14/3068  
MRN: 84276109  
PCP: Dr. Luis Ortega, MD  

Date of Admission: 01/26/3093  
Time: 04:47  
Location: MED01A  
Attending Provider: Dr. Samantha Varela, MD  

Chief Complaint/Reason for Admission: dysuria, suprapubic pain, fever  

History of Present Illness:  
58yo F w/ h/o HTN, CKD stage 3 (baseline Cr 1.6), DM2 (A1c 8.9%), recent prostatitis‑like episode (actually cystitis) p/w N/V/D and R flank pain 3 days ago. She presented to an outside ED on 01/23/3093 with temp 38.9°C, dysuria, urgency, suprapubic tenderness. UA showed +leukocyte esterase, nitrites, WBC 45/hpf. CT abdomen/pelvis negative for obstruction. Treated with PO ceftriaxone 500 mg BID and discharged after 6 h observation with instructions to complete 5‑day course. Since discharge, symptoms have worsened: now has persistent burning on voiding, increased frequency (Q1‑2 h), lower abdominal cramping, chills, and a new onset of mild left flank dullness. She reports no flank tenderness on exam at home, no gross hematuria, no flank mass. She denies recent sexual activity, new sexual partners, or use of spermicides. She reports compliance with meds but missed the last dose of ceftriaxone due to nausea. She also notes that she has been drinking 2‑3 glasses of water daily, but increased caffeine intake over past week. She denies recent travel, sick contacts, or catheter use. She presents now for re‑evaluation and admission for possible complicated UTI/pyelonephritis given CKD and persistent fever.

Past Medical History:  
• Hypertension – diagnosed 2025, on lisinopril 20 mg daily  
• Type 2 Diabetes Mellitus – on metformin 1000 mg BID, insulin glargine 20 U qHS  
• Chronic Kidney Disease Stage 3 – baseline eGFR ~45 mL/min/1.73 m²  
• Osteoarthritis – knees  
• Seasonal Allergic Rhinitis  

Past Surgical History:  
• Cholecystectomy – 04/12/3075  
• Appendectomy – 09/30/3060  

Family History:  
Father – HTN, died MI at 68  
Mother – CKD secondary to diabetes, alive 82  
Sister – healthy  

Social History:  
Tobacco – Never smoker  
Alcohol – Social, 1‑2 drinks/week  
Illicit Drugs – Denies  
Occupation – Administrative assistant, works from home  
Living Situation – Lives with husband, two adult children visiting weekly  

Allergies:  
No known drug allergies (NKDA)  

Medications Prior to Admission:  
lisinopril 20 mg PO daily  
metformin 1000 mg PO BID  
insulin glargine 20 U SC qHS  
furosemide 20 mg PO daily  
omeprazole 20 mg PO daily  

Review of Systems:  
Constitutional – fever, chills, fatigue, negative weight loss.  
HEENT – no sore throat, vision changes.  
Cardiovascular – no chest pain, palpitations.  
Respiratory – no cough, dyspnea.  
GI – N/V mild, no abdominal distention.  
GU – dysuria, urgency, suprapubic pain, left flank dullness, no hematuria.  
Musculoskeletal – mild knee OA pain.  
Neurologic – no headache, no focal deficits.  
Psychiatric – mood stable, no anxiety.  

Physical Examination:  
Vital Signs: T 38.4 °C, HR 102, RR 20, BP 138/78, SpO2 97% RA, Weight 78 kg (172 lb)  
General: Alert, appears mildly ill, NAD.  
HEENT: Normocephalic, PERRLA, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, mild suprapubic tenderness to palpation, no rebound, no guarding.  
GU: No CVA tenderness, left flank mild tenderness on deep palpation.  
Extremities: No edema, pulses 2+ bilat.  
Skin: Warm, dry, no rashes.  
Neuro: AOx3, grossly non‑focal.  

Laboratory Data (drawn 01/26/3093):  
CBC: WBC 14.2 K/µL (neutrophils 84%), Hgb 12.1 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.6, Cl 102, CO2 23, BUN 28 mg/dL, Cr 1.9 mg/dL (↑ from baseline 1.6)  
Glucose 182 mg/dL (random)  
CRP 12.5 mg/dL (elevated)  
Procalcitonin 0.68 ng/mL (moderately elevated)  

Urinalysis (point‑of‑care):  
Color yellow, Cloudy, pH 6.0, Specific Gravity 1.020  
Leukocyte esterase +2, Nitrite +, WBC 68/hpf, RBC 12/hpf, Bacteria many, Casts none  

Urine Culture: pending (specimen collected on admission)  

Blood Cultures: x2 sets, pending  

Imaging:  
Renal Ultrasound (01/26/3093): Kidneys normal size, no hydronephrosis, no stones.  

Assessment and Plan:  
58yo F with CKD3, DM2, HTN presenting with persistent febrile UTI likely progressing to acute pyelonephritis despite prior oral ceftriaxone course. Risk factors: CKD, diabetes, incomplete antibiotic course, possible resistant organism.  

1. Complicated UTI / possible pyelonephritis – start IV cefepime 2 g q8h (adjust for Cr) and oral ciprofloxacin 500 mg BID pending culture sensitivities. Hold ceftriaxone.  
2. Diabetes – continue insulin glargine; add correctional sliding scale (regular insulin 4 U qSL) while on steroids if needed.  
3. Hypertension – continue lisinopril; monitor BP and renal function.  
4. CKD – monitor daily BMP, adjust cefepime dose (Cr 1.9 → 2 g q12h).  
5. Fluid management – NS 125 mL/hr, reassess I/O; aim for euvolemia.  
6. Fever – acetaminophen 650 mg PO q6h PRN.  
7. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (hold if Cr >2.0).  
8. Monitoring – telemetry not required, but continuous pulse oximetry, q4h vitals, daily labs (CBC, BMP, CRP).  
9. Education – counsel on completing full antibiotic course, hydration, signs of worsening (increasing flank pain, rigors).  

Disposition: Admit to General Medicine floor, anticipate 4‑5 day stay pending clinical response and culture results. Code Status: Full Code (Presumed).  

Samantha Varela, MD  
Attending Physician  
Pager: 22458');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (7, 7, 97738540490, 97738540490, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Ethan Marlowe
DOB: 02/14/3065
MRN: 84276109
PCP: Lila Hart, MD

Date of Admission: 07/10/3091
Time: 17:41
Location: MED01 – Internal Medicine
Attending: Dr. Victor Selby, MD
Admitting Resident: Dr. Maya Chen, MD

Chief Complaint:
Fever, chills, and erythematous right subclavian PICC line site x3 days.

History of Present Illness:
26yo M with h/o cholecystectomy 2 wk ago (lap, uncomplicated), T2DM (A1c 8.1%), HTN, and recent PICC line placement for TPN now p/w fever up to 39.4°C, rigors, localized pain and erythema over right mid‑clavicular line. Pt reports line was placed 10 days post‑op, used for TPN for 7 days, removed 4 days ago after TPN completion. Since removal, he notes “red spot” that has enlarged, now tender, with serous drainage. He denies SOB, cough, chest pain, dysuria, or abdominal pain. He reports mild nausea but no vomiting, no diarrhea. He took acetaminophen at home with minimal relief. He was seen in the ED 2 days ago; vitals: T 38.9°C, HR 112, BP 128/78, RR 20, SpO2 98% RA. Labs then showed WBC 14.2, CRP 12.5 mg/dL. Blood cultures drawn, pending. He was discharged on oral cefpodoxime 200 mg BID pending results, but symptoms worsened, prompting return. He denies recent travel, sick contacts, or animal exposure. No known drug allergies.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2019, on metformin 1000 mg BID
• Hypertension – on lisinopril 10 mg daily
• Obesity – BMI 32 kg/m²
• Recent laparoscopic cholecystectomy – 07/01/3091

Past Surgical History:
• Laparoscopic cholecystectomy – 07/01/3091
• PICC line insertion – 07/03/3091 (right subclavian)

Family History:
Father – HTN, MI at 58
Mother – T2DM
Sister – healthy
No known hereditary cancers.

Social History:
Tobacco – never
Alcohol – occasional social (1‑2 drinks/week)
Illicit drugs – denies
Occupation – software engineer, works from home
Living situation – lives with partner, no pets
Sexual activity – monogamous, uses condoms intermittently

Review of Systems:
Constitutional: +fever, chills, fatigue; -weight loss, night sweats.
HEENT: -headache, vision changes, sore throat.
Cardiovascular: -chest pain, palpitations.
Respiratory: -cough, dyspnea, wheeze.
Gastrointestinal: +nausea, -vomiting, -diarrhea, -abdominal pain.
Genitourinary: -dysuria, -frequency.
Musculoskeletal: +tenderness at PICC site; -myalgias.
Skin: +erythema, warmth, serous drainage at line site; -rashes elsewhere.
Neurologic: -dizziness, -syncope.
Psychiatric: -anxiety, -depression.

Prior to Admission Medications:
metformin 1000 mg PO BID
lisinopril 10 mg PO daily
atorvastatin 20 mg PO nightly
insulin glargine 20 U SC qd (prn for BG >180)
vitamin D3 2000 IU PO daily

Physical Examination:
Vital Signs: T 38.9°C, HR 115, RR 22, BP 130/76, SpO2 97% RA, Weight 92 kg, Height 1.78 m, BMI 29.0.
General: Alert, appears mildly ill, diaphoretic.
HEENT: Normocephalic, PERRLA, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no rales or wheezes.
Abdomen: Soft, non‑tender, surgical scar well healed, no masses.
Extremities: Right mid‑clavicular area – 4 cm erythematous plaque with central induration, mild warmth, serous drainage noted; no fluctuance. No edema elsewhere.
Skin: No petechiae, no other lesions.
Neurologic: AOx3, CN II‑XII grossly intact, strength 5/5 all extremities.
Psych: Cooperative, mood appropriate.

Laboratory Data (drawn 07/10/3091):
CBC: WBC 15.8 K/µL (neut 88%), Hgb 13.2 g/dL, Hct 39.5%, Plt 312 K/µL.
BMP: Na 138 mmol/L, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.9 mg/dL, Glucose 162 mg/dL.
CRP: 13.2 mg/dL
Procalcitonin: 0.78 ng/mL
Blood cultures x2: pending (pre‑antibiotic)
Lactate: 1.2 mmol/L
Urinalysis: normal.

Imaging:
Chest X‑ray (PA, 07/10/3091): No infiltrates, clear lung fields, normal cardiac silhouette.
Right upper extremity ultrasound (07/10/3091): No deep vein thrombosis; superficial soft‑tissue edema over PICC site, no abscess cavity.

Assessment and Plan:
58yo M with recent PICC line for TPN now presenting with line‑associated infection (likely MSSA) – fever, localized erythema, positive inflammatory markers. Blood cultures pending; start empiric IV vancomycin 15 mg/kg q12h and cefazolin 2 g q8h pending sensitivities. Remove any residual catheter fragments; obtain wound cultures from drainage. Continue TPN discontinued. Monitor vitals q4h, CBC q12h, CRP daily. If abscess develops, consider IR‑guided drainage. DVT prophylaxis with SQ enoxaparin 40 mg daily. Continue home antihypertensives and metformin; hold insulin glargine until glucose <180. Diabetes management with sliding scale insulin as needed. Encourage fluid intake, maintain NPO until infection controlled, then advance diet as tolerated. Infectious Diseases consult placed. Education on line care, signs of infection. Anticipate discharge to home with PICC line removed, oral cephalexin 500 mg q6h for total 10‑day course after afebrile ≥48 h. Code Status: Full Code.  

Victor Selby, MD
Attending Physician
07/10/3091 18:05');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (8, 8, 70710239527, 70710239527, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
12/09/3070 00:03  

Patient: Ethan J. Cellulitis  
DOB: 03/14/3012  
MRN: 98765432  
PCP: Dr. Lila Hart, MD  

CHIEF COMPLAINT: Right lower leg swelling, erythema, pain  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o T2DM (A1c 8.7%), CKD stage 3, HTN, and recent plantar ulcer p/w erythema, warmth, swelling of RLE presents to ED after 2 days of progressive pain and expanding erythema from mid‑calf to ankle. Pt reports the ulcer began after a minor foot trauma while gardening 5 days ago; he self‑treated with OTC bacitracin and kept foot dry. Yesterday he noted increasing redness, throbbing pain, low‑grade fever (T 100.4 °F at home) and difficulty ambulating. Went to urgent care on 12/07/3070, received PO clindamycin 300 mg q8h and ibuprofen, but symptoms worsened, now with streaking erythema up the posterior calf and a tender, indurated area ~12 × 8 cm. Denies dysuria, SOB, chest pain, N/V, or recent travel. No known sick contacts. No prior similar episodes. Review of outside records shows WBC 13.2 K/µL, CRP 12 mg/dL. Pt was given a dose of IV ceftriaxone in urgent care and transferred for IV antibiotics and possible imaging.  

PAST MEDICAL HISTORY:  
• Type 2 diabetes mellitus – diagnosed 2015, on insulin glargine 30 U qHS and metformin 1000 mg BID  
• Hypertension – on lisinopril 20 mg daily  
• Chronic kidney disease stage 3 (eGFR 45 mL/min)  
• Hyperlipidemia – rosuvastatin 10 mg nightly  
• Peripheral neuropathy – diabetic  

PAST SURGICAL HISTORY:  
• Appendectomy – 2008, laparoscopic  
• Right foot debridement – 12/01/3069 for ulcer (wound healed)  

FAMILY HISTORY:  
Father – HTN, MI at 62  
Mother – DM2, CKD  
Brother – alive, no chronic illness  

SOCIAL HISTORY:  
Marital status: Married, spouse Jane C. Cellulitis  
Occupation: Maintenance supervisor at municipal water plant  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 beers/week  
Illicit drugs: Denies  
Living situation: Owns single‑family home, two adult children living out of state  
Travel: No recent travel, works locally  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills denied, fatigue present.  
HEENT: No sore throat, vision changes.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No cough, dyspnea.  
GI: No N/V, abdominal pain.  
GU: No dysuria, frequency.  
Musculoskeletal: Right lower leg pain, swelling, erythema.  
Skin: No rash elsewhere, ulcer on plantar surface noted.  
Neurologic: No headache, dizziness.  
Psych: Mood stable, no depression.  

PRIOR TO ADMISSION MEDICATIONS:  
metformin 1000 mg PO BID  
insulin glargine 30 U SC qHS  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
aspirin 81 mg PO daily  

ALLERGIES: No known drug allergies (NKDA)  

PHYSICAL EXAMINATION:  
Vital Signs: Temp 38.2 °C (100.8 °F), HR 102, RR 18, BP 138/84, SpO2 96 % RA, Weight 112 kg (247 lb)  

General: Alert, appears mildly ill, in mild distress due to leg pain.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: Supple, no JVD.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.  

Respiratory: Clear to auscultation bilaterally, no wheezes.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Right lower leg – diffuse erythema from mid‑calf to ankle, warm, tender to palpation, indurated, fluctuance absent, no crepitus. Area ~12 × 8 cm, edema present, calf compartments soft, dorsalis pedis pulse 2+ bilaterally, posterior tibial 2+ bilaterally. No ulcer drainage noted at time of exam. No stasis changes. Left leg normal.  

Skin: No rashes elsewhere, no petechiae.  

Neuro: AO×3, grossly non‑focal.  

LABORATORY DATA (drawn on admission):  
CBC: WBC 14.1 K/µL, Hgb 12.3 g/dL, Hct 37 %, Plt 312 K/µL  
BMP: Na 138, K 4.6, Cl 102, CO2 23, BUN 22, Cr 1.6 (baseline 1.4), Glu 182 mg/dL  
CRP: 15 mg/dL (elevated)  
ESR: 48 mm/hr  
Procalcitonin: 0.9 ng/mL  
Blood cultures x2: pending  

IMAGING:  
Right lower extremity X‑ray (12/09/3070): No fracture, no gas in soft tissues.  
Duplex US of right leg (12/09/3070): No DVT, compressible veins.  

ASSESSMENT/PLAN:  
58yo M with DM2, CKD3, HTN and recent plantar ulcer now presenting with acute cellulitis of right lower leg, likely streptococcal (possible MRSA) – start IV cefazolin 2 g q8h; add vancomycin 15 mg/kg q12h pending cultures given CKD and risk factors. Hold metformin (AKI risk). Continue insulin glargine, hold lisinopril today (BP stable).  

- Admit to med‑surg floor, telemetry not required.  
- IV fluids NS 125 mL/hr, monitor urine output.  
- Wound care consult for debridement assessment.  
- Infectious disease consult for antibiotic stewardship.  
- DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
- Stress ulcer prophylaxis: PO pantoprazole 40 mg daily.  
- Daily CBC, BMP, CRP q48h.  
- Re‑evaluate for surgical intervention if worsening.  
- Education: leg elevation, wound hygiene, glucose control.  
- Code status: Full Code (Presumed).  
- Disposition: anticipate 4‑5 day stay, discharge to home with home health nursing for IV antibiotics if clinical improvement.  

“Portion of this record may have been generated with voice recognition; occasional transcription errors possible – please verify.”  

Dr. Maya L. Rivera, MD  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (9, 9, 50196317731, 50196317731, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
07/18/3050 21:54  

Patient: Ethan Marlowe  
DOB: 02/14/3015  
PCP: Dr. Lila Hart, MD  

CHIEF COMPLAINT: Left lower leg swelling, erythema, pain  

HISTORY OF PRESENT ILLNESS:  
35yo M with h/o T2DM (A1c 8.7% 06/2025), obesity (BMI 34), prior left leg cellulitis 2022, and chronic venous insufficiency p/w acute left lower leg swelling, erythema, warmth, and throbbing pain x 3 days. Patient reports a minor scrape on the medial shin while gardening 4 days ago, initially brushed off, but over the past 48 hrs the area became increasingly red, now extending from the ankle to mid‑calf with a well‑demarcated, raised border. He noted feverish chills, subjective fever up to 101°F, and malaise. Went to urgent care on 07/15/3050, was given oral clindamycin 300 mg q6h and instructed to elevate leg; after 24 hrs symptoms worsened, new purulent drainage noted, and he now has difficulty ambulating. Denies shortness of breath, chest pain, dysuria, or recent travel. No known sick contacts. No prior MRSA colonization.  

Outside Hospital Course: Urgent care labs showed WBC 13.2 K/µL, CRP 12 mg/dL. No imaging performed. Patient received one dose of PO clindamycin then left.  

Review of Systems (pertinent positives/negatives):  
CONSTITUTIONAL: Fever, chills, fatigue – positive. Weight loss – negative.  
SKIN: Left lower leg erythema, swelling, pain, purulent drainage – positive. Other rashes – negative.  
CARDIOVASCULAR: No chest pain, palpitations – negative.  
RESPIRATORY: No cough, dyspnea – negative.  
GI: No nausea, vomiting, abdominal pain – negative.  
GU: No dysuria, hematuria – negative.  
NEURO: No headache, dizziness – negative.  
HEMATOLOGIC: No easy bruising, bleeding – negative.  

MEDICAL & SURGICAL HISTORY:  

Past Medical History:  
• Type 2 diabetes mellitus (diagnosed 2018)  
• Obesity (BMI 34)  
• Chronic venous insufficiency (right lower extremity)  
• Hypertension (controlled)  

Past Surgical History:  
• Appendectomy – 12/2010  
• Right inguinal hernia repair – 06/2022  

FAMILY HISTORY:  
Father – HTN, MI at 58; Mother – T2DM; Sister – healthy; No known hereditary disorders.  

SOCIAL HISTORY:  
Marital status: Single, lives alone in an apartment.  
Employment: Warehouse supervisor, shift work, frequent standing.  
Tobacco: Never smoker.  
Alcohol: Social beer 1–2 drinks/week.  
Illicit drugs: Denies.  
Travel: No recent travel.  
Housing: Stable, no homelessness.  

ALLERGIES: No known drug allergies (NKDA).  

PRIOR TO ADMISSION MEDICATIONS:  
metformin 1000 mg PO BID  
lisinopril 20 mg PO daily  
atorvastatin 40 mg PO nightly  
insulin glargine 30 U SC qHS  
aspirin 81 mg PO daily  

PHYSICAL EXAMINATION:  
Vital Signs: Temp 38.4 °C (101.1 °F), HR 112, RR 20, BP 138/84, SpO2 97% RA, Pain score 7/10.  

General: Alert, appears mildly ill, in mild distress due to leg pain.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: Supple, no JVD.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Left lower leg edematous, erythematous from ankle to mid‑calf, warm, tender to palpation, ill‑defined raised border, area of purulent drainage over medial shin, no crepitus. No fluctuance noted. No ulcerations. Right leg: mild varicosities, no edema. No calf tenderness suggestive of DVT. Pulses 2+ bilaterally.  

Skin: No petechiae, no rash elsewhere.  

Neuro: Alert and oriented x3, grossly non‑focal.  

LABORATORY DATA (STAT):  
CBC: WBC 14.1 K/µL (Neut 88%), Hgb 13.2 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 16, Cr 0.9, Glucose 212 mg/dL  
CRP: 15 mg/dL (elevated)  
ESR: 48 mm/hr  
Lactate: 1.2 mmol/L  
Blood cultures: x2 sets drawn, pending  

IMAGING:  
Left lower extremity duplex ultrasound (07/18/3050): No DVT, arterial flow normal, subcutaneous edema noted.  

ASSESSMENT / PLAN:  
1. LEFT LOWER LEG CELLULITIS – likely polymicrobial, concern for MRSA given purulent drainage and prior clindamycin failure.  
   • Start IV cefazolin 2 g q8h + add IV vancomycin loading dose then adjust per trough.  
   • Obtain wound cultures from drainage.  
   • Elevate leg, compression stockings as tolerated, wound care consult.  
   • Monitor vitals, CBC, CRP q24h.  

2. TYPE 2 DIABETES – hyperglycemia on admission.  
   • Continue insulin glargine; add correctional sliding scale insulin (IV regular insulin infusion if glucose >250).  

3. HYPERTENSION – continue lisinopril PO daily.  

4. OBESITY – dietitian consult for calorie‑controlled diabetic diet.  

5. DVT PROPHYLAXIS – SQ enoxaparin 40 mg SC daily.  

6. PAIN MANAGEMENT – IV acetaminophen 1 g q6h PRN, consider oral ibuprofen if no contraindication.  

7. CODE STATUS: Full Code (Presumed).  

8. DISPOSITION: Admit to General Medicine floor, telemetry not required.  

9. CONSULTS: Infectious Diseases for antibiotic stewardship, Wound Care for possible debridement.  

10. PATIENT EDUCATION: Discuss signs of worsening infection, importance of leg elevation, glucose monitoring, and follow‑up.  

Signature:  
Dr. Mara L. Keene, MD  
Hospitalist Attending  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (10, 10, 83755820021, 83755820021, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 10/23/3064 07:22  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  

Patient: Marcus L. Whitaker  
DOB: 02/14/3019 (45 y/o)  
MRN: 98765432  
PCP: Dr. Samuel Greene, MD  

Chief Complaint: SOB and increased sputum production  

History of Present Illness:  
45yo M with severe COPD (GOLD D, home O2 2Lpm qhs), chronic bronchiectasis, and 30‑pack‑yr smoking hx (quit 5 y ago) presents w/ 3‑day worsening dyspnea, productive cough now yellow‑green sputum (~150 mL/d), low‑grade fever (Tmax 38.2 °C at home). He reports using albuterol MDI q2h with minimal relief, and his nightly nocturnal O2 requirement increased from 2 L to 4 L. Denies chest pain, palpitations, calf pain, or recent travel. He was seen at an urgent care 2 days ago, given a 5‑day course of azithro 500 mg PO daily which he completed; symptoms progressed despite therapy. He reports recent exposure to a neighbor with “bad cold” 1 wk ago. No prior hospitalizations for COPD exacerbation in past year, but had one admission 3 yrs ago requiring NPPV. He uses home inhalers: albuterol 90 µg MDI 2‑4 puffs q4h PRN, tiotropium 18 µg inhaled daily, and a rescue nebulizer (ipratropium/albuterol) at home. He also uses a portable O2 concentrator. He denies recent steroid use.  

Past Medical History:  
• COPD, severe, chronic bronchitis phenotype  
• Bronchiectasis, right lower lobe  
• Hypertension  
• Hyperlipidemia  

Past Surgical History:  
• Appendectomy – 2005  
• Right knee arthroscopy – 2018  

Family History:  
Father – CAD, died 58 y (MI)  
Mother – HTN, alive 78 y  
Brother – asthma  

Social History:  
Tobacco: 30‑pack‑yr, quit 5 y ago (never vaped)  
Alcohol: Social, 1‑2 beers/week  
Illicit drugs: Denies  
Occupation: Maintenance supervisor at a manufacturing plant (exposure to dust)  
Living situation: Lives with spouse, no pets  

Review of Systems:  
Constitutional: Positive for fever, fatigue; negative for weight loss.  
HEENT: Negative for sore throat, sinus pain.  
Respiratory: Positive for dyspnea at rest, increased sputum, wheezes; negative for hemoptysis.  
Cardiovascular: Negative for chest pain, palpitations.  
GI: Negative for nausea, vomiting, diarrhea.  
GU: Negative.  
Musculoskeletal: Negative for joint pain.  
Neuro: Negative.  
Psych: Negative.  

Prior to Admission Medications:  
Medication                Sig  
Albuterol 90 µg MDI       2‑4 puffs q4h PRN  
Ipratropium/albuterol Neb 2 mL q4h PRN (home)  
Tiotropium Respimat 18 µg 1 inhalation daily  
Fluticasone/salmeterol 250/50 µg DPI 1 inhalation BID  
Lisinopril 20 mg PO daily  
Atorvastatin 40 mg PO nightly  
Aspirin 81 mg PO daily  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs (at 07:30):  
Temp: 37.9 °C (100.2 °F)  
HR: 112 bpm (range 60‑100)  
RR: 24 /min (range 12‑20)  
BP: 138/84 mmHg (range 110‑140/70‑90)  
SpO2: 88 % on room air, 94 % on 4 L nasal cannula  
Weight: 84 kg (185 lb)  

General: Alert, mildly diaphoretic, in mild respiratory distress, using accessory muscles.  
HEENT: Normocephalic, oropharynx clear, no tonsillar erythema.  
Neck: Supple, no JVD.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Diffuse wheezes bilaterally, coarse crackles at right lower base, decreased breath sounds RLL.  
Abdomen: Soft, NT/ND, BS present.  
Extremities: No edema, pulses 2+ bilat, no calf tenderness.  
Skin: Warm, no rashes.  
Neuro: AOx3, no focal deficits.  

Diagnostics:  
CBC: WBC 14.2 ×10⁹/L (neut 82 %), Hgb 13.1 g/dL, Plt 312 ×10⁹/L  
BMP: Na 138, K 4.3, Cl 102, CO₂ 22, BUN 16, Cr 0.9, Glu 112  
ABG (room air): pH 7.32, PaCO₂ 58 mmHg, PaO₂ 58 mmHg, HCO₃⁻ 28 (acute on chronic resp acidosis)  
CRP: 12 mg/L (elevated)  
Procalcitonin: 0.18 ng/mL (low)  
Chest X‑ray: Hyperinflated lungs, flattening of diaphragms, increased interstitial markings, right lower lobe infiltrate consistent with bronchopneumonia.  
CT Thorax (non‑contrast): Confirmed right lower lobe bronchiectatic changes with focal consolidation, no PE.  
EKG: Sinus tachycardia, HR 112, no ischemic changes.  

Assessment and Plan:  
1. Acute COPD exacerbation, likely bacterial bronchopneumonia (right lower lobe).  
   • Start IV methylprednisolone 40 mg q24h x 3 days then PO taper.  
   • Continue nebulized ipratropium/albuterol q4h + add IV ceftriaxone 2 g q24h and azithromycin 500 mg IV q24h for 5 days.  
   • Initiate BiPAP for respiratory support (IPAP 12, EPAP 6) if SpO₂ < 90 % despite 4 L O₂.  
   • Continue home tiotropium and fluticasone/salmeterol; hold inhaled steroids if hypercapnia worsens.  
   • Monitor ABG q6h, electrolytes daily.  

2. Chronic hypercapnic respiratory failure.  
   • Maintain O₂ target 88‑92 % on nasal cannula; avoid over‑oxygenation.  
   • Pulmonary rehab consult for optimization of inhaler technique.  

3. Hypertension, controlled.  
   • Continue lisinopril 20 mg PO daily; monitor BP q8h.  

4. Hyperlipidemia.  
   • Continue atorvastatin 40 mg nightly.  

5. DVT prophylaxis.  
   • SQ enoxaparin 40 mg SC daily (adjust for renal if needed).  

6. Nutrition.  
   • Diet: Regular, high‑protein, low‑salt.  

7. Disposition.  
   • Admit to Med‑Surg floor with telemetry; consider step‑down if stable after 48 h.  

Code Status: Full Code (Presumed)  

Signature:  
Evelyn Hartwell, MD  
Attending Hospitalist  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (11, 11, 96193705092, 96193705092, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Michael Example
MRN: 98765432
DOB: 03/22/3035
Age: 29 y/o
PCP: Dr. Linda Sample, MD

Date of Admission: 11/10/3064
Time: 14:48
Location: EXAMP03
Attending Provider: Dr. Samantha Realname, MD
Admitting Resident: Dr. Aaron Intern, MD

Chief Complaint: Cough, dyspnea, fever

History of Present Illness:
29yo M with h/o mild intermittent asthma (SABA PRN), HTN (lisinopril 10 mg daily), recent URI p/w 5‑day productive cough, fever up to 102.4°F, pleuritic chest pain, SOB on exertion, and fatigue. Symptoms began 5 days ago after a weekend camping trip; he reports exposure to smoke from campfire and a roommate with “cold” symptoms. He self‑treated with ibuprofen and guaifenesin, but cough worsened, now producing yellow‑green sputum. Yesterday he presented to the outside ED (St. Mercy Hospital) where vitals were T 101.8°F, HR 112, RR 22, SpO2 94% RA. Labs showed WBC 14.2 K with left shift, CRP 12 mg/dL. CXR demonstrated right lower lobe infiltrate. He received 1 L NS, IV ceftriaxone 1 g, and azithromycin 500 mg, then was transferred for higher‑level care. He denies chest pain radiating, orthopnea, PND, leg swelling, hemoptysis, recent travel, or sick contacts beyond roommate. No known drug allergies. He reports occasional alcohol (2‑3 beers/week) and denies tobacco or illicit drug use.

Review of Systems:
Constitutional: +fever, +fatigue, -chills, -weight loss.
HEENT: +sore throat, -vision changes.
Respiratory: +cough with purulent sputum, +dyspnea on exertion, -hemoptysis, -wheezing.
Cardiovascular: -chest pain, -palpitations, -edema.
GI: -nausea, -vomiting, -diarrhea.
GU: -dysuria, -frequency.
Musculoskeletal: -myalgias.
Neurologic: -headache, -dizziness.
Psychiatric: -anxiety, -depression.
Skin: -rashes.

Past Medical History:
• Asthma, intermittent
• Hypertension
• Seasonal allergic rhinitis

Past Surgical History:
• Appendectomy – 2022
• Right ankle fracture repair – 2029

Family History:
Father: HTN, MI at 58
Mother: DM2, alive
Sister: Healthy
No known hereditary diseases.

Social History:
Marital Status: Single, lives alone in apartment.
Occupation: Software engineer, works from home.
Tobacco: Never
Alcohol: Social, 2‑3 beers/week
Illicit drugs: Denies
Travel: None recent
Vaccinations: Up to date, COVID‑19 booster 2024.

Medications Prior to Admission:
lisinopril 10 mg PO daily
albuterol inhaler PRN
ibuprofen 600 mg PO q6h PRN for pain

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 101.2°F, HR 108, RR 20, BP 128/76, SpO2 94% on RA, Weight 82 kg, Height 178 cm, BMI 25.9
General: Alert, appears mildly ill, in no acute distress.
HEENT: Normocephalic, oropharynx erythematous, no exudates.
Neck: Supple, no JVD, no lymphadenopathy.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Decreased breath sounds RLL, crackles + at right base, no wheezes.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: No edema, pulses 2+ bilaterally.
Skin: Warm, dry, no rashes.
Neuro: AOx3, CN II‑XII grossly intact.

Data/Results:
CBC: WBC 14.2 K (Neut 82%), Hgb 13.1 g/dL, Hct 39%, Plt 312 K
BMP: Na 138, K 4.1, Cl 102, CO2 24, BUN 12, Cr 0.78, Glu 112
CRP: 12 mg/dL
Procalcitonin: 0.45 ng/mL
CXR (PA/Lat): Right lower lobe air‑space opacity consistent with lobar pneumonia, no effusion.
CT Chest (without contrast): Confirms RLL consolidation, no cavitation, no PE.
Blood cultures: x2 pending.
Sputum Gram stain: Gram‑positive cocci in pairs, many PMNs.
EKG: Sinus tachycardia, HR 108, no ischemic changes.

Assessment and Plan:
29yo M with community‑acquired pneumonia (CAP) likely bacterial (S. pneumoniae) based on RLL infiltrate, purulent sputum, elevated WBC, and Gram‑positive cocci on sputum. He is hemodynamically stable, mild hypoxemia, no ICU criteria.

1. Antibiotics: Continue ceftriaxone 1 g IV q24h + azithromycin 500 mg PO daily x5 days. Re‑evaluate culture results for de‑escalation.
2. Oxygen: Maintain SpO2 > 92% on RA; if drops, start 2 L NC.
3. Fluids: Continue NS 125 mL/hr; monitor I/O.
4. VTE prophylaxis: Enoxaparin 40 mg SC daily.
5. Cardiac monitoring: Telemetry for 24 h given tachycardia.
6. Labs: Repeat CBC, BMP, CRP q48h; hold cultures until final.
7. Disposition: Admit to medical floor, anticipate 3‑4 day stay, reassess for step‑down if improving.
8. Education: Discuss smoking cessation (though non‑smoker), adherence to antibiotics, signs of worsening.
9. Follow‑up: Infectious Diseases consult if no improvement by day 3 or if atypical pathogen suspected.

Code Status: Full Code (Presumed)
Level of Care: Medical Floor, Telemetry
Diet: Regular, encourage oral hydration.

Signature:
Dr. Samantha Realname, MD
Attending Physician
Hospital Medicine Service
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (12, 12, 37142384425, 37142384425, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'PATIENT: Ethan Marlowe
MRN: 84276109
DOB: 09/15/3045
PCP: Dr. Lila Hart, MD

DATE OF ADMISSION: 05/02/3077
TIME: 05:29
ADMITTING ATTENDING: Dr. Victor Selby, MD
LOCATION: MED01
SERVICE: Hospital Medicine

CHIEF COMPLAINT: SOB, progressive dyspnea, respiratory distress

HISTORY OF PRESENT ILLNESS:
31yo M with h/o moderate COPD (GOLD II), HTN, and recent URI p/w worsening dyspnea, hypoxemia, and hypercapnia without fever. Patient reports 3‑day history of increasing shortness of breath that began after a weekend camping trip where he was exposed to cold, damp air and did not use his rescue inhaler until yesterday. He notes a dry cough, no sputum, denies chest pain, fever, chills, or rigors. Yesterday night he felt “air hunger,” was unable to speak full sentences, and his wife called EMS. EMS noted RR 32, SpO2 84% on RA, placed on non‑rebreather 15L, and transported to ED. In ED ABG showed pH 7.28, PaCO2 68, PaO2 55 on 15L O2. He was placed on BiPAP with improvement to SpO2 92% but remains tachypneic. He denies recent travel, sick contacts, or known COVID‑19 exposure. Home meds include tiotropium inhaler daily, albuterol PRN, lisinopril 10 mg daily, and low‑dose aspirin. He reports good compliance with inhalers but ran out of albuterol two days ago. No prior intubations. No known drug allergies.

PAST MEDICAL HISTORY:
• COPD, diagnosed 2029, GOLD stage II
• Hypertension
• Seasonal allergic rhinitis

PAST SURGICAL HISTORY:
• Appendectomy – 2035
• Right knee arthroscopy – 2048

FAMILY HISTORY:
Father – HTN, died of MI at 68
Mother – COPD, alive 78
Sister – healthy

SOCIAL HISTORY:
Tobacco: 1 pack/day since age 18, quit 2 years ago
Alcohol: occasional beer, <2 drinks/week
Illicit drugs: denies
Occupation: HVAC technician, works indoors, occasional exposure to dust
Living situation: lives with partner, no pets

REVIEW OF SYSTEMS:
Constitutional – negative for fever, chills, weight loss
HEENT – mild nasal congestion, no sore throat
Cardiovascular – denies chest pain, palpitations
Respiratory – progressive dyspnea, dry cough, no sputum, no wheeze reported at home
GI – N/V negative, normal appetite
GU – no dysuria
Neuro – no headache, dizziness
Skin – no rashes
Psych – no anxiety/depression noted

MEDICATIONS PRIOR TO ADMISSION:
tiotropium inhaler 18 mcg daily
albuterol inhaler 90 mcg PRN – last used 2 days ago
lisinopril 10 mg PO daily
aspirin 81 mg PO daily

ALLERGIES:
No known drug allergies

VITAL SIGNS ON ADMISSION:
Temp: 36.7 °C (98.1 °F)
HR: 112 bpm
RR: 30 breaths/min
BP: 138/78 mmHg
SpO2: 92% on BiPAP (IP 12 cmH2O, EP 6 cmH2O, FiO2 0.45)
Weight: 84 kg (185 lb)

PHYSICAL EXAMINATION:
GENERAL: Alert, in mild respiratory distress, using accessory muscles
HEENT: Normocephalic, atraumatic, mucous membranes moist
NECK: Supple, no JVD
CARDIOVASCULAR: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops
RESPIRATORY: Diffuse expiratory wheezes bilaterally, decreased breath sounds at bases, no crackles, hyperinflation noted
ABDOMEN: Soft, non‑tender, normoactive bowel sounds
EXTREMITIES: No edema, pulses 2+ bilaterally
SKIN: Warm, dry, no rashes
NEURO: AOx3, no focal deficits

LABORATORY DATA (ED):
CBC: WBC 9.2 K/µL, Hgb 13.4 g/dL, Plt 242 K/µL
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 112
ABG (on BiPAP FiO2 0.45): pH 7.28, PaCO2 68, PaO2 55, HCO3‑ 30, SaO2 92%
Lactate: 1.1 mmol/L
Troponin I: <0.01 ng/mL
Procalcitonin: 0.07 ng/mL

IMAGING:
CXR (PA/LAT): Hyperinflated lungs, flattened diaphragms, no infiltrates, no effusion.
CT Thorax (non‑contrast): No pulmonary embolus, no focal consolidation, diffuse emphysematous changes.

ASSESSMENT:
31yo M with known moderate COPD presenting with acute hypercapnic respiratory failure secondary to COPD exacerbation, no fever, no radiographic pneumonia. Contributing factors likely cold/damp exposure and suboptimal bronchodilator use. Mild hypertension well controlled. No evidence of acute coronary syndrome or PE.

PLAN:
1. Respiratory support: Continue BiPAP, target SpO2 90‑94%, monitor ABGs q4h. If worsening hypercapnia or fatigue, consider intubation.
2. Pharmacotherapy:
   - IV methylprednisolone 40 mg q8h × 3 days, then PO prednisone taper.
   - Nebulized albuterol 2.5 mg q4h + ipratropium 0.5 mg q4h.
   - Continue tiotropium inhaler daily.
   - Start azithromycin 500 mg PO daily × 5 days (cover atypical bacteria per COPD guidelines).
3. Antibiotics: Hold ceftriaxone unless sputum cultures later show bacterial infection.
4. Fluid management: Maintain euvolemia, isotonic fluids as needed.
5. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
6. Cardiac monitoring: Telemetry for arrhythmia surveillance.
7. Labs: Repeat BMP, CBC, ABG in 6 hours, then daily.
8. Education: Reinforce inhaler technique, ensure rescue inhaler refilled, smoking cessation counseling (though quit 2 yrs ago).
9. Disposition: Anticipate ICU step‑down if stable on BiPAP; otherwise consider floor with continued non‑invasive ventilation.
10. Code status: Full Code (Presumed).

FOLLOW‑UP:
Pulmonology consult placed for possible inpatient pulmonary rehab and evaluation for long‑term home BiPAP. Physical therapy for ambulation. Discharge planning to include home health respiratory therapist.

Victor Selby, MD
Hospital Medicine Attending
Pager: 22457');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (13, 13, 70148484267, 70148484267, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Elena Marquez  
DOB: 07/14/3064  
MRN: 84201957  
PCP: Dr. Luis Ortega, MD  

Admission Date/Time: 03/31/3092 04:45  
Location: MED01 – General Medicine Floor  
Attending: Dr. Priya K. Desai, MD  

Chief Complaint: Cough, dyspnea, fever  

History of Present Illness:  
58yo F with h/o COPD (GOLD 2), HTN, DM2 (A1c 8.1%), recent URI p/w 5d of productive cough, fever (Tmax 102.4°F), SOB on exertion, pleuritic chest pain, and fatigue. She reports that 6 days ago she began feeling “scratchy” in the throat after a weekend visit to her granddaughter’s birthday party where she was in a crowded indoor space. Over the next 48 h she developed a low‑grade fever and a dry cough that progressed to a thick, yellow‑green sputum. Yesterday she noted worsening shortness of breath, now at rest, and a new sharp pain on the right lower chest that worsens with deep breaths. She denies hemoptysis, wheezing, orthopnea, PND, leg swelling, recent travel, or known sick contacts. She took ibuprofen 400 mg q6h at home with minimal relief. She presents to the ED after EMS transport; EMS noted HR 112, RR 24, SpO2 91% on room air, BP 138/78. In the ED she received 2 L NS, albuterol nebulizer, and a dose of IV ceftriaxone 1 g. CXR showed right lower lobe infiltrate. She was placed on supplemental O₂ 2 L NC en route to floor.  

Past Medical History:  
- COPD, diagnosed 2018, on tiotropium/olodaterol inhaler BID  
- Hypertension, on lisinopril 20 mg daily  
- Type 2 Diabetes Mellitus, on metformin 1000 mg BID, insulin glargine 20 U qHS  
- Hyperlipidemia, on rosuvastatin 10 mg daily  
- Osteoarthritis, intermittent NSAIDs  

Past Surgical History:  
- Cholecystectomy – laparoscopic, 04/12/3075  
- Right total knee arthroplasty – 09/03/3082  

Family History:  
- Mother: HTN, died of stroke at 78  
- Father: COPD, died of MI at 71  
- Sister: DM2, alive 62  

Social History:  
- Tobacco: 1 pack/day for 30 y, quit 2 y ago (former smoker)  
- Alcohol: occasional wine, 1‑2 glasses/week  
- Illicit drugs: denies  
- Occupation: Retired schoolteacher, lives with husband, 2 adult children, no pets  
- Housing: Single‑family home, stable  

Review of Systems:  
Constitutional: fever, chills, fatigue, weight stable.  
HEENT: sore throat resolved, no sinus pain.  
Respiratory: productive cough, dyspnea, pleuritic chest pain, no wheeze.  
Cardiovascular: denies chest pressure, palpitations.  
GI: Nausea mild, no vomiting, no abdominal pain.  
GU: No dysuria, no frequency.  
Musculoskeletal: baseline OA pain, no new joint swelling.  
Neurologic: No headache, dizziness, focal deficits.  
Skin: No rashes.  
Psych: Anxious about hospitalization, otherwise stable.  

Medications Prior to Admission:  
metformin 1000 mg PO BID  
insulin glargine 20 U SC qHS  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
tiotropium/olodaterol inhaler 1 puff BID  
albuterol inhaler PRN q4h PRN SOB  
omeprazole 20 mg PO daily  

Allergies:  
No known drug allergies (NKDA).  

Physical Examination:  
Vital Signs: T 38.9 °C (102.0 °F), HR 108, RR 22, BP 136/80, SpO2 92% on 2 L NC, Weight 78 kg (172 lb).  

General: Alert, mildly diaphoretic, appears her stated age, in mild respiratory distress.  

HEENT: Normocephalic, oropharynx erythematous, no exudate, nares patent.  

Neck: Supple, no JVD, no cervical LAD.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Decreased breath sounds R lower lung field, crackles + at RLL, scattered wheezes bilaterally, no pleural rub.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Warm, no edema, pulses 2+ bilat.  

Skin: No rashes, no lesions.  

Neuro: AOx3, grossly non‑focal.  

Laboratory Data (drawn 03/31/3092):  
CBC: WBC 14.2 K/µL (neut 84%, lymph 10%), Hgb 12.8 g/dL, Hct 38.5%, Plt 312 K/µL.  
BMP: Na 138 mmol/L, K 4.3 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 16 mg/dL, Cr 0.9 mg/dL, Glu 182 mg/dL.  
LFTs: AST 28 U/L, ALT 32 U/L, ALP 78 U/L, Total bili 0.8 mg/dL.  
ABG (room air): pH 7.32, PaCO2 48 mmHg, PaO2 68 mmHg, HCO3‑ 24 mmol/L.  
CRP: 12 mg/dL (elevated).  
Procalcitonin: 0.9 ng/mL.  

Microbiology:  
Sputum Gram stain: many PMNs, gram‑positive cocci in pairs.  
Blood cultures x2: pending.  

Imaging:  
Chest X‑ray (03/31/3092): Right lower lobe consolidation with air bronchograms, mild interstitial infiltrates bilaterally.  
CT Chest (non‑contrast, 03/31/3092): Confirms RLL lobar pneumonia, no PE, no cavitation.  

Assessment and Plan:  
1. Community‑acquired pneumonia, likely bacterial (Streptococcus pneumoniae) with right lower lobe involvement, in a patient with COPD and DM2.  
   - Start IV ceftriaxone 2 g q24h + azithromycin 500 mg IV q24h.  
   - Continue O₂ to keep SpO₂ > 94%; wean as tolerated.  
   - Incentive spirometry qhourly, chest physiotherapy.  
   - Monitor vitals q4h, repeat BMP and CBC daily.  
   - Re‑evaluate need for steroids; given COPD exacerbation, start prednisone 40 mg PO daily x5 days.  

2. COPD exacerbation secondary to infection.  
   - Continue tiotropium/olodaterol BID, add short course oral prednisone as above.  
   - Continue albuterol PRN, consider adding ipratropium nebulizer q6h if dyspnea worsens.  

3. Diabetes mellitus, hyperglycemia on admission.  
   - Hold metformin (risk of lactic acidosis with possible hypoxia).  
   - Continue basal insulin glargine; add correctional rapid‑acting insulin sliding scale qac.  

4. Hypertension – continue lisinopril 20 mg daily; monitor BP.  

5. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  

6. Stress ulcer prophylaxis: PO pantoprazole 40 mg daily.  

7. Diet: Regular, diabetic‑appropriate.  

8. Code Status: Full Code (Presumed).  

9. Disposition: Admit to telemetry floor for close monitoring of respiratory status and glucose; anticipate 4‑5 day course of IV antibiotics then step‑down to PO amoxicillin‑clavulanate 875/125 mg BID to complete 7‑day total therapy.  

10. Follow‑up: Repeat CXR in 48 h to assess response; adjust antibiotics based on culture results.  

Consults: Pulmonology consulted for COPD management; Infectious Diseases to review antimicrobial plan if no improvement by day 3.  

Prepared by: Dr. Priya K. Desai, MD  
Pager: 22458');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (14, 14, 72881543976, 72881543976, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Alexi Rivera  
DOB: 02/28/3049  
MRN: 98765432  
PCP: Dr. Maya L. Ortiz, MD  

Date of Admission: 09/15/3078  
Time: 06:12  
Location: MED01 – Internal Medicine Floor  
Attending Provider: Dr. Samuel K. Vance, MD  

Chief Complaint: Genital ulceration and dysuria  

History of Present Illness:  
38yo M with h/o HIV (CD4 420, VL undetectable), prior syphilis (treated), and recent unprotected anal intercourse presents w/ a 5‑day history of a painful ulcer on the distal penile shaft, associated dysuria, and mild urethral discharge. Pt reports the lesion began as a papule, rapidly ulcerated with a raised indurated border and a serosanguinous base. Denies fever, chills, rash, or lymphadenopathy. Pt notes 2 episodes of watery diarrhea last week, thought to be travel‑related (trip to Luna City 2 weeks ago). He was seen at an urgent care 3 days ago, given a single dose of ceftriaxone for presumed gonorrhea, but symptoms persisted. Pt reports occasional “bumps” on the groin but no overt swelling. No prior episodes of similar lesions. Pt admits to recent use of recreational methamphetamine and occasional binge drinking (≈6 drinks per occasion).  

Past Medical History:  
- HIV infection (diagnosed 2015) – on ART (bictegravir/emtricitabine/tenofovir alafenamide)  
- Prior syphilis (treated 2022)  
- Hypertension (controlled)  

Past Surgical History:  
- Appendectomy – 3035  

Family History:  
Father: HTN, died 2072 MI  
Mother: Alive, DM2  
Sister: Healthy  

Social History:  
Tobacco: Never smoker  
Alcohol: Social, 2–3 drinks/week, occasional binge (6–8 drinks)  
Illicit drugs: Methamphetamine use 1–2 times/month, last use 4 days ago  
Sexual: Male, 3 partners past 6 months, inconsistent condom use, receptive anal intercourse  
Living situation: Lives alone in apartment, employed as freelance graphic designer  

Allergies: No known drug allergies (NKDA)  

Review of Systems:  
Constitutional: Negative for fever, weight loss, night sweats.  
HEENT: No sore throat, no visual changes.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No cough, dyspnea.  
GI: Diarrhea resolved, no abdominal pain.  
GU: Painful penile ulcer, dysuria, scant urethral discharge, no hematuria.  
Skin: No rash, no other lesions.  
Neurologic: No headache, no focal deficits.  
Psychiatric: Mood stable, occasional anxiety related to substance use.  

Prior to Admission Medications:  
bictegravir/emtricitabine/tenofovir alafenamide 50/200/25 mg tablet – 1 PO daily  
lisinopril 10 mg tablet – 1 PO daily  
amlodipine 5 mg tablet – 1 PO daily  

Physical Examination:  
Vital Signs: Temp 37.8°C (100.0°F), HR 96 bpm, RR 18, BP 132/78 mmHg, SpO2 98% RA, Weight 84 kg, Height 178 cm, BMI 26.5  

General: Alert, oriented x3, appears mildly uncomfortable due to genital pain.  
HEENT: Normocephalic, PERRLA, mucous membranes moist, no oral lesions.  
Neck: Supple, no cervical adenopathy.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Genitourinary: 1.5 cm ulcer on distal penile shaft, indurated border, serosanguinous base, no purulent exudate. Tender inguinal lymph nodes bilaterally, 1–2 cm, mobile. No urethral discharge noted on speculum exam.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: No rashes, no lesions elsewhere.  
Neurologic: Grossly non‑focal, strength 5/5 all extremities.  

Diagnostic Data:  
CBC: WBC 7.8 K/µL, Hgb 13.2 g/dL, Plt 210 K/µL  
BMP: Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 112 mg/dL  
HIV panel: CD4 420 cells/µL, HIV RNA <20 copies/mL (most recent 2 weeks ago)  
RPR: Reactive, titer 1:8 (previously 1:4)  
TPPA: Positive  
HSV PCR (lesion swab): Pending  
GC/CT NAAT (urine): Positive for Neisseria gonorrhoeae, negative for Chlamydia trachomatis  
Syphilis IgM: Negative  
Liver panel: AST 32, ALT 28, ALP 78, Total bili 0.8  

Imaging: None indicated at this time.  

Assessment and Plan:  
38yo M with HIV on suppressive ART, presenting with a new painful penile ulcer, positive GC NAAT, rising RPR titer → likely co‑infection with primary syphilis and gonorrhea, possible HSV superinfection pending PCR.  

1. Primary syphilis: Benzathine penicillin G 2.4 million units IM x1 dose today; arrange follow‑up RPR in 3 months.  
2. Gonorrhea: Ceftriaxone 500 mg IV q24h for 5 days; consider adding doxycycline 100 mg PO BID x7 days for possible chlamydia coverage pending repeat testing.  
3. HSV: If HSV PCR returns positive, start acyclovir 400 mg PO TID for 7 days; otherwise hold.  
4. HIV: Continue current ART, monitor CD4/viral load q3 months.  
5. Pain control: Acetaminophen 650 mg PO q6h PRN, consider ibuprofen 400 mg PO q8h if no contraindication.  
6. Substance use: Counsel on methamphetamine use, refer to outpatient addiction services; offer nicotine‑free resources (though not a smoker).  
7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
8. Diet: Regular, encourage hydration.  
9. Activity: As tolerated, ambulate q2h.  
10. Disposition: Admit to telemetry floor for monitoring of infection and pain control; anticipate discharge in 48–72 hrs with outpatient follow‑up with Infectious Diseases and HIV clinic.  

Code Status: Full Code (Presumed)  

Signature: Samuel K. Vance, MD  
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (15, 15, 25481031640, 25481031640, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

12/06/3071 02:36

Patient: Samuel G. Thorne
DOB: 04/15/3035
MRN: 98765432
PCP: Dr. Lila M. Vance, MD

CHIEF COMPLAINT: Right foot pain, black discoloration, foul odor.

HISTORY OF PRESENT ILLNESS:
36yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, HTN, CKD‑3, and recent admission for cellulitis of R lower extremity p/w erythema, swelling, and low‑grade fever. Discharged 5 days ago on PO clindamycin 300 mg q8h, instructed to keep foot elevated, wound care daily. Since discharge, patient notes progressive worsening: increasing throbbing pain, now 8/10 at rest, blackening of distal hallux extending to mid‑metatarsal, foul smelling drainage, fevers up to 101.5°F at home, chills, nausea. Denies new trauma. Reports that foot became “cold” yesterday, now “doesn’t feel” the tip. He tried OTC ibuprofen with minimal relief. No recent travel. Works as a warehouse supervisor, spends long periods on feet. No known drug allergies. He presents to ED by EMS after wife called due to concern for gangrene.

ED course: Vitals on arrival HR 112, BP 138/78, RR 22, Temp 38.9°C, SpO2 96% RA. Labs: WBC 18.2 K, CRP 12 mg/dL, lactate 2.4 mmol/L, glucose 312 mg/dL, creatinine 1.8 mg/dL (baseline 1.5). Foot X‑ray: soft tissue gas, cortical erosion of 2nd metatarsal suggestive of osteomyelitis. CTA lower extremity: occlusive disease of posterior tibial artery, poor perfusion to forefoot. Started on IV vancomycin 1 g q12h and piperacillin‑tazobactam 3.375 g q6h, insulin infusion per protocol, analgesia with IV morphine 2 mg q1h PRN. Vascular surgery consulted, recommended emergent debridement and possible below‑knee amputation.

MEDICAL & SURGICAL HX:

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2015
• Peripheral Arterial Disease – diagnosed 2028
• Hypertension – diagnosed 2020
• Chronic Kidney Disease Stage 3 – diagnosed 2029
• Hyperlipidemia – diagnosed 2022
• Diabetic Neuropathy – diagnosed 2027

Past Surgical History:
Procedure Laterality Date
• LEFT KNEE ARTHROSCOPY – LEFT – 02/12/3030
• RIGHT FOOT DEBRIDEMENT – RIGHT – 09/15/3069 (partial)

FAMILY HX:
Problem Relation Age of Onset
• CAD – Father – 58
• DM2 – Mother – 55
• HTN – Sister – 45

SOCIAL HX:
Marital status: Married
Spouse: Jenna Thorne
Children: 2 (ages 4 and 7)
Employment: Warehouse supervisor, full‑time, shift 7 am‑3 pm
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Single‑family home, owns home, no pets
Transportation: Owns vehicle

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.
HEENT: Negative.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
GI: Negative for N/V/D, mild anorexia.
GU: Negative.
Musculoskeletal: Positive for right foot pain, black discoloration, decreased sensation distal foot. Negative for other joint pain.
Neurologic: Positive for peripheral neuropathy in feet. Negative for headache, dizziness.
Skin: Positive for foul drainage from right foot ulcer. Negative for rash elsewhere.
Psych: Negative for depression/anxiety.

PRIOR TO ADMISSION MEDICATIONS:
Medication Sig
metformin 1000 mg PO BID
insulin glargine 30 U SC nightly
lisinopril 20 mg PO daily
atorvastatin 40 mg PO nightly
aspirin 81 mg PO daily
clindamycin 300 mg PO q8h (prescribed at discharge)
gabapentin 300 mg PO TID
vitamin D3 2000 IU PO daily

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 38.9 °C (102 °F)
Heart Rate: 112 bpm
Respiratory Rate: 22 /min
Blood Pressure: 138/78 mmHg
SpO2: 96% RA
Weight: 92 kg (203 lb)

General: Alert, appears uncomfortable, NAD aside from foot pain.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: Right foot – black necrotic tissue involving distal hallux to mid‑metatarsal, foul smelling purulent drainage, edema, warmth proximal, decreased capillary refill, absent dorsalis pedis pulse, diminished posterior tibial pulse. Left foot – intact, peripheral pulses 2+.
Skin: No other lesions.
Neurologic: Alert ×3, grossly non‑focal, decreased sensation to light touch in both feet (stocking distribution).

LABS & IMAGING:
CBC: WBC 18.2 K, Hgb 11.2 g/dL, Plt 312 K
BMP: Na 138, K 4.6, Cl 102, CO2 22, BUN 28, Cr 1.8, Glu 312
CRP: 12 mg/dL
Lactate: 2.4 mmol/L
ABG: pH 7.32, pCO2 30, HCO3‑ 16 (metabolic acidosis with partial respiratory compensation)
Blood cultures x2: pending
Wound culture: pending
X‑ray right foot: soft tissue gas, cortical erosion of 2nd metatarsal.
CTA lower extremities: occlusive disease of posterior tibial artery, poor perfusion to forefoot.

ASSESSMENT/PLAN:
36yo M with poorly controlled T2DM, PAD, CKD‑3, now presenting with right foot gangrene, suspected osteomyelitis, and early sepsis.

1. RIGHT FOOT GANGRENE w/ possible osteomyelitis – emergent surgical debridement / possible below‑knee amputation. Vascular surgery and orthopedic surgery consults placed. NPO, keep foot elevated, wound care dressing q4h.
2. SEPSIS – continue broad‑spectrum IV antibiotics (vancomycin + piperacillin‑tazobactam) pending cultures; adjust per sensitivities. Monitor lactate, q6h.
3. DIABETIC CONTROL – insulin infusion targeting glucose 140‑180 mg/dL; resume basal insulin once stable.
4. CKD‑3 – adjust meds, hold nephrotoxic agents, monitor Cr q12h.
5. HTN – continue lisinopril; hold if K >5.5.
6. DVT PROPHYLAXIS – SQ enoxaparin 40 mg daily (adjust for Cr).
7. NUTRITION – diabetic diet, consult dietitian.
8. PAIN MANAGEMENT – IV morphine q1h PRN, consider gabapentin for neuropathic component.
9. CODE STATUS – Full Code (Presumed); discussed with patient and family, documented.
10. DISPOSITION – Admit to step‑down unit with telemetry, surgical service primary team. Anticipate OR within 12 hrs.

FOLLOW‑UP:
- Labs q12h (CBC, BMP, lactate, CRP)
- Wound cultures in 48 hrs
- Repeat foot X‑ray post‑op
- Endocrinology consult for glycemic optimization
- Physical therapy consult for mobility planning post‑op

Prepared by: Dr. Marcus L. Hargrove, MD
Attending Hospitalist
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (16, 16, 67634736269, 67634736269, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

03/06/3096 22:29

Patient: Miguel Alvarez
DOB: 11/14/3065
MRN: 98765432
PCP: Dr. Lucia Ramos, MD

CHIEF COMPLAINT: SOB & increased sputum

HISTORY OF PRESENT ILLNESS:
58yo M with h/o severe COPD (GOLD D, home O2 2Lpm qhs), chronic bronchiectasis, HTN, and prior tobacco use (40 pack‑yr, quit 5y ago) presents from urgent care with worsening dyspnea x4 days, productive cough now greenish sputum, low‑grade fever 100.4°F, and pleuritic chest pain R side. He reports that his baseline dyspnea is 2‑3 L/min O2, but today he needed 4 L/min to keep sats >90% and felt “out of breath” at rest. He used his rescue inhaler (albuterol/ipratropium) q2h with minimal relief, and increased his oral prednisone (started 30 mg PO daily 3 days ago by his PCP) but symptoms progressed. Denies recent travel, sick contacts, or known COVID exposure. He was seen 2 weeks ago for a COPD flare, received a 5‑day course of azithromycin and prednisone taper, completed without issue. He reports occasional nighttime wheeze, but no orthopnea, PND, or leg swelling. No chest pain radiating, no palpitations. He has been compliant with inhalers (tiotropium daily, fluticasone/salmeterol BID) and O2. He states he “feels like I’m drowning” and came to ED after EMS found RR 28, HR 112, BP 138/78, SpO2 84% on 4 L O2.

ED COURSE:
Vitals on arrival: T 38.2°C, HR 112, RR 28, BP 138/78, SpO2 84% on 4 L nasal cannula. ABG: pH 7.32, pCO2 58, pO2 58 on 4 L. Labs: WBC 14.2 (neut 88%), CRP 12.5 mg/dL. CXR: hyperinflated lungs with bilateral peribronchial thickening, new right lower lobe infiltrate. Started on IV methylpred 40 mg q8h, nebulized albuterol/ipratropium q4h, IV ceftriaxone 1 g q24h, and oral azithro 500 mg day 1 then 250 mg daily x4. Placed on BiPAP for CO2 retention, improved to SpO2 92% on 6 L. He was admitted to the medical floor for COPD exacerbation with possible bacterial pneumonia.

PAST MEDICAL HISTORY:
• COPD (severe, GOLD D) – diagnosed 2015
• Chronic bronchiectasis – 2018
• Hypertension – 2020
• Hyperlipidemia – 2022
• GERD – 2024

PAST SURGICAL HISTORY:
• Appendectomy – 2021
• Right knee arthroscopy – 2028

FAMILY HISTORY:
Father – CAD s/p stent @ 62, died MI 2045
Mother – HTN, alive 88
Sister – asthma
No known genetic disorders.

SOCIAL HISTORY:
Marital status: Married
Occupation: Retired electrician
Tobacco: Former smoker, 40 pack‑yr, quit 5y ago
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives with spouse in single‑family home, owns a home, has home O2 concentrator.
Transportation: Drives with assistance.

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.
HEENT: Negative for sore throat, sinus pain.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Positive for dyspnea at rest, productive cough, wheezes. Negative for hemoptysis.
GI: Positive for mild GERD symptoms. Negative for N/V/D.
GU: Negative.
Musculoskeletal: Negative for new joint pain.
Neuro: Negative for headache, dizziness.
Psych: Negative for depression/anxiety.

PRIOR TO ADMISSION MEDICATIONS:
Medication                Sig
tiotropium Respimat      18 mcg inhalation daily
fluticasone/salmeterol   250/50 mcg inhalation BID
albuterol/ipratropium    2.5 mg/0.5 mg nebulizer q4h PRN
prednisone               30 mg PO daily (started 3 d ago)
lisinopril               10 mg PO daily
atorvastatin             20 mg PO nightly
omeprazole               20 mg PO daily
home O2                  2 L/min nocturnal

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 38.2 °C (100.8 °F)
Heart Rate: 112 bpm
Respiratory Rate: 28/min
Blood Pressure: 138/78 mmHg
SpO2: 84% on 4 L NC (improved to 92% on BiPAP)
General: Alert, in mild respiratory distress, using accessory muscles.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Diffuse wheezes bilaterally, rhonchi R lower lobe, decreased breath sounds at bases, use of accessory muscles.
Abdomen: Soft, NT, BS present.
Extremities: No edema, warm.
Skin: No rashes.
Neuro: AOx3, CN II‑XII grossly intact.

LABS (most recent):
CBC:
WBC 14.2 K/µL
Hgb 13.1 g/dL
Hct 39%
Plt 312 K/µL

BMP:
Na 138 mmol/L
K 4.3 mmol/L
Cl 102 mmol/L
CO2 24 mmol/L
BUN 16 mg/dL
Cr 0.9 mg/dL
Glucose 112 mg/dL

ABG (on 4 L NC):
pH 7.32, pCO2 58 mmHg, pO2 58 mmHg, HCO3‑ 26

CRP 12.5 mg/dL
Procalcitonin 0.45 ng/mL

CXR:
Hyperinflated lungs, bilateral peribronchial thickening, new right lower lobe infiltrate consistent with pneumonia.

CT CHEST (non‑contrast):
Right lower lobe consolidation with surrounding ground‑glass, bronchiectatic changes throughout both lungs.

EKG:
Sinus tachycardia, HR 112, no acute ischemia.

IMPRESSION/PLAN:
1. COPD exacerbation GOLD D with acute hypercapnic respiratory failure, secondary bacterial pneumonia (RLL).  
   • Continue IV methylpred 40 mg q8h, transition to PO prednisone 40 mg daily taper over 7 days.  
   • Continue nebulized albuterol/ipratropium q4h, add ipratropium inhaler BID.  
   • Continue ceftriaxone 1 g IV q24h ×5 days; consider de‑escalation based on cultures.  
   • Initiate azithromycin PO 500 mg day 1 then 250 mg daily x4.  
   • BiPAP support as needed; wean to high‑flow nasal cannula when pCO2 <50.  
   • O2 target 88‑92% on home O2 baseline; adjust flow accordingly.  

2. Hypertension – continue lisinopril 10 mg daily, monitor BP q8h.  

3. Hyperlipidemia – continue atorvastatin 20 mg nightly.  

4. GERD – continue omeprazole 20 mg daily.  

5. DVT prophylaxis – SQ enoxaparin 40 mg SC daily.  

6. Diet – regular, low sodium, encourage fluid intake as tolerated.  

7. Activity – ambulate with assistance q8h, incentive spirometry qhourly.  

8. Disposition – Admit to telemetry floor for close respiratory monitoring, anticipate 4‑5 day stay, reassess for step‑down to floor without telemetry if stable.  

CODE STATUS: Full Code (Presumed)

PHYSICIAN: Dr. Elena Marquez, MD  
Pager #: 84219

(Note: This note was generated using synthetic data for educational purposes only.)');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (17, 17, 37769248665, 37769248665, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Michael Hartman
DOB: 11/15/3025
MRN: 98765432
PCP: Dr. Linda Sample, MD

Date of Admission: 04/02/3062 06:01
Location: SURG01
Attending Provider: Dr. Samuel Realist, MD

Chief Complaint/Reason for Admission: Redness, purulent drainage, and pain at abdominal incision site

History of Present Illness:
58yo M with h/o HTN, DM2 (A1c 8.4%), CKD3, recent laparoscopic right hemicolectomy p/w SSI. Patient underwent uncomplicated laparoscopic right hemicolectomy for adenocarcinoma of the ascending colon on 03/20/3062 at outside facility. Post‑op course initially uneventful, discharged home on POD 3 with standard analgesics and oral antibiotics (ciprofloxacin 500 mg BID). On POD 9 (04/01/3062) he noted increasing erythema, warmth, and serosanguinous drainage from the midline port site. He reports low‑grade fevers up to 38.2 °C, chills, and worsening pain rated 7/10, especially with movement. He tried to self‑manage with OTC acetaminophen and ibuprofen, but symptoms progressed. No nausea, vomiting, or change in bowel habits. No recent travel. No known sick contacts. He presented to the ED of this hospital at 04/02/3062 04:45, where vitals showed HR 112, BP 138/84, RR 22, Temp 38.4 °C, SpO2 96% RA. Physical exam noted a 6 cm incision with surrounding erythema, induration, and purulent drainage. Labs drawn, wound cultures obtained, and CT abdomen/pelvis with contrast performed showing fluid collection adjacent to the anastomosis suggestive of localized abscess. He was started on IV ceftriaxone and metronidazole in the ED and admitted for IV antibiotics, possible IR drainage, and wound care.

Past Medical History:
• Hypertension – diagnosed 04/10/3035, on lisinopril 20 mg daily
• Type 2 Diabetes Mellitus – A1c 8.4% (last 02/15/3062), on metformin 1000 mg BID and insulin glargine 30 U qHS
• Chronic Kidney Disease Stage 3 – baseline Cr 1.6 mg/dL
• Colon adenocarcinoma – status post right hemicolectomy 03/20/3062

Past Surgical History:
• Laparoscopic right hemicolectomy – 03/20/3062
• Appendectomy – 02/02/3028
• Cholecystectomy – 07/15/3030

Family History:
Father – HTN, MI at 62
Mother – DM2, CKD
Sister – healthy

Social History:
Marital status: Married
Occupation: Accountant, works from home
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives with spouse, two adult children, no pets

Medications Prior to Admission:
lisinopril 20 mg PO daily
metformin 1000 mg PO BID
insulin glargine 30 U SC qHS
ciprofloxacin 500 mg PO BID (started 03/23/3062)
acetaminophen 650 mg PO q6h PRN
ibuprofen 400 mg PO q8h PRN

Allergies:
No known drug allergies.

Review of Systems:
Constitutional: Fever, chills, fatigue – positive; weight loss – negative.
HEENT: No sore throat, vision changes.
Cardiovascular: No chest pain, palpitations.
Respiratory: No cough, dyspnea at rest.
Gastrointestinal: No nausea, vomiting, diarrhea; normal bowel movements.
Genitourinary: No dysuria, flank pain.
Musculoskeletal: Incision pain – positive; no joint swelling.
Neurologic: No headache, dizziness.
Skin: Redness, drainage at incision – positive; no rash elsewhere.
Psychiatric: No anxiety or depression.

Physical Examination:
Vital Signs:
Temp 38.4 °C
HR 112 bpm
RR 22 breaths/min
BP 138/84 mmHg
SpO2 96% RA
Weight 92 kg (202 lb)

General: Alert, appears mildly ill, in mild distress due to pain.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate, tachycardic, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.
Abdomen: Midline laparoscopic incision ~6 cm, erythematous, indurated, purulent drainage noted. No rebound, mild guarding. Bowel sounds present.
Extremities: Warm, no edema, pulses 2+ bilaterally.
Skin: As above, no other lesions.
Neuro: AOx3, grossly non‑focal.

Labs and Imaging:
CBC: WBC 14.2 K/µL (neutrophils 84%), Hgb 12.1 g/dL, Plt 312 K/µL
BMP: Na 138, K 4.3, Cl 102, CO2 22, BUN 22, Cr 1.7 mg/dL, Glucose 182 mg/dL
CRP: 12.5 mg/dL
Procalcitonin: 0.9 ng/mL
Blood cultures x2: pending
Wound culture: pending
CT Abdomen/Pelvis w/ contrast: 3 cm fluid collection adjacent to anastomosis, no free air, consistent with localized abscess.
Chest X‑ray: No infiltrates.

Assessment and Plan:
58yo M with recent laparoscopic right hemicolectomy now presenting with surgical site infection (SSI) of midline port site, localized intra‑abdominal fluid collection, and early sepsis. Plan:
1. IV antibiotics: ceftriaxone 2 g q24h + metronidazole 500 mg q8h. Adjust per culture sensitivities.
2. Interventional radiology consult for possible percutaneous drainage of fluid collection; hold off until labs stable.
3. Wound care: daily dressing changes, monitor drainage, consider negative pressure therapy if needed.
4. Glycemic control: insulin sliding scale, target glucose 140‑180 mg/dL.
5. Renal function: monitor Cr, adjust meds as needed; hold nephrotoxic agents.
6. Fluid management: maintain euvolemia, NS 75 mL/hr, adjust per intake/output.
7. DVT prophylaxis: SQ low‑molecular‑weight heparin 40 mg subcut daily.
8. Diet: NPO initially, advance to clear liquids when tolerated, then regular diet.
9. Code Status: Full Code (Presumed).
10. Disposition: Admit to surgical floor, telemetry for arrhythmia monitoring given tachycardia and sepsis risk.
11. Education: Discuss wound care, signs of worsening infection, glucose monitoring.
12. Follow‑up labs: CBC, BMP, CRP q24h, cultures q48h.

Consults:
- Surgery – for operative assessment if drainage fails.
- Infectious Diseases – for antibiotic stewardship.

Signature:
Samuel Realist, MD
Attending Surgeon
Pager # 84210

Date/Time: 04/02/3062 06:45');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (18, 18, 65869176080, 65869176080, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Hospital Admission History and Physical

Date of Admission: 08/11/3058 12:12
Location: MED01
Attending: Dr. Evelyn Hartwell, MD
Admitting Resident: Dr. Luis Mendoza, MD
PCP: Dr. Sandra Kline, MD

Patient: Miguel Alvarez
DOB: 02/14/3018
MRN: 98765432
Sex: M
Age: 40

Chief Complaint: Fever, chills, malaise

History of Present Illness:
40yo M with h/o T2DM (A1c 8.7%), HTN, CKD stage 3 (eGFR 48), and recent right foot cellulitis p/w erythema, swelling, low‑grade fever now presents with 3‑day history of non‑localizing fever up to 39.4°C, chills, night sweats, diffuse myalgias and generalized fatigue. Patient reports that fever started abruptly on 08/08 after completing a 7‑day course of oral clindamycin for cellulitis; he felt “hot all the time” and woke up sweating. Denies cough, dyspnea, chest pain, dysuria, abdominal pain, rash, or focal joint pain. He notes mild headache and occasional nausea but no vomiting or diarrhea. He went to urgent care on 08/09; vitals showed T 38.9°C, HR 112, BP 138/84, RR 18, SpO2 97% RA. Labs then showed WBC 13.2, Cr 1.4 (baseline 1.2). He was given IV ceftriaxone and sent home with instructions to follow‑up. Over the next 48 h symptoms persisted, now with new mild confusion and decreased oral intake. Family brought him to ED where he was found febrile 39.2°C, tachycardic 118, BP 132/78, RR 20, SpO2 95% on room air. Physical exam in ED noted mild scleral icterus, no focal tenderness, lungs clear, heart regular, abdomen soft, no CVA tenderness. No obvious source of infection identified on exam or bedside US. He was admitted for further work‑up of FUO (fever of unknown origin) and possible sepsis.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2015, on insulin glargine 30 U qHS and metformin 1000 mg BID
• Hypertension – lisinopril 20 mg daily
• Chronic Kidney Disease stage 3 – baseline Cr 1.2‑1.4
• Right foot cellulitis – treated 08/07‑08/13 with clindamycin
• Hyperlipidemia – rosuvastatin 10 mg daily
• GERD – omeprazole 20 mg daily

Past Surgical History:
• Appendectomy – 2002, laparoscopic
• Left inguinal hernia repair – 2018, open mesh

Family History:
Father – HTN, MI at 62
Mother – DM2, CKD
Sister – healthy
No known hereditary cancers.

Social History:
Marital Status: Married
Occupation: Warehouse supervisor, works night shifts
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives with spouse, two children, owns home
Travel: No recent travel outside state
Vaccinations: Up to date, COVID‑19 booster 04/3058

Review of Systems:
Constitutional: Positive for fever, chills, night sweats, fatigue, mild headache. Negative for weight loss, polyuria.
HEENT: Negative for sore throat, visual changes, ear pain.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea, hemoptysis.
Gastrointestinal: Negative for nausea/vomiting, abdominal pain, diarrhea.
Genitourinary: Negative for dysuria, flank pain.
Musculoskeletal: Negative for joint swelling, myalgia limited to generalized aches.
Neurologic: Positive for mild confusion, otherwise oriented x3.
Skin: No rash, cellulitis resolved.
Psychiatric: No depression/anxiety reported.

Allergies:
No known drug allergies.

Medications Prior to Admission:
metformin 1000 mg PO BID
insulin glargine 30 U SC qHS
lisinopril 20 mg PO daily
rosuvastatin 10 mg PO nightly
omeprazole 20 mg PO daily
clindamycin 300 mg PO TID (completed 08/13)

Physical Examination:
Vital Signs: T 38.9°C, HR 115, RR 20, BP 130/78, SpO2 96% RA, Weight 92 kg, Height 175 cm, BMI 30.1
General: Alert but appears fatigued, mild confusion, NAD otherwise.
HEENT: PERRLA, mucous membranes moist, no oropharyngeal erythema.
Neck: Supple, no JVD, no lymphadenopathy.
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.
Abdomen: Soft, non‑tender, nondistended, bowel sounds present, no hepatosplenomegaly.
Extremities: No edema, no erythema, pulses 2+ bilaterally.
Skin: No rashes, surgical scars healed, no new lesions.
Neurologic: AOx3, mild confusion, CN II‑XII grossly intact, no focal deficits.
Psych: Cooperative, appropriate affect.

Laboratory Data (most recent):
CBC: WBC 13.8 K/µL, Hgb 12.4 g/dL, Hct 37.2%, Plt 312 K/µL
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 28 mg/dL, Cr 1.5 mg/dL (eGFR 45 mL/min), Glucose 212 mg/dL
LFTs: AST 34 U/L, ALT 38 U/L, ALP 88 U/L, Total Bilirubin 1.2 mg/dL
CRP: 12.4 mg/dL (elevated)
Procalcitonin: 0.42 ng/mL
Lactate: 1.8 mmol/L
Blood cultures: x2 pending
Urinalysis: Clear, no leukocyte esterase, no nitrites, <5 WBC/hpf
Chest X‑ray: No infiltrates, clear lung fields.
Abdominal US: No abscess, kidneys normal size, no hydronephrosis.
CT chest (non‑contrast): No pulmonary embolus, mild ground‑glass opacities in bilateral lower lobes, indeterminate.

Assessment and Plan:
40yo M with h/o T2DM, HTN, CKD3, recent cellulitis now presents with 3‑day FUO, tachycardia, mild encephalopathy, leukocytosis, elevated CRP, no clear source on initial imaging → concern for occult infection vs. drug‑induced fever vs. early sepsis. Plan:
1. Empiric broad‑spectrum antibiotics: IV cefepime 2 g q8h + vancomycin dosed per trough, continue for 48 h pending cultures.
2. Infectious work‑up: Blood cultures x2 (already drawn), urine culture, sputum culture if productive, viral PCR panel (respiratory), CMV PCR, EBV serology, HIV screen (previously negative), repeat CBC/q24h.
3. Imaging: Repeat chest CT with contrast if clinical status worsens, consider MRI abdomen/pelvis if source remains elusive.
4. Metabolic: Tight glucose control with insulin infusion targeting 140‑180 mg/dL; hold oral metformin given AKI risk.
5. Renal: Monitor Cr q12h, adjust meds, maintain euvolemia with IV NS 75 mL/hr.
6. Fluid status: Input/output charted, consider diuretics if volume overload.
7. Consults: Infectious Diseases, Nephrology (CKD management), Endocrinology (DM optimization).
8. DVT prophylaxis: SQ enoxaparin 40 mg SC daily (adjust for Cr).
9. Nutrition: NPO initially, advance to clear liquids when afebrile, then regular renal‑appropriate diet.
10. Code status: Full Code (presumed), discussed with patient and spouse, documented.
11. Disposition: Admit to telemetry floor, reassess q24h, anticipate possible transfer to ICU if hemodynamic instability develops.

Signature:
Dr. Luis Mendoza, MD
Resident Physician
Hospital Medicine Service
08/11/3058 12:45');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (19, 19, 84826071984, 84826071984, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'HOSPITAL ADMISSION NOTE

PATIENT: Michael J. Rowan
MRN: 98765432
DOB: 03/14/3045
PCP: Dr. Elaine V. Kline, MD
DATE OF ADMISSION: 12/26/3080
TIME: 13:57
ATTENDING: Dr. Victor L. Haines, MD
LOCATION: MED01
CODE STATUS: Full Code (Presumed)

CHIEF COMPLAINT:
Fever, chills, and painful left forearm swelling.

HISTORY OF PRESENT ILLNESS:
58yo M with h/o IVDU (heroin, 3‑yr), chronic HCV (RNA+, untreated), COPD s/p tobacco, and prior MRSA SSTI p/w cellulitis now presents w/ 3‑day hx of low‑grade fevers (T max 38.9°C), rigors, and progressive erythema/edema of left forearm. Pt reports injecting heroin into left antecubital fossa 2 days ago using a reused needle; noted “hard spot” that became painful, red, and warm. Denies SOB, chest pain, N/V/D. Pt says he slept on couch, used “street” antibiotics (amoxicillin) with no relief. Yesterday he went to urgent care, got PO clindamycin 300 mg q8h, but swelling worsened, now with fluctuance and foul odor. Pt was EMS‑ed to ED. In ED vitals: T 38.7°C, HR 112, BP 118/72, RR 22, SpO2 96% RA. Labs: WBC 15.2, ANC 12.1, CRP 12.4 mg/dL. Blood cultures drawn. Bedside US shows 3 cm fluid collection. Started IV vancomycin 1 g q12h and cefepime 2 g q8h. Pt reports last heroin use 2 days ago, last methadone dose 5 days ago, denies alcohol binge. Pt is currently homeless, lives in shelter, no stable housing. He is aware of HCV but never treated. No recent travel. No known sick contacts.

ED COURSE:
Received 2 L NS, IV vancomycin, cefepime, acetaminophen 650 mg PRN. Blood cultures pending. X‑ray forearm: soft tissue swelling, no fracture. US guided I&D performed in ED with 15 mL purulent material sent for Gram stain/culture. Pt tolerated procedure. Pain controlled with IV morphine 2 mg q2h PRN.

MEDICAL & SURGICAL HX:
Past Medical History:
• Chronic hepatitis C virus infection (RNA+, untreated) – 2018
• Chronic obstructive pulmonary disease – 3025
• Hypertension – 3030
• Prior MRSA cellulitis – 3065
• Depression – 3070

Past Surgical History:
Procedure Laterality Date
• INCISION & DRAINAGE LEFT FOREARM 12/26/3080 (ED)

FAMILY HX:
Mother – HTN, died 3078 of stroke.
Father – COPD, alive.
Sibling – No known chronic illness.

SOCIAL HX:
Tobacco Use: Smokes 1 pack/day since age 18, currently 0.5 pack/day.
Alcohol Use: Social, 1‑2 drinks/week.
Illicit Drug Use: Active IV heroin use, last 2 days ago; also occasional cocaine snort.
Housing: Homeless, lives in municipal shelter.
Employment: Unemployed, receives SSI.
Sexual Activity: Heterosexual, multiple partners, inconsistent condom use.
Legal: No current legal issues.

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills, malaise. Negative for weight loss.
HEENT: Negative for sore throat, sinus pain.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Mild cough, no dyspnea at rest.
GI: Nausea denied, appetite decreased.
GU: No dysuria, no flank pain.
Musculoskeletal: Left forearm pain, swelling, fluctuance. No other joint pain.
Neurologic: No headache, no focal deficits.
Skin: Erythema & warmth left forearm, no other rashes.
Psych: Depressed mood, anxiety about housing.

PRIOR TO ADMISSION MEDICATIONS:
Medication Sig
methadone 30 mg PO daily
albuterol inhaler 90 mcg PRN q4h PRN
lisinopril 10 mg PO daily
sertraline 50 mg PO daily
vitamin D3 2000 IU PO daily

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 38.6 °C
Heart Rate: 110 bpm
Respiratory Rate: 22/min
Blood Pressure: 116/70 mmHg
SpO2: 96% RA
General: Alert, appears mildly ill, diaphoretic.
HEENT: Normocephalic, PERRLA, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate & rhythm, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, mild wheeze RUL.
Abdomen: Soft, non‑tender, BS +.
Extremities: Left forearm – erythematous, warm, 8 × 6 cm area of fluctuance, tenderness to palpation, limited flexion due to pain. No lymphangitic streaking proximally. No edema elsewhere.
Skin: No other lesions.
Neurologic: AOx3, CN II‑XII grossly intact.
Psych: Mood depressed, cooperative.

LABS & IMAGING:
CBC: WBC 15.2 K/µL, Hgb 13.1 g/dL, Plt 210 K/µL
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 112
CRP: 12.4 mg/dL
Procalcitonin: 1.8 ng/mL
Liver Panel: AST 68 U/L, ALT 55 U/L, Alk Phos 92 U/L, Total Bili 0.8 mg/dL
Blood cultures: x2 pending
Wound culture: Gram stain shows Gram‑positive cocci in clusters.
Chest X‑ray: No infiltrates.
Forearm US: 3 cm hypoechoic collection, no deep abscess.
ECG: Sinus tachycardia, HR 110, no ischemia.

ASSESSMENT:
58yo M with active IVDU, chronic HCV, COPD, and recent left forearm injection site infection now presenting with cellulitis complicated by a 3 cm abscess, systemic inflammatory response (fever, tachycardia, leukocytosis). Likely MRSA given prior history and community exposure; empiric VANC + CEFEPIME appropriate. Also consider polymicrobial coverage for gram‑neg rods from skin flora. Risk factors: homelessness, needle reuse, delayed presentation.

PLAN:
1. Infectious Disease consult – advise continuation of vancomycin (trough goal 15‑20 µg/mL) and cefepime; consider daptomycin if renal function declines.
2. Continue IV fluids NS 125 mL/hr, monitor input/output.
3. Pain control: IV morphine 2 mg q2h PRN, switch to PO oxycodone when tolerating.
4. Wound care: Daily dressing changes, repeat US in 48 h; consider repeat I&D if no improvement.
5. Labs: CBC, BMP, CRP q24h; repeat blood cultures q48h.
6. Hepatitis C: Offer linkage to outpatient HCV treatment program; start counseling.
7. Substance use: Initiate buprenorphine‑naloxone bridge therapy; refer to addiction medicine.
8. Social work: Arrange temporary shelter placement, discharge planning, insurance enrollment.
9. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
10. VTE monitoring, telemetry not needed.
11. Diet: Regular, high protein.
12. Code status: Full Code (Presumed) – discuss with patient, document preferences.
13. Follow‑up: Infectious Disease daily, primary team rounds qMorning.

Signature:
Victor L. Haines, MD
Attending Hospitalist
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (20, 20, 88379319666, 88379319666, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION NOTE

PATIENT: Michael J. Alder
MRN: 34201987
DOB: 04/12/3045
PCP: Dr. Lila Harrow, MD
DATE OF ADMISSION: 10/21/3081
TIME: 13:05
ADMITTING ATTENDING: Dr. Samuel K. Vance, MD
LOCATION: MED01
CODE STATUS: Full Code (Presumed)

CHIEF COMPLAINT: “I just feel weak all the time, can’t keep weight on.”

HISTORY OF PRESENT ILLNESS:
58yo M with h/o COPD (GOLD II), HTN, CKD stage 3 (baseline Cr 1.4), anemia of chronic disease, and recent hospitalization for UTI now p/w progressive malaise, anorexia, and failure to thrive w/o fever. Pt reports 6‑week history of generalized fatigue, low energy, and 8‑lb weight loss despite unchanged diet. Denies chills, night sweats, cough, dyspnea at rest, chest pain, GI bleed, or dysuria. He notes occasional light‑headedness when standing, but no syncope. He was discharged from outside hospital 2 days ago after 5‑day course of IV ceftriaxone for E. coli UTI; cultures were negative on discharge, but he feels “still not getting better.” Pt states he has been sleeping 10‑12 h/night but still feels “exhausted.” No recent travel, no sick contacts. He lives alone, uses a walker for ambulation due to COPD dyspnea on exertion. He stopped his home inhalers (tiotropium) a week ago because he thought they made him sleepy. He continues metoprolol 50 mg daily, lisinopril 20 mg daily, and ferrous sulfate 325 mg PO BID. He denies alcohol, tobacco (quit 5 yr ago), or illicit drug use.

PAST MEDICAL HISTORY:
• COPD – diagnosed 2015, on tiotropium, albuterol PRN
• Hypertension – on lisinopril, metoprolol
• Chronic Kidney Disease – stage 3, baseline eGFR ~45 mL/min
• Anemia of chronic disease – Hgb 10‑11 g/dL
• Remote cholecystectomy (2008)

PAST SURGICAL HISTORY:
Procedure                Laterality   Date
CHOLECYSTECTOMY          –            02/14/3008

FAMILY HISTORY:
Father: HTN, died MI age 68
Mother: DM2, alive 92
Sister: Breast CA dx 2022, in remission
No known hereditary kidney disease.

SOCIAL HISTORY:
Marital status: Single, lives alone in assisted‑living apartment
Employment: Retired electrician
Tobacco: Never smoked; former pipe smoker quit 5 yr ago
Alcohol: Social beer 1‑2 per week
Illicit drugs: Denies
Living situation: Independent, uses walker, meals delivered 3×/wk
Transportation: Own vehicle, limited driving

REVIEW OF SYSTEMS:
Constitutional: +fatigue, +weight loss 8 lb, -fever, -chills
HEENT: -vision changes, -sore throat, -nasal congestion
Cardiovascular: -chest pain, -palpitations, -edema
Respiratory: +mild dyspnea on exertion, -cough, -hemoptysis
Gastrointestinal: -nausea, -vomiting, -diarrhea, -abdominal pain
Genitourinary: -dysuria, -hematuria, -frequency (UTI resolved)
Musculoskeletal: +weakness, -myalgias, -joint pain
Neurologic: +light‑headedness on standing, -syncope, -headache
Psychiatric: -depression, -anxiety
Skin: -rashes, -lesions

PRIOR TO ADMISSION MEDICATIONS:
Medication                     Sig
LISINOPRIL 20 MG               TAKE 1 TAB PO DAILY
METOPROLOL SUCCINATE 50 MG     TAKE 1 TAB PO DAILY
TIOTRIPIUM 18 MCG INHALER      1 PUFF DAILY (patient stopped 7 d ago)
ALBUTEROL INHALER PRN         2 Puffs q4‑6h PRN SOB
FERROUS SULFATE 325 MG        TAKE 1 TAB PO BID
VITAMIN D3 2000 IU            DAILY
OMEPRAZOLE 20 MG               DAILY

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 36.8 °C (98.2 °F)
Heart Rate: [55‑110] 88 bpm
Respiratory Rate: [12‑22] 18/min
Blood Pressure: (110‑150)/(60‑90) 132/78 mmHg
SpO2: 94% on RA
Weight: 71 kg (156 lb) – down 8 lb since last admission
General: Alert, oriented x3, appears thin, mild cachexia, NAD
HEENT: Normocephalic, atraumatic, mucous membranes moist, no scleral icterus
Neck: Supple, no JVD, no thyromegaly
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops
Respiratory: Clear to auscultation bilaterally, mild expiratory wheeze at bases, no rales
Abdomen: Soft, non‑tender, normoactive bowel sounds
Extremities: No edema, warm, pulses 2+ bilaterally, mild tremor noted in hands
Skin: Thin, turgor decreased, no rashes, no ulcerations
Neuro: AOx3, CN II‑XII grossly intact, strength 4/5 diffusely, gait slow, uses walker
Psych: Cooperative, mood neutral

LABS (drawn 10/21/3081):
CBC:
WBC 7.2 K/µL
Hgb 10.2 g/dL
Hct 31%
MCV 88 fL
Plt 210 K/µL

BMP:
Na 138 mmol/L
K 4.6 mmol/L
Cl 102 mmol/L
CO2 24 mmol/L
BUN 22 mg/dL
Cr 1.5 mg/dL (eGFR 44 mL/min)
Glucose 112 mg/dL

CRP: 12 mg/L (elevated)
ESR: 38 mm/hr
Ferritin: 210 ng/mL
TSAT: 22%
Lactate: 1.1 mmol/L

UA: Clear, specific gravity 1.015, no leukocyte esterase, no nitrites, no bacteria.

VIRAL PANEL (BioFire): pending

IMAGING:
Chest X‑ray (10/21/3081): Hyperinflated lungs, mild bibasilar flattening of diaphragms, no infiltrates.
Abdominal US (10/21/3081): Unremarkable, kidneys normal size, no hydronephrosis.

EKG (10/21/3081): Sinus rhythm, HR 88, PR 160 ms, QRS 92 ms, QTc 420 ms, no acute ST‑T changes.

ASSESSMENT/PLAN:
58yo M with COPD, HTN, CKD3, anemia of chronic disease, recent UTI now presents with subacute malaise, anorexia, and 8‑lb weight loss w/o fever → likely multifactorial: (1) deconditioning & possible malnutrition, (2) anemia exacerbation, (3) possible occult infection or inflammatory process, (4) medication non‑adherence (tiotropium stopped). Plan:

1. INFECTION: Blood cultures x2, repeat UA, pending BioFire panel. Continue ceftriaxone 1 g IV q24h until cultures negative (5 days total). Consider adding azithromycin 500 mg PO daily if atypical coverage needed.

2. ANEMIA: Check iron studies (already done), consider IV iron if ferritin <100 or symptomatic. Hold ferrous sulfate for now given GI upset risk.

3. NUTRITION: Dietitian consult for high‑calorie, high‑protein diet; start oral nutritional supplement (Ensure Plus) 2 packs BID. Encourage small frequent meals.

4. COPD: Reinstate tiotropium 18 mcg daily; add short‑acting bronchodilator (albuterol) PRN; consider inhaled steroids if wheeze persists.

5. CARDIOVASCULAR: Continue metoprolol and lisinopril; monitor BP and renal function q48h.

6. RENAL: Maintain euvolemia, avoid nephrotoxic agents, monitor Cr q24h.

7. ANEMIA: Transfusion threshold Hgb <7; currently 10.2 – observe.

8. FALL PREVENTION: Physical therapy for ambulation, assess home safety, consider walker reinforcement.

9. LABS: Repeat CBC, BMP, CRP q48h; monitor lactate.

10. OTHER: DVT prophylaxis with SQ enoxaparin 40 mg SC daily; GI prophylaxis with pantoprazole 40 mg daily; stress ulcer prophylaxis not needed.

Disposition: Admit to Med‑Surg floor, telemetry for cardiac monitoring given beta‑blocker and CKD. Anticipated LOS 4‑5 days pending work‑up.

FOLLOW‑UP: Infectious Diseases consult if cultures positive or BioFire panel reveals pathogen. Nutrition service within 24 h. PT/OT evaluation today.

Samuel K. Vance, MD
Hospitalist
Pager 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (21, 21, 40152264630, 40152264630, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Elias M. Thorne
DOB: 02/14/3047
MRN: 84276109
PCP: Dr. Selma V. Kline, MD
Date of Admission: 03/19/3085
Time of Admission: 08:11
Location: MED01 – General Medicine Floor
Attending: Dr. Victor L. Ames, MD
Admitting Resident: Dr. Priya N. Shah, MD

Chief Complaint: “Right foot pain, black discoloration”

History of Present Illness:
58yo M with h/o T2DM (A1c 9.2% 03/01/3085), PAD s/p fem‑pop bypass 3079, CKD‑3, HTN, and recent cellulitis of R lower extremity p/w worsening pain, edema, and black necrotic tip of 2nd toe. Patient reports that 5 days ago he noticed a small blister on the dorsal aspect of the right 2nd toe after a minor scrape while gardening. He cleaned it with over‑the‑counter antiseptic, but over the next 48 h the area became erythematous, swollen, and increasingly painful to light touch. Yesterday he awoke with a “burning” sensation radiating up the forefoot, and the distal tip turned dark, now black, with foul odor. He denies fevers, chills, or systemic symptoms, but reports mild dyspnea on exertion (climbing two flights of stairs) and occasional orthopnea. He has been non‑compliant with his insulin regimen for the past week due to “forgetting” and has been taking only metformin 500 mg BID. He has been smoking 1 pack/day for 35 y, drinks socially (2‑3 beers/week). He presented to an urgent care on 03/16/3085 where a wound culture was taken (pending) and he was given oral clindamycin 300 mg QID and instructed to follow‑up. Pain persisted, and on 03/18/3085 the toe became black; EMS was called and he was brought to the ED. In the ED he was tachycardic (HR 112), BP 138/78, RR 22, SpO2 96% RA, T 38.2 °C. Labs showed leukocytosis (WBC 14.8 K), CRP 12 mg/dL, and a serum lactate 2.4 mmol/L. Bedside Doppler demonstrated absent pulses distal to the mid‑tarsal region. Vascular surgery was consulted and recommended admission for possible wet gangrene and urgent debridement. Patient is now on IV cefazolin 1 g q8h, insulin drip, and analgesia.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 3049
• Peripheral Arterial Disease – s/p fem‑pop bypass 3079
• Chronic Kidney Disease – Stage 3 (eGFR 45 mL/min)
• Hypertension – on lisinopril
• Hyperlipidemia – on rosuvastatin
• Gout – intermittent flares

Past Surgical History:
Procedure               Laterality   Date
Fem‑pop bypass          Right        07/12/3079
Left knee arthroscopy   Left         03/05/3065
Appendectomy            N/A          02/20/3050

Family History:
Father – MI at 62, HTN
Mother – CKD stage 4
Brother – T2DM
No known hereditary clotting disorders.

Social History:
Tobacco Use: Smoker, 1 ppd × 35 y
Alcohol Use: Social, 2‑3 beers/week
Illicit Drugs: Denies
Occupation: Retired electrician, now part‑time handyman
Living Situation: Lives alone in an apartment, limited mobility, relies on daughter for grocery runs.
Sexual Activity: Heterosexual, monogamous, last STI screen 2 y ago – negative.

Review of Systems:
Constitutional: +Fever 38.2 °C, +Weight loss 3 lb past week; -Chills, -Night sweats.
HEENT: -Vision changes, -Sore throat.
Cardiovascular: +HTN, -Chest pain, -Palpitations.
Respiratory: +Dyspnea on exertion, -Cough, -Wheezing.
Gastrointestinal: -Nausea, -Vomiting, -Abdominal pain.
Genitourinary: -Dysuria, -Hematuria.
Musculoskeletal: +Right foot pain, +Edema R foot; -Joint swelling elsewhere.
Neurologic: -Dizziness, -Headache.
Skin: +Black necrotic tip R 2nd toe, +Erythema; -Rash elsewhere.
Psych: -Depression, -Anxiety.

Prior to Admission Medications:
Medication                     Dose/Frequency
Metformin HCl                  500 mg PO BID
Lisinopril                     20 mg PO daily
Rosuvastatin                  10 mg PO nightly
Aspirin                       81 mg PO daily
Insulin glargine               30 U SC qd (patient reports missed doses)
Allopurinol                    300 mg PO daily
Vitamin D3                     2000 IU PO daily

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 38.2 °C, HR 112, RR 22, BP 138/78, SpO2 96% RA, Weight 112 kg (247 lb)
General: Alert, appears uncomfortable, NAD aside from foot pain.
HEENT: Normocephalic, PERRLA, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no rales, no wheezes.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: Right foot – edema up to mid‑midfoot, dusky discoloration of distal 2nd toe with black necrotic tip, foul odor, no crepitus. Dorsalis pedis pulse absent on right, present on left. Warmth preserved proximally. No other skin lesions.
Neurologic: AOx3, strength 5/5 proximally, 2/5 at toes R, 5/5 L.
Skin: No rashes elsewhere, intact skin elsewhere.

Laboratory Data (03/19/3085):
CBC: WBC 14.8 K, Hgb 12.1 g/dL, Hct 36%, Plt 312 K
BMP: Na 138, K 4.6, Cl 102, CO2 24, BUN 22, Cr 1.8 mg/dL (eGFR 45), Glu 312 mg/dL
CRP: 12 mg/dL
Procalcitonin: 0.9 ng/mL
Lactate: 2.4 mmol/L
ABG (room air): pH 7.32, pCO2 30, pO2 78, HCO3‑ 16
Coags: PT 13.1 s, INR 1.1, aPTT 32 s
Serum Lipids: LDL 92 mg/dL, HDL 44 mg/dL, TG 158 mg/dL
HbA1c (03/01/3085): 9.2%

Microbiology:
Wound culture (collected 03/16/3085) pending.
Blood cultures x2: No growth at 24 h.

Imaging:
Plain X‑ray Right foot (03/19/3085): Soft tissue swelling, gas lucencies within soft tissue of distal phalanx of 2nd toe consistent with wet gangrene; no underlying osteomyelitis evident.
Duplex US lower extremities (03/19/3085): Absent arterial flow distal to mid‑tarsal region R; patent left arterial flow.
CT Angiography lower extremities (ordered, pending): to assess for revascularization feasibility.

Assessment and Plan:
58yo M with T2DM, PAD s/p bypass, CKD‑3, HTN, now presenting with wet gangrene of right 2nd toe (RLE) secondary to delayed treatment of cellulitis/necrotizing infection. He is septic‑appearing (T 38.2, WBC 14.8, lactate 2.4) but hemodynamically stable. Plan:

1. Infectious: Continue IV cefazolin 1 g q8h pending cultures; add IV clindamycin 900 mg q8h for anaerobic coverage. If cultures grow MRSA or gram‑negative, adjust per sensitivities. Monitor CBC, CRP q24h.

2. Glycemic control: Initiate insulin drip (regular insulin infusion titrated to target glucose 140‑180 mg/dL). Hold oral agents. Check fingersticks q1h.

3. Vascular: Vascular surgery consult – urgent surgical debridement vs. possible transmetatarsal amputation. Await CTA results; consider percutaneous transluminal angioplasty if revascularization possible.

4. Renal: Adjust cefazolin dose for eGFR 45; monitor Cr q24h. Maintain fluid balance, avoid nephrotoxins.

5. Pain: IV morphine 2 mg q2h PRN, transition to PO oxycodone when tolerating.

6. DVT prophylaxis: SQ enoxaparin 40 mg SC daily (adjust for renal function).

7. Nutrition: Diabetic renal diet (protein 0.8 g/kg, sodium <2 g, potassium 2‑3 g). Consult dietitian.

8. Wound care: Daily dressing changes, wound vac considered post‑debridement.

9. Disposition: Admit to telemetry floor for close vitals, labs, and surgical timing. Anticipate possible ICU transfer if hemodynamic instability.

10. Education: Discuss smoking cessation, importance of glucose adherence, foot care. Provide smoking cessation resources.

Code Status: Full Code (Presumed)

Follow‑up labs: CBC, BMP, CRP q24h; repeat lactate q12h until <2.0. Wound cultures as soon as available.

Prepared by: Dr. Priya N. Shah, MD
Pager: 8421
Signature: /s/ Priya N. Shah, MD');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (22, 22, 38603008904, 38603008904, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 10/12/3066 03:05  

Patient: Ethan Marlowe  
DOB: 02/14/3025  
MRN: 98765432  
PCP: Dr. Lila Hart, MD  

Chief Complaint: Right foot pain, swelling, black discoloration  

History of Present Illness:  
41yo M with h/o T2DM (A1c 9.8%), PAD, HTN, CKD‑3, and recent plantar ulcer p/w worsening pain, edema, foul odor, and black necrotic tissue of the right forefoot. Patient reports that the ulcer began ~3 weeks ago after stepping on a nail at work; he initially cleaned it at home, applied OTC ointment, and continued to bear weight. Over the past 5 days pain escalated to 9/10, foot became dusky, then black, with increasing swelling up the leg. He noted foul smelling drainage and low‑grade fevers (T 38.2 °C) at home, but did not seek care until today when EMS was called by his wife after he could not ambulate. EMS noted HR 112, BP 138/84, RR 22, SpO2 96% RA, and a warm, erythematous right foot with crepitus. He was given 1 L NS en route, placed on high‑flow O₂, and transported to ED. In the ED he received IV cefazolin 1 g q8h, labs drawn, and a bedside Doppler showed absent pulses distal to the mid‑tarsal region. Orthopedic surgery was consulted and recommended transfer for possible emergent debridement. He denies chest pain, SOB, dysuria, or recent travel. No known sick contacts.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 3028, last A1c 9.8% (10/01/3065)  
• Hypertension – on lisinopril  
• Peripheral Arterial Disease – intermittent claudication, ABI 0.68 right  
• Hyperlipidemia – on atorvastatin 40 mg daily  
• Chronic Kidney Disease Stage 3 (eGFR 45 mL/min)  

Past Surgical History:  
• Left transmetatarsal amputation – 3062  
• Drug‑eluting stent to LAD – 3058  

Family History:  
Mother – HTN, died of stroke at 68  
Father – MI at 62, HTN  
Sister – healthy  

Social History:  
• Tobacco: 1 pack/day for 20 yr, currently smoking  
• Alcohol: 2‑3 beers weekends  
• Illicit drugs: denies  
• Occupation: construction laborer, frequent heavy lifting, exposure to metal debris  
• Living situation: lives with wife, two teenage children, owns home  

Review of Systems:  
Constitutional – fever, chills negative, weight loss negative  
HEENT – no visual changes, sore throat negative  
Cardiovascular – chest pain negative, palpitations negative  
Respiratory – dyspnea negative, cough negative  
GI – N/V/D negative, abdominal pain negative  
GU – dysuria negative, polyuria present (baseline)  
Musculoskeletal – right foot pain, swelling, black discoloration, limited ROM, no other joint pain  
Neurologic – peripheral neuropathy in feet (baseline), no new weakness  
Skin – described above, no rash elsewhere  
Psych – anxiety about amputation, otherwise stable  

Prior to Admission Medications:  
Medication                Sig  
Insulin glargine 30 U SC qHS  
Metformin 1000 mg PO BID  
Lisinopril 20 mg PO daily  
Atorvastatin 40 mg PO nightly  
Aspirin 81 mg PO daily  
Nitroglycerin SL 0.4 mg PRN chest pain  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs: T 38.3 °C, HR 115, RR 24, BP 140/86, SpO2 95% RA, Weight 102 kg (225 lb)  

General: Ill‑appearing, diaphoretic, in moderate distress, lying supine  
HEENT: Normocephalic, PERRLA, mucous membranes dry  
Neck: Supple, no JVD, carotid bruits absent  
Cardiovascular: Regular rate, tachycardic, S1 S2 normal, no murmurs, no rubs, peripheral pulses absent distal to right mid‑tarsal, left dorsalis pedis 2+  
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales  
Abdomen: Soft, non‑tender, normoactive bowel sounds  
Extremities: Right foot – extensive black necrosis of forefoot toes 1‑4, foul smelling serosanguinous drainage, edema to mid‑leg, crepitus noted. No erythema beyond foot. Left foot – intact, mild peripheral edema. No clubbing, cyanosis.  
Skin: Warm proximal to necrotic area, cool distal.  
Neurologic: AO×3, grossly intact sensation proximally, diminished distal to lesion.  
Psych: Anxious, cooperative  

Laboratory Data (drawn ED, verified):  
CBC: WBC 16.2 K/µL (neut 88%), Hgb 11.2 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.6, Cl 102, CO2 22, BUN 28 mg/dL, Cr 1.8 mg/dL (baseline 1.3), Glucose 312 mg/dL  
HbA1c: 9.8% (10/01/3065)  
CRP: 12.4 mg/dL  
Procalcitonin: 2.8 ng/mL  
Lactate: 2.1 mmol/L  

Microbiology: Wound swab sent for Gram stain/culture, blood cultures x2 drawn.  

Imaging:  
– Right foot X‑ray (10/12/3066): Soft tissue gas tracking along plantar fascia, cortical erosions of metatarsal heads suggestive of osteomyelitis. No obvious fracture.  
– Duplex ultrasound of right lower extremity: No DVT, arterial flow absent distal to mid‑tarsal.  
– CT angiography (pending) to assess revascularization options.  

Assessment and Plan:  
41yo M with poorly controlled T2DM, PAD, CKD‑3, now presenting with wet gangrene of right forefoot, sepsis (WBC 16.2, lactate 2.1), possible osteomyelitis, and acute kidney injury secondary to volume depletion and nephrotoxic exposure.  

1. Surgical Management – emergent right forefoot debridement/amputation (likely transmetatarsal or below‑knee) – OR scheduled ASAP. Vascular surgery consult for possible revascularization prior to amputation if feasible.  
2. Antimicrobial Therapy – broaden to IV vancomycin 15 mg/kg q12h (adjust for Cr) + piperacillin‑tazobactam 3.375 g q6h after cultures. De‑escalate per sensitivities.  
3. Glycemic Control – insulin drip targeting 140‑180 mg/dL, transition to basal‑bolus regimen when stable.  
4. Fluid Management – 30 mL/kg NS bolus, then maintain euvolemia; monitor urine output, adjust for CKD.  
5. Renal Protection – hold metformin, adjust lisinopril dose, monitor Cr q12h.  
6. DVT Prophylaxis – SQ enoxaparin 40 mg daily (adjust for Cr).  
7. Pain Control – IV morphine PCA, then PO oxycodone PRN.  
8. Wound Care – daily dressing changes, negative pressure wound therapy post‑op.  
9. Disposition – ICU for post‑op monitoring, telemetry for arrhythmia risk, continue broad‑spectrum antibiotics 5‑7 days then tailor.  
10. Education – discuss amputation level, prosthetic options, smoking cessation referral, diabetes education.  

Code Status: Full Code (Presumed)  
Level of Care: ICU – surgical service  

Andrew L. Whitaker, MD  
Hospital Medicine Attending  
Pager 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (23, 23, 43867340583, 43867340583, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
04/21/3084  
10:31 AM  

Patient: Marcus L. Whitaker  
DOB: 02/14/3049  
PCP: Dr. Eleanor Vance, MD  

CHIEF COMPLAINT: Fever, progressive dyspnea, and new‑onset cough  

HISTORY OF PRESENT ILLNESS:  
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 215,000), chronic HCV (treated), CKD‑3 (eGFR 42), HTN, and remote PCP‑nonadherent, presents from outside ED with 5‑day history of low‑grade fevers (Tmax 101.4°F), worsening dyspnea on exertion, and a productive cough now yellow‑green sputum. Pt reports “feeling like I’m drowning” after climbing two flights of stairs at work (warehouse loading dock). Denies chest pain, palpitations, PND, orthopnea. Reports recent weight loss ~8 lb over 2 weeks, night sweats, and diffuse myalgias. He was admitted to County Hospital 3 days ago for presumed PCP pneumonia; received ceftriaxone 2 g q24h and azithro 500 mg PO x5, but symptoms progressed after discharge. He also notes intermittent diarrhea and abdominal cramping, no blood. No recent travel, no known TB exposure. Admits occasional IV heroin use (last use 2 weeks ago) and daily tobacco (1 ppd) and binge alcohol (≈6 drinks/week).  

MEDICAL & SURGICAL HISTORY:  

Past Medical History:  
• HIV infection – diagnosed 2008, non‑adherent ART (last meds 4 mo ago)  
• Chronic hepatitis C – SVR 2022  
• Chronic kidney disease stage 3  
• Hypertension  
• Hyperlipidemia  
• Prior opportunistic infection – oral thrush 2021  

Past Surgical History:  
Procedure Laterality Date  
• Appendectomy — 03/12/3065  
• Right inguinal hernia repair Right 09/08/3072  

FAMILY HISTORY:  
Father – died 3075 of MI at 62  
Mother – alive, HTN, DM2  
Sister – alive, HIV+, on ART, well‑controlled  

SOCIAL HISTORY:  
Marital Status: Single, lives alone in low‑income housing  
Employment: Warehouse loader, full‑time  
Tobacco: Smokes 1 pack/day, 30‑yr pack‑year history, no quit attempts  
Illicit Drugs: IV heroin intermittent, last use 2 weeks ago; shares needles  
Alcohol: Social, ~6 drinks/week, binge on weekends  
Sexual Activity: Heterosexual, multiple partners, inconsistent condom use  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, night sweats, weight loss; negative for chills.  
HEENT: Sore throat, no vision changes.  
Respiratory: Positive for dyspnea, productive cough; negative for hemoptysis.  
Cardiovascular: No chest pain, palpitations, edema.  
GI: Diarrhea x3 days, abdominal cramp, no melena.  
GU: No dysuria, no flank pain.  
Musculoskeletal: Myalgias, no arthralgia.  
Neurologic: Headache, no focal deficits.  
Psychiatric: Anxiety about health, depressive affect.  
Dermatologic: No rash, no lesions.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
abacavir/lamivudine/dolutegravir Take 1 tablet PO daily (last taken 4 mo ago)  
lisinopril Take 20 mg PO daily  
amlodipine Take 5 mg PO daily  
atorvastatin Take 40 mg PO nightly  
cimetidine Take 400 mg PO BID (GERD)  
levothyroxine Take 75 µg PO daily (hypothyroid)  

ALLERGIES:  
No known drug allergies (NKDA)  

PHYSICAL EXAMINATION:  
Temperature: 38.9 °C (102 °F)  
Heart Rate: 112 bpm (irregularly irregular)  
Respiratory Rate: 24 bpm  
Blood Pressure: 138/84 mmHg  
SpO₂: 92 % on RA  
Weight: 78 kg (172 lb)  
General: Ill‑appearing, diaphoretic, mild distress, oriented x3.  
HEENT: Mucous membranes dry, oropharynx erythematous, no exudate.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: Irregularly irregular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Bilateral coarse crackles R>L bases, decreased breath sounds at bases, no wheezes.  
Abdomen: Soft, mildly tender RUQ, no hepatosplenomegaly.  
Extremities: No edema, peripheral pulses 2+ bilat.  
Skin: Multiple healed track marks on forearms, no active lesions.  
Neuro: Alert, CN II‑XII grossly intact, no focal deficits.  

LABS AND IMAGING:  

CBC:  
WBC 14.2 ×10⁹/L (neut 84%, lymph 8%)  
Hgb 10.8 g/dL  
Hct 32 %  
Plt 210 ×10⁹/L  

BMP:  
Na 138 mmol/L  
K 4.6 mmol/L  
Cl 102 mmol/L  
CO₂ 22 mmol/L  
BUN 28 mg/dL  
Cr 1.8 mg/dL (eGFR 42)  
Glucose 112 mg/dL  

Liver Panel:  
AST 58 U/L, ALT 62 U/L, Alk Phos 112 U/L, Total Bilirubin 1.2 mg/dL  

HIV Labs:  
CD4 78 cells/µL, HIV‑1 RNA 215,000 copies/mL  

HCV RNA: Undetectable  

CRP: 12 mg/dL (elevated)  
Procalcitonin: 0.9 ng/mL  

Arterial Blood Gas (on 2 L NC): pH 7.32, PaCO₂ 48 mmHg, PaO₂ 68 mmHg, HCO₃⁻ 24  

Chest X‑ray: Bilateral interstitial infiltrates, right lower lobe consolidation, no pleural effusion.  

CT Chest (w/ contrast): Diffuse ground‑glass opacities, right lower lobe cavitary lesion 2.3 cm, mediastinal lymphadenopathy.  

Blood cultures x2: pending  

Sputum Gram stain: many neutrophils, Gram‑negative rods; culture pending  

ASSESSMENT AND PLAN:  
58yo M with uncontrolled HIV/AIDS (CD4 < 100, VL > 200k), CKD‑3, HTN, and recent treatment‑failure pneumonia now presenting with probable opportunistic pulmonary infection (possible PCP vs. bacterial vs. fungal) and early sepsis.  

1. Pneumonia – likely mixed bacterial (Gram‑neg) and opportunistic (Pneumocystis jirovecii).  
   • Start IV TMP‑SMX 15 mg/kg (based on trimethoprim) q6h + primaquine 30 mg PO daily for PCP coverage.  
   • Add cefepime 2 g IV q8h for broad‑spectrum gram‑negative coverage pending cultures.  
   • Consider adding voriconazole if fungal elements on culture or if clinical deterioration.  
   • Continue azithromycin 500 mg IV daily for atypical coverage.  

2. HIV – uncontrolled, ART‑naïve for 4 mo.  
   • Initiate ART after stabilization: bictegravir/emtricitabine/tenofovir alafenamide 1 tablet PO daily (adjust for CrCl > 30).  
   • Consult Infectious Diseases for timing and prophylaxis.  

3. PCP prophylaxis – already covered by TMP‑SMX; continue for CD4 < 200.  

4. CKD‑3 – adjust cefepime dose (2 g q12h) and avoid nephrotoxic agents. Monitor Cr q24h.  

5. Hypertension – continue lisinopril 20 mg PO daily; hold if K > 5.5.  

6. Fluid management – 1 L NS bolus then maintain euvolemia; monitor I/O.  

7. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for CrCl).  

8. Isolation – airborne + contact precautions for PCP pending confirmatory test.  

9. Labs/Imaging – repeat CBC, BMP, lactate q12h; send sputum fungal stain; obtain serum (1,3)-β‑D‑glucan.  

10. Disposition – Admit to intermediate‑care unit, telemetry for arrhythmia monitoring.  

CODE STATUS: Full Code (Presumed)  

ATTENDING: Dr. Samuel K. Ortega, MD  
Pager: 84219  

--- End of Note ---');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (24, 24, 10225620358, 10225620358, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'PATIENT:  Evelyn Mae Calderon
MRN:  84201957
DOB:  02/14/3068
PCP:  Dr. Lionel Hargrave, MD

DATE OF ADMISSION: 09/17/3092
TIME: 18:22
ADMITTING ATTENDING: Dr. Selene K. Voss, MD
LOCATION: MED-02B
SERVICE: Hospital Medicine

CHIEF COMPLAINT: Cough, dyspnea, fever x4 days

HISTORY OF PRESENT ILLNESS:
58yo F w/ h/o HTN, T2DM (A1c 8.6% 02/3092), CKD stage 3, and remote cholecystectomy p/w progressive dyspnea, productive cough (yellow‑green sputum), subjective fevers, chills, and pleuritic chest pain for the past 4 days. Pt reports onset after a weekend trip to the coastal resort where she attended a family reunion; denies recent travel outside the region. Initially self‑treated with OTC acetaminophen and ibuprofen, thought it was a “cold”. On day 2 she developed low‑grade fever (max 38.3°C) and cough became more productive; visited urgent care on 09/13/3092 where a rapid strep test was negative, chest X‑ray read as “possible infiltrate” and she was prescribed azithromycin 500 mg PO daily x3 days and albuterol inhaler PRN. She completed the azithromycin course but symptoms worsened, with increased sputum volume, dyspnea at rest, and new onset fatigue. On 09/16/3092 she presented to the ED of the regional medical center. Vitals in ED: T 38.9°C, HR 112, RR 24, BP 138/78, SpO2 91% on RA. Labs showed WBC 16.2 K with left shift, lactate 2.1 mmol/L, procalcitonin 1.8 ng/mL. CXR demonstrated a right lower lobe consolidation with air bronchograms. She received 2 L NS, ceftriaxone 1 g IV q24h, and azithromycin 500 mg IV q24h. After 6 h she remained tachypneic, required 2 L NC to maintain SpO2 > 94%, and was transferred to our facility for continued management and possible ICU evaluation. On arrival to our floor she is alert, oriented x3, appears mildly uncomfortable, and reports “feeling like I can’t catch my breath”.

REVIEW OF SYSTEMS:
Constitutional: +fever, chills, fatigue; – weight loss, night sweats.
HEENT: +sore throat 2 days ago, – vision changes, hearing loss.
Cardiovascular: – chest pain at rest, palpitations, edema.
Respiratory: +productive cough, dyspnea at rest, pleuritic chest pain; – wheezes, hemoptysis.
GI: – N/V, abdominal pain, diarrhea.
GU: – dysuria, frequency; – flank pain.
Musculoskeletal: – myalgias, arthralgias; – no focal weakness.
Neurologic: – headache, dizziness; – no focal deficits.
Psych: +anxiety about illness; – depression, SI/HI.
Skin: – rashes, lesions.

PAST MEDICAL HISTORY:
• Hypertension (diagnosed 3075)
• Type 2 Diabetes Mellitus
• Chronic Kidney Disease stage 3 (baseline Cr 1.6 mg/dL)
• Hyperlipidemia
• Osteoarthritis of knees

PAST SURGICAL HISTORY:
• Laparoscopic cholecystectomy (09/3078)
• Right total knee arthroplasty (03/3085)

FAMILY HISTORY:
Mother – HTN, died of stroke 3090 age 78.
Father – CKD, on dialysis, alive 82.
Sister – T2DM.
No known hereditary cancer syndromes.

SOCIAL HISTORY:
Marital status: Married.
Occupation: Retired elementary school teacher.
Tobacco: Never smoker.
Alcohol: Social, 1‑2 drinks/week.
Illicit drugs: Denies.
Living situation: Lives with husband in single‑family home; caregiver support available.
Travel: Coastal resort 09/12‑09/13/3092.

ALLERGIES:
No known drug allergies (NKDA).

MEDICATIONS PRIOR TO ADMISSION:
metformin 1000 mg PO BID
lisinopril 20 mg PO daily
amlodipine 10 mg PO daily
atorvastatin 40 mg PO nightly
furosemide 20 mg PO daily
insulin glargine 30 U SC qHS
albuterol inhaler 2 puffs PRN
acetaminophen 500 mg PO q6h PRN

PHYSICAL EXAMINATION:
VITALS: T 38.6 °C, HR 108, RR 22, BP 136/80, SpO2 93% on room air, Weight 84 kg (185 lb).

GENERAL: Alert, NAD, appears mildly dyspneic, oriented x3.
HEENT: Normocephalic, PERRLA, oropharynx erythematous, no exudates.
NECK: Supple, no JVD, no lymphadenopathy.
CARDIOVASCULAR: RRR, S1 S2 normal, no murmurs, rubs, gallops.
RESPIRATORY: Decreased breath sounds RLL, crackles + at bases, egophony present RLL, no wheezes.
ABDOMEN: Soft, NT, BS +, no hepatosplenomegaly.
EXTREMITIES: Warm, no edema, pulses 2+ bilat.
SKIN: No rashes, no lesions.
NEURO: AOx3, CN II‑XII grossly intact, no focal deficits.

LABORATORY DATA (most recent):
CBC: WBC 15.8 K (neut 84%), Hgb 12.1 g/dL, Hct 36%, Plt 312 K.
BMP: Na 138, K 4.5, Cl 102, CO2 22, BUN 22, Cr 1.7 mg/dL (eGFR 38 mL/min), Glu 162 mg/dL.
LFT: AST 34 U/L, ALT 38 U/L, ALP 88 U/L, TBili 0.8 mg/dL.
CRP: 12.4 mg/dL.
Procalcitonin: 1.9 ng/mL.
ABG (room air): pH 7.32, PaCO2 38, PaO2 68, HCO3‑ 20.
Blood cultures x2: pending.
Sputum Gram stain: many PMNs, Gram‑negative rods.
Urine dip: negative.

IMAGING:
Chest X‑ray (09/16/3092): Right lower lobe consolidation with air bronchograms, mild left basilar interstitial markings.
CT chest w/ contrast (09/16/3092): Confirms RLL consolidation, no cavitation, no PE.

ASSESSMENT / PLAN:
1. COMMUNITY‑ACQUIRED PNEUMONIA, likely bacterial (right lower lobe) with early sepsis. Continue ceftriaxone 1 g IV q24h and azithromycin 500 mg IV q24h. Re‑evaluate cultures at 48 h; de‑escalate based on sensitivities. Consider adding vancomycin if MRSA risk factors emerge.
2. SEPSIS (SIRS + lactate 2.1). Maintain IV fluids 30 mL/kg bolus, then reassess MAP; target MAP >65 mmHg. Continue telemetry for arrhythmia monitoring.
3. DIABETES MELLITUS – hyperglycemia on admission (BG 162‑190). Restart insulin glargine 30 U qHS; add sliding scale regular insulin qac PRN for BG >180.
4. CHRONIC KIDNEY DISEASE – adjust ceftriaxone dose if Cr >2.0 (currently 1.7, continue standard dose). Monitor Cr q24h.
5. HYPERTENSION – hold lisinopril today (BP stable), resume when euvolemic.
6. DVT PROPHYLAXIS – SQ enoxaparin 40 mg SC daily (adjust for Cr if <30).
7. NUTRITION – Diabetic diet, cardiac diet (low sodium, low fat).
8. CODE STATUS – Full Code (presumed).
9. TELEMETRY – Low‑risk telemetry for arrhythmia monitoring.
10. CONSULTS: Infectious Diseases (recommendation on duration, possible atypical coverage), Nephrology (renal dosing), Pharmacy (antibiotic stewardship).
11. DISPOSITION: Admit to step‑down unit; anticipate 5‑7 day course of IV antibiotics, then transition to PO (levofloxacin 750 mg PO daily) if clinically improving and cultures negative for resistant organisms.
12. PATIENT EDUCATION: Discussed diagnosis, need for IV antibiotics, glucose monitoring, signs of worsening (increased SOB, chest pain, confusion). Provided smoking cessation resources (though never smoker) and encouraged fluid intake.

FOLLOW‑UP: Labs q24h, repeat CXR day 3, reassess clinical status daily.  

Selene K. Voss, MD
Hospitalist, Service Attending  
Pager: 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (25, 25, 92996718023, 92996718023, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

05/20/3078 11:34

Patient: Miguel Alvarez
DOB: 02/14/3045
MRN: 98765432
PCP: Dr. Lila Moreno, MD

CHIEF COMPLAINT: Low back pain, worsening over 3 days

HISTORY OF PRESENT ILLNESS:
58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), chronic low back pain s/p L4‑L5 discectomy 2015, and recent admission for UTI (04/28/3078) p/w dysuria and fever now presents with acute exacerbation of lumbar pain. Patient reports sharp, constant 7/10 pain radiating to left buttock, worsened by standing >10 min and flexion, partially relieved by lying supine and ibuprofen. He notes new numbness over the dorsum of the left foot and occasional tingling in the big toe since yesterday. Denies bowel/bladder incontinence, saddle anesthesia, or recent trauma. He was discharged from outside hospital on 04/30 after 3 days IV ceftriaxone, completed oral ciprofloxacin 5 days ago, and was told to follow up with PCP. Since discharge he has been ambulating more, but pain escalated after a weekend gardening session where he lifted a 30‑lb pot. He tried OTC naproxen 500 mg BID with minimal relief, and used a heating pad intermittently. No recent weight loss, fevers, or night sweats. He reports occasional alcohol (1‑2 beers/week) and denies tobacco or illicit drug use. He is concerned about possible disc herniation recurrence and wants imaging.

MEDICAL & SURGICAL HX:

Past Medical History:
• Hypertension (diagnosed 2022)
• Chronic kidney disease stage 3
• Low back pain, s/p L4‑L5 microdiscectomy 2015
• Urinary tract infection 04/28/3078
• Hyperlipidemia

Past Surgical History:
Procedure               Laterality   Date
L4‑L5 microdiscectomy   Left        06/12/2015
Appendectomy            N/A         09/03/3010

FAMILY HX:
Problem                Relation    Age of Onset
Hypertension           Mother      55
CKD                    Father      60
Coronary artery disease  Brother   58

SOCIAL HX:
Marital status: Married
Spouse: Ana Alvarez
Children: 2 (ages 12 and 9)
Employment: Construction foreman (full‑time)
Tobacco: Never smoker
Alcohol: Social (1‑2 beers/week)
Illicit drugs: None
Living situation: Own home, 2‑story, stairs present
Physical activity: Light gardening, occasional weight lifting at work

REVIEW OF SYSTEMS:
Constitutional: Negative for fever, chills, weight loss.
HEENT: No visual changes, hearing normal.
Cardiovascular: No chest pain, palpitations, edema.
Respiratory: No cough, dyspnea at rest.
Gastrointestinal: No nausea, vomiting, abdominal pain.
Genitourinary: No dysuria now, no hematuria.
Musculoskeletal: Positive low back pain radiating left, numbness left foot; negative shoulder, knee pain.
Neurologic: No headache, dizziness, syncope; positive left foot paresthesia.
Skin: No rashes.
Psychiatric: No depression or anxiety reported.

PRIOR TO ADMISSION MEDICATIONS:
Medication                     Sig
lisinopril 20 MG tablet        TAKE 1 TAB PO DAILY
amlodipine 10 MG tablet        TAKE 1 TAB PO DAILY
atorvastatin 40 MG tablet      TAKE 1 TAB PO DAILY
acetaminophen 500 MG tablet    PRN Q6H PRN pain
naproxen 500 MG tablet        TAKE 1 TAB PO BID PRN pain
vitamin D3 2000 IU capsule    TAKE 1 CAP PO DAILY

Allergies:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 36.8 °C (98.2 °F)
Heart Rate: 88 bpm
Respiratory Rate: 16/min
Blood Pressure: 138/82 mmHg
SpO2: 98% RA
General: Alert, NAD, appears stated age, mild discomfort on movement.
HEENT: Normocephalic, PERRLA, mucous membranes moist.
Neck: Supple, no JVD, no lymphadenopathy.
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, rales or rhonchi.
Abdomen: Soft, NT, +BS, no masses.
Back: Tender over L4‑L5 region, decreased ROM on flexion/extension, positive straight leg raise left at 45°, diminished sensation to light touch over left dorsum foot, strength 5/5 proximally, 4/5 toe extensors left.
Extremities: No edema, pulses 2+ bilaterally.
Skin: Warm, dry, no lesions.
Neurologic: AOx3, CN II‑XII grossly intact, gait antalgic, reflexes 2+ bilat, Babinski negative.

LABS (drawn on admission):
CBC:
WBC 9.2 K/µL
Hgb 13.1 g/dL
Hct 39%
Plt 242 K/µL

BMP:
Na 138 mmol/L
K 4.5 mmol/L
Cl 102 mmol/L
CO2 24 mmol/L
BUN 22 mg/dL
Cr 1.7 mg/dL (baseline)
Glucose 112 mg/dL

CRP 4.2 mg/dL (elevated)
ESR 28 mm/hr

UA: Clear, specific gravity 1.015, no leukocyte esterase, no nitrites, no bacteria.

Imaging:
CT lumbar spine without contrast (ordered) pending – to evaluate for disc herniation vs. stenosis.

EKG: Normal sinus rhythm, HR 86, no ischemic changes.

IMPRESSION/PLAN:
58yo M with chronic low back pain s/p L4‑L5 microdiscectomy now with acute exacerbation, radicular symptoms left lower extremity, possible recurrent disc herniation vs. post‑surgical scar tissue. CKD stage 3 limits NSAID use; consider acetaminophen and short course oral steroids if no contraindication. Plan:

1. Analgesia: Continue acetaminophen 650 mg q6h PRN, add tramadol 50 mg PO q6h PRN for breakthrough pain, hold naproxen pending renal function review.
2. Imaging: CT lumbar spine non‑contrast today; if concerning for surgical compression, obtain MRI next.
3. Consults: Neurosurgery for possible operative evaluation; Pain Management for multimodal regimen.
4. Labs: Repeat BMP q24h, monitor Cr.
5. DVT prophylaxis: SQ low‑molecular‑weight heparin 40 mg SC daily (unless contraindicated).
6. Activity: Bed rest limited to 24 h, then ambulate with PT assistance, avoid heavy lifting.
7. Education: Discuss proper body mechanics, use of lumbar support, avoid prolonged standing.
8. Disposition: Admit to med‑surg floor, telemetry not required, monitor neuro status.

CODE STATUS: Full Code (Presumed)

Attending: Dr. Samuel K. Patel, MD
Pager: 84219

(Note: This note was generated using voice recognition; minor transcription errors may be present; please verify.)');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (26, 26, 76482833548, 76482833548, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
12/11/3084 10:24  

Patient: Marcus L. Whitaker  
DOB: 03/22/3049 (35 y/o)  
PCP: Dr. Elaine V. Kline, MD  

CHIEF COMPLAINT: Dysuria, suprapubic pain, fever  

HISTORY OF PRESENT ILLNESS:  
35yo M with h/o recurrent UTIs (last 2 yr), neurogenic bladder secondary to sacral chordoma resection (2019), and intermittent self‑catheterization presents to ED w/ 2‑day history of worsening dysuria, cloudy urine, suprapubic tenderness, and low‑grade fevers up to 38.6°C. Pt reports N/V x1 episode yesterday, no flank pain, no gross hematuria. He notes increased catheterization frequency to q4h over past 48 h because of decreased urine output. Denies recent sexual activity, new sexual partners, or recent travel. He was seen 3 days ago at an urgent care where a dipstick showed +leukocyte esterase and +nitrites; he was prescribed TMP‑SMX 800/160 mg BID but stopped after 1 dose due to nausea. Pt reports compliance with clean intermittent catheterization (CIC) technique taught by rehab, but admits occasional missed hand‑washing. No known drug allergies.  

Outside Hospital Course: Transferred from community ED after CT abdomen/pelvis showed no obstruction, but noted mild bladder wall thickening. Received 1 L NS, acetaminophen 650 mg PO, and a dose of IV ceftriaxone 1 g. Blood cultures drawn, urine sent for culture and sensitivity.  

MEDICAL & SURGICAL HX:  

Past Medical History:  
• Neurogenic bladder – post‑sacral chordoma resection 2019  
• Recurrent urinary tract infections  
• Hypertension – controlled on lisinopril  
• Obesity (BMI 32)  

Past Surgical History:  
Procedure Laterality Date  
• Sacral chordoma resection – Midline – 06/15/3019  
• Appendectomy – RLQ – 02/08/3030  

FAMILY HX:  
Father – HTN, died MI age 62  
Mother – DM2, alive 68  
Sister – healthy  

SOCIAL HX:  
Marital Status: Single, lives alone in assisted‑living apartment  
Employment: Unemployed, receiving disability benefits  
Tobacco Use: Never smoker  
Alcohol Use: Social, 1‑2 drinks/week  
Illicit Drugs: Denies  
Sexual Activity: Heterosexual, monogamous, last activity 3 mo ago, uses condoms inconsistently  
Housing: Stable, no recent moves  
Support: Sister visits weekly  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills; negative for weight loss.  
Genitourinary: Positive for dysuria, suprapubic pain, urgency, frequency, cloudy urine; negative for flank pain, hematuria.  
GI: N/V x1, no diarrhea, no abdominal pain.  
Respiratory: No cough, dyspnea.  
Cardiovascular: No chest pain, palpitations.  
Neurologic: No headache, no focal deficits.  
Skin: No rashes.  
Psych: No depression or anxiety noted.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
lisinopril 20 MG tablet TAKE 1 TABLET BY MOUTH DAILY  
hydrochlorothiazide 25 MG tablet TAKE 1 TABLET BY MOUTH DAILY  
metformin 500 MG tablet TAKE 1 TABLET BY MOUTH BID  
TMP‑SMX 800/160 MG tablet TAKE 1 TABLET BY MOUTH BID (started 3 days ago, discontinued)  

ALLERGIES:  
No known drug allergies (NKDA)  

PHYSICAL EXAMINATION:  
Temperature: 38.4 °C (101.1 °F)  
Heart Rate: [70‑110] 96 bpm  
Respiratory Rate: [12‑20] 18 breaths/min  
Blood Pressure: (110‑150)/(60‑90) 132/78 mmHg  
SpO₂: 98 % on RA  

General: Alert, oriented x3, appears mildly uncomfortable, NAD otherwise.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales or rhonchi.  
Abdomen: Soft, mild suprapubic tenderness to palpation, no rebound, no guarding, bowel sounds present.  
Genitourinary: External genitalia normal, catheter site clean, no erythema.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neuro: AOx3, CN II‑XII grossly intact, strength 5/5 all extremities.  

LABS:  
CBC – 12/11/3084  
WBC 13.2 ×10⁹/L (Neut 84%)  
Hgb 13.5 g/dL  
Hct 40 %  
Plt 312 ×10⁹/L  

BMP – 12/11/3084  
Na 138 mmol/L  
K 4.3 mmol/L  
Cl 102 mmol/L  
CO₂ 24 mmol/L  
BUN 14 mg/dL  
Cr 0.9 mg/dL (eGFR 95 mL/min)  

CRP 8.5 mg/L (elevated)  

Urinalysis (point‑of‑care) – Positive leukocyte esterase, nitrites, WBC 45/hpf, bacteria many, RBC 2/hpf.  

Urine culture sent – pending.  

Blood cultures – pending.  

Imaging:  
Renal/bladder ultrasound 12/11/3084 – No hydronephrosis, bladder wall thickening ~4 mm, post‑void residual 120 mL.  

Assessment and Plan:  
1. Acute uncomplicated cystitis in setting of neurogenic bladder, likely ESBL‑producing E. coli (pending culture).  
   • Start IV ceftriaxone 1 g q24h now; will de‑escalate to oral ciprofloxacin 500 mg BID once sensitivities return and patient tolerates PO.  
   • Continue clean intermittent catheterization every 4 h, reinforce aseptic technique, consider prophylactic low‑dose nitrofurantoin if recurrent episodes persist.  
   • Encourage increased oral fluid intake ≥2 L/day, monitor urine output.  

2. Hypertension – continue lisinopril 20 mg daily, monitor BP q8h.  

3. Obesity – dietitian consult for calorie‑controlled diet, encourage ambulation as tolerated.  

4. Pain/fever – Acetaminophen 650 mg PO q6h PRN, consider ibuprofen 400 mg PO q8h if no contraindication.  

5. DVT prophylaxis – SQ low‑molecular‑weight heparin 40 mg SC daily.  

6. Code Status: Full Code (Presumed).  

7. Disposition: Admit to medical floor, telemetry not required, monitor vitals q4h, repeat CBC and BMP in 48 h, reassess after culture results.  

8. Education: Reviewed signs of worsening infection, importance of catheter hygiene, when to call nursing.  

Attending: Dr. Victor M. Larkin, MD  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (27, 27, 91447658882, 91447658882, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL  
06/14/3058 19:24  

Patient: Marcus L. Whitaker  
DOB: 02/03/2985  
MRN: 98765432  
PCP: Dr. Elaine V. Kline, MD  

CHIEF COMPLAINT: Fever, profuse night sweats, progressive dyspnea, and diffuse abdominal pain  

HISTORY OF PRESENT ILLNESS:  
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2 × 10⁶ copies/mL), chronic HCV (genotype 1a, untreated), prior PCP pneumonia (2 y ago), and remote TB (treated 1998) presents from the ED with 10‑day history of intermittent fevers up to 39.4 °C, night sweats soaking sheets, worsening dyspnea on exertion, and a new diffuse, crampy abdominal pain radiating to the RLQ. He reports a 12‑kg weight loss over the past month despite a reported appetite of “fair”. He was seen 3 days ago at an outside urgent care where a rapid HIV test was positive (known baseline) and a chest X‑ray showed bilateral interstitial infiltrates; he was given azithromycin 500 mg PO daily and discharged with instructions to follow up. Since then, symptoms have progressed, now with cough productive of scant yellow sputum, and occasional non‑bloody diarrhea. He denies chest pain, orthopnea, PND, dysuria, or focal neurologic deficits. He reports poor adherence to his ART regimen (tenofovir/emtricitabine/efavirenz) for the past 6 weeks due to nausea and “feeling too sick to take meds”. He also admits to occasional IV heroin use (last use 4 days ago) and daily smoking (1 pack). No recent travel, no known TB contacts.  

ED COURSE: Vitals on arrival: T 38.9 °C, HR 112, BP 118/68, RR 24, SpO₂ 92 % on RA, weight 78 kg (172 lb). Labs: WBC 14.2 K with left shift, Hgb 10.8 g/dL, Plt 210 K, Na 136, K 4.5, Cl 102, CO₂ 22, BUN 18, Cr 1.1, ALT 84, AST 92, Alk Phos 112, total bili 1.2, CD4 78, HIV VL 1.2 × 10⁶, HCV RNA 5.6 × 10⁶. CXR: diffuse bilateral reticulonodular opacities. CT chest/abdomen/pelvis: diffuse ground‑glass opacities, mild mediastinal lymphadenopathy, splenomegaly (14 cm), and a 2.3 cm hypodense lesion in the right hepatic lobe. Blood cultures x2 pending. Sputum Gram stain: many PMNs, rare Gram‑negative rods.  

He was started on IV cefepime 2 g q8h, oral azithromycin 500 mg daily, TMP‑SMX DS for PCP prophylaxis (held due to sulfa allergy), and IV fluconazole 400 mg daily for possible fungal infection. ART was held pending evaluation. He was admitted to the medical floor for further work‑up of opportunistic infection vs. disseminated mycobacterial disease.

MEDICAL & SURGICAL HX  

Past Medical History:  
• HIV infection, diagnosed 2002 (uncontrolled)  
• Chronic hepatitis C infection (genotype 1a)  
• Prior PCP pneumonia (2019)  
• Remote treated TB (1998)  
• Hypertension (diagnosed 2025)  

Past Surgical History:  
• Appendectomy – L – 03/12/3005  
• Right inguinal hernia repair – L – 07/08/3012  

FAMILY HX:  
Father – deceased (MI at 62)  
Mother – alive, HTN, DM2  
Sister – alive, HIV negative, no chronic illness  

SOCIAL HX:  
Marital status: Single, lives alone in a transitional housing unit  
Tobacco: Current smoker, 1 ppd, 30‑yr pack‑year history  
Alcohol: Social drinker, 2‑3 drinks/week  
Illicit drugs: IV heroin, last use 4 days ago; shares needles intermittently  
Sexual history: Multiple male partners, inconsistent condom use, last HIV care visit 8 weeks ago  
Housing: Unstable, recent shelter stay  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, night sweats, weight loss; negative for chills.  
HEENT: No sore throat, no visual changes.  
Respiratory: Positive for dyspnea, cough with scant sputum; negative for hemoptysis.  
Cardiovascular: No chest pain, palpitations.  
GI: Positive for diffuse abdominal pain, non‑bloody diarrhea x2 days; negative for vomiting.  
GU: No dysuria, no flank pain.  
Musculoskeletal: No myalgias, no joint swelling.  
Neurologic: No headache, no focal deficits.  
Dermatologic: No rash, no lesions.  
Psychiatric: Reports anxiety about housing, occasional depressive symptoms.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication                     Sig  
tenofovir/emtricitabine/efavirenz 1 tablet PO daily (non‑adherent)  
lisinopril 20 mg PO daily  
amlodipine 10 mg PO daily  
hydroxyzine 25 mg PO PRN for itching  
acetaminophen 650 mg PO q6h PRN for fever  

Allergies:  
Sulfa – rash (hives)  

PHYSICAL EXAMINATION:  
Temperature: 38.9 °C (102 °F)  
Heart Rate: 112 bpm  
Respiratory Rate: 24/min  
Blood Pressure: 118/68 mmHg  
SpO₂: 92 % on RA  
Weight: 78 kg (172 lb)  

General: Ill‑appearing, diaphoretic, mild distress, oriented x3.  
HEENT: Normocephalic, mucous membranes dry, no oral thrush noted.  
Neck: Supple, no JVD, no cervical adenopathy.  
Cardiovascular: Regular rate, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Bilateral coarse crackles at bases, decreased breath sounds posteriorly, no wheezes.  
Abdomen: Soft, mildly distended, diffuse tenderness, no rebound, hepatomegaly 2 cm, splenomegaly palpable.  
Extremities: No edema, no clubbing, track marks noted on left forearm.  
Skin: No rashes, healed scar from prior hernia repair.  
Neuro: Alert, oriented, CN II‑XII grossly intact, no focal deficits.  

LABS & IMAGING (selected):  
CBC: WBC 14.2 K, Hgb 10.8 g/dL, Plt 210 K  
BMP: Na 136, K 4.5, Cl 102, CO₂ 22, BUN 18, Cr 1.1, Glucose 112  
LFTs: AST 92, ALT 84, Alk Phos 112, Total bili 1.2  
CD4: 78 cells/µL, HIV VL 1.2 × 10⁶ copies/mL  
HCV RNA: 5.6 × 10⁶ IU/mL  
CRP: 12.4 mg/dL, Procalcitonin: 0.8 ng/mL  
Blood cultures: pending  
Sputum Gram stain: many PMNs, rare Gram‑negative rods (no AFB seen)  
Chest X‑ray: diffuse bilateral reticulonodular infiltrates  
CT chest/abdomen/pelvis: bilateral ground‑glass opacities, mediastinal nodes, splenomegaly, 2.3 cm hypodense right hepatic lesion  

EKG: Sinus tachycardia, HR 112, no ischemic changes  

ASSESSMENT:  
58yo M with uncontrolled HIV/AIDS (CD4 78, VL high), chronic HCV, and recent IV drug use presenting with fever, progressive dyspnea, diffuse abdominal pain, and radiographic evidence of diffuse interstitial lung disease and possible hepatic lesion. Differential includes opportunistic infections (Pneumocystis jirovecii pneumonia, disseminated Mycobacterium avium complex, CMV pneumonitis, fungal infection such as Histoplasma or Cryptococcus), bacterial superinfection, and drug‑related lung injury. Hepatic lesion raises concern for HCV‑related HCC vs. disseminated infection.  

PLAN:  
1. Continue broad‑spectrum IV antibiotics (cefepime) and add oral azithromycin; hold until cultures return.  
2. Initiate high‑dose IV TMP‑SMX (15 mg/kg/day divided q6h) for presumptive PCP pending bronchoscopy; monitor for sulfa reaction.  
3. Order bronchoscopy with BAL for PCP PCR, fungal stains, AFB, CMV PCR.  
4. Obtain serum (1‑3)-β‑D‑glucan and galactomannan; start empiric IV fluconazole 400 mg daily pending results.  
5. Hepatic lesion: schedule abdominal MRI with contrast; obtain AFP, CEA.  
6. Re‑initiate ART on day 3 if no contraindication; consider integrase‑based regimen (dolutegravir/abacavir/lamivudine) after baseline labs.  
7. Start prophylaxis for MAC (azithromycin 1200 mg weekly) if CD4 remains <50 after 2 weeks of therapy.  
8. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
9. Fluid management: maintain euvolemia, monitor input/output.  
10. Consult Infectious Diseases, Hepatology, and Social Work for housing and substance use counseling.  
11. Code status: Full Code (presumed).  
12. Disposition: Admit to telemetry floor, anticipate ICU transfer if respiratory status worsens.  

FOLLOW‑UP: Labs q24h, vitals q4h, repeat CXR in 48 h, BAL results in 72 h.  

Patrick W. Hargrove, MD  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (28, 28, 73270670196, 73270670196, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 11/30/3060 00:56  
Patient: Michael A. Thorne  
DOB: 04/12/3015  
MRN: 98765432  
PCP: Dr. Elaine V. Kline, MD  

Chief Complaint:  
Progressive malaise, weight loss, and generalized weakness for 8 weeks.

History of Present Illness:  
58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), COPD (GOLD B), and remote colon cancer s/p resection (2018) p/w 8‑wk history of worsening malaise, anorexia, and failure to thrive. Denies fever, chills, night sweats, cough, dyspnea at rest, chest pain, abdominal pain, N/V/D, dysuria or change in bowel habits. He reports a 12‑lb (5.4 kg) unintentional weight loss despite unchanged diet, increased fatigue limiting ADLs (needs assistance to get out of bed). He notes occasional light‑headedness when standing, but no syncope. Review of recent labs from outside hospital (09/15/3060) showed mild normocytic anemia (Hgb 11.2) and hypoalbuminemia (3.2 g/dL). He was seen at an urgent care 2 weeks ago, given a short course of azithromycin for presumed bronchitis – no improvement. No recent travel, sick contacts, or known exposures. He lives alone in an assisted‑living apartment, receives meals on wheels. He reports occasional alcohol (1‑2 beers/week) and denies tobacco or illicit drug use. He has not been to the gym in months due to fatigue. He is concerned about “just getting older” but wants evaluation for possible underlying cause (malignancy vs. chronic disease progression).  

Past Medical History:  
- Hypertension (diagnosed 2022) – on lisinopril 20 mg daily  
- Chronic kidney disease stage 3 (baseline eGFR 45)  
- COPD, former smoker 20‑pack‑yr, quit 2015 – on tiotropium inhaler daily  
- Colon adenocarcinoma s/p left hemicolectomy 2018, completed adjuvant chemo 2019, currently in surveillance  
- Osteoarthritis of knees  
- GERD  

Past Surgical History:  
- Left hemicolectomy (2018) – Laparoscopic  
- Right knee arthroscopy (2025)  

Family History:  
- Mother: HTN, died of stroke at 78  
- Father: CAD, MI at 66, deceased 2045  
- Sister: Breast cancer diagnosed 2032, alive  

Social History:  
Marital Status: Single, lives alone, assisted‑living facility  
Employment: Retired electrician  
Tobacco: Never smoker (quit nicotine patches 2015)  
Alcohol: Social – 1‑2 beers/week, no binge  
Illicit Drugs: Denies  
Sexual Activity: Heterosexual, monogamous, last activity 6 months ago, uses condoms intermittently  
Support: Daughter lives 30 mi away, visits weekly; home health aide visits twice weekly  

Review of Systems:  
Constitutional: +weight loss, +fatigue, -fever, -chills, -night sweats.  
HEENT: -headache, -vision changes, -sore throat.  
Cardiovascular: -chest pain, -palpitations, -edema.  
Respiratory: -cough, -dyspnea at rest, -wheezes.  
Gastrointestinal: -nausea, -vomiting, -diarrhea, -abdominal pain.  
Genitourinary: -dysuria, -hematuria.  
Musculoskeletal: +knee OA, -myalgias.  
Neurologic: -dizziness, -syncope, -weakness focal.  
Psychiatric: -depression, -anxiety.  
Skin: -rashes, -lesions.  

Prior to Admission Medications:  
Lisinopril 20 mg PO daily  
Tiotropium inhaler 18 mcg inhalation daily  
Albuterol inhaler 90 mcg PRN q4‑6h PRN SOB  
Aspirin 81 mg PO daily  
Omeprazole 20 mg PO daily  
Acetaminophen 500 mg PO q6h PRN pain  
Vitamin D3 2000 IU PO daily  

Allergies:  
No known drug allergies.

Physical Examination:  
Vital Signs: Temp 36.8 °C (98.2 °F), HR 92 bpm, RR 18/min, BP 138/78 mmHg, SpO₂ 96% RA, Weight 68 kg (150 lb) (down 5 kg since last visit).  

General: Elderly male, appears thin, mildly ill‑looking, NAD, alert, oriented x3.  

HEENT: Normocephalic, atraumatic, mucous membranes dry, oropharynx clear, no cervical adenopathy.  

Neck: Supple, no JVD, no thyromegaly.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Clear to auscultation bilaterally, mild decreased breath sounds at bases, no wheezes or rales.  

Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly.  

Extremities: No edema, mild sarcopenic appearance, full range of motion.  

Skin: Turgor slightly decreased, no rashes.  

Neurologic: Awake, alert, oriented, strength 4/5 diffusely, sensation intact, gait not assessed (bedbound).  

Labs (drawn 11/30/3060):  
CBC: WBC 7.2 K/µL, Hgb 10.9 g/dL, Hct 33 %, Plt 210 K/µL  
BMP: Na 138 mmol/L, K 4.5 mmol/L, Cl 102 mmol/L, CO₂ 24 mmol/L, BUN 22 mg/dL, Cr 1.7 mg/dL (eGFR 44), Glucose 112 mg/dL  
LFTs: AST 22 U/L, ALT 18 U/L, ALP 78 U/L, Total Bili 0.6 mg/dL  
Albumin 3.1 g/dL, Total protein 6.2 g/dL  
CRP 12 mg/L (elevated)  
TSH 2.1 µIU/mL, Free T4 1.1 ng/dL  
Vitamin B12 310 pg/mL (low‑normal)  
Ferritin 45 ng/mL, Iron 55 µg/dL, TIBC 320 µg/dL  

Imaging:  
Chest X‑ray (11/30/3060): Mild hyperinflation, no infiltrates.  
Abdominal US (ordered): pending.  

Assessment and Plan:  
58yo M with multimorbidity (HTN, CKD3, COPD, remote colon CA) presenting with progressive malaise, 12‑lb weight loss, hypoalbuminemia, and mild anemia – concern for underlying malignancy recurrence vs. chronic disease progression vs. malnutrition.  

1. Rule out recurrent colon cancer:  
   - Order CT abdomen/pelvis with contrast (within 24 h).  
   - Review prior surveillance colonoscopy reports (last 2028, no polyps).  

2. Evaluate for occult infection/inflammation:  
   - Blood cultures x2, urine culture, sputum culture (if productive).  
   - Continue CRP trend, consider procalcitonin.  

3. Nutritional support:  
   - Dietitian consult for high‑protein, high‑calorie plan.  
   - Start oral nutritional supplement (Boost 1.5 cal mL QID).  

4. Anemia work‑up:  
   - Repeat CBC in 48 h, iron studies already drawn, consider EPO if CKD‑related anemia persists.  

5. CKD management:  
   - Hold NSAIDs, continue lisinopril, monitor electrolytes daily.  

6. COPD optimization:  
   - Continue tiotropium, add short course oral steroids (prednisone 40 mg PO daily ×5 days) if dyspnea worsens.  

7. Fall risk / functional status:  
   - Physical therapy consult for bedside mobility.  
   - Ensure fall precautions, assistive devices.  

8. Advance care planning:  
   - Discuss goals of care with patient and daughter; code status currently Full Code (presumed).  

9. Disposition:  
   - Admit to Medicine floor, telemetry not required, monitor labs q24 h, reassess in 48 h.  

Orders:  
- CBC, BMP, LFTs, CRP, ferritin, vitamin B12 (stat)  
- Blood cultures x2, UA with culture, sputum culture if indicated  
- CT abdomen/pelvis w/ contrast (STAT)  
- Dietitian, PT, OT consults  
- IV fluids: D5 0.45% NS 1 L over 8 h for mild dehydration  
- DVT prophylaxis: SQ enoxaparin 40 mg SC daily  
- Continue home meds except hold NSAIDs (none listed)  

Signature:  
Dr. Samuel L. Ortega, MD  
Hospitalist Attending  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (29, 29, 38589555007, 38589555007, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 12/03/3092 17:51  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  

Patient: Marcus L. Whitaker  
DOB: 04/22/3065 (27 y/o)  
MRN: 98765432  
PCP: Dr. Lionel Greene, MD  

Chief Complaint: Fever, chills, malaise  

History of Present Illness:  
27yo M with h/o mild intermittent asthma (SABA PRN), recent travel to Luna City for a tech conference, now p/w 3‑day history of non‑localizing fever up to 102.4°F, chills, diffuse myalgias, and generalized fatigue. He reports that the fever started abruptly on 12/01/3092 while he was still in transit; he denied any cough, SOB, chest pain, dysuria, GI upset, or rash. He took ibuprofen 400 mg PO q6h with minimal relief. He also noted a mild headache and occasional light‑headedness when standing. No known sick contacts; airport exposure noted. He presented to the ED after a telehealth visit where a rapid COVID‑19 antigen test was negative. In the ED vitals: T 101.9°F, HR 112, BP 118/74, RR 20, SpO2 98% RA. Labs showed mild leukocytosis (WBC 11.2 K) with neutrophil predominance, CRP 6.8 mg/dL. Blood cultures drawn, chest X‑ray unremarkable. He was given 1 L NS, acetaminophen 650 mg PO, and observed. He remains febrile on the floor (T 101.2°F) and is being admitted for further work‑up of FUO (fever of unknown origin).  

Past Medical History:  
• Asthma, intermittent, SABA PRN  
• Seasonal allergic rhinitis  

Past Surgical History:  
• Appendectomy – Laparoscopic, 3078  

Family History:  
Father – HTN, died 3090 MI at 62  
Mother – DM2, alive 78, controlled on metformin  
Sister – Healthy  

Social History:  
Marital Status: Single, lives alone in downtown Neo‑Portland apartment  
Employment: Software engineer, remote, occasional on‑site meetings  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week, no binge  
Illicit Drugs: Denies  
Travel: Luna City 12/01‑12/02/3092 (conference)  
Vaccinations: Up to date, COVID‑19 booster 3091  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue, myalgias; negative for weight loss, night sweats.  
HEENT: Positive for mild headache, sore throat; negative for visual changes, nasal congestion.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea, wheeze.  
GI: Negative for nausea, vomiting, diarrhea, abdominal pain.  
GU: Negative for dysuria, flank pain.  
Musculoskeletal: Positive for diffuse myalgias, negative for joint swelling.  
Neurologic: Negative for focal deficits, seizures.  
Skin: Negative for rash, lesions.  
Psych: Negative for anxiety, depression.  

Prior to Admission Medications:  
Medication                Sig  
Albuterol Inhaler         2 puffs q4‑6h PRN  
Fluticasone Nasal Spray  2 sprays each nostril daily  
Ibuprofen 400 mg          1 tablet PO q6h PRN for pain/fever (taken x3)  

Allergies:  
No known drug allergies  

Physical Examination:  
Vital Signs: T 101.2°F, HR 108, RR 20, BP 116/72, SpO2 98% RA, Weight 78 kg, Height 180 cm, BMI 24.1  

General: Alert, oriented x3, appears mildly ill, no acute distress.  
HEENT: Normocephalic, atraumatic, oropharynx erythematous without exudate, tympanic membranes clear, pupils equal, reactive.  
Neck: Supple, no lymphadenopathy, no JVD.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.  
Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly.  
Extremities: No edema, pulses 2+ bilaterally, no clubbing.  
Skin: Warm, dry, no rash or lesions.  
Neurologic: AOx3, CN II‑XII grossly intact, no focal deficits.  

Laboratory Data (12/03/3092):  
CBC: WBC 11.2 K, Hgb 13.8 g/dL, Hct 41%, Plt 245 K  
BMP: Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.78, Glu 92  
CRP: 6.8 mg/dL (elevated)  
Procalcitonin: 0.12 ng/mL (low)  
Liver Panel: AST 22, ALT 18, ALP 78, Total Bili 0.6  
Blood cultures: x2 pending  
Urinalysis: Clear, no leukocyte esterase, no nitrites, <5 WBC/hpf  
Chest X‑ray (PA): No infiltrates, cardiac silhouette normal  

Imaging:  
CT Chest w/ contrast (ordered) – pending  
Abdominal US (ordered) – pending  

Assessment and Plan:  
27yo M with recent travel, now with 3‑day non‑localizing fever, mild leukocytosis, elevated CRP, negative rapid COVID, unremarkable CXR – FUO work‑up.  

1. Infectious: Continue supportive care, acetaminophen 650 mg q6h PRN, encourage oral hydration. Hold antibiotics pending cultures and imaging; consider empiric ceftriaxone + azithro if fever > 102°F or new focal findings.  
2. Labs: Repeat CBC, BMP q12h, send blood cultures to final, obtain viral PCR panel (influenza, RSV, adenovirus, SARS‑CoV‑2).  
3. Imaging: CT chest/abdomen/pelvis with contrast to evaluate for occult infection or inflammatory process.  
4. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
5. Telemetry: Not indicated; place on routine floor monitoring.  
6. Code Status: Full Code (Presumed).  
7. Disposition: Admit to Med Service, reassess q24h, adjust plan based on culture/imaging results.  

Signature:  
Evelyn Hartwell, MD  
Attending Physician  
Pager # 84210');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (30, 30, 30018603567, 30018603567, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Hospital Medicine Admission History and Physical

Date of Admission: 05/15/3060
Time: 16:09

Patient: Marcus L. Whitaker
DOB: 02/28/3002
MRN: 98765432
PCP: Dr. Elaine R. Vance, MD

Chief Complaint: Dysuria, suprapubic pain, fever

History of Present Illness:
58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (baseline Cr 1.6), recent prostatitis p/w N/V/D and R flank pain now presents with 2‑day history of worsening dysuria, urgency, suprapubic pressure and chills. He reports dark amber urine, occasional gross hematuria, and a low‑grade fever up to 101.4°F at home. Yesterday he went to urgent care where a UA showed +leukocyte esterase, nitrites positive, WBC 45/hpf; he was given a single dose of IM ceftriaxone and instructed to start oral ciprofloxacin 500 mg BID, but he stopped after one dose because of nausea and vomiting. He now feels “more sick,” with fatigue, decreased oral intake, and mild right flank tenderness. Denies recent catheterization, recent sexual activity, or new sexual partners. No known drug allergies. He was admitted from home after EMS called due to fever 102°F and hypotension 98/58 mmHg in the field; EMS gave 1 L NS en route. He is currently on 2 L O₂ via nasal cannula, SpO₂ 96% on room air prior to O₂. He reports prior UTIs in 2025 and 2028 treated with TMP‑SMX, and a history of recurrent prostatitis treated with fluoroquinolones. He lives alone, works as a freelance IT consultant, occasional alcohol (2‑3 beers/week), never smoker.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2015, on insulin glargine 30 U qHS and metformin 1000 mg BID
• Chronic Kidney Disease Stage 3 – baseline eGFR 45 mL/min/1.73 m²
• Hypertension – on lisinopril 20 mg daily
• Benign Prostatic Hyperplasia – on tamsulosin 0.4 mg daily
• Hyperlipidemia – on rosuvastatin 10 mg daily
• Prior prostatitis – 2022, 2024

Past Surgical History:
• Appendectomy – 2020, laparoscopic
• Right knee arthroscopy – 2027

Family History:
Father – HTN, died MI age 68
Mother – CKD stage 4
Sister – T2DM

Social History:
Tobacco Use: Never smoker
Alcohol Use: Social, 2‑3 beers/week
Illicit Drugs: Denies
Living Situation: Lives alone, independent ADLs
Occupation: IT consultant, works from home

Review of Systems:
Constitutional: Positive for fever, chills, fatigue; negative for weight loss.
HEENT: Negative
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
Gastrointestinal: Nausea, vomiting x1, no diarrhea.
Genitourinary: Positive dysuria, suprapubic pain, hematuria, flank tenderness; negative for incontinence.
Musculoskeletal: Negative
Neurologic: Negative
Psychiatric: Negative
Skin: No rashes.

Prior to Admission Medications:
Medication                Sig
metformin                 1000 mg PO BID
insulin glargine          30 U SC qHS
lisinopril                20 mg PO daily
rosuvastatin              10 mg PO nightly
tamsulosin                0.4 mg PO daily
aspirin                   81 mg PO daily
vitamin D3                2000 IU PO daily

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: Temp 38.9 °C (102 °F), HR 112, RR 22, BP 102/58 mmHg, SpO₂ 96% on 2 L NC, Weight 92 kg (202 lb)

General: Appears ill, diaphoretic, in mild distress, alert, oriented x3.
HEENT: Normocephalic, atraumatic, mucous membranes dry.
Neck: Supple, no JVD.
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, mild tachypnea, no wheezes or crackles.
Abdomen: Soft, mildly distended, suprapubic tenderness to palpation, no rebound, no guarding.
Genitourinary: CVA tenderness R flank, no scrotal edema.
Extremities: Warm, no edema, pulses 2+ bilaterally.
Skin: No rashes, no lesions.
Neuro: AOx3, grossly non‑focal.

Data/Results:
Laboratory Studies (drawn 05/15/3060):
CBC: WBC 18.2 K/µL (neutrophils 84%), Hgb 13.1 g/dL, Plt 210 K/µL
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO₂ 22 mmol/L, BUN 28 mg/dL, Cr 1.8 mg/dL (baseline 1.6), Glucose 212 mg/dL
CRP: 12 mg/dL
Procalcitonin: 0.9 ng/mL
Urinalysis: pH 6, leukocyte esterase +++, nitrite +, WBC 45/hpf, RBC 12/hpf, bacteria many
Urine culture: pending
Blood cultures: x2 sets pending
Lactate: 1.4 mmol/L
ABG (room air): pH 7.32, pCO₂ 32, pO₂ 78, HCO₃⁻ 18

Imaging:
Renal ultrasound (05/15/3060): No hydronephrosis, kidneys normal size, no stones.
Chest X‑ray: No infiltrates, cardiac silhouette normal.

Assessment and Plan:
58yo M with h/o T2DM, CKD3, recent prostatitis now presents with acute pyelonephritis vs. complicated UTI, febrile, hypotensive, leukocytosis, positive UA, pending urine culture. Likely fluoroquinolone‑resistant organism given prior exposure; start empiric broad‑spectrum IV antibiotics.

1. Infectious – Acute pyelonephritis/complicated UTI:
   • Start IV cefepime 2 g q12h (adjust for Cr) and IV metronidazole 500 mg q8h for anaerobic coverage pending culture.
   • Hold ciprofloxacin; consider de‑escalation when sensitivities return.
   • Obtain repeat UA and cultures q48h.
   • Monitor renal function q24h, adjust cefepime dose accordingly.
2. Sepsis bundle:
   • Continue NS 125 mL/hr, target MAP >65 mmHg; consider norepinephrine if MAP remains <65 after 30 mL fluid.
   • Lactate trending q6h.
3. Diabetes:
   • Hold oral agents, continue insulin glargine; start sliding scale regular insulin qac for BG >180.
4. Hypertension:
   • Hold lisinopril while AKI risk; resume when BP stable and Cr <2.0.
5. CKD:
   • Nephrology consult for AKI on CKD; avoid nephrotoxic agents.
6. Pain/comfort:
   • Acetaminophen 650 mg PO q6h PRN; avoid NSAIDs.
7. DVT prophylaxis:
   • SQ enoxaparin 40 mg SC daily (adjust for Cr if <30).
8. Diet:
   • NPO initially, advance to renal‑appropriate diet once stable.
9. Monitoring:
   • Telemetry not required; continuous cardiac monitor for arrhythmia risk due to sepsis.
   • Urine output strict I/O; Foley catheter not placed unless retention develops.
10. Disposition:
    • Admit to Medicine floor, anticipate 5‑7 day course of IV antibiotics with step‑down to PO when afebrile 48 h and cultures cleared.
    • Infectious Diseases consult for antibiotic stewardship.

Code Status: Full Code (Presumed)

Prepared by:
Dr. Nathaniel K. Sloane, MD
Hospitalist
Pager # 84231

05/15/3060 16:09');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (31, 31, 20051851129, 20051851129, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Alex Rivera
MRN: 98765432
DOB: 03/22/3040
PCP: Dr. Maya L. Ortiz, MD

Date of Admission: 12/15/3065
Time: 17:03
Location: MED01
Attending Provider: Dr. Samuel K. Patel, MD

Chief Complaint: urethral discharge, dysuria, lower abdominal pain

History of Present Illness:
58yo M with h/o HIV (well controlled, CD4 540, VL <20), chronic hepatitis C (treated, SVR), prior chlamydia (treated 2022), now p/w 3‑day history of copious yellow‑green urethral discharge, burning dysuria, suprapubic tenderness, and mild fever (~38.2°C). Patient reports increased sexual activity over past month with multiple new male partners; reports inconsistent condom use. Denies penile lesions, testicular swelling, or hematuria. He noticed the discharge after a night of unprotected oral sex and anal intercourse 2 days ago. He tried OTC phenazopyridine with minimal relief. No recent travel. He presented to urgent care on 12/13 where a rapid NAAT for gonorrhea/chlamydia was pending; he was given a single dose of ceftriaxone 250 mg IM and instructed to follow up. Symptoms worsened, prompting ED visit and subsequent admission for IV antibiotics and evaluation for possible disseminated gonococcal infection (DGI). He also reports mild arthralgias in knees and wrists but no rash. No nausea, vomiting, or diarrhea. He is adherent to HAART (bictegravir/emtricitabine/tenofovir alafenamide) and HCV regimen (sofosbuvir/velpatasvir) with good tolerance.

ED Course:
Vitals on arrival: T 38.4 °C, HR 112, BP 128/78, RR 20, SpO2 98% RA. Physical exam notable for purulent urethral discharge, mild suprapubic tenderness, no genital lesions, no joint effusions. Labs: WBC 13.2 K/µL (neutrophils 84%), CRP 5.8 mg/dL. Urine NAAT positive for Neisseria gonorrhoeae, negative for Chlamydia trachomatis. Blood cultures drawn. Started on IV ceftriaxone 1 g q24h and azithromycin 500 mg IV q24h for possible chlamydial co‑infection pending results. HIV labs: CD4 540, VL <20. Admitted for IV therapy and monitoring for DGI.

Past Medical History:
• HIV infection (diagnosed 2015), on ART
• Chronic hepatitis C (cured 2024)
• Prior chlamydial urethritis (2022)
• Hypertension (controlled)
• Hyperlipidemia

Past Surgical History:
• Appendectomy – 2030
• Circumcision – neonatal

Family History:
Father – deceased MI at 62
Mother – alive, HTN
Sister – healthy

Social History:
Tobacco Use: Never smoker
Alcohol Use: Social (1‑2 drinks/week)
Illicit Drug Use: No current use, prior occasional marijuana (quit 2018)
Sexual Activity: MSM, multiple partners, inconsistent condom use
Living Situation: Lives alone in apartment, employed as graphic designer
Legal/Financial: Stable

Review of Systems:
Constitutional: Fever, chills negative
HEENT: No sore throat, vision changes
Cardiovascular: No chest pain, palpitations
Respiratory: No cough, dyspnea
GI: No nausea, vomiting, diarrhea
GU: Urethral discharge, dysuria, suprapubic pain
Musculoskeletal: Mild arthralgias, no swelling
Skin: No rash, lesions
Neurologic: No headache, no focal deficits
Psychiatric: Mood stable, no depression/anxiety

Prior to Admission Medications:
Medication                Sig
Bictegravir/Emtricitabine/Tenofovir alafenamide  (Biktarvy) 1 tablet PO daily
Sofosbuvir/Velpatasvir (Epclusa) 1 tablet PO daily
Lisinopril 20 mg PO daily
Atorvastatin 40 mg PO nightly
Amlodipine 5 mg PO daily
Vitamin D3 2000 IU PO daily

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs:
Temp 38.2 °C
HR 110 bpm
RR 18 breaths/min
BP 126/76 mmHg
SpO2 99% RA
Weight 82 kg (180 lb)

General: Alert, oriented x3, appears mildly uncomfortable due to dysuria.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no lymphadenopathy.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.
Abdomen: Soft, mild suprapubic tenderness, no rebound, no organomegaly.
Genitourinary: External genitalia normal, copious purulent urethral discharge noted, no lesions, testes non‑tender.
Extremities: No edema, mild tenderness to palpation of bilateral knees, no effusion.
Skin: No rash, no petechiae.
Neuro: Grossly non‑focal, strength 5/5 in all extremities.
Psych: Cooperative, mood euthymic.

Laboratory Data (most recent):
CBC: WBC 13.2 K/µL, Hgb 13.8 g/dL, Plt 210 K/µL
BMP: Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 96
CRP: 5.8 mg/dL
HIV Panel: CD4 540 cells/µL, HIV‑1 RNA <20 copies/mL
Hep C PCR: Undetectable
Urine NAAT: GC positive, CT negative
Blood cultures: pending
Liver panel: AST 32, ALT 28, ALP 78, Total bili 0.8
Lipid panel: LDL 95, HDL 52, TG 110

Imaging:
None performed; bedside genital exam sufficient.

Assessment and Plan:
58yo M with well‑controlled HIV and recent untreated gonococcal urethritis now presenting with acute purulent urethritis, dysuria, suprapubic pain, and mild migratory arthralgias concerning for early disseminated gonococcal infection (DGI). Positive urine NAAT for N. gonorrhoeae, pending blood cultures. Continue IV ceftriaxone 1 g q24h and add azithromycin 500 mg IV q24h for possible chlamydial co‑infection pending NAAT. Monitor for signs of septic arthritis; obtain joint aspiration if swelling develops. Continue current ART and HCV regimen; no drug‑drug interactions anticipated with ceftriaxone/azithromycin. Counsel on safe sex practices, consistent condom use, and partner notification; arrange for expedited partner therapy (EPT) upon discharge. VTE prophylaxis with SQ enoxaparin 40 mg daily. DVT prophylaxis, stress ulcer prophylaxis with pantoprazole 40 mg daily. Encourage fluid intake, analgesia with acetaminophen PRN. Repeat CBC and CRP q48h. Discharge planning: anticipate 48‑72 h IV therapy then transition to oral cefixime 400 mg BID for 7 days plus azithromycin 1 g PO single dose. Arrange follow‑up with infectious disease and primary care within 1 week. Code Status: Full Code.  

Samuel K. Patel, MD
Hospitalist, Medicine Service  
Pager: 22457');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (32, 32, 93228055429, 93228055429, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITAL ADMISSION HISTORY AND PHYSICAL  
07/13/3064 15:24  

PATIENT: Marcus L. Whitaker  
DOB: 02/14/3025 (39 y/o)  
MRN: 84276109  
PCP: Dr. Elaine R. Voss, MD  

CHIEF COMPLAINT: Fever, progressive dyspnea, oral thrush, 15‑lb weight loss  

HISTORY OF PRESENT ILLNESS:  
39yo M with uncontrolled HIV/AIDS (CD4 45, VL 1.2 ×10⁶ copies/mL) s/p multiple ART failures, non‑adherent to efavirenz/tenofovir/emtricitabine for past 6 mo, now presents w/ 2‑wk hx of low‑grade fevers (T 38‑38.5 °C), worsening dyspnea on exertion, dry cough, and 15‑lb unintentional weight loss. He reports new oral white plaques for 5 days, dysphagia to solids, and night sweats. He was discharged from outside hospital 4 days ago after a 5‑day course of oral TMP‑SMX for presumed PCP pneumonia; symptoms improved briefly then recurred. He denies chest pain, hemoptysis, or recent travel. He reports occasional IV drug use (last use 3 mo ago) and inconsistent condom use. He lives alone, works as a freelance IT consultant, and has no reliable transportation. He reports missing his ART doses because of “feeling sick” and “not wanting to take more pills.”  

ED COURSE: Vitals on arrival: T 38.7 °C, HR 112, RR 24, BP 108/62, SpO₂ 88 % on RA, weight 68 kg (150 lb). Labs: WBC 2.1 K/µL (ANC 900), Hgb 9.8 g/dL, Plt 112 K, Na 138, K 4.0, Cl 102, CO₂ 22, BUN 14, Cr 0.9, Glu 112, LDH 420 U/L. ABG on 2 L NC: pH 7.45, pCO₂ 32, pO₂ 58. CXR: bilateral diffuse interstitial infiltrates, “ground‑glass” pattern. CT chest: diffuse perihilar ground‑glass opacities, no PE. Sputum GMS stain positive for Pneumocystis jirovecii. Oral swab culture grew Candida albicans. HIV viral load 1.2 ×10⁶, CD4 45.  

He was started on IV TMP‑SMX 15 mg/kg q6h, prednisone 40 mg PO daily, and fluconazole 400 mg PO daily. He was placed on airborne + droplet precautions.  

MEDICAL & SURGICAL HX:  
PAST MEDICAL HISTORY:  
• HIV infection (diagnosed 2008)  
• Chronic hepatitis C (treated, SVR 2022)  
• Prior PCP pneumonia 06/3064 (treated)  
• Recurrent oral candidiasis  
• Hypertension (controlled)  

PAST SURGICAL HISTORY:  
• Appendectomy (2010)  

FAMILY HX:  
Father: HTN, died MI age 62  
Mother: Alive, DM2, CKD stage 3  
Sister: Healthy  

SOCIAL HX:  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: IV heroin use intermittently, last 3 mo ago; participates in needle exchange program  
Sexual: Heterosexual, multiple partners, inconsistent condoms  
Living situation: Lives alone in apartment, no caregiver support  
Employment: Freelance IT, currently on disability  

REVIEW OF SYSTEMS:  
Constitutional: Fever, night sweats, 15‑lb weight loss, fatigue – positive.  
HEENT: Oral thrush, sore throat – positive.  
Respiratory: Dyspnea, dry cough, no hemoptysis – positive.  
Cardiovascular: No chest pain, palpitations – negative.  
GI: Nausea occasional, no vomiting, no diarrhea – negative.  
GU: Dysphagia to solids, no dysuria – positive.  
Skin: No rash, no lesions – negative.  
Neuro: No headache, no focal deficits – negative.  
Psych: Anxiety about illness, depressive affect – positive.  

PRIOR TO ADMISSION MEDICATIONS:  
efavirenz 600 mg PO daily (non‑adherent)  
tenofovir alafenamide 25 mg PO daily (non‑adherent)  
emtricitabine 200 mg PO daily (non‑adherent)  
lisinopril 10 mg PO daily  
amlodipine 5 mg PO daily  
TMP‑SMX DS 800/160 mg PO BID (missed doses past 2 weeks)  

ALLERGIES:  
No known drug allergies (NKDA)  

PHYSICAL EXAMINATION:  
Temperature: 38.7 °C  
Heart Rate: 112 bpm  
Respiratory Rate: 24/min  
Blood Pressure: 108/62 mmHg  
SpO₂: 88 % RA (improved to 94 % on 2 L NC)  
General: Thin, appears chronically ill, NAD but mildly dyspneic at rest.  
HEENT: Oral cavity – extensive white plaques on buccal mucosa, tongue; no erythema. Pupils equal, reactive.  
Neck: Supple, no lymphadenopathy.  
Cardiovascular: Regular rate, normal S1 S2, no murmurs, rubs, gallops.  
Respiratory: Bilateral diffuse crackles, worse at bases, no wheezes.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: No edema, no clubbing.  
Skin: No rashes, multiple healed scars on forearms (IV sites).  
Neuro: Alert, oriented x3, no focal deficits.  

LABS & RESULTS (most recent):  
CBC: WBC 2.1 K/µL (ANC 900), Hgb 9.8 g/dL, Plt 112 K  
BMP: Na 138, K 4.0, Cl 102, CO₂ 22, BUN 14, Cr 0.9, Glu 112  
Liver panel: AST 34, ALT 28, ALP 78, TBili 0.6  
LDH 420 U/L (elevated)  
CRP 12 mg/dL (elevated)  
HIV VL 1.2 ×10⁶ copies/mL, CD4 45 cells/µL  
Sputum GMS: Pneumocystis jirovecii (positive)  
Oral swab culture: Candida albicans (sensitive)  
CXR: Bilateral diffuse interstitial infiltrates, ground‑glass opacities.  
CT chest: Diffuse perihilar ground‑glass, no focal consolidation, no PE.  

IMPRESSION/PLAN:  
1. HIV/AIDS, uncontrolled (CD4 45, VL > 1 M) – start ART after stabilization; plan to initiate bictegravir/emtricitabine/tenofovir alafenamide 50/200/25 mg PO daily on day 3 once TMP‑SMX tolerated.  
2. PCP pneumonia – continue IV TMP‑SMX 15 mg/kg q6h, add prednisone 40 mg PO daily taper 21 days.  
3. Oral/esophageal candidiasis – fluconazole 400 mg PO daily for 14 days, consider endoscopy if dysphagia persists.  
4. Anemia of chronic disease / possible marrow suppression – monitor CBC q48h, consider transfusion if Hgb <7.5.  
5. Prophylaxis: Continue TMP‑SMX for PCP prophylaxis after treatment course; add azithromycin 1200 mg PO weekly for MAC prophylaxis (CD4 < 50).  
6. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
7. Isolation: Airborne + droplet precautions until PCP treatment completed and patient clinically stable.  
8. Nutrition: High‑calorie, high‑protein diet; consult dietetics for supplemental shakes.  
9. Social work: Arrange case management for housing, medication assistance, and outpatient HIV follow‑up.  
10. Disposition: Admit to internal medicine service, telemetry for arrhythmia monitoring given tachycardia; anticipate length of stay 7‑10 days pending response to therapy.  

CODE STATUS: Full Code (Presumed)  

ATTENDING PHYSICIAN: Dr. Samuel K. Larkin, MD  
Pager: 3221  

---   (End of note)');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (33, 33, 53423001714, 53423001714, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Elena Marlowe  
DOB: 02/14/3052  
MRN: 98765432  
PCP: Dr. Victor L. Haines, MD  

Date of Admission: 07/18/3085  
Time of Admission: 12:41  
Location: MED01 – General Medicine Floor  
Attending Provider: Dr. Samantha K. Ortiz, MD  

CHIEF COMPLAINT:  
Left foot pain, swelling, foul odor, black discoloration of toes x3 days  

HISTORY OF PRESENT ILLNESS:  
58yo F with h/o T2DM (A1c 9.4% 03/3085), PAD (bilateral fem‑pop stents 3079), CKD‑3 (eGFR 48), and recent cellulitis of left lower extremity presents w/ progressive left foot pain and swelling that began 3 days ago after a minor “scrape” while gardening. She reports the area became increasingly painful, throbbing, and now has black, necrotic tips on the 2nd–4th toes with a foul, “rotting” odor. She denies any trauma beyond the scrape, denies fevers, chills, or rigors. She notes that the pain is constant, 8/10 at rest, worsens with elevation, and is partially relieved by over‑the‑counter ibuprofen which she stopped after 2 doses due to GI upset. She was seen at an urgent care 2 days ago; they prescribed oral clindamycin 300 mg q6h and instructed her to keep the foot elevated. She took 2 doses then stopped because of nausea. Over the past 24 h the discoloration spread proximally to the mid‑foot, the skin is now mottled, and she reports new tingling and numbness distal to the lesion. She has a history of poor glycemic control and admits to occasional non‑adherence to insulin (last dose 18 h ago). She reports a prior episode of “foot ulcer” 2 years ago that healed after debridement. No recent travel, no known sick contacts. She works part‑time as a librarian, lives with husband, no tobacco, occasional wine (1‑2 glasses/week), denies illicit drugs.

ED COURSE:  
Vitals on arrival: T 38.2 °C, HR 112, RR 22, BP 138/78, SpO2 96% RA. Left foot: edema to mid‑calf, erythema, foul odor, black necrotic tips on toes 2‑4, crepitus absent, pulses 1+ dorsalis pedis, 2+ posterior tibial. Labs: WBC 16.8 K/µL (neut 88%), CRP 12 mg/dL, ESR 78 mm/hr, glucose 312 mg/dL, creatinine 1.6 mg/dL (baseline 1.4). X‑ray foot: soft‑tissue swelling, no gas. CTA lower extremity: no arterial occlusion, but extensive soft‑tissue gas tracking along the intermuscular planes of the foot → concern for wet gangrene. Started IV vancomycin 1 g q12h, piperacillin‑tazobactam 3.375 g q6h, insulin drip, and analgesia with IV morphine 2 mg q15 min PRN. Orthopedic surgery consulted; recommendation for emergent surgical debridement and possible below‑knee amputation.

PAST MEDICAL HISTORY:  
• Type 2 Diabetes Mellitus – diagnosed 2015  
• Peripheral Arterial Disease – stents 3079  
• Chronic Kidney Disease – stage 3  
• Hypertension – controlled on lisinopril  
• Hyperlipidemia – on rosuvastatin  

PAST SURGICAL HISTORY:  
• Right femoral‑popliteal artery stent placement – 07/3079  
• Left great toe amputation (partial) – 06/3077 (for ulcer)  

FAMILY HISTORY:  
Father: HTN, died MI age 68  
Mother: DM2, alive 82  
Sister: CKD stage 4 (unknown cause)  

SOCIAL HISTORY:  
Marital Status: Married  
Occupation: Librarian (part‑time)  
Tobacco: Never smoker  
Alcohol: Social – 1‑2 glasses wine/week  
Illicit Drugs: Denies  
Living Situation: Lives with husband, two adult children, independent ADLs  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills denied, weight stable.  
HEENT: No visual changes, no sore throat.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No cough, dyspnea.  
GI: Nausea x2 days, no vomiting, no abdominal pain.  
GU: Polyuria, no dysuria.  
Musculoskeletal: Left foot pain, swelling, black discoloration, numbness distal.  
Neurologic: No headache, no dizziness.  
Skin: As above.  
Psych: No depression/anxiety noted.  

PRIOR TO ADMISSION MEDICATIONS:  
Metformin 1000 mg PO BID  
Insulin glargine 30 U SC nightly  
Lisinopril 20 mg PO daily  
Rosuvastatin 20 mg PO nightly  
Aspirin 81 mg PO daily  
Clopidogrel 75 mg PO daily (post‑stent)  

Allergies: No known drug allergies  

PHYSICAL EXAMINATION:  
Vital Signs: Temp 38.2 °C, HR 112, RR 22, BP 138/78, SpO2 96% RA, Weight 84 kg (185 lb)  

General: Alert, appears uncomfortable, NAD aside from foot pain.  

HEENT: Normocephalic, atraumatic, mucous membranes moist, no scleral icterus.  

Neck: Supple, no JVD, no carotid bruits.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities:  
- Right lower extremity: No edema, pulses 2+ bilaterally.  
- Left lower extremity: Marked edema to mid‑calf, erythema, foul odor, black necrotic tips on toes 2‑4, skin warm, tenderness to palpation, diminished dorsalis pedis (1+), posterior tibial 2+, no crepitus.  

Skin: No other rashes or lesions.  

Neurologic: AOx3, grossly non‑focal, decreased sensation to light touch distal to mid‑foot on left.  

ASSESSMENT AND PLAN:  
1. Wet gangrene of left foot w/ soft‑tissue gas – emergent surgical debridement / possible below‑knee amputation. Orthopedic surgery to take patient to OR ASAP.  
   • Continue broad‑spectrum IV antibiotics (Vanc + Zosyn) pending cultures.  
   • Tight glycemic control with insulin infusion.  
   • Pain control with IV morphine PCA.  
   • Serial labs q12h (CBC, BMP, CRP).  
   • Vascular surgery consult for limb‑sparing options.  

2. Type 2 Diabetes Mellitus – poorly controlled.  
   • Adjust insulin regimen post‑op, endocrinology consult.  

3. Peripheral Arterial Disease – chronic, on antiplatelet therapy.  
   • Continue aspirin + clopidogrel, hold if bleeding risk post‑op.  

4. Chronic Kidney Disease – stage 3.  
   • Monitor creatinine, adjust meds as needed (hold metformin).  

5. Hypertension – controlled.  
   • Continue lisinopril, hold if hypotension intra‑op.  

6. DVT prophylaxis – SQ low‑molecular‑weight heparin 40 mg SC daily (unless contraindicated).  

7. Nutrition – NPO pre‑op, then advance as tolerated post‑op, diabetic diet.  

8. Code Status – Full Code (presumed).  

Disposition: Admit to surgical floor, telemetry for cardiac monitoring, pending OR.  

Signature: Samantha K. Ortiz, MD  
Pager #: 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (34, 34, 68441991029, 68441991029, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
09/30/3066 21:42  

Patient: Ethan Marlowe  
DOB: 02/14/3038  
MRN: 98765432  
PCP: Dr. Lila Hart, MD  

Chief Complaint: Dysuria, suprapubic pain, fever  

History of Present Illness:  
58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 48), recent urethral stricture dilation p/w dysuria, urgency, N/V/D and low‑grade fever. Patient reports 3‑day history of burning on urination, suprapubic pressure, and chills that began after a Foley was removed on 09/26/3066 following a brief admission for left ureteral stone. He notes cloudy urine with occasional gross hematuria, and now a Tmax of 38.9 °C (102 °F) measured at home. Denies flank pain, but reports mild left flank tenderness on palpation. No recent sexual activity, no new sexual partners. He took OTC acetaminophen with minimal relief. No prior UTIs documented, but has a history of recurrent prostatitis treated with ciprofloxacin 2 years ago. He was discharged from the outside hospital on 09/27/3066 with a 5‑day course of TMP‑SMX; he stopped meds after 2 days because of nausea. He now presents to our ED for worsening symptoms.  

ED Course: Vitals on arrival: T 38.7 °C, HR 112, BP 128/74, RR 20, SpO₂ 96% RA. Labs drawn, UA sent, and a non‑contrast CT abdomen/pelvis performed – no obstructing stone, mild left renal pelvis fullness. Patient given 1 L NS, IV acetaminophen, and started on empiric IV ceftriaxone 1 g q24h pending culture.  

Past Medical History:  
• Type 2 Diabetes Mellitus (diagnosed 3045)  
• Chronic Kidney Disease stage 3 (2028)  
• Hypertension (2015)  
• Recurrent prostatitis (2024)  

Past Surgical History:  
• Urethral stricture dilation – 09/20/3066 (right side)  
• Left ureteral stone lithotripsy – 09/24/3066  

Family History:  
Father – HTN, MI at 62  
Mother – CKD secondary to diabetes  
Sister – healthy  

Social History:  
Marital Status: Single, lives alone in an apartment.  
Occupation: Software engineer, works from home.  
Tobacco: Never smoker.  
Alcohol: Social, 1‑2 drinks/week.  
Illicit drugs: Denies.  
Sexual activity: Heterosexual, monogamous, last activity 3 weeks ago.  

Allergies: No known drug allergies (NKDA).  

Medications Prior to Admission:  
Metformin 1000 mg PO BID  
Lisinopril 20 mg PO daily  
Amlodipine 5 mg PO daily  
Atorvastatin 40 mg PO nightly  
TMP‑SMX DS PO BID (stopped 2 days ago)  

Review of Systems:  
Constitutional – fever, chills, fatigue.  
HEENT – negative.  
Cardiovascular – no chest pain, palpitations.  
Respiratory – no cough, dyspnea.  
GI – N/V, no abdominal pain, normal bowel.  
GU – dysuria, suprapubic pain, hematuria, frequency.  
Musculoskeletal – mild left flank tenderness, no myalgias.  
Neurologic – negative.  
Skin – no rashes.  

Physical Examination:  
Vital Signs: T 38.7 °C, HR 112, BP 128/74, RR 20, SpO₂ 96% RA, Weight 84 kg (185 lb).  
General: Alert, appears mildly ill, in mild discomfort.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, mildly tender suprapubic, left flank tenderness to deep palpation, no rebound, no guarding.  
GU: No external lesions, bladder not palpable.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no lesions.  
Neuro: AOx3, grossly non‑focal.  

Recent Labs:  
CBC: WBC 14.2 K/µL (neutrophils 84%), Hgb 13.1 g/dL, Plt 312 K/µL.  
BMP: Na 138, K 4.6, Cl 102, CO₂ 22, BUN 28 mg/dL, Cr 1.8 mg/dL (baseline 1.5), Glucose 162 mg/dL.  
UA: Cloudy, pH 5.5, leukocyte esterase +++, nitrite +, WBC 45/hpf, RBC 12/hpf, bacteria many.  
Blood cultures: x2 pending.  
Urine culture: sent.  
CT Abdomen/Pelvis (non‑contrast): No obstruction, mild left renal pelvis dilation, no perinephric stranding.  

Assessment and Plan:  
58yo M with h/o T2DM, CKD3, recent urethral instrumentation p/w acute cystitis progressing toward possible pyelonephritis.  
- Start IV ceftriaxone 1 g q24h; transition to PO levofloxacin 750 mg daily when afebrile and able to tolerate PO, pending sensitivities.  
- Continue IV fluids 125 mL/hr to maintain renal perfusion.  
- Hold metformin while Cr >1.5 mg/dL.  
- Monitor urine output, daily BMP, and repeat CBC q48h.  
- Obtain repeat UA in 48 h to assess response.  
- DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
- Stress ulcer prophylaxis: PRN famotidine 20 mg PO nightly.  
- Code Status: Full Code.  
- Education: Discussed importance of completing full antibiotic course, hydration, and signs of worsening infection.  
- Disposition: Admit to Medicine floor, telemetry not required unless arrhythmia develops.  

Signature:  
Dr. Mara L. Keene, MD  
Hospitalist, Example Hospital  
Pager # 84210');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (35, 35, 65239534408, 65239534408, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITAL ADMISSION HISTORY AND PHYSICAL

07/31/3058 07:47

PATIENT: Evelyn Hartwell
DOB: 02/14/3025
MRN: 98765432
PCP: Lila Monroe, MD
ATTENDING: Marcus Vale, MD
LOCATION: EXAMP04
SERVICE: Internal Medicine

CHIEF COMPLAINT: SOB, progressive dyspnea, respiratory failure w/o fever

HISTORY OF PRESENT ILLNESS:
Evelyn Hartwell is a 33 y/o F with h/o mild intermittent asthma (last exacerbation 2019), obesity (BMI 34), and GERD who presents with acute worsening dyspnea over the past 48 hrs leading to respiratory failure requiring non‑invasive ventilation. She reports that 2 days ago she began feeling “tight in the chest” after a long shift as a night‑shift security guard; she noted increased work of breathing, tachypnea to 28‑30 bpm, and inability to speak full sentences. Denies fever, chills, cough, sputum production, chest pain, palpitations, or recent sick contacts. She did not take her albuterol inhaler because she thought it was “just stress”. Yesterday she went to an urgent care where she was given a trial of nebulized albuterol and oral steroids; O2 sat remained 84 % on room air, so she was placed on 2 L NC and transferred by EMS to our facility for further management of acute hypoxemic respiratory failure. EMS report notes initial RR 34, HR 112, BP 138/78, SpO2 78 % on RA, improved to 90 % on 15 L non‑rebreather. No fever documented. She reports occasional nocturnal GERD symptoms, no recent travel, no known COVID‑19 exposure. She is a never smoker, drinks socially (1‑2 drinks/week), no illicit drug use.

ED COURSE:
Vitals on arrival: T 36.8 °C, HR 108, RR 32, BP 132/76, SpO2 92 % on 6 L NC. ABG: pH 7.31, PaCO2 48, PaO2 58, HCO3‑ 24. Labs: WBC 9.2, Hgb 13.1, Plt 312, Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.78, Glucose 112, Lactate 1.1. CXR: diffuse bilateral interstitial infiltrates, no focal consolidation. CT chest (PE protocol) negative for PE, shows ground‑glass opacities consistent with acute inflammatory process. SARS‑CoV‑2 PCR pending (sent). Started on HFNC 40 L/90 % FiO2, IV methylprednisolone 125 mg q6h, nebulized albuterol/ipratropium q4h, and broad‑spectrum antibiotics (ceftriaxone 2 g q24h, azithromycin 500 mg q24h) pending cultures.

MEDICAL & SURGICAL HX:
Past Medical History:
• Asthma, intermittent
• Obesity (BMI 34)
• GERD
• Seasonal allergic rhinitis

Past Surgical History:
• Appendectomy – 2022 (laparoscopic)
• Cholecystectomy – 2030 (lap)

FAMILY HX:
Mother – HTN, died of stroke @68
Father – DM2, alive @78
Sister – Healthy
No known hereditary lung disease.

SOCIAL HX:
Marital status: Single, lives alone in an apartment.
Occupation: Security guard (night shift), occasional overtime.
Tobacco: Never smoker.
Alcohol: Social, 1‑2 drinks/week.
Illicit drugs: Denies.
Housing: Stable, no homelessness.
Transportation: Owns car.

REVIEW OF SYSTEMS:
Constitutional: No fever, chills, weight loss.
HEENT: No sore throat, sinus congestion.
Cardiovascular: No chest pain, palpitations.
Respiratory: Progressive dyspnea, no cough, no sputum, no hemoptysis.
GI: GERD symptoms, no N/V/D.
GU: No dysuria, no flank pain.
Neuro: No headache, dizziness, syncope.
Skin: No rashes.
Psych: Anxious about breathing, otherwise stable.

PRIOR TO ADMISSION MEDICATIONS:
Medication – Dose – Frequency
Albuterol inhaler – 2 puffs PRN – as needed
Omeprazole 20 mg – daily – 1 tablet PO qAM
Montelukast 10 mg – daily – 1 tablet PO qHS
Multivitamin – daily – 1 tablet PO

Allergies:
No known drug allergies.

PHYSICAL EXAMINATION:
Vital Signs: T 36.8 °C, HR 108, RR 32, BP 132/76, SpO2 92 % on 6 L NC, Weight 102 kg, Height 1.73 m, BMI 34.
General: Alert, in mild respiratory distress, using accessory muscles.
HEENT: Normocephalic, atraumatic, mucous membranes moist, oropharynx clear.
Neck: Supple, no JVD.
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Diffuse bilateral wheezes and fine crackles, decreased breath sounds at bases, no pleural rub.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: No edema, pulses 2+ bilaterally.
Skin: Warm, dry, no rashes.
Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.

LABS & IMAGING:
CBC: WBC 9.2 K/µL, Hgb 13.1 g/dL, Plt 312 K/µL
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.78, Glucose 112
ABG (on HFNC 40 L/90%): pH 7.31, PaCO2 48, PaO2 78, HCO3‑ 24
Lactate: 1.1 mmol/L
CRP: 12 mg/L
Procalcitonin: 0.08 ng/mL
CXR: Bilateral interstitial infiltrates, no consolidation.
CT Chest (PE protocol): No PE; diffuse ground‑glass opacities.
SARS‑CoV‑2 PCR: Pending.
Blood cultures: x2 drawn, pending.

IMPRESSION / PLAN:
1. Acute hypoxemic respiratory failure secondary to presumed inflammatory/viral pneumonitis (no fever, negative initial bacterial markers). Continue HFNC titrated to SpO2 >94 %. Maintain steroids (methylpred 125 mg q6h → taper per protocol). Hold antibiotics after 48 h if cultures remain negative and procalcitonin stays low.
2. Asthma – optimize inhaled therapy: add inhaled corticosteroid (budesonide/formoterol 160/4.5 µg 2 puffs BID) and continue nebulized albuterol/ipratropium.
3. GERD – continue omeprazole, consider H2 blocker PRN for nocturnal symptoms.
4. Obesity – diet consult, low‑calorie, high‑protein; physical therapy for gradual mobilization.
5. DVT prophylaxis – SQ enoxaparin 40 mg SC daily.
6. Monitoring – telemetry for arrhythmia, q4h vitals, daily ABG until stable, repeat CXR in 48 h.
7. Infectious work‑up – SARS‑CoV‑2 PCR result, respiratory viral panel, sputum culture if productive later.
8. Code status – Full Code (presumed). Discuss advanced directives with patient tomorrow.
9. Disposition – Anticipate ICU step‑down to medical floor once FiO2 ≤ 0.5 and PaCO2 ≤ 45 mmHg; otherwise continue current level of care.

Prepared by: Marcus Vale, MD
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (36, 36, 24315574657, 24315574657, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Ethan Caldwell
DOB: 03/14/3045
MRN: 98765432
PCP: Lila Hartman, MD

Date of Admission: 12/26/3083
Time: 06:36
Admitting Attending: Marcus V. Lorne, MD
Location: MED01
Service: Hospital Medicine

Chief Complaint/Reason for Admission: Low back pain

History of Present Illness:
38yo M with h/o HTN, CKD‑3, chronic low back pain (CLBP) s/p L4‑L5 microdiscectomy 4 mo ago, now p/w worsening axial low back pain radiating to left buttock and posterior thigh, associated with numbness L5 distribution, intermittent LE weakness, low‑grade fevers (T max 38.2 °C) and N/V x2 d. He reports that pain began 2 days ago after lifting a 30 lb box at work (warehouse). Initially “sharp” and 7/10, now constant 9/10, worsened by standing >10 min, partially relieved by lying supine with pillows. He took ibuprofen 600 mg q6h PRN with minimal relief, and his home gabapentin 300 mg tid. Yesterday he presented to urgent care where a lumbar spine MRI was obtained showing new L3‑L4 disc protrusion with mild central canal stenosis and edema of the paraspinal muscles. Labs drawn there showed WBC 13.2 K/µL, CRP 12 mg/L. He was given IV ketorolac and discharged with a prescription for oral oxycodone 5 mg q4h PRN and instructions to follow up with orthopedics. Over the night pain escalated, he became febrile, and developed new urinary hesitancy. EMS brought him to the ED where vitals were HR 112, BP 138/84, RR 22, SpO2 96% RA, Temp 38.4 °C. He was placed on telemetry, given IV morphine 4 mg, and a CT lumbar spine was ordered (no acute fracture). He was admitted for pain control, evaluation of possible postoperative infection, and further work‑up of new neurologic deficits.

Past Medical History:
Diagnosis                                 Date
HTN                                        02/12/3065
Chronic kidney disease stage 3            09/08/3070
Chronic low back pain                    01/15/3060
Hyperlipidemia                           03/20/3062
Obesity (BMI 32)                         04/01/3068

Past Surgical History:
Procedure             Laterality  Date
L4‑L5 microdiscectomy  Right      08/15/3083
Appendectomy            N/A        02/10/3061

Family History:
Problem                 Relation  Age of Onset
Hypertension            Father    45
CKD                    Mother    50
Coronary artery disease Maternal Grandfather 60

Social History:
Tobacco Use: Never smoker
Alcohol Use: Social, 1‑2 drinks/week
Illicit Drugs: Denies
Occupation: Warehouse associate (full‑time)
Living Situation: Lives with spouse, two children (ages 6 & 9)
Transportation: Owns car
Physical Activity: Light walking, no regular exercise

Review of Systems:
Constitutional: Fever, chills – negative for night sweats.
HEENT: No headache, vision changes, sinus pain.
Cardiovascular: No chest pain, palpitations.
Respiratory: No cough, dyspnea at rest.
Gastrointestinal: N/V x2, no abdominal pain, normal bowel movements.
Genitourinary: Dysuria, urinary hesitancy.
Musculoskeletal: Low back pain radiating to left leg, decreased strength LLE, no swelling.
Neurologic: Numbness L5 distribution, no dizziness.
Skin: No rashes.
Psychiatric: No anxiety/depression.

Prior to Admission Medications:
Medication                 Sig
lisinopril 300 mg tablet TAKE 1 TAB PO DAILY
amlodipine 10 mg tablet TAKE 1 TAB PO DAILY
simvastatin 40 mg tablet TAKE 1 TAB PO HS
gabapentin 300 mg capsule TAKE 1 CAP PO TID
metformin 500 mg tablet TAKE 1 TAB PO BID
ibuprofen 600 mg tablet TAKE 1 TAB PO Q6H PRN pain
vitamin D 2000 IU tablet TAKE 1 TAB PO DAILY

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 38.2 °C, HR 108, RR 20, BP 136/82, SpO2 96% RA, Weight 112 kg (247 lb), Height 175 cm (5''9"), BMI 36.6
General: Alert, in moderate distress due to pain, oriented x3.
HEENT: Normocephalic, atraumatic, PERRLA, mucous membranes moist.
Neck: Supple, no meningismus.
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear bilaterally, no wheezes, rales, or rhonchi.
Abdomen: Soft, non‑tender, BS +, no hepatosplenomegaly.
Back/Spine: Tender over L3‑L5 spinous processes, paraspinal muscle spasm noted, limited forward flexion due to pain, straight leg raise positive at 30° left, negative right. No step-offs.
Extremities: Left lower extremity strength 4/5 hip flexion, 4/5 knee extension, 3/5 ankle dorsiflexion; right lower extremity 5/5 throughout. Sensation decreased to light touch over left L5 dermatome. No edema, pulses 2+ bilaterally.
Neurologic: Cranial nerves II‑XII intact, gait unable to ambulate due to pain, reflexes 2+ bilaterally, Babinski negative.
Skin: Warm, dry, no rashes or lesions.

Laboratory Data (drawn 12/26/3083):
CBC:
WBC 13.8 K/µL, Hgb 13.2 g/dL, Hct 39.5 %, Plt 312 K/µL
BMP:
Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 24 mmol/L, BUN 22 mg/dL, Cr 1.8 mg/dL (eGFR 38 mL/min/1.73 m²), Glu 112 mg/dL
CRP: 14 mg/L (ref <5)
ESR: 48 mm/hr
CK: 210 U/L
Urinalysis: Cloudy, 2+ leukocyte esterase, 10‑15 WBC/hpf, no nitrites, no bacteria.

Imaging:
MRI Lumbar Spine (12/25/3083) – New central protrusion of L3‑L4 disc with mild canal stenosis, increased T2 signal in L3 vertebral body suggestive of edema, paraspinal muscle edema, no epidural abscess.
CT Lumbar Spine (12/26/3083) – No acute fracture, confirms MRI findings.

Assessment and Plan:
38yo M with h/o HTN, CKD‑3, recent L4‑L5 microdiscectomy now presenting with acute worsening low back pain, new L3‑L4 disc protrusion, possible postoperative infection vs. inflammatory myositis, febrile, leukocytosis, elevated CRP/ESR, left L5 radiculopathy.

1. Pain Control: Continue IV morphine PCA q1h PRN, add acetaminophen 1 g q6h PO, consider ketorolac 15 mg q8h PO if renal function permits (monitor Cr). Transition to oral oxycodone/acetaminophen 5/325 mg q4h PRN when stable.
2. Infectious Work‑up: Blood cultures x2, urine culture, start empiric IV cefazolin 2 g q8h (adjust for CKD) pending cultures. If MRI later shows abscess, broaden to vancomycin + cefepime.
3. Neurologic Monitoring: Serial neuro exams q4h, consider repeat MRI in 48 h if deficits progress.
4. Renal Management: Hold NSAIDs, maintain IV fluids 1 L NS bolus then 75 mL/hr, monitor urine output, adjust antibiotics for eGFR.
5. Hypertension: Continue lisinopril 300 mg daily, monitor BP; hold amlodipine if hypotensive.
6. Diabetes/Metabolic: Metformin held (eGFR <30), start sliding‑scale insulin sliding scale qac.
7. DVT Prophylaxis: SQ enoxaparin 40 mg SC daily (adjust for Cr).
8. Diet: NPO initially, advance to regular as tolerated.
9. Consults: Orthopedic spine surgery for possible re‑exploration, Infectious Diseases for antimicrobial guidance, Physical Therapy for early mobilization once pain controlled.
10. Disposition: Admit to telemetry floor, anticipate 4‑5 day stay pending response to therapy and surgical evaluation.

Code Status: Full Code (Presumed)

Prepared by: Marcus V. Lorne, MD
Pager: 84210');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (37, 37, 34551248420, 34551248420, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient:  Alejandro Rivera  
DOB: 02/14/3068  
MRN: 98765432  
PCP: Dr. Lucia Mendoza, MD  

Date of Admission: 05/20/3094 04:46  
Location: MED01  
Attending Provider: Dr. Samuel Ortega, MD  

Chief Complaint: Genital ulceration, dysuria, and malaise  

History of Present Illness:  
58yo M with h/o HIV (CD4 420, VL undetectable), chronic HCV (treated), prior syphilis (treated 2018), and recent unprotected intercourse p/w painful penile ulcer, dysuria, and low‑grade fever. Pt reports that 4 days ago he noticed a 1 cm shallow ulcer on the distal glans, erythematous base, serous discharge. Denies trauma. Yesterday developed dysuria, urinary frequency, and chills. Pt was seen at urgent care 2 days ago, given empiric doxy 100 mg BID for presumed urethritis, but symptoms worsened. Pt reports multiple partners over past month, including a new male partner who was diagnosed with primary syphilis 1 week ago. Pt admits occasional methamphetamine use, last use 3 days ago, and drinks socially (≈4 drinks/week). No known drug allergies. No prior episodes of similar lesions.  

Past Medical History:  
• HIV infection (diagnosed 2015) – on bictegravir/emtricitabine/tenofovir alafenamide (BIC/FTC/TAF) qd, adherent  
• Chronic hepatitis C (genotype 1a) – completed 12‑week ledipasvir/sofosbuvir 2022, SVR achieved  
• Prior secondary syphilis, treated 2018 with IM benzathine penicillin G x3 weekly  
• Hypertension – lisinopril 10 mg daily  
• Hyperlipidemia – rosuvastatin 20 mg nightly  

Past Surgical History:  
• Appendectomy – 3075  
• Circumcision – 3070  

Family History:  
Father – HTN, died MI 2090; Mother – alive, DM2; Sister – healthy  

Social History:  
Tobacco: Never smoker  
Alcohol: Social, 4‑5 drinks/week, no binge pattern  
Illicit drugs: Methamphetamine occasional, last use 3 d ago; denies IV drug use  
Sexual: Hetero & homo, multiple partners, inconsistent condom use, last STI screen 2 mo ago (negative except for partner’s recent syphilis)  

Review of Systems:  
Constitutional: Fever 38.2 °C, chills, fatigue – positive; weight loss – negative  
HEENT: No sore throat, no visual changes – negative  
Cardiovascular: No chest pain, palpitations – negative  
Respiratory: No cough, dyspnea – negative  
GI: No nausea, vomiting, abdominal pain – negative  
GU: Painful penile ulcer, dysuria, urinary frequency – positive; hematuria – negative  
Skin: No rash elsewhere, no lymphadenopathy noted – negative  
Neurologic: No headache, no focal deficits – negative  
Psych: Mood stable, no depression – negative  

Prior to Admission Medications:  
Bictegravir/Emtricitabine/Tenofovir alafenamide 50/200/25 mg tablet – TAKE 1 PO DAILY  
Lisinopril 10 mg tablet – TAKE 1 PO DAILY  
Rosuvastatin 20 mg tablet – TAKE 1 PO DAILY  
Vitamin D3 2000 IU tablet – TAKE 1 PO DAILY  

Physical Examination:  

Vital Signs:  
Temp 38.3 °C (101 °F)  
HR 102 bpm (regular)  
RR 18/min  
BP 132/78 mmHg  
SpO₂ 98 % RA  
Weight 84 kg (185 lb)  

General: Alert, mildly ill‑appearing, in no acute distress  
HEENT: Normocephalic, PERRLA, mucous membranes moist, no oropharyngeal lesions  
Neck: Supple, no cervical adenopathy palpable  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi  
Abdomen: Soft, non‑tender, normoactive bowel sounds  
Genitourinary: 1 cm shallow ulcer on distal glans, erythematous base, serous exudate; no induration, no palpable inguinal nodes bilaterally  
Extremities: Warm, well perfused, no edema, no lesions  
Skin: No rashes, no petechiae  
Neurologic: AO×3, CN II‑XII grossly intact, no focal deficits  

Labs (drawn 05/20/3094):  
CBC: WBC 9.2 K/µL, Hgb 13.4 g/dL, Hct 40 %, Plt 215 K/µL  
BMP: Na 138 mmol/L, K 4.3 mmol/L, Cl 102 mmol/L, CO₂ 24 mmol/L, BUN 14 mg/dL, Cr 0.9 mg/dL, Glucose 112 mg/dL  
Liver Panel: AST 32 U/L, ALT 28 U/L, ALP 78 U/L, Total Bilirubin 0.6 mg/dL  
HIV Viral Load: <20 copies/mL (undetectable)  
CD4 Count: 420 cells/µL  
RPR: Reactive, titer 1:64 (up from prior 1:8)  
TPPA: Positive  
HSV PCR (ulcer swab): Pending  
GC/CT NAAT (urine): Negative  
CRP: 12 mg/L (elevated)  

Imaging:  
None indicated at this time  

Assessment and Plan:  
58yo M with well‑controlled HIV, chronic HCV, and new primary syphilis presenting with painful penile ulcer, dysuria, and systemic symptoms → likely syphilitic chancre with possible superimposed bacterial urethritis.  

1. Primary syphilis – treat with IM benzathine penicillin G 2.4 MU single dose today; obtain repeat RPR in 3 mo.  
2. Possible gonococcal urethritis – start ceftriaxone 250 mg IV q24h + doxycycline 100 mg PO BID x10 d pending GC/CT results.  
3. HSV superinfection – if HSV PCR positive, add acyclovir 400 mg PO q8h for 7 d.  
4. HIV – continue current ART, monitor CD4/VL q3 mo.  
5. HCV – no active treatment needed, SVR confirmed.  
6. Pain control – acetaminophen 650 mg PO q6h PRN; consider ibuprofen if no renal contraindication.  
7. Counsel on safe sex practices, condom use, partner notification; arrange for partner testing and treatment.  
8. Substance use – brief counseling on methamphetamine use, refer to outpatient addiction services.  
9. DVT prophylaxis – SQ low‑molecular‑weight heparin 40 mg SC daily.  
10. Diet – regular, encourage hydration.  
11. Code status – Full Code (Presumed).  
12. Disposition – Admit to medical floor, telemetry not required, monitor ulcer healing and response to antibiotics; anticipate discharge in 48‑72 h with outpatient follow‑up with ID and urology.  

Samuel Ortega, MD  
Attending Hospitalist  
Pager 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (38, 38, 12077099065, 12077099065, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 12/13/3069 08:56  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  

Patient: Marcus L. Whitaker  
DOB: 04/22/3015  
MRN: 98765432  
PCP: Dr. Samuel Greene, MD  

Chief Complaint: Dyspnea on exertion, orthopnea, lower extremity edema  

History of Present Illness:  
58yo M with h/o HFrEF (EF 35% on echo 06/3069), CAD s/p PCI 02/3068, HTN, CKD stage 3, DM2 (A1c 8.7%), and recent admission for decompensated HF 12/02/3069 now presents w/ progressive SOB x5 days, NYHA class III→IV, PND 2×/night, orthopnea requiring 3 pillows, +2 LE edema up to mid‑calf, weight gain ~7 lb despite diuretic compliance. Pt reports “feeling like my heart is pounding” and occasional chest pressure but denies acute chest pain. He was discharged 12/02 after IV furosemide 40 mg q8h, transitioned to oral bumetanide 2 mg daily, metoprolol succinate 100 mg daily, lisinopril 20 mg daily, and spironolactone 25 mg daily. Since discharge, he has been taking meds as prescribed but noted that urine output has decreased and his ankles are more swollen. He also reports a low‑grade fever 100.2 °F yesterday, mild cough, no sputum. No recent travel, no sick contacts. He denies alcohol binge, tobacco (quit 2010), illicit drugs.  

ED Course:  
Vitals on arrival: T 37.8 °C, HR 112, RR 22, BP 158/92, SpO2 93% RA. Labs: BNP 1120 pg/mL, Creatinine 1.8 mg/dL (baseline 1.5), BUN 34 mg/dL, K 5.1 mmol/L, Na 138 mmol/L, WBC 9.2 ×10⁹/L. CXR: cardiomegaly, bilateral interstitial edema, small pleural effusions. EKG: sinus tachycardia, LVH criteria, no acute ischemia. Received IV furosemide 80 mg bolus, then 40 mg q6h, started on O₂ 2 L NC, and placed on telemetry.  

Past Medical History:  
• Heart Failure, HFrEF (EF 35%) – 06/3069  
• Coronary Artery Disease – PCI 02/3068 (LAD)  
• Hypertension – 03/3018  
• Type 2 Diabetes Mellitus – 05/3019  
• Chronic Kidney Disease Stage 3 – 11/3065  
• Hyperlipidemia – 04/3020  

Past Surgical History:  
• PCI with drug‑eluting stent – 02/3068  
• Cholecystectomy – 08/3042  

Family History:  
Father – MI at 62, died 3064  
Mother – HTN, alive 88  
Brother – DM2, alive 60  

Social History:  
Marital Status: Married, spouse Jane Whitaker  
Children: 2 adult daughters, both live out of state  
Employment: Retired electrician, now part‑time handyman  
Tobacco: Never smoker (quit nicotine patches 2010)  
Alcohol: Social, 1‑2 drinks/week, no binge  
Illicit Drugs: Denies  
Living Situation: Own home, single‑story, stairs 2 flights, uses walker for ambulation  

Review of Systems:  
Constitutional: +weight gain, +fatigue, -fever (except low‑grade yesterday)  
HEENT: -headache, -vision changes, -sore throat  
Cardiovascular: +dyspnea on exertion, +PND, +orthopnea, -chest pain  
Respiratory: +cough, -hemoptysis, -wheezing  
Gastrointestinal: -N/V, -abdominal pain, -change in bowel habits  
Genitourinary: -dysuria, -frequency  
Musculoskeletal: +LE edema, -joint pain  
Neurologic: -syncope, -TIA symptoms  
Psychiatric: -depression, -anxiety  

Prior to Admission Medications:  
Medication                Sig  
furosemide 40 mg PO BID  
bumetanide 2 mg PO daily  
metoprolol succinate 100 mg PO daily  
lisinopril 20 mg PO daily  
spironolactone 25 mg PO daily  
atorvastatin 40 mg PO nightly  
metformin 1000 mg PO BID  
insulin glargine 30 U SC qd  
aspirin 81 mg PO daily  
vitamin D3 2000 IU PO daily  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs:  
Temp 37.8 °C (100.0 °F)  
HR 112 bpm (irregularly regular)  
RR 22/min  
BP 158/92 mmHg  
SpO2 93% on RA  
Weight 215 lb (97.5 kg) – up 7 lb since discharge  

General: Alert, oriented x3, in mild distress due to dyspnea, sitting upright with 3 pillows.  

HEENT: Normocephalic, PERRLA, mucous membranes moist, no JVD.  

Neck: Supple, no thyromegaly, no carotid bruits.  

Cardiovascular: PMI displaced laterally, S1 S2 normal, S3 present, no murmurs, regular rhythm.  

Respiratory: Bilateral basilar crackles, decreased breath sounds at bases, no wheezes.  

Abdomen: Soft, non‑tender, BS present, no hepatosplenomegaly.  

Extremities: +2 pitting edema bilat to mid‑calf, warm, pulses 2+ bilat, no cyanosis.  

Skin: No rashes, intact.  

Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.  

Labs:  
CBC: WBC 9.2 ×10⁹/L, Hgb 13.1 g/dL, Hct 39.5%, Plt 210 ×10⁹/L  
BMP: Na 138 mmol/L, K 5.1 mmol/L, Cl 103 mmol/L, CO₂ 24 mmol/L, BUN 34 mg/dL, Cr 1.8 mg/dL, Glu 162 mg/dL  
BNP: 1120 pg/mL  
Troponin I: 0.02 ng/mL (reference <0.04)  
LFTs: within normal limits  

Imaging:  
Chest X‑ray 12/13/3069: Cardiomegaly, bilateral interstitial edema, small bilateral pleural effusions, no focal consolidation.  
Echocardiogram 06/3069 (reviewed): LVEF 35%, LV dilation, moderate MR, mild TR, PASP 45 mmHg.  

Assessment and Plan:  
58yo M with known HFrEF (EF 35%) now presenting with acute decompensated heart failure (ADHF) secondary to suboptimal diuresis and possible volume overload. Contributing factors: recent weight gain, reduced urine output, mild infection (low‑grade fever, leukocytosis absent).  

1. ADHF – continue IV loop diuretic: furosemide 80 mg IV bolus now, then 40 mg q6h PRN, monitor urine output, daily weights, electrolytes. Add metolazone 5 mg PO daily if diuresis inadequate.  
2. Optimize GDMT: hold ACE‑I (lisinopril) today due to borderline AKI (Cr 1.8) and hyperkalemia; restart when K <5.0 and Cr <2.0. Continue beta‑blocker (metoprolol) at current dose, monitor HR. Continue spironolactone, hold if K >5.5.  
3. CKD stage 3 – monitor renal function q24h, adjust diuretic dosing accordingly.  
4. Diabetes – continue metformin and basal insulin; check finger‑stick q4h while on steroids (none planned).  
5. Anemia – Hgb stable, no transfusion needed.  
6. Infection – low‑grade fever, consider urinary source; obtain UA, urine culture. No clear pneumonia; continue supportive O₂, consider antibiotics only if cultures positive.  
7. Education – fluid restriction 1.5 L/day, low‑sodium diet <2 g Na, daily weight monitoring.  
8. Disposition – admit to telemetry floor, continue IV diuresis, reassess for possible transition to oral diuretics in 48 h.  

Code Status: Full Code (Presumed)  
DVT Prophylaxis: SQ enoxaparin 40 mg daily (hold if platelet <50k).  
Diet: Low‑sodium, fluid‑restricted.  
Telemetry: Yes.  

Follow‑up labs in 12 h, repeat BMP, BNP q24h, daily weight.  

“Portion of this record may have been generated with voice recognition; please verify for transcription errors.”  

Evelyn Hartwell, MD  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (39, 39, 95546043852, 95546043852, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL  
01/05/3074 05:57  

PATIENT: MARKUS L. DONOVAN  
DOB: 02/14/3045  
MRN: 98765432  
PCP: DR. ELAINE R. SLOANE, MD  

CHIEF COMPLAINT: Dysuria, suprapubic pain, fever x2 days  

HISTORY OF PRESENT ILLNESS:  
29yo M with h/o recurrent prostatitis (most recent episode 3 wks ago, treated with IV levofloxacin → oral ciprofloxacin) now p/w worsening dysuria, urinary frequency, urgency, low back pain, chills, N/V. Symptoms began 48 h ago after completing a 7‑day course of ciprofloxacin prescribed by urgent care; he reports “nothing helped,” now has temperature spikes to 38.9 °C, HR 112, feels “very shaky.” He denies flank tenderness on exam but notes dull ache in lower back radiating to right groin. He was seen at the urgent care on 01/03/3074, given a repeat ciprofloxacin 500 mg BID, but returned to ED when fever persisted and urine became cloudy. He reports prior admission 12/20/3073 for acute bacterial prostatitis, received 48 h IV levofloxacin then discharged on oral levofloxacin 750 mg daily for 10 days; completed that course 5 days ago. No recent catheterization, no recent travel, no sick contacts. Denies alcohol >2 drinks/week, no tobacco, no illicit drugs.  

PAST MEDICAL HISTORY:  
• Recurrent bacterial prostatitis (dx 12/2029)  
• Hypertension (controlled)  
• Seasonal allergic rhinitis  

PAST SURGICAL HISTORY:  
• Appendectomy – 02/15/3030 (lap)  

FAMILY HISTORY:  
Father – HTN, MI @62  
Mother – DM2, CKD stage 3  
Brother – healthy  

SOCIAL HISTORY:  
Marital status: Single, lives alone in apartment.  
Employment: Software engineer, works from home.  
Tobacco: Never smoker.  
Alcohol: Social, 1‑2 beers/week.  
Illicit drugs: Denies.  
Sexual activity: Heterosexual, monogamous, uses condoms inconsistently.  

REVIEW OF SYSTEMS:  
Constitutional: Fever, chills, fatigue – positive.  
HEENT: No sore throat, no visual changes.  
Cardiovascular: No chest pain, palpitations – negative.  
Respiratory: No cough, dyspnea – negative.  
GI: N/V present, no abdominal pain, no diarrhea.  
GU: Dysuria, frequency, suprapubic pain – positive.  
Musculoskeletal: Low back dull ache – positive.  
Neurologic: No headache, no focal deficits – negative.  
Skin: No rashes.  
Psych: No anxiety/depression.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication                Sig  
lisinopril 10 mg PO daily  
amlodipine 5 mg PO daily  
cetirizine 10 mg PO nightly PRN for allergies  
levothyroxine 50 mcg PO daily (for subclinical hypothyroid)  

ALLERGIES: No known drug allergies  

PHYSICAL EXAMINATION:  
Temperature: 38.8 °C (101.8 °F)  
Heart Rate: 112 bpm  
Respiratory Rate: 20/min  
Blood Pressure: 132/78 mmHg  
SpO₂: 97% RA  
Weight: 84 kg (185 lb)  

General: Alert, appears mildly ill, diaphoretic, in no acute distress.  
HEENT: Normocephalic, oropharynx clear, no tonsillar erythema.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  
Abdomen: Soft, mildly tender suprapubic region, no rebound, no guarding.  
Genitourinary: DRE – prostate enlarged, tender, no fluctuance.  
Extremities: Warm, no edema, pulses 2+ bilaterally.  
Skin: No rashes, no lesions.  
Neuro: AOx3, grossly non‑focal.  

LABS AND RESULTS (STAT):  
CBC: WBC 15.2 K/µL (neut 88%), Hgb 13.4 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.1, Cl 102, CO₂ 23, BUN 14, Cr 0.9, Glu 112  
CRP: 12.8 mg/dL (elevated)  
Procalcitonin: 0.78 ng/mL  
Urinalysis: Cloudy, pH 6.5, WBC 45/hpf, RBC 5/hpf, nitrite positive, leukocyte esterase ++  
Urine culture: pending (collected in ED)  
Blood cultures: 2 sets, pending  
Liver panel: within normal limits  

IMAGING:  
Transrectal prostate ultrasound (01/05/3074) – heterogeneous echotexture, no abscess cavity identified.  
Chest X‑ray – no infiltrates.  

ASSESSMENT AND PLAN:  
58yo M with h/o recurrent bacterial prostatitis (most recent admission 12/20/3073) now presenting with acute bacterial prostatitis complicated by possible early sepsis.  

PLAN:  
1. Admit to Med Floor, telemetry not required unless arrhythmia develops.  
2. IV ceftriaxone 2 g q24h + IV levofloxacin 750 mg q24h – broad gram‑negative coverage pending cultures.  
3. IV normal saline 1 L bolus then maintenance 125 mL/hr; adjust per I/O.  
4. Pain control: IV acetaminophen 1 g q6h PRN, morphine 2‑4 mg IV q4h PRN for severe pain.  
5. Urology consult for possible repeat imaging, consider repeat prostate drainage if abscess forms.  
6. Continue home antihypertensives (lisinopril, amlodipine) PO daily.  
7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
8. GI prophylaxis: none indicated.  
9. Diet: regular, encourage oral hydration.  
10. Code status: Full Code (Presumed).  
11. Monitoring: vitals q4h, labs q24h (CBC, BMP, CRP), repeat UA q48h.  
12. Education: discuss importance of completing full antibiotic course, avoid sexual activity until symptom resolution.  

FOLLOW‑UP:  
- Review culture results as soon as available, de‑escalate antibiotics per sensitivities.  
- Re‑evaluate prostate tenderness daily; if worsening or new fluctuance, consider CT pelvis with contrast.  

NATHANIEL K. VALE, MD  
Pager # 67890');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (40, 40, 10527253250, 10527253250, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

10/16/3069 21:58

Patient: Evelyn Hartwell
DOB: 02/14/3035
PCP: Dr. Lila Monroe, MD

CHIEF COMPLAINT: Redness, swelling, and purulent drainage from recent abdominal incision.

HISTORY OF PRESENT ILLNESS:
34yo F with h/o morbid obesity (BMI 42), DM2 (A1c 8.7%), HTN, and recent laparoscopic cholecystectomy p/w erythema, serosanguinous drainage, low‑grade fever, and increasing pain over the RUQ incision site. Patient was discharged from outside hospital 3 days ago after uncomplicated cholecystectomy; received peri‑op cefazolin 1 g q8h and was told to follow up in 2 weeks. On POD #5 she noted mild erythema around the port site, which she attributed to “minor irritation.” Over the past 24 h the erythema expanded to ~6 cm, now warm, tender, with thick yellow‑green purulent ooze. She reports subjective chills, temperature at home 38.2 °C, and pain 7/10, worse with movement. Denies nausea, vomiting, dysuria, or new abdominal pain beyond the incision. No recent travel, no sick contacts. She presented to the ED at 19:45, vitals: T 38.4 °C, HR 112, BP 138/84, RR 20, SpO2 97% RA. Labs drawn, wound swab obtained. Started on IV cefazolin 1 g q8h in ED. She was admitted for IV antibiotics, wound care, and possible imaging to rule out deeper infection.

MEDICAL & SURGICAL HX:

Past Medical History:
• Diabetes mellitus type 2 – diagnosed 2018
• Hypertension – diagnosed 2020
• Obesity – BMI 42
• Hyperlipidemia
• GERD

Past Surgical History:
Procedure               Laterality   Date
• Laparoscopic cholecystectomy   –   10/11/3069
• Appendectomy (open)            –   02/03/3042
• Tonsillectomy                  –   09/15/3025

FAMILY HX:
Problem                     Relation          Age of Onset
• HTN                       Mother            45
• DM2                       Father            50
• CAD                       Grandfather       60
• Breast cancer             Aunt (maternal)  48

SOCIAL HX:
Marital status: Married
Occupation: Warehouse manager
Tobacco use: Never smoker
Alcohol: Social – 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives with spouse and two children in single‑family home
Transportation: Own vehicle
Exercise: Walks 15 min daily
Vaccinations: Up to date, COVID‑19 booster 2028

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills; negative for weight loss.
HEENT: Negative for headache, visual changes.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
GI: Positive for incision pain; negative for nausea, vomiting, diarrhea.
GU: Negative for dysuria, flank pain.
Musculoskeletal: Negative for joint pain.
Skin: Positive for incision erythema, purulent drainage; negative for rash elsewhere.
Neurologic: Negative for weakness, dizziness.
Psych: Negative for anxiety/depression.

PRIOR TO ADMISSION MEDICATIONS:
Medication                     Sig
metformin 500 mg PO BID
lisinopril 20 mg PO daily
atorvastatin 40 mg PO nightly
metoprolol succinate 50 mg PO daily
insulin glargine 30 U SC qHS
omeprazole 20 mg PO daily
multivitamin PO daily

Allergies:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 38.3 °C
Heart Rate: 110 bpm
Respiratory Rate: 20/min
Blood Pressure: 136/82 mmHg
SpO2: 97% RA
Weight: 112 kg (247 lb)

General: Alert, appears mildly ill, in no acute distress.
HEENT: Normocephalic, atraumatic, oropharynx clear.
Neck: Supple, no lymphadenopathy.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.
Abdomen: Midline laparoscopic ports healed; RUQ incision ~6 cm erythematous, warm, tender to palpation, with purulent drainage noted. No rebound, no guarding. Bowel sounds present.
Extremities: No edema, pulses 2+ bilaterally.
Skin: As above, no other lesions.
Neuro: AOx3, grossly non‑focal.

LABORATORY DATA (drawn 10/16/3069):
CBC:
WBC 14.2 K/µL (Neut 86%)
Hgb 12.8 g/dL
Hct 38%
Plt 312 K/µL

BMP:
Na 138 mmol/L
K 4.3 mmol/L
Cl 102 mmol/L
CO2 24 mmol/L
BUN 16 mg/dL
Cr 0.9 mg/dL
Glucose 162 mg/dL

CRP: 12.5 mg/dL (elevated)
Procalcitonin: 0.42 ng/mL
Lactate: 1.2 mmol/L

Wound culture: pending.

Chest X‑ray: No infiltrates, clear lung fields.

IMPRESSION/PLAN:
34yo F with recent laparoscopic cholecystectomy now presenting with superficial incisional surgical site infection (SSI) – erythema, purulence, fever. Plan:

1. Antibiotics: Continue IV cefazolin 1 g q8h; obtain cultures; if no improvement in 48 h or if deeper infection suspected, broaden to IV vancomycin + piperacillin‑tazobactam.
2. Wound care: Daily dressing changes, irrigation with normal saline, monitor for drainage; consider bedside incision and drainage if collection enlarges.
3. Imaging: Obtain abdominal US on day 2 to assess for intra‑abdominal abscess.
4. Glycemic control: Hold sliding scale; start basal‑bolus insulin regimen (glargine 30 U nightly, lispro 4 U qAC PRN) to keep glucose 100‑180 mg/dL.
5. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
6. Diet: Regular diet, encourage high‑protein intake.
7. Activity: Ambulate QID as tolerated.
8. Code status: Full code (presumed).
9. Disposition: Admit to surgical floor, telemetry not required; anticipate 3‑5 day course of IV antibiotics then transition to PO (cephalexin 500 mg PO q6h) to complete 10‑day total therapy.
10. Follow‑up: Surgical team daily, Infectious Diseases consult if no response by day 3.

Prepared by:
Marcus Vale, MD
Attending Hospitalist
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (41, 41, 82339259222, 82339259222, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

04/29/3086 07:11

Patient: Marcus L. Whitaker
DOB: 02/14/3058
MRN: 98765432
PCP: Dr. Eleanor Vance, MD

CHIEF COMPLAINT: Fever, progressive dyspnea, and diffuse rash

HISTORY OF PRESENT ILLNESS:
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2M), chronic HCV (treated), CKD stage 3, and recent PCP pneumonia p/w fever, cough, SOB, and new pruritic maculopapular rash. Pt reports 2 wk of low‑grade fevers (T max 38.9°C) and worsening shortness of breath on exertion. Yesterday he noted a non‑blanching rash starting on trunk then spreading to extremities, associated with itching and occasional chills. He was seen at an outside urgent care 5 days ago, given oral azithro 500 mg daily x3d for presumed atypical pneumonia; symptoms persisted. Pt admits missing several doses of his ART (BIC/FTC/TAF) over past month due to nausea and vomiting. He also reports 2 episodes of non‑bloody, non‑mucoid diarrhea last week. No recent travel, no known TB exposure, no sick contacts. He lives alone, works part‑time as a freelance IT consultant, and reports occasional IV drug use (last use 3 mo ago). He denies alcohol >2 drinks/week, tobacco never. He presents to ED after EMS transport; vitals on arrival: T 38.6 °C, HR 112, RR 24, BP 118/72, SpO2 92% on RA. Labs drawn, CXR performed. Pt appears ill, diaphoretic, with diffuse rash.

PAST MEDICAL HISTORY:
Diagnosis                Date
HIV/AIDS (uncontrolled)  01/12/3065
Chronic Hepatitis C       03/08/3060
Chronic Kidney Disease   07/15/3075
Pneumocystis jirovecii pneumonia 02/20/3084
Hypertension              09/30/3068
Hyperlipidemia            11/12/3069

PAST SURGICAL HISTORY:
Procedure                Laterality   Date
Appendectomy             -            04/02/3062
Right inguinal hernia repair   Right   08/19/3070

FAMILY HISTORY:
Problem                Relation   Age of Onset
Hypertension           Mother     55
Hepatitis C            Father     48
Kidney disease         Maternal uncle 62

SOCIAL HISTORY:
Tobacco Use: Never smoker
Alcohol Use: Social, ~1‑2 drinks/week
Illicit Drug Use: IV heroin, last use 3 mo ago; occasional marijuana
Sexual Activity: Heterosexual, multiple partners, inconsistent condom use
Living Situation: Lives alone in studio apartment
Employment: Freelance IT consultant, works from home
Legal Issues: None

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills, night sweats; negative for weight loss.
HEENT: No sore throat, no visual changes.
Cardiovascular: No chest pain, palpitations.
Respiratory: Positive for dyspnea on exertion, non‑productive cough; negative for hemoptysis.
Gastrointestinal: Positive for nausea, vomiting, 2 episodes of non‑bloody diarrhea; negative for abdominal pain.
Genitourinary: No dysuria, no flank pain.
Skin: Positive for diffuse maculopapular rash, pruritic; negative for lesions on palms/soles.
Neurologic: No headache, no focal deficits.
Psychiatric: Mood “okay,” occasional anxiety related to health.
Hematologic/Lymphatic: No easy bruising, no lymphadenopathy.
Endocrine: No polyuria, polydipsia.

PRIOR TO ADMISSION MEDICATIONS:
Medication                     Sig
BIC/FTC/TAF (Descovy)         TAKE ONE TABLET BY MOUTH DAILY
Ritonavir-boosted darunavir   TAKE ONE TABLET BY MOUTH DAILY
Tenofovir alafenamide         (included in above)
Lisinopril                     TAKE 10 MG BY MOUTH DAILY
Atorvastatin                  TAKE 20 MG BY MOUTH DAILY
Amlodipine                    TAKE 5 MG BY MOUTH DAILY
Trimethoprim‑sulfamethoxazole (Bactrim)  TAKE ONE DOUBLE‑STRENGTH TAB DAILY (PJP prophylaxis)
Acetaminophen PRN            TAKE 500 MG PO Q6H PRN FEVER
Albuterol inhaler PRN         2 Puffs q4h PRN SOB

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 38.6 °C
Heart Rate: 112 bpm
Respiratory Rate: 24 /min
Blood Pressure: 118/72 mmHg
SpO2: 92% on RA
Weight: 78 kg (172 lb)

General: Ill‑appearing, diaphoretic, alert, oriented x3.
HEENT: Normocephalic, atraumatic; mucous membranes moist; no oral thrush.
Neck: Supple, no JVD, no cervical LAD.
Cardiovascular: Regular rate, tachycardic; S1 S2 normal; no murmurs, rubs, gallops.
Respiratory: Diffuse bilateral crackles at bases, decreased breath sounds posteriorly; no wheezes.
Abdomen: Soft, non‑tender, nondistended; bowel sounds present.
Extremities: No edema; diffuse erythematous maculopapular rash covering trunk, upper arms, thighs; non‑blanching, warm to touch.
Skin: Rash as above; no petechiae, no ulcerations.
Neurologic: Alert, oriented, CN II‑XII grossly intact; no focal deficits.
Psych: Anxious but cooperative.

LABS AND IMAGING (most recent):
CBC:
WBC 14.2 K/µL (Neut 84%, Lymph 8%)
Hgb 11.2 g/dL
Hct 34%
Plt 210 K/µL

BMP:
Na 138 mmol/L
K 4.6 mmol/L
Cl 102 mmol/L
CO2 22 mmol/L
BUN 28 mg/dL
Cr 1.8 mg/dL (baseline 1.5)
Glucose 112 mg/dL

Liver Panel:
AST 48 U/L
ALT 52 U/L
ALP 112 U/L
Total Bilirubin 0.9 mg/dL

HIV Panel:
CD4 78 cells/µL
VL 1,200,000 copies/mL

Hepatitis C PCR: Undetectable (post‑treatment)

Arterial Blood Gas (on RA):
pH 7.32, PaCO2 38, PaO2 68, HCO3‑ 20

CXR: Bilateral interstitial infiltrates, more prominent in lower lobes; no focal consolidation.

CT Chest (non‑contrast): Diffuse ground‑glass opacities, no PE.

Blood cultures x2: Pending.

Urinalysis: Cloudy, WBC 15/hpf, no nitrites, no leukocyte esterase.

ASSESSMENT/PLAN:
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2M), CKD‑3, recent PCP pneumonia, now presenting with fever, progressive dyspnea, and diffuse maculopapular rash → likely opportunistic infection (possible disseminated histoplasmosis vs. CMV vs. drug reaction) plus possible superimposed bacterial pneumonia.

1. INFECTION:
   • Start empiric IV cefepime 2 g q8h for broad‑spectrum coverage.
   • Add IV ganciclovir 5 mg/kg q12h pending CMV PCR.
   • Add oral fluconazole 400 mg daily for possible disseminated histoplasmosis (pending urine antigen).
   • Continue Bactrim for PCP prophylaxis.
   • Obtain serum (1,3)-β‑D‑glucan, CMV PCR, Histoplasma urine antigen, fungal cultures.

2. HIV MANAGEMENT:
   • Hold current ART pending evaluation of drug‑related rash; consult ID.
   • Start IV TMP‑SMX 15 mg/kg q8h for possible PCP relapse if respiratory status worsens.
   • Monitor CD4, VL q48h.

3. RENAL:
   • Adjust cefepime dose for Cr 1.8 mg/dL.
   • Maintain fluid balance; I/O charted; consider nephrology consult if Cr rises >2.0.

4. CARDIO‑RESPIRATORY:
   • Place on supplemental O2 2 L NC to keep SpO2 >94%.
   • Telemetry for arrhythmia monitoring.
   • Repeat CXR q48h.

5. RASH:
   • Dermatology consult for skin biopsy.
   • Hold all non‑essential meds (e.g., amlodipine) pending evaluation.
   • Consider systemic steroids only after infectious work‑up excluded.

6. VTE PROPHYLAXIS:
   • SQ enoxaparin 40 mg SC daily (adjust for renal if needed).

7. NUTRITION / SUPPORT:
   • High‑protein, renal‑appropriate diet.
   • Encourage oral intake; consider NG if unable to maintain >75% needs.

8. CODE STATUS:
   • Full code (presumed); discuss goals of care with patient and family.

9. DISPOSITION:
   • Admit to Infectious Diseases service, intermediate‑care unit.
   • Anticipate LOS 7‑10 days pending response to therapy.

10. FOLLOW‑UP:
   • Daily labs, vitals, fluid balance.
   • ID team daily review; pulmonary consult if respiratory status deteriorates.
   • Dermatology results within 48 h.

Prepared by: Dr. Samuel K. Larkin, MD
Attending Hospitalist
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (42, 42, 55591271667, 55591271667, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 06/29/3063 01:03  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  

Patient: Marcus L. Whitaker  
DOB: 02/14/1992  
MRN: 84276109  
PCP: Dr. Samuel Greene, MD  

Chief Complaint: Cough, dyspnea, fever  

History of Present Illness:  
58yo M with h/o T2DM (A1c 8.7%), HTN, CKD stage 3 (eGFR 48), and recent URI p/w 5‑day history of productive cough, pleuritic chest pain, fevers up to 102.4°F, and progressive SOB. Symptoms began 06/24 after returning from a weekend trip to the coastal resort of New Avalon where he attended a family reunion. Denies recent travel outside the region, but reports exposure to several grandchildren who had “cold” symptoms. He initially self‑treated with OTC acetaminophen and azithromycin prescribed by his urgent‑care clinic on 06/25; however, cough worsened, sputum turned rust‑colored, and he noted new night sweats. On 06/27 he presented to the outside ED at Harborview Medical Center where CXR showed right lower lobe infiltrate, labs revealed WBC 14.2 with left shift, procalcitonin 1.8 ng/mL. He received 1 L NS, ceftriaxone 1 g q24h, and was placed on supplemental O₂ 2 L NC. He was discharged home on 06/28 with oral levofloxacin 750 mg daily for 5 days, instructed to follow‑up if no improvement. Over the night he became increasingly dyspneic, SpO₂ dropped to 88% on room air, and he called EMS. EMS noted HR 112, RR 28, BP 138/84, O₂ 92% on 4 L NC. He was transported to our facility, where he was placed on 6 L NC with SpO₂ 96% and transferred to the floor.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2015, on insulin glargine 20 U qHS and metformin 1000 mg BID  
• Hypertension – lisinopril 20 mg daily  
• Chronic Kidney Disease stage 3 – baseline Cr 1.4 mg/dL  
• Hyperlipidemia – rosuvastatin 10 mg daily  
• Seasonal Allergic Rhinitis  

Past Surgical History:  
• Appendectomy – 2008, laparoscopic  
• Right Carpal Tunnel Release – 2020  

Family History:  
Father – HTN, MI at 62; Mother – CKD secondary to diabetes; Sister – asthma  

Social History:  
Marital Status: Married, spouse Jane Whitaker (no med hx)  
Children: 3 (ages 5, 8, 12)  
Occupation: Software engineer, works from home  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Single‑family home, no pets  

Review of Systems:  
Constitutional: Positive for fever, chills, night sweats; negative for weight loss.  
HEENT: Positive for sore throat early in course; negative for vision changes.  
Respiratory: Positive for productive cough, pleuritic chest pain, dyspnea at rest; negative for wheezing.  
Cardiovascular: Negative for chest pressure, palpitations.  
GI: Negative for nausea, vomiting, diarrhea.  
GU: Negative for dysuria.  
Musculoskeletal: Negative for myalgias.  
Neurologic: Negative for headache, dizziness.  
Skin: No rashes.  
Psych: No anxiety or depression noted.  

Prior to Admission Medications:  
Medication Sig  
metformin 500 mg PO BID  
insulin glargine 20 U SC qHS  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
levothyroxine 25 µg PO daily (for subclinical hypothyroid)  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs (on arrival): Temp 38.9°C (102.0°F), HR 108, RR 26, BP 136/78, SpO₂ 92% on 4 L NC, Weight 92 kg (202 lb).  

General: Alert, mildly diaphoretic, in mild respiratory distress.  
HEENT: Normocephalic, oropharynx erythematous, no exudate.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Decreased breath sounds at right lower lung field, crackles heard, egophony present over right base, no wheezes.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neurologic: AOx3, no focal deficits.  

Recent Labs:  
CBC: WBC 14.2 K/µL (neutrophils 84%), Hgb 13.1 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.3, Cl 102, CO₂ 22, BUN 22, Cr 1.5 (eGFR 45), Glucose 212 mg/dL  
CRP: 12.4 mg/dL (↑)  
Procalcitonin: 1.8 ng/mL (↑)  
Lactate: 1.1 mmol/L  
ABG on 2 L NC: pH 7.45, PaCO₂ 34, PaO₂ 78, HCO₃⁻ 24  

Imaging:  
Chest X‑ray (06/29): Right lower lobe consolidation with air bronchograms, mild left basilar interstitial markings.  
CT Chest (non‑contrast, 06/29): Consolidation of right lower lobe with surrounding ground‑glass opacity, no pulmonary embolus.  

Assessment and Plan:  
58yo M with DM, HTN, CKD3 and community‑acquired pneumonia (CAP) right lower lobe, now requiring supplemental O₂, elevated procalcitonin, and mild renal impairment.  

1. Pneumonia – start IV ceftriaxone 2 g q24h and azithromycin 500 mg IV daily; hold levofloxacin given recent exposure. Adjust ceftriaxone dose for Cr >1.5 (no adjustment needed). Continue O₂ titration to maintain SpO₂ ≥ 94%; consider HFNC if worsening.  
2. Diabetes – check finger‑stick q4h, resume basal insulin glargine at 20 U qHS; hold metformin while Cr >1.4.  
3. Hypertension – continue lisinopril; monitor BP q8h.  
4. CKD – monitor BMP daily, avoid nephrotoxic agents, ensure adequate hydration.  
5. VTE prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr >1.5).  
6. Fluid management – 1 L NS bolus given, then maintenance 80 mL/hr; reassess I/O.  
7. Diet – Diabetic/renal diet, low sodium, moderate protein.  
8. Monitoring – Telemetry for arrhythmia risk (HTN, DM), q8 vitals, repeat CXR in 48 h.  
9. Disposition – Admit to medical floor, anticipate 4‑5 day stay; if clinical deterioration, consider ICU transfer.  

Code Status: Full Code (Presumed)  
Disposition: Admit to MED01, low‑acuity telemetry.  

Evelyn Hartwell, MD  
Attending Physician  
Pager 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (43, 43, 81603227618, 81603227618, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Marcus L. Whitaker
DOB: 02/14/3035
MRN: 98765432
PCP: Dr. Evelyn Hart, MD

Date of Admission: 04/21/3071
Time: 13:09
Location: MED01
Attending Provider: Dr. Samuel K. Rhodes, MD

Chief Complaint: Fever, dyspnea, and progressive weakness

History of Present Illness:
58yo M with h/o HIV/AIDS (CD4 78, VL 1.2M), chronic HCV (treated), CKD stage 3, HTN, and recent PCP pneumonia p/w cough, SOB, night sweats, now presents w/ 5‑day hx of high‑grade fevers (T up to 39.8°C), worsening dyspnea on exertion, diffuse myalgias, and marked fatigue. Pt reports that 2 weeks ago he was discharged from outside hospital after 7‑day course of IV cefepime for PCP (TMP‑SMX stopped early due to rash). Since discharge he has been non‑adherent to ART (Biktarvy missed >50% doses) and to TMP‑SMX prophylaxis. He notes new onset of oral thrush, dysphagia to solids, and occasional non‑bloody diarrhea. Denies chest pain, palpitations, leg swelling, or recent travel. He reports drinking 2–3 beers daily, occasional marijuana, no tobacco. He lives in a group home, works part‑time as a janitor, and has multiple sexual partners; last condom‑protected encounter 3 weeks ago. He was seen in the ED 3 days ago where labs showed leukocytosis (WBC 14.2), Cr 1.8, and CXR with diffuse interstitial infiltrates; he was given IV ceftriaxone and discharged with oral levofloxacin. Symptoms have progressed despite antibiotics. He now feels “like he can’t get out of bed,” with orthostatic dizziness. No recent surgeries.

Past Medical History:
Diagnosis                Date
HIV/AIDS (diagnosed 2008)   02/2008
Chronic Hepatitis C (cured) 04/3025
Chronic Kidney Disease Stage 3 06/3030
Hypertension                09/3028
Hyperlipidemia              01/3029
Peripheral Neuropathy (HIV) 03/3032
Depression                  11/3035

Past Surgical History:
Procedure                Laterality   Date
Appendectomy             -            05/3010
Right inguinal hernia repair   Right   08/3022

Family History:
Problem                Relation    Age of Onset
Hypertension           Mother      55
Coronary artery disease Father    62
HIV                    Sister      30

Social History:
Tobacco Use: Never smoker
Alcohol Use: 2–3 beers daily, occasional binge
Illicit Drugs: Marijuana occasional, no IV drug use
Sexual Activity: Multiple partners, inconsistent condom use
Living Situation: Group home, supportive staff
Employment: Janitor (part‑time)
Legal: No arrests

Review of Systems:
Constitutional: +Fever, +Weight loss ~10 lb, +Fatigue, -Chills
HEENT: +Oral thrush, -Vision changes
Respiratory: +Dyspnea on exertion, -Cough, -Hemoptysis
Cardiovascular: -Chest pain, -Palpitations, -Edema
GI: +Non‑bloody diarrhea x3 days, -N/V, -Abdominal pain
GU: +Dysuria, -Hematuria
Musculoskeletal: +Myalgias, -Joint swelling
Neurologic: +Peripheral neuropathy, -Headache, -Seizures
Psychiatric: +Depression, -Suicidal ideation
Skin: +Rash on trunk (previous TMP‑SMX reaction), -Lesions

Prior to Admission Medications:
Medication                     Sig
Biktarvy (bictegravir/emtricitabine/tenofovir alafenamide) 1 tablet PO daily
Lisinopril 20 mg PO daily
Atorvastatin 40 mg PO nightly
Amlodipine 5 mg PO daily
Trimethoprim‑sulfamethoxazole DS 800/160 mg PO daily (held 5 days ago)
Furosemide 20 mg PO daily
Gabapentin 300 mg PO TID
Sertraline 100 mg PO daily
Vitamin D3 2000 IU PO daily

Allergies:
Drug            Reaction
Trimethoprim‑sulfamethoxazole   Rash (maculopapular)

Physical Examination:
Vital Signs:
Temp: 38.9 °C (102 °F)
HR: 112 bpm
RR: 22/min
BP: 118/72 mmHg (supine), 102/64 mmHg standing
SpO2: 94% on RA
Weight: 78 kg (172 lb)

General: Ill‑appearing, NAD but appears fatigued, lies in bed, oriented x3
HEENT: Oral thrush noted on tongue and buccal mucosa, sclera non‑icteric, PERRLA
Neck: Supple, no JVD, no lymphadenopathy
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops
Respiratory: Bilateral diffuse crackles, decreased breath sounds at bases, no wheezes
Abdomen: Soft, non‑tender, BS present, no hepatosplenomegaly
Extremities: Warm, no edema, peripheral pulses 2+ bilaterally, mild decreased sensation in feet (stocking distribution)
Skin: Maculopapular rash on trunk, oral thrush, no petechiae
Neurologic: Alert, oriented, CN II‑XII grossly intact, mild distal weakness 4/5 in lower extremities
Psych: Mood depressed but cooperative

Laboratory Data (most recent):
CBC: WBC 14.2 K/µL, Hgb 10.8 g/dL, Hct 32 %, Plt 210 K/µL
BMP: Na 138, K 4.6, Cl 102, CO2 22, BUN 28, Cr 1.9 mg/dL, Glucose 112 mg/dL
Liver Panel: AST 48 U/L, ALT 52 U/L, ALP 112 U/L, Total Bilirubin 0.9 mg/dL
CD4 Count: 78 cells/µL
HIV Viral Load: 1.2 × 10⁶ copies/mL
Lactate: 2.4 mmol/L
CRP: 12 mg/dL
Procalcitonin: 0.8 ng/mL
Urinalysis: WBC 15/hpf, nitrite negative, protein trace
Blood cultures: x2 pending
Sputum Gram stain: many PMNs, few Gram‑positive cocci in pairs
Chest X‑ray: Diffuse interstitial infiltrates bilaterally, no focal consolidation
CT Chest (non‑contrast): Ground‑glass opacities throughout both lungs, small bilateral pleural effusions, no PE
ECG: Sinus tachycardia, HR 112, no ischemic changes

Assessment and Plan:
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2M), recent PCP pneumonia, now presents with fever, progressive dyspnea, diffuse GGO, possible opportunistic infection (PJP relapse vs CMV pneumonitis vs bacterial superinfection) and acute on chronic kidney injury. Also has oral thrush, non‑adherence to ART, and mild hepatic dysfunction.

1. Suspected PJP relapse – start high‑dose TMP‑SMX DS 15 mg/kg (based on ideal body weight) IV q6h plus adjunctive prednisone 40 mg PO BID. Monitor for renal function and rash; consider desensitization if needed.
2. Empiric broad‑spectrum coverage for bacterial superinfection – IV cefepime 2 g q8h.
3. CMV pneumonitis in differential – send plasma CMV PCR, consider ganciclovir if PCR >1000 IU/mL.
4. Continue ART after 48 h of TMP‑SMX tolerance; hold Biktarvy until renal function stabilizes, then restart with dose adjustment.
5. CKD stage 3 – adjust cefepime dose, monitor Cr q12h, maintain fluid balance, avoid nephrotoxins.
6. Oral thrush – start fluconazole 200 mg PO daily for 14 days.
7. Anemia of chronic disease – monitor Hgb, consider EPO if <8 g/dL and symptomatic.
8. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).
9. Nutrition – high‑protein, renal‑appropriate diet, consider NG tube if intake <50 % for >48 h.
10. Social work – arrange case management for medication adherence, housing stability, and outpatient HIV follow‑up.
11. Isolation – airborne + contact precautions for PJP; continue droplet precautions until infectious work‑up complete.
12. Labs – CBC, BMP, CD4, VL, CMV PCR, fungal cultures q48h; repeat CXR q72h.
13. Consults: Infectious Diseases, Nephrology, Pharmacy for ART dosing, Psychiatry for depression.

Disposition: Admit to intermediate‑care unit for telemetry, respiratory monitoring, and close labs. Goal to stabilize infection, improve oxygenation, and re‑initiate ART. Code Status: Full Code (Presumed).  

Samuel K. Rhodes, MD
Attending Hospitalist  
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (44, 44, 66398765634, 66398765634, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient:  Michael J. Harrow
MRN:  98765432
DOB:  02/14/3024
PCP:  Dr. Lena K. Voss, MD

Date of Admission: 06/22/3069 15:55
Location:  MED01 – Internal Medicine Floor
Attending Provider:  Dr. Samuel T. Raines, MD

Chief Complaint:  Fever, chills, and worsening right thigh pain

History of Present Illness:
45yo M with h/o IVDU (heroin, last use 2 d ago), chronic HCV (RNA+), COPD (GOLD II), and recent right thigh cellulitis/abscess p/w fever, chills, dyspnea, and progressive swelling. Pt reports that 5 d ago he noticed a painful, erythematous nodule on the anterolateral right thigh after injecting heroin into the area; he self‑drained a small amount of purulent fluid at home, applied over‑the‑counter ointment, and continued using the same site. Over the past 48 h he developed high‑grade fevers (T up to 39.8 °C), rigors, SOB on exertion, and the thigh became increasingly tender, fluctuant, and now has a foul‑smelling drainage. He denies chest pain, palpitations, cough, or recent travel. He reports occasional alcohol use (2‑3 beers/week) and denies tobacco (quit 3 y ago). He was seen at an urgent care 2 d ago, received a single IM dose of ceftriaxone and was discharged with oral clindamycin; symptoms have not improved. He presents to the ED for further evaluation.

ED Course (summarized):
Vitals on arrival: T 39.4 °C, HR 112, BP 118/72, RR 22, SpO2 94% RA. Labs showed WBC 18.2 K with left shift, CRP 12 mg/dL, lactic acid 2.8 mmol/L. Blood cultures drawn x2. CT thigh with contrast demonstrated a 5 cm rim‑enhancing fluid collection within the subcutaneous tissue, no deep fascial involvement. Empiric IV vancomycin and cefepime started. Pt was admitted for IV antibiotics, possible incision & drainage, and evaluation for endocarditis given IVDU history.

Past Medical History:
• Chronic hepatitis C infection (RNA+)
• Chronic obstructive pulmonary disease
• Hypertension
• Prior right forearm abscess (2019)

Past Surgical History:
• Incision & drainage of left forearm abscess – 2019
• Appendectomy – 2025

Family History:
Father – deceased MI at 62
Mother – alive, HTN
Sister – healthy

Social History:
Tobacco: Never smoker (quit 3 y ago after occasional use)
Alcohol: Social, 2‑3 beers/week
Illicit Drugs: Active IVDU (heroin, last use 2 d ago); shares needles intermittently
Housing: Unstable, lives in transitional shelter
Employment: Unemployed
Sexual Activity: Heterosexual, multiple partners, inconsistent condom use

Review of Systems:
Constitutional: Fever, chills, fatigue – positive; weight loss – negative.
HEENT: No sore throat, no visual changes.
Cardiovascular: No chest pain, palpitations – negative.
Respiratory: Dyspnea on exertion, cough – negative.
GI: Nausea, vomiting – negative; appetite decreased.
GU: No dysuria, hematuria.
Musculoskeletal: Right thigh pain, swelling, drainage – positive; other joints – negative.
Neurologic: No headache, dizziness.
Skin: Right thigh cellulitis/abscess – positive; other rashes – negative.
Psych: Anxiety about housing – positive.

Prior to Admission Medications:
Medication                Sig
Lisinopril 20 mg PO daily
Albuterol inhaler 90 mcg PRN q4‑6h PRN SOB
Amlodipine 5 mg PO daily
None for HCV (patient not on antiviral therapy)

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 38.9 °C, HR 108, BP 122/70, RR 20, SpO2 95% RA, Weight 84 kg (185 lb)

General: Alert, appears ill, in mild distress due to pain.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD, no lymphadenopathy.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, mild wheeze on expiration.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: Right anterior thigh – erythematous, warm, 12 cm x 8 cm area of fluctuance with central drainage; surrounding induration. No crepitus. No edema elsewhere. Pulses 2+ bilaterally.
Skin: No other lesions.
Neurologic: AOx3, grossly non‑focal.
Psych: Cooperative.

Diagnostic Data:
CBC: WBC 18.2 K, Hgb 13.1 g/dL, Plt 210 K
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 112
CRP: 12 mg/dL
Lactate: 2.8 mmol/L
Blood Cultures: Pending (x2)
Thigh CT (contrast): 5 cm rim‑enhancing fluid collection within subcutaneous tissue, no fascial plane involvement.
ECG: Sinus tachycardia, HR 108, no ST/T changes.
Chest X‑ray: No infiltrates, cardiac silhouette normal.

Assessment and Plan:
45yo M with h/o IVDU, chronic HCV, and recent right thigh abscess now presenting with fever, leukocytosis, and a 5 cm sub‑Q collection – likely complicated cellulitis/abscess with possible bacteremia. Differential includes MRSA, gram‑negative rods, and polymicrobial infection; also consider endocarditis given IVDU.

1. Soft‑tissue infection:
   • Continue IV vancomycin (dose adjusted for renal function) + cefepime.
   • Surgical consult for possible incision & drainage today.
   • Monitor vitals, WBC trend, drainage output.
2. Blood cultures:
   • Review results when available; de‑escalate antibiotics based on sensitivities.
3. Endocarditis screen:
   • Obtain transthoracic echo (TTE) now; if high suspicion, consider TEE.
4. Hepatitis C:
   • Counsel on treatment; arrange referral to hepatology for direct‑acting antivirals after acute infection resolves.
5. Substance use:
   • Initiate inpatient addiction consult; discuss MAT (buprenorphine) and needle‑exchange resources.
6. DVT prophylaxis:
   • SQ low‑molecular‑weight heparin 40 mg SC daily.
7. Pain control:
   • Acetaminophen 650 mg PO q6h PRN; consider IV morphine PRN for breakthrough pain.
8. Diet: Regular, high protein.
9. Code Status: Full Code (presumed).
10. Disposition: Anticipate 5‑7 day course of IV antibiotics, possible step‑down to oral after clinical improvement and negative cultures; discharge planning with social work for housing and outpatient IV antibiotic therapy if needed.

Signature:
Samuel T. Raines, MD
Hospitalist, Internal Medicine
Pager 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (45, 45, 61238613706, 61238613706, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Ethan Marlowe  
DOB: 04/23/3045  
MRN: 98765432  
PCP: Dr. Lila Hart, MD  

Date of Admission: 01/12/3081  
Time: 08:39  
Location: SURG01  
Attending Provider: Victor Selby, MD  

Chief Complaint: Redness, swelling, and purulent drainage from right thigh surgical incision  

History of Present Illness:  
36yo M with h/o MVC 5d ago s/p ORIF of right femur (plate & screws) now p/w increasing erythema, warmth, and serosanguinous drainage from the incision site. Pt reports low‑grade fevers up to 38.3°C since POD #3, chills intermittent, and increasing pain despite oral acetaminophen 650 mg q6h. He was discharged from community hospital on POD #2 with a 5‑day course of cephalexin 500 mg PO q6h; he completed 3 doses then stopped when drainage worsened. No known drug allergies. No prior wound complications. He denies SOB, chest pain, dysuria, or GI symptoms. He notes that the dressing was changed at home on POD #4 and now appears saturated with yellow‑green fluid. He reports mild nausea but no vomiting. He works as a freelance carpenter, lives alone, and has limited support; he came to ED because pain is now 8/10 at rest and he feels “feverish”.  

Past Medical History:  
- Hypertension (diagnosed 3048)  
- Obesity (BMI 32)  
- Seasonal allergic rhinitis  

Past Surgical History:  
- Right femur ORIF (01/07/3081) – trauma from MVC  
- Appendectomy (3049)  

Family History:  
- Mother: HTN, DM2  
- Father: CAD, died 3075 MI  
- Sister: Healthy  

Social History:  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Occupation: Carpenter (frequent heavy lifting)  
Living situation: Lives alone, no home health services  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.  
HEENT: Negative.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No cough, dyspnea.  
Gastrointestinal: Nausea present, no vomiting, no abdominal pain.  
Genitourinary: No dysuria, no flank pain.  
Musculoskeletal: Right thigh pain, swelling, erythema.  
Skin: Positive for wound drainage, warmth.  
Neurologic: No headache, no focal deficits.  
Psychiatric: Anxious about infection.  

Medications Prior to Admission:  
Lisinopril 20 mg PO daily  
Hydrochlorothiazide 25 mg PO daily  
Amlodipine 5 mg PO daily  
Acetaminophen 650 mg PO q6h PRN pain  

Allergies: No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs: Temp 38.2 °C (100.8 °F), HR 112, RR 20, BP 138/84, SpO2 97% RA, Pain score 8/10.  

General: Alert, appears mildly ill, diaphoretic.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: Supple, no JVD.  

Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Right thigh surgical incision ~12 cm, erythematous, indurated, warm to touch, with ~3 cm of serosanguinous purulent drainage. No fluctuance noted. No crepitus. Distal pulses 2+ bilaterally, no edema.  

Skin: No other rashes.  

Neurologic: AOx3, grossly non‑focal.  

Laboratory Data (drawn 01/12/3081):  
CBC: WBC 14.2 K/µL (neutrophils 88%), Hgb 13.1 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.3, Cl 102, CO2 22, BUN 14, Cr 0.9, Glucose 112  
CRP: 12.8 mg/dL (elevated)  
Procalcitonin: 0.68 ng/mL  
Blood cultures x2: pending  
Wound culture: obtained in ED, pending  

Imaging:  
Right femur AP/ lateral X‑ray (01/12/3081) – hardware in place, no obvious peri‑implant lucency, mild soft‑tissue swelling.  

Assessment and Plan:  
1. Surgical site infection (right femur ORIF) – likely cellulitis with early deep tissue involvement, possible early osteomyelitis.  
   • Start empiric IV antibiotics: Vancomycin 15 mg/kg q12h (adjust for trough) + Cefepime 2 g IV q8h.  
   • Obtain wound cultures (already done) and adjust antibiotics per sensitivities.  
   • Orthopedic surgery consult for possible debridement; keep patient NPO until OR decision.  
   • Serial CBC, CRP q48h to monitor response.  
   • Wound care: sterile dressing change q12h, monitor for increased drainage.  

2. Hypertension – continue home lisinopril 20 mg PO daily; monitor BP.  

3. Obesity – dietitian consult for weight management, low‑sodium cardiac diet.  

4. DVT prophylaxis – SQ enoxaparin 40 mg SC daily.  

5. Pain control – IV acetaminophen 1 g q6h PRN, consider low‑dose morphine PCA if pain >6/10 after 24 h.  

6. Code Status: Full Code (Presumed).  

7. Disposition: Admit to surgical floor, telemetry not required unless arrhythmia develops.  

8. Education: Discuss wound care, signs of worsening infection, importance of completing IV antibiotics.  

9. Follow‑up labs: BMP, CBC, cultures q24h until stable.  

Prepared by: Victor Selby, MD  
Pager #: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (46, 46, 36061499778, 36061499778, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Hospital Admission Note

Patient: Evelyn Mae Calderon
DOB: 02/14/3005
MRN: 84276109
PCP: Dr. Luis Ramirez, MD
Date of Admission: 04/20/3061
Time: 18:25
Location: CARDIO01
Attending Provider: Dr. Naomi Sinclair, MD
Admitting Resident: Dr. Omar Patel, MD
Code Status: Full Code (Presumed)

Chief Complaint/Reason for Admission: Dyspnea on exertion, orthopnea, lower extremity edema

History of Present Illness:
58yo F with h/o HFrEF (EF 32% on echo 03/3061), CAD s/p PCI to RCA 02/3060, HTN, CKD stage 3, and recent admission for decompensated HF 03/28/3061 now presents with 5‑day history of worsening SOB, NYHA class III→IV, dyspnea on minimal ambulation, 2‑L of PND nightly, and 2+ pitting edema to mid‑calves. She reports that she was discharged 2 weeks ago after a 4‑day stay for acute on chronic HF; at discharge she was on furosemide 40 mg PO BID, carvedilol 12.5 mg BID, lisinopril 20 mg daily, and spironolactone 25 mg daily. Since discharge she has been non‑adherent to diuretics due to “feeling light‑headed” and has been drinking 2‑3 glasses of wine nightly. She denies chest pain, palpitations, fever, cough, or recent travel. She notes a 4‑lb weight gain despite restricting salt, and her urine output has decreased to <1 L/24 h. She was seen in the ED 04/19/3061 where vitals showed HR 112, BP 138/78, RR 22, SpO2 92% on RA, and a bedside echo suggested EF 30% with moderate mitral regurg. She was given IV furosemide 40 mg with modest diuresis and then transferred to our floor for further management.

Past Medical History:
Diagnosis                Date
HFrEF (ischemic)        01/3060
Coronary artery disease 02/3060
Hypertension            03/3008
Chronic kidney disease stage 3 05/3015
Hyperlipidemia          04/3010
Atrial fibrillation (paroxysmal) 06/3025
Depression              09/2015

Past Surgical History:
Procedure                Laterality   Date
Percutaneous coronary intervention (RCA)   -   02/3060
Cholecystectomy        -   11/3022

Family History:
Problem                Relation   Age of Onset
CAD                    Father     58
Hypertension           Mother     55
CKD                    Maternal Grandfather  70
Breast cancer          Sister     45

Social History:
Tobacco Use: Never smoker
Alcohol Use: 2‑3 glasses wine nightly, occasional beer
Illicit Drugs: Denies
Occupation: Retired elementary school teacher
Living Situation: Lives with husband, 2 adult children visit weekly
Transportation: Drives herself
Exercise: Walks <5 min due to dyspnea
Advance Directives: None documented

Review of Systems:
Constitutional: +fatigue, +weight gain, -fever, -chills
HEENT: -vision changes, -headache
Cardiovascular: +DOE, +PND, +orthopnea, -chest pain, -palpitations
Respiratory: +dyspnea, -cough, -hemoptysis
Gastrointestinal: -nausea, -vomiting, -abdominal pain
Genitourinary: -dysuria, -hematuria
Musculoskeletal: -myalgias
Neurologic: -syncope, -dizziness
Psychiatric: +depression, -anxiety
Skin: -rashes, -lesions

Prior to Admission Medications:
Medication                     Sig
Furosemide 40 mg               PO BID
Carvedilol 12.5 mg             PO BID
Lisinopril 20 mg               PO daily
Spironolactone 25 mg           PO daily
Atorvastatin 40 mg            PO nightly
Metoprolol succinate 25 mg    PO daily (for AF)
Warfarin 5 mg                 PO daily (INR goal 2‑3)
Escitalopram 10 mg            PO daily
Albuterol inhaler              2 puffs PRN q4h

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 36.8 °C (98.2 °F)  HR 108  RR 20  BP 136/78  SpO2 93% RA  Weight 84 kg (185 lb)  BMI 31
General: Alert, mildly diaphoretic, in mild respiratory distress, sitting upright
HEENT: Normocephalic, PERRLA, mucous membranes moist
Neck: JVD present, no thyromegaly
Cardiovascular: S1 S2 normal, S3 present, regular rate, no murmurs
Respiratory: Bilateral basilar crackles, decreased breath sounds lower fields, no wheezes
Abdomen: Soft, non‑tender, mild hepatomegaly, no ascites
Extremities: 2+ pitting edema to mid‑calves bilaterally, warm, pulses 2+ dorsalis pedis
Skin: No rashes, intact
Neuro: AOx3, no focal deficits

Laboratory Data (drawn 04/20/3061):
CBC:
WBC 9.2 K/µL
Hgb 11.8 g/dL
Hct 35%
Plt 210 K/µL

BMP:
Na 138 mmol/L
K 5.1 mmol/L
Cl 102 mmol/L
CO2 22 mmol/L
BUN 28 mg/dL
Cr 1.6 mg/dL (baseline 1.4)
Glucose 138 mg/dL

Cardiac Biomarkers:
Troponin I 0.04 ng/mL (reference <0.03)

BNP: 1120 pg/mL

Liver Panel: AST 32 U/L, ALT 28 U/L, ALP 78 U/L, Total bili 0.9 mg/dL

Coagulation: INR 1.2, PT 13.0 sec, aPTT 32 sec

Urinalysis: Specific gravity 1.015, 2+ protein, no glucose, no blood

Imaging:
Chest X‑ray (PA & lateral): Cardiomegaly, pulmonary venous congestion, bilateral interstitial edema, small pleural effusions.
Transthoracic Echo (03/3061): LVEF 32%, global hypokinesis, moderate MR, mild LV dilation, RV normal.
Lower extremity Doppler US: No DVT.

Assessment and Plan:
58yo F with known HFrEF (EF 32%) presenting with acute decompensated heart failure secondary to diuretic non‑adherence and excess alcohol intake. Contributing factors include CKD stage 3 limiting diuretic tolerance and recent hospitalization with suboptimal volume status optimization.

1. Acute decompensated HF:
   - IV furosemide 80 mg bolus then continuous infusion 10 mg/hr, titrate to net negative 1‑1.5 L/24 h.
   - Add IV metolazone 5 mg q24h if diuresis inadequate.
   - Hold spironolactone while K >5.0, monitor electrolytes q6h.
   - Continue carvedilol 12.5 mg BID, hold if SBP <90.
   - Continue lisinopril 20 mg daily, hold if AKI worsens (Cr >2.0) or K >5.5.
   - Initiate low‑dose IV nitroglycerin drip for preload reduction if pulmonary edema persists.
   - Daily weights, strict I&O, fluid restriction 1.5 L/day.

2. CKD stage 3:
   - Adjust diuretic dosing, monitor Cr and K closely.
   - Avoid NSAIDs, contrast.

3. Atrial fibrillation (paroxysmal):
   - Continue warfarin, check INR q2 days, target 2‑3.
   - Rate control with metoprolol succinate; consider digoxin if renal clearance permits.

4. Hypertension:
   - Optimize BP with current regimen, avoid abrupt changes.

5. Alcohol use:
   - Counsel on limiting intake, consider brief intervention, screen for dependence.
   - Offer referral to outpatient counseling.

6. Depression:
   - Continue escitalopram 10 mg daily, monitor mood.

7. Disposition:
   - Admit to telemetry floor for close monitoring, daily labs, and diuresis titration.
   - DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
   - Stress ulcer prophylaxis: PO pantoprazole 40 mg daily.
   - Diet: Low‑sodium (2 g) cardiac diet.
   - Education: Fluid restriction, daily weights, medication adherence.

8. Follow‑up:
   - Repeat BMP, BNP, and INR in 24 h.
   - Repeat chest X‑ray if clinical status unchanged after 48 h.
   - Cardiology consult for possible uptitration of GDMT and evaluation for device therapy (ICD/CRT) given EF <35%.

Prepared by: Dr. Omar Patel, MD
Pager #: 22457
Date/Time: 04/20/3061 19:02');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (47, 47, 46166091990, 46166091990, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'PATIENT:  Michael A. Sample  
MRN:  98765432  
DOB:  04/15/3015 (35 y/o M)  
PCP:  Dr. Laura Example, MD  

DATE OF ADMISSION: 02/28/3050  
TIME: 18:12  
ADMITTING ATTENDING:  Dr. Ethan Notreal, MD  
LOCATION:  MED01  

CHIEF COMPLAINT:  
Fever x3 days, associated chills, generalized malaise.

HISTORY OF PRESENT ILLNESS:  
35yo M with h/o T2DM (A1c 8.6%), CKD stage 3 (eGFR 48), recent discharge from outside hospital (02/25/3050) after treatment for uncomplicated cystitis now p/w persistent low‑grade fever (T 38.2‑38.7°C), chills, fatigue, mild frontal headache, no localized pain. Denies cough, dyspnea, chest pain, SOB, N/V/D, dysuria, flank pain, rash. Reports that after discharge he was on oral ciprofloxacin 500 mg BID, completed 5 days, but fever persisted and he felt “worse” on day 3 post‑discharge. He went to urgent care on 02/27, got a CBC (WBC 12.4 K) and was told to go to ED for further eval. In ED vitals: T 38.5 °C, HR 112, BP 128/78, RR 20, SpO2 98% RA. Labs showed leukocytosis with left shift, mild AKI (Cr 1.6 from baseline 1.3). Blood cultures drawn, urinalysis negative for nitrites/leukocyte esterase. CXR read as “clear lungs, no infiltrates.” He was given 1 L NS, acetaminophen 650 mg PO, and started on IV ceftriaxone 1 g q24h and vancomycin 1 g q12h pending cultures. He was admitted for continued work‑up of FUO (fever of unknown origin) and possible sepsis.  

PAST MEDICAL HISTORY:  
• Type 2 diabetes mellitus (diagnosed 2025)  
• Chronic kidney disease stage 3 (2028)  
• Hypertension (2019)  
• Hyperlipidemia (2020)  

PAST SURGICAL HISTORY:  
• Appendectomy (2022)  

FAMILY HISTORY:  
Father – HTN, died MI @68  
Mother – DM2, alive 62  
Sister – healthy  

SOCIAL HISTORY:  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Occupation: Software engineer, works from home  
Living situation: Lives with spouse, no pets  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills, fatigue; negative for weight loss.  
HEENT: Negative for sore throat, visual changes.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea, wheeze.  
GI: Negative for N/V/D, abdominal pain.  
GU: Negative for dysuria, flank pain.  
Musculoskeletal: Negative for myalgias, arthralgias.  
Neurologic: Negative for focal deficits, seizures.  
Skin: No rash, lesions.  
Psych: No depression/anxiety reported.  

MEDICATIONS PRIOR TO ADMISSION:  
metformin 1000 mg PO BID  
lisinopril 20 mg PO daily  
atorvastatin 40 mg PO nightly  
insulin glargine 30 U SC qHS  
ciprofloxacin 500 mg PO BID (completed 5 days)  

ALLERGIES:  
No known drug allergies (NKDA).  

PHYSICAL EXAMINATION:  
VITALS: T 38.4 °C, HR 110, BP 126/76, RR 20, SpO2 98% RA, Weight 92 kg (202 lb).  

GENERAL: Alert, oriented x3, appears mildly ill, diaphoretic.  

HEENT: NC/AT, PERRLA, EOMI, oropharynx clear, no tonsillar exudate.  

NECK: Supple, no JVD, no lymphadenopathy.  

CARDIOVASCULAR: RRR, S1 S2 normal, no murmurs, rubs, gallops.  

RESPIRATORY: Clear to auscultation bilaterally, no rales, wheezes, or rhonchi.  

ABDOMEN: Soft, non‑tender, nondistended, BS +, no hepatosplenomegaly.  

EXTREMITIES: No edema, pulses 2+ bilaterally, no calf tenderness.  

NEURO: AOx3, CN II‑XII grossly intact, no focal deficits.  

SKIN: Warm, dry, no rashes.  

LABS (02/28/3050):  
CBC: WBC 12.4 K, Hgb 13.2 g/dL, Hct 39.5 %, Plt 312 K.  
CMP: Na 138, K 4.6, Cl 102, CO2 23, BUN 22, Cr 1.6, Glu 162, AST 28, ALT 32, Alk Phos 78, Total Bili 0.6.  
CRP: 8.2 mg/dL (elevated).  
Procalcitonin: 0.45 ng/mL.  
UA: Specific gravity 1.015, pH 6.0, no leukocyte esterase, no nitrites, 2+ glucose, no casts.  
Blood cultures x2: pending.  

IMAGING:  
Chest X‑ray (PA/AP): No infiltrates, clear lung fields, normal cardiac silhouette.  

ASSESSMENT/PLAN:  
35yo M with h/o DM2, CKD3, recent cystitis discharge now p/w FUO, leukocytosis, mild AKI, currently on empiric ceftriaxone + vancomycin pending cultures.  

1. FEVER OF UNKNOWN ORIGIN – likely infectious; continue broad‑spectrum IV antibiotics, obtain repeat CBC, CMP q24h, monitor renal function, adjust vancomycin trough.  
2. SEPSIS‑LIKE STATE – give 30 mL/kg IV crystalloid (NS) over first 24 h, monitor urine output, consider ICU if MAP <65 mmHg.  
3. DIABETES – check fingerstick q6h, continue insulin glargine, hold metformin while Cr >1.5.  
4. CKD – avoid nephrotoxic agents, adjust vancomycin dosing per eGFR.  
5. DVT PROPHYLAXIS – SQ enoxaparin 40 mg daily (adjust for Cr).  
6. TELEMETRY – low‑risk telemetry for arrhythmia monitoring.  
7. CODE STATUS – Full Code (Presumed).  
8. DIET – Diabetic/renal appropriate, low sodium, moderate protein.  
9. CONSULTS: Infectious Diseases for guidance on duration/coverage, Nephrology for AKI management.  
10. DISPOSITION: Admit to Med floor, anticipate 4‑5 day stay pending culture results and clinical response.  

Signature:  Ethan Notreal, MD  
Pager # 22458');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (48, 48, 66419809395, 66419809395, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Hospitalist Admission History and Physical  
07/17/3059 21:04  

Patient: Samuel T. Whitaker  
DOB: 03/22/3015  
MRN: 98765432  
PCP: Dr. Lena Marlowe, MD  

CHIEF COMPLAINT: Dysuria, suprapubic pain, fever  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 45), BPH, recent prostatitis p/w N/V/D and R flank pain now presents with 3‑day history of worsening dysuria, cloudy urine, suprapubic pressure and chills. Pt reports that 2 weeks ago he was discharged from an outside facility after a 4‑day stay for an uncomplicated ureteral stone that required ureteroscopy and stent placement. Post‑op course was uneventful, stent was removed 5 days ago, but he notes that urine has been “smelly” and “burning” since then. Yesterday he developed fever to 38.9°C (102°F) at home, associated with rigors and mild nausea. He denies flank tenderness now, no gross hematuria, no recent sexual activity, no new meds. He has been taking his home metformin 500 mg BID, lisinopril 20 mg daily, and tamsulosin 0.4 mg nightly. He tried OTC phenazopyridine with minimal relief. He presents to the ED after his wife called EMS because of persistent fever and confusion (felt “foggy”). In the ED vitals: T 38.7°C, HR 112, BP 138/78, RR 22, SpO2 96% RA. Labs drawn, UA positive for leukocyte esterase, nitrites, WBC 45/hpf. Blood cultures obtained. He was started on IV ceftriaxone 1 g q24h and admitted for urosepsis work‑up.  

MEDICAL & SURGICAL HX:  

Past Medical History:  
• Type 2 Diabetes Mellitus (diagnosed 2012)  
• Chronic Kidney Disease stage 3 (2025)  
• Benign Prostatic Hyperplasia (2018)  
• Hypertension (2010)  
• Prior ureteral stone s/p ureteroscopy & stent (07/01/3059)  

Past Surgical History:  
Procedure Laterality Date  
• URETEROSCOPY – Right – 07/01/3059  

FAMILY HX:  
Father – HTN, died MI age 68  
Mother – DM2, alive 84  
Brother – CKD stage 4  

SOCIAL HX:  
Marital status: Married  
Occupation: IT consultant, works from home  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Lives with spouse, two adult children, no pets  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills, fatigue.  
Genitourinary: Positive dysuria, suprapubic pain, cloudy urine, nitrites on UA. Denies hematuria, flank pain.  
GI: Nausea mild, no vomiting, no diarrhea.  
Respiratory: No cough, SOB.  
Cardiovascular: No chest pain, palpitations.  
Neurologic: “Foggy” mental status, no focal deficits.  
Skin: No rashes.  
Psych: No depression/anxiety noted.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
metformin 500 MG tablet TAKE 1 TABLET BY MOUTH BID  
lisinopril 20 MG tablet TAKE 1 TABLET BY MOUTH DAILY  
tamsulosin 0.4 MG capsule TAKE 1 CAPSULE BY MOUTH QHS  
aspirin 81 MG EC tablet TAKE 1 TABLET DAILY  

PHYSICAL EXAMINATION:  
Temperature: 38.7°C (101.7°F)  
Heart Rate: 112 bpm  
Respiratory Rate: 22/min  
BP: 138/78 mmHg  
SpO2: 96% RA  

General: Alert but appears mildly confused, NAD otherwise.  
HEENT: PERRLA, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  
Abdomen: Soft, mild suprapubic tenderness, no rebound, no guarding.  
Genitourinary: No CVA tenderness, bladder palpable? none.  
Extremities: Warm, no edema, pulses 2+ bilat.  
Skin: No rashes, no lesions.  
Neurologic: AOx3, mild confusion, no focal deficits.  

LABS & IMAGING:  

CBC: WBC 14.2 K/µL, Hgb 13.1 g/dL, Hct 39.2%, Plt 312 K/µL  
BMP: Na 138, K 4.6, Cl 102, CO2 22, BUN 28, Cr 1.8 (baseline 1.5), Glucose 212 mg/dL  
CRP: 12.4 mg/dL (elevated)  
Procalcitonin: 0.68 ng/mL  
Urinalysis: Leukocyte esterase +++, nitrites +, WBC 45/hpf, RBC 5/hpf, bacteria many  
Urine culture: pending (sent)  
Blood cultures: x2 pending  
Chest X‑ray: No infiltrates, clear lung fields.  
Renal US (performed 07/17/3059): No hydronephrosis, mild cortical thinning consistent with CKD.  

IMPRESSION / PLAN:  
1. Acute uncomplicated cystitis progressing to urosepsis in setting of recent urologic instrumentation.  
   • Continue IV ceftriaxone 1 g q24h; reassess after 48 h, pending cultures.  
   • Add IV fluids NS bolus 1 L then maintenance to target MAP >65.  
   • Monitor urine output Q4h, consider Foley if output <0.5 mL/kg/h.  
   • Consult Urology for possible repeat imaging if no clinical improvement.  

2. Diabetes mellitus, hyperglycemia on admission.  
   • Start insulin sliding scale qac, target glucose 140‑180 mg/dL.  
   • Hold metformin while AKI/CKD concerns persist.  

3. Chronic kidney disease stage 3.  
   • Avoid nephrotoxic agents, adjust ceftriaxone dose if needed (creatinine clearance ~45).  
   • Monitor daily BMP, urine output.  

4. Hypertension, currently controlled.  
   • Continue lisinopril; hold if K >5.5 or Cr rises >0.5 from baseline.  

5. BPH – continue tamsulosin.  

6. Sepsis bundle: blood cultures obtained, lactate 1.2 mmol/L, source control pending.  

7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily (adjust for Cr).  

8. Diet: NPO initially, advance to clear liquids when afebrile, then regular renal diet.  

9. Code status: Full Code (Presumed).  

10. Disposition: Admit to Med‑Surg floor, telemetry for cardiac monitoring given tachycardia and sepsis.  

Signature:  
Dr. Maya L. Ortega, MD  
Hospitalist Attending  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (49, 49, 22577729310, 22577729310, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 01/31/3072 12:39  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  
Resident: Dr. Milo Grant, MD  

Patient: Samuel L. Kline  
DOB: 04/12/3035  
MRN: 84276109  
PCP: Dr. Lena Ortiz, MD  

Chief Complaint: Redness, swelling, and drainage from left femoral central line site  

History of Present Illness:  
58yo M with h/o ESRD on hemodialysis (AVF left arm), CKD‑5, HTN, DM2 (A1c 8.7%), CAD s/p PCI 3065, and recent admission for urosepsis now p/w erythema, warmth, and purulent drainage from his tunneled femoral dialysis catheter placed 3 weeks ago. Patient reports that 2 days ago he noticed increasing redness extending ~4 cm around the exit site, mild pain on movement, and a yellow‑green discharge that is foul smelling. He denies fevers, chills, or rigors but notes low‑grade temp at home (max 100.2°F). He has been dialyzing via the line daily; last session yesterday was uneventful. He tried to clean the site with sterile wipes, but drainage persisted and increased. He presented to the ED after his dialysis nurse noted the change and called EMS. In the ED he was afebrile, HR 102, BP 138/84, RR 20, SpO2 96% RA. Labs showed WBC 14.2 K with left shift, CRP 12 mg/dL. Blood cultures drawn from catheter and peripheral line grew MRSA (preliminary). He was started on vancomycin 1 g IV q12h and line lock with heparin. He was transferred to floor for line removal and further management.  

Past Medical History:  
• End‑stage renal disease – dialysis dependent (AVF left arm)  
• Hypertension – diagnosed 3048, on lisinopril 20 mg daily  
• Type 2 diabetes mellitus – on insulin glargine 30 U qHS, metformin 500 mg BID (held on admission)  
• Coronary artery disease – PCI 3065, on aspirin 81 mg daily, clopidogrel 75 mg daily  
• Hyperlipidemia – rosuvastatin 10 mg nightly  

Past Surgical History:  
• AVF creation – left arm, 3060  
• Right knee arthroscopy – 3052  

Family History:  
Father – HTN, died MI at 68  
Mother – DM2, alive 92  
Sister – breast CA, in remission  

Social History:  
Tobacco – never smoker  
Alcohol – occasional wine, 1‑2 drinks/week  
Illicit drugs – none  
Living situation – lives alone in assisted living facility, receives home health nursing for dialysis  
Employment – retired electrician  

Review of Systems:  
Constitutional – negative for fever, chills, weight loss.  
HEENT – no sore throat, sinus pain.  
Cardiovascular – no chest pain, palpitations.  
Respiratory – no cough, dyspnea.  
GI – N/V/D negative.  
GU – no dysuria, flank pain.  
Musculoskeletal – mild left thigh discomfort at line site.  
Skin – erythema, drainage as described.  
Neuro – no headache, dizziness.  
Psych – mood stable, no depression.  

Prior to Admission Medications:  
Aspirin 81 mg PO daily  
Clopidogrel 75 mg PO daily  
Lisinopril 20 mg PO daily  
Rosuvastatin 10 mg PO nightly  
Insulin glargine 30 U SC qHS  
Metformin 500 mg PO BID (held)  
Epoetin alfa 4000 U SC weekly (dialysis)  
Calcium acetate 1330 mg PO TID with meals  

Allergies:  
Penicillin – rash (hives)  

Physical Examination:  
Vital Signs: Temp 37.8 °C (100.0 °F), HR 104, RR 20, BP 140/86, SpO2 96% RA, Weight 78 kg (172 lb)  

General: Alert, oriented x3, appears mildly uncomfortable, NAD otherwise.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: Supple, no JVD, no lymphadenopathy.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Left femoral tunneled dialysis catheter exit site with erythema ~4 cm, induration, purulent yellow‑green drainage, no fluctuance. No peripheral edema.  

Skin: Warm, no other rashes.  

Neuro: Grossly non‑focal, strength 5/5 in all extremities, sensation intact.  

Labs (most recent):  
CBC: WBC 14.2 K, Hgb 10.1 g/dL, Hct 30.5 %, Plt 210 K  
BMP: Na 138, K 4.6, Cl 102, CO2 22, BUN 48, Cr 9.2 (baseline 9.0), Glucose 162 mg/dL  
CRP: 12 mg/dL (ref <0.5)  
Procalcitonin: 0.8 ng/mL (ref <0.1)  
Blood cultures: MRSA (prelim) from catheter and peripheral line  
Urine culture: no growth  

Imaging:  
Chest X‑ray – no infiltrates.  
Ultrasound of left thigh – no abscess collection, soft tissue edema noted.  

Assessment and Plan:  
58yo M with ESRD on femoral tunneled dialysis catheter now with line‑associated infection (MRSA) – likely catheter‑related bloodstream infection (CRBSI) with local cellulitis.  

1. Infectious: Continue vancomycin 1 g IV q12h (adjust per trough), add cefazolin 2 g IV q8h for gram‑positive coverage pending sensitivities. Remove left femoral catheter today, place new right internal jugular tunneled catheter under US guidance. Obtain line tip culture.  
2. Hemodialysis: Continue scheduled HD via AVF; coordinate with dialysis team for temporary catheter use.  
3. Anemia: Continue epoetin alfa, monitor Hgb; consider transfusion if <7 g/dL or symptomatic.  
4. Diabetes: Restart insulin glargine at 30 U qHS; add correctional sliding scale insulin per protocol. Hold metformin (renal).  
5. Hypertension: Continue lisinopril; monitor BP, hold if AKI worsens.  
6. Cardiology: Continue aspirin, clopidogrel; hold if bleeding risk increases.  
7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily (unless contraindicated).  
8. Nutrition: Renal diet, protein 1.2 g/kg, fluid restriction 1 L/day.  
9. Disposition: Admit to telemetry floor for monitoring, line removal, and IV antibiotics. Anticipate discharge to skilled nursing facility with outpatient dialysis once infection cleared.  

Code Status: Full Code (Presumed)  

Attending: Dr. Evelyn Hartwell, MD  
Resident: Dr. Milo Grant, MD  
Pager: 842‑555‑0198');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (50, 50, 88544154944, 88544154944, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'HOSPITALIST ADMISSION HISTORY AND PHYSICAL  
05/19/3093 22:29  

Patient: Samuel K. Whitaker  
DOB: 02/14/3065 (28 y/o)  
MRN: 00457893  
PCP: Dr. Lila Monroe, MD  

CHIEF COMPLAINT:  
Fever, night sweats, progressive dyspnea x10 days, non‑productive cough, weight loss.

HISTORY OF PRESENT ILLNESS:  
Samuel Whitaker is a 28‑year‑old male with uncontrolled HIV/AIDS (diagnosed 2005, last CD4 78 cells/µL, VL 1.2 × 10⁶ copies/mL) who presents with 10‑day history of low‑grade fevers (T max 38.9 °C), drenching night sweats, worsening dyspnea on exertion, dry cough, and a 7‑kg weight loss. He reports increasing fatigue, occasional pleuritic chest discomfort, and new onset mild headache. He admits to poor adherence to his antiretroviral regimen (efavirenz/tenofovir/emtricitabine) over the past 3 months and has not taken his TMP‑SMX prophylaxis during that time. He was evaluated at an outside urgent care 5 days ago, given a course of azithromycin for presumed “bronchitis,” but symptoms progressed. He was transferred to our ED by EMS after a syncopal episode at home; EMS noted O₂ sat 86 % on room air, HR 118, RR 28. In the ED he was placed on 2 L NC, started on high‑flow O₂, and a bronchoscopy with BAL was performed (pending). CXR showed diffuse bilateral interstitial infiltrates. He was given a dose of IV methylprednisolone 125 mg and TMP‑SMX 15 mg/kg q6h (IV) pending diagnosis. He denies chest pain radiating to arm, orthopnea, PND, leg swelling, dysuria, or recent travel. No known sick contacts. He lives in a group home for adults with HIV; reports occasional marijuana use, denies alcohol or other illicit drugs.  

ED COURSE:  
Vitals on arrival: T 38.4 °C, HR 122, BP 108/64, RR 30, SpO₂ 84 % on RA → 94 % on 4 L NC. Labs: WBC 12.3 K (neut 84 %), Hgb 10.8, Plt 210 K, Na 138, K 4.5, Cl 102, CO₂ 22, BUN 14, Cr 0.9, Glu 112, LDH 420 U/L, β‑D‑glucan 420 pg/mL (↑). ABG on 4 L NC: pH 7.46, pCO₂ 32, pO₂ 68, HCO₃⁻ 23. CD4 count returned 78, VL 1.2 × 10⁶. CXR: bilateral diffuse ground‑glass opacities. CT chest: diffuse interstitial infiltrates without focal consolidation.  

MEDICAL & SURGICAL HX:  

Past Medical History:  
• HIV infection (uncontrolled)  
• Chronic hepatitis C (treated, SVR)  
• Prior PCP pneumonia (2019)  
• Depression (on sertraline)  

Past Surgical History:  
• Appendectomy – 3072  

Family HX:  
Mother – HTN, alive 62 y; Father – MI at 55 y (deceased); Sibling – healthy.  

Social HX:  
Marital status: Single, lives in group home.  
Tobacco: Never smoker.  
Alcohol: None.  
Illicit drugs: Marijuana occasional, no IV use.  
Employment: Unemployed, receives disability benefits.  
Sexual activity: Heterosexual, inconsistent condom use, multiple partners in past year.  

REVIEW OF SYSTEMS:  
Constitutional: +fever, +night sweats, +weight loss, −chills.  
HEENT: −sore throat, −visual changes.  
Neck: −lymphadenopathy.  
Respiratory: +dyspnea, +dry cough, −hemoptysis.  
Cardiovascular: −chest pain, −palpitations.  
GI: −nausea, −vomiting, −diarrhea.  
GU: −dysuria, −frequency.  
Skin: −rash, −lesions.  
Neuro: −headache (mild), −confusion.  
Psych: +depression, −suicidal ideation.  

PRIOR TO ADMISSION MEDICATIONS:  
efavirenz 600 mg PO daily (non‑adherent)  
tenofovir alafenamide 25 mg PO daily (non‑adherent)  
emtricitabine 200 mg PO daily (non‑adherent)  
sertraline 100 mg PO daily  
TMP‑SMX DS 800/160 mg PO BID (not taken)  

Allergies: No known drug allergies.

PHYSICAL EXAMINATION:  
Temperature: 38.4 °C  
Heart Rate: 118 bpm  
Respiratory Rate: 30/min  
Blood Pressure: 108/64 mmHg  
SpO₂: 94 % on 4 L NC  

General: Alert, appears cachectic, mild distress from dyspnea.  
HEENT: Normocephalic, mucous membranes dry, oropharynx clear, no thrush.  
Neck: Supple, no JVD, no cervical LAD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Diffuse fine crackles bilaterally, decreased breath sounds at bases, no wheezes.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: No edema, no clubbing, peripheral pulses 2+ bilaterally.  
Skin: Thin, pallor, no rashes, no lesions.  
Neurologic: AO×3, CN II‑XII grossly intact, no focal deficits.  

LABS & RESULTS (most recent):  

CBC: WBC 12.3 K, Hgb 10.8 g/dL, Hct 33 %, Plt 210 K.  
BMP: Na 138, K 4.5, Cl 102, CO₂ 22, BUN 14, Cr 0.9, Glu 112.  
Liver panel: AST 34, ALT 28, ALP 78, Total bili 0.8.  
CD4 count: 78 cells/µL.  
HIV VL: 1.2 × 10⁶ copies/mL.  
β‑D‑glucan: 420 pg/mL (↑).  
LDH: 420 U/L (↑).  
ABG (room air): pH 7.46, pCO₂ 32, pO₂ 68, HCO₃⁻ 23.  
CXR: Bilateral diffuse ground‑glass opacities.  
CT chest: Diffuse interstitial infiltrates, no PE.  
BAL (pending): pending PCP PCR, fungal stains.  
EKG: Sinus tachycardia, HR 118, QTc 420 ms, no ST‑T changes.  

IMPRESSION / PLAN:  
1. PCP pneumonia (probable) in setting of uncontrolled HIV/AIDS (CD4 < 100).  
   • Start IV TMP‑SMX 15 mg/kg q6h (adjust for renal function).  
   • Adjunctive steroids: methylprednisolone 40 mg IV q12h × 5 days then taper.  
   • Obtain BAL results; if negative, consider alternative opportunistic pathogens (CMV, fungal).  

2. HIV/AIDS – uncontrolled, non‑adherent ART.  
   • Restart ART after 48 h of TMP‑SMX, using dolutegravir 50 mg PO daily + tenofovir alafenamide/emtricitabine 25/200 mg PO daily (once tolerated).  
   • Counsel on adherence, arrange social work and case management for medication assistance.  

3. Respiratory support.  
   • Continue high‑flow nasal cannula as needed to maintain SpO₂ ≥ 94 %.  
   • Monitor ABG q8h, consider ICU transfer if worsening.  

4. DVT prophylaxis.  
   • SQ enoxaparin 40 mg SC daily (adjust for renal).  

5. Isolation.  
   • Airborne + contact precautions until PCP ruled out; continue droplet precautions.  

6. Code status: Full Code (Presumed).  

7. Disposition: Admit to Medicine Service, low‑risk telemetry, anticipate 7‑10 day course of TMP‑SMX with step‑down to oral when clinically stable.  

8. Follow‑up labs: CBC, BMP, CD4, VL q48 h, β‑D‑glucan q72 h, repeat CXR day 3.  

9. Social/psych: Psychiatry consult for depression, substance use counseling, arrange outpatient HIV clinic follow‑up.  

10. Nutrition: Diet – regular, high‑protein, consider oral supplements.  

Prepared by: Nathaniel R. Hayes, MD  
Hospitalist, Pager # 67890  
05/19/3093 22:45');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (51, 51, 55082209061, 55082209061, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
04/09/3096 12:15  

Patient: Marcus L. Whitaker  
DOB: 02/14/3068 (28 y/o)  
PCP: Dr. Elaine R. Voss, MD  

Chief Complaint: Progressive dyspnea, orthopnea, lower extremity edema  

History of Present Illness:  
28yo M with h/o HFrEF (EF 32% on echo 03/3096), CAD s/p PCI to RCA 02/3095, HTN, CKD stage 3 (baseline Cr 1.4), and recent admission for decompensated HF 12/3095 p/w SOB, now presents to ED with 5‑day history of worsening dyspnea on exertion, 2‑night orthopnea, 1‑L PND, and 2+ pitting edema to mid‑calves. He reports that he “just can’t catch his breath” after climbing a single flight of stairs, and has been sleeping propped up on three pillows. Denies chest pain, palpitations, fever, cough, or recent viral prodrome. He missed his furosemide dose on day 3 of his prior discharge because he ran out of meds and was “too busy”. He has been drinking 2‑3 beers nightly, no tobacco, occasional marijuana. He tried over‑the‑counter diuretics (furosemide 20 mg PO) at home with minimal relief. No recent travel.  

ED Course:  
Vitals on arrival: T 37.2 °C, HR 112, RR 24, BP 138/78, SpO2 92% RA, weight 102 kg (225 lb) (up 5 kg since last discharge). Labs: BNP 1120 pg/mL, Cr 1.6, BUN 28, Na 138, K 4.9, Hgb 13.2, WBC 9.1, LFTs WNL. CXR: bilateral interstitial edema, small pleural effusions. Echo (03/3096): LV EF 32%, global hypokinesis, mild MR, RV normal. Received 40 mg IV furosemide bolus, 1 L NS, O2 2 L NC → SpO2 96%.  

He was admitted to the cardiology service for acute on chronic systolic HF exacerbation, likely precipitated by medication non‑adherence and dietary sodium excess.  

Past Medical History:  
- Heart Failure, systolic, EF 32% (diagnosed 01/3094)  
- Coronary Artery Disease, s/p PCI to RCA 02/3095  
- Hypertension, controlled on lisinopril  
- Chronic Kidney Disease stage 3 (baseline Cr 1.4)  
- Hyperlipidemia  

Past Surgical History:  
- PCI with drug‑eluting stent, RCA 02/3095  
- Appendectomy 12/3075  

Family History:  
- Father: HTN, MI at 55  
- Mother: DM2, CKD  
- Sister: Healthy  

Social History:  
Marital Status: Single, lives alone in an apartment.  
Employment: Software engineer, works from home, sedentary.  
Tobacco: Never.  
Alcohol: 2‑3 beers nightly, no binge.  
Illicit drugs: Occasionally marijuana, no IV use.  
Diet: “I try to eat healthy but I love pizza.”  
Exercise: Minimal, walks to fridge.  

Review of Systems:  
Constitutional: +fatigue, +weight gain 5 lb, -fever, -chills.  
Cardiovascular: +dyspnea on exertion, +orthopnea, +PND, -chest pain, -palpitations.  
Respiratory: +shortness of breath, -cough, -hemoptysis.  
GI: -nausea, -vomiting, -diarrhea.  
GU: -dysuria, -frequency.  
Neuro: -headache, -dizziness.  
Psych: -depression, -anxiety.  

Prior to Admission Medications:  
Medication                Sig  
Lisinopril 20 mg PO daily  
Metoprolol succinate 100 mg PO daily  
Furosemide 40 mg PO BID (missed doses last week)  
Spironolactone 25 mg PO daily  
Atorvastatin 40 mg PO nightly  
Aspirin 81 mg PO daily  
Carvedilol 12.5 mg PO BID (started 06/3095)  

Allergies: No known drug allergies.  

Physical Examination:  
Vital Signs: T 37.2 °C, HR 112, RR 24, BP 138/78, SpO2 92% RA, Weight 102 kg.  
General: Alert, NAD, appears volume overloaded.  
HEENT: Normocephalic, mucous membranes moist.  
Neck: JVD present, no thyromegaly.  
Cardiovascular: PMI displaced laterally, S1 S2 normal, S3 present, no murmurs.  
Respiratory: Bilateral basilar crackles, decreased breath sounds at bases, no wheezes.  
Abdomen: Soft, non‑tender, mild hepatomegaly, no ascites.  
Extremities: 2+ pitting edema to mid‑calves, warm, pulses 2+ bilaterally.  
Skin: No rashes, cool peripheries.  
Neuro: AOx3, grossly non‑focal.  

Recent Labs:  
CBC: WBC 9.1 K/µL, Hgb 13.2 g/dL, Plt 215 K/µL  
BMP: Na 138 mmol/L, K 4.9 mmol/L, Cl 103 mmol/L, CO2 24 mmol/L, BUN 28 mg/dL, Cr 1.6 mg/dL, Glu 112 mg/dL  
Cardiac Markers: Troponin I <0.01 ng/mL  
BNP: 1120 pg/mL  
Liver Panel: WNL  
ABG (room air): pH 7.36, pCO2 38, pO2 68, HCO3‑ 22  

Assessment/Plan:  
28yo M with HFrEF (EF 32%) s/p recent PCI, now presents with acute on chronic decompensated systolic HF likely secondary to diuretic non‑adherence and high‑salt intake.  

- Diuresis: Continue IV furosemide 40 mg q6h PRN, add metolazone 5 mg PO daily.  
- Guideline‑directed medical therapy: Optimize GDMT – uptitrate carvedilol to 25 mg BID as tolerated, switch lisinopril to sacubitril/valsartan 24/26 mg BID after washout, continue spironolactone.  
- Renal monitoring: Daily BMP, hold ACEI/ARB if Cr >2.0 or K >5.5.  
- Fluid restriction: 1.5 L/day, sodium <2 g/day.  
- Education: Reinforce medication adherence, provide pillbox, arrange home health nursing for daily weights.  
- Consults: Cardiology for GDMT titration, Pharmacy for medication reconciliation, Nutrition for low‑sodium diet.  
- Imaging: Repeat CXR in 48 h, bedside echo if clinical status worsens.  
- VTE prophylaxis: SQ enoxaparin 40 mg SC daily.  
- DVT prophylaxis: Sequential compression devices.  
- Code Status: Full Code (Presumed).  
- Disposition: Admit to telemetry floor, anticipate LOS 4‑5 days, reassess for possible discharge with outpatient HF clinic follow‑up.  

Signature:  
Dr. Nathaniel K. Rhodes, MD  
Hospitalist, Example Medical Center  
Pager 8421  

"A portion of this record may have been created with voice recognition software. Occasionally wrong word or sound‑alike substitutions may have occurred; please review for accuracy."');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (52, 52, 50342540620, 50342540620, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 05/05/3066  
Time: 08:50  

Patient: Marcus L. Whitaker  
DOB: 02/14/3028  
MRN: 98765432  
PCP: Dr. Elaine V. Ramos, MD  

Chief Complaint: Fever, progressive dyspnea, and productive cough with purulent sputum  

History of Present Illness:  
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 215,000), chronic HCV (treated), COPD (GOLD III), and prior PCP pneumonia presents w/ 7‑day hx of worsening dyspnea, fever up to 102.4°F, night sweats, and a productive cough now yellow‑green sputum. Pt reports that 3 days ago he was seen at an outside urgent care where a CXR was read as “possible infiltrate” and he was given azithro 500 mg PO daily x3 days – no improvement. Since then he has had increasing SOB at rest, orthopnea, and a new pleuritic chest pain left lower chest. Denies chest pressure, palpitations, or leg swelling. Pt admits to missing several doses of his ART (Bictegravir/Emtricitabine/Tenofovir) over the past month due to “feeling too sick to swallow pills.” He also reports recent binge drinking (≈6 beers daily) and occasional crack cocaine use (last use 2 days ago). He lives alone in a low‑income housing complex, works part‑time as a handyman, and has limited social support. He was brought by EMS after a syncopal episode at home; EMS noted HR 112, RR 28, SpO2 86% on RA, BP 98/58. In the ED he received 2 L NS, O2 4 L NC (Sat 94%). Labs showed leukocytosis 15.2 K, lactate 2.1, creatinine 1.4 (baseline 1.0), and ABG with pH 7.32, pCO2 48, HCO3‑ 24. CXR: left lower lobe consolidation with right mid‑lung infiltrates. CT chest pending. Pt was placed on telemetry and admitted for severe community‑acquired pneumonia, possible sepsis, and HIV non‑adherence.  

Past Medical History:  
• HIV/AIDS – diagnosed 2008, non‑adherent, last CD4 78 (05/01/3066)  
• Chronic Hepatitis C – SVR achieved 2025  
• COPD – GOLD III, on tiotropium/olodaterol  
• Hypertension – controlled on lisinopril  
• GERD – on omeprazole  
• Prior PCP pneumonia – 2022  

Past Surgical History:  
• Appendectomy – 2030, Laparoscopic  
• Right inguinal hernia repair – 2045, Open  

Family History:  
Father: HTN, died MI 2055  
Mother: Alive, HTN, DM2  
Sister: Alive, HIV+, on ART, well controlled  

Social History:  
Tobacco: Smokes 1 pack/day for 30 yr, currently 0.5 pack/day  
Alcohol: Daily, 6 beers, occasional binge  
Illicit Drugs: Crack cocaine, last use 2 d ago; IV heroin – denied  
Sexual: Heterosexual, multiple partners, inconsistent condom use  
Housing: Low‑income apartment, lives alone  
Employment: Handyman, part‑time  

Review of Systems:  
Constitutional: Fever, chills, night sweats, weight loss ~5 lb past 2 wks.  
HEENT: Sore throat, no visual changes.  
Respiratory: Dyspnea at rest, productive cough, pleuritic chest pain L side.  
Cardiovascular: No chest pressure, palpitations, orthopnea.  
GI: Nausea, no vomiting, mild abdominal discomfort.  
GU: No dysuria, no flank pain.  
Musculoskeletal: Generalized myalgias, no joint swelling.  
Neurologic: Light‑headedness, syncopal episode, no focal deficits.  
Psychiatric: Anxiety, depressive symptoms, reports “feeling hopeless.”  
Skin: No rashes, no lesions.  

Prior to Admission Medications:  
Bictegravir/Emtricitabine/Tenofovir 50 mg/200 mg/245 mg PO daily – missed doses past 2 wks  
Lisinopril 20 mg PO daily  
Tiotropium/Olodaterol inhaler 2 puffs BID  
Omeprazole 20 mg PO daily  
Albuterol inhaler PRN q4h PRN wheeze  
Azithromycin 500 mg PO daily – completed 3 days (outside)  
Acetaminophen 650 mg PO q6h PRN fever  

Allergies: NKDA  

Physical Examination:  
Vital Signs: Temp 101.9 °F, HR 108, RR 26, BP 100/60, SpO2 92% on 4 L NC, Weight 78 kg (172 lb)  
General: Appears ill, diaphoretic, in mild respiratory distress, oriented x3  
HEENT: Normocephalic, oropharynx erythematous, no exudates, pupils 3 mm reactive  
Neck: Supple, no JVD, no cervical LAD  
Cardiovascular: Regular rate, tachycardic, S1 S2 normal, no murmurs, rubs, gallops  
Respiratory: Diminished breath sounds L lower lobe, crackles +, scattered rhonchi bilaterally, increased work of breathing  
Abdomen: Soft, non‑tender, normoactive bowel sounds  
Extremities: Warm, no edema, no clubbing, peripheral pulses 2+  
Skin: No rashes, track marks absent  
Neuro: Alert, CN II‑XII grossly intact, no focal deficits  

Laboratory Data (most recent):  
CBC: WBC 15.2 K, Hgb 12.1 g/dL, Hct 36 %, Plt 210 K  
BMP: Na 138, K 4.6, Cl 102, CO2 24, BUN 22, Cr 1.4, Glu 112  
Liver Panel: AST 48, ALT 52, ALP 110, Total Bili 0.8  
HIV Labs: CD4 78 (05/01/3066), HIV‑1 VL 215,000 copies/mL  
ABG (room air): pH 7.32, pCO2 48, pO2 58, HCO3‑ 24, SaO2 89%  
Lactate: 2.1 mmol/L  
CRP: 12 mg/dL  
Procalcitonin: 0.8 ng/mL  
Blood Cultures: x2 pending  
Sputum Gram stain: many PMNs, Gram‑negative rods seen  
CXR: LLL consolidation, R mid‑lung infiltrates, no effusion  
CT Chest (pending): to evaluate for cavitation, PE  

Assessment and Plan:  
58yo M with uncontrolled HIV/AIDS (CD4 <100, VL >200k) presenting with severe community‑acquired pneumonia, possible sepsis, and acute respiratory failure on background of COPD and recent ART non‑adherence.  

1. Pneumonia – likely bacterial (Gram‑neg rods) + possible opportunistic (PJP less likely given productive sputum). Start IV cefepime 2 g q8h + azithromycin 500 mg IV daily. Add TMP‑SMX 15 mg/kg IV q6h for PJP coverage pending bronchoscopy. Continue O2 titrated to >94%, consider HFNC if worsening.  

2. HIV – CD4 78, VL high. Restart ART on day 3 after cultures negative for drug‑drug interactions; plan to resume bictegravir/emtricitabine/tenofovir once renal function stable. Consult ID for opportunistic infection prophylaxis (TMP‑SMX, azithro for MAC).  

3. Sepsis – lactate 2.1, MAP >65 with fluids; continue 30 mL/kg NS bolus x2, monitor urine output, start norepinephrine infusion if MAP <65 after fluids.  

4. COPD – continue tiotropium/olodaterol, add IV methylprednisolone 40 mg q12h for acute exacerbation.  

5. Hypertension – hold lisinopril for now (AKI risk).  

6. Substance use – screen urine tox, arrange social work consult for addiction counseling, consider nicotine replacement.  

7. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  

8. Nutrition – diet regular, high protein, monitor intake.  

9. Monitoring – telemetry, q4 vitals, daily labs, repeat CXR in 48 h, sputum culture results.  

10. Disposition – Admit to medicine floor with step‑down telemetry; consider ICU transfer if respiratory failure progresses.  

Code Status: Full Code (Presumed)  

Attending: Dr. Samuel K. Ortega, MD  
Pager: 22457');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (53, 53, 87629439609, 87629439609, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
09/22/3079 08:54  

Patient: Evelyn Marlowe  
DOB: 04/13/3015  
MRN: 98765432  
PCP: Dr. Harold Finch, MD  

Chief Complaint: Progressive malaise, weight loss, and generalized weakness  

History of Present Illness:  
58yo F with h/o HTN, CKD stage 3 (baseline Cr 1.6), COPD (GOLD B), and remote colon CA s/p resection (2019) p/w 3‑mo history of worsening fatigue, anorexia, and 12‑lb unintentional weight loss. Denies fever, chills, night sweats, cough, dyspnea at rest, chest pain, abdominal pain, N/V/D, or change in bowel habits. She reports “just feeling like I’m getting older” and has been unable to finish a full meal for >4 weeks. Home BP meds (lisinopril 20 mg daily) and inhaler (tiotropium) taken as prescribed. Two weeks ago she was seen at an outside urgent care for mild dehydration; received 1 L NS and was told to increase oral fluids. Since then she has had intermittent dizziness on standing, but no syncope. No recent travel, sick contacts, or new meds. She was admitted from home after her daughter noted progressive decline and called EMS; vitals on arrival: T 36.8 °C, HR 96, RR 18, BP 118/72, SpO2 96% RA.  

Past Medical History:  
• Hypertension – diagnosed 2008  
• Chronic kidney disease stage 3 – baseline Cr 1.6 mg/dL  
• COPD – former smoker, 30‑pack‑yr, quit 2015  
• Colon adenocarcinoma – right hemicolectomy 2019, currently in remission  
• Osteopenia – on calcium/vit D  

Past Surgical History:  
Procedure Laterality Date  
• RIGHT HEMICOLECTOMY – 06/12/2019  
• LEFT TOTAL KNEE ARTHROPLASTY – 03/05/2025  

Family History:  
Father – HTN, died MI age 68  
Mother – DM2, alive 92  
Sister – breast CA, in remission  

Social History:  
Marital status: Widowed  
Living situation: Lives alone, daughter visits daily  
Tobacco: Never smoker (former smoker, quit)  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Employment: Retired school teacher  

Medications Prior to Admission:  
Medication Sig  
lisinopril 20 mg PO daily  
amlodipine 5 mg PO daily  
tiotropium inhaler 18 mcg inhalation daily  
furosemide 20 mg PO daily PRN edema  
calcitriol 0.25 mcg PO daily  
vitamin D3 1000 IU PO daily  

Allergies:  
No known drug allergies (NKDA)  

Review of Systems:  
Constitutional: +fatigue, +weight loss, -fever, -chills  
HEENT: -vision change, -sore throat, -nasal congestion  
Cardiovascular: -chest pain, -palpitations, -edema (except occasional mild ankle swelling)  
Respiratory: -cough, -dyspnea at rest, mild exertional dyspnea  
GI: -nausea, -vomiting, -diarrhea, -abdominal pain, -change in stool caliber  
GU: -dysuria, -hematuria, -frequency unchanged  
Musculoskeletal: -myalgias, -joint pain (except post‑knee arthroplasty)  
Neurologic: -dizziness on standing, -syncope, -headache, -weakness (generalized)  
Psychiatric: -depression, -anxiety  
Skin: -rashes, -lesions  

Physical Examination:  
Vital Signs: T 36.8 °C, HR 96, RR 18, BP 118/72, SpO2 96% RA, Weight 132 lb (59.9 kg), Height 5''4" (162 cm), BMI 24.9  

General: Alert, oriented x3, appears thin, mild frailty, NAD  
HEENT: Normocephalic, atraumatic, PERRLA, mucous membranes dry, no oropharyngeal erythema  
Neck: Supple, no JVD, no thyromegaly  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops  
Respiratory: Clear to auscultation bilaterally, mild decreased breath sounds at bases, no wheezes or rales  
Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly  
Extremities: No clubbing, cyanosis, or edema; mild bilateral ankle puffiness on standing  
Skin: Turgor slightly decreased, no rashes, bruises, or lesions  
Neuro: Grossly non‑focal, strength 4/5 diffusely, sensation intact, gait slow but steady  

Labs (drawn 09/22/3079):  
CBC: WBC 7.2 K/µL, Hgb 11.2 g/dL, Hct 34%, Plt 210 K/µL  
BMP: Na 138 mmol/L, K 4.8 mmol/L, Cl 102 mmol/L, CO2 23 mmol/L, BUN 22 mg/dL, Cr 1.8 mg/dL (eGFR ~38 mL/min/1.73 m²), Glucose 112 mg/dL  
LFTs: AST 22 U/L, ALT 18 U/L, ALP 78 U/L, Total Bili 0.6 mg/dL  
TSH: 2.1 µIU/mL (ref 0.4‑4.0)  
CRP: 4.2 mg/L (elevated)  
Vitamin B12: 312 pg/mL (low‑normal)  

Imaging:  
Chest X‑ray (09/22/3079): Mild hyperinflation consistent with COPD, no infiltrates, cardiac silhouette normal size.  
Abdominal US (09/22/3079): Kidneys mildly echogenic, no hydronephrosis, liver normal, no ascites.  

Assessment and Plan:  
58yo F with multimorbidity (HTN, CKD‑3, COPD, remote colon CA) presenting with 3‑mo progressive malaise, anorexia, and 12‑lb weight loss, no fever or infectious source identified. Differential includes:  
1. Chronic disease‑related cachexia / malnutrition  
2. Early uremic symptoms from CKD progression  
3. Unrecognized malignancy recurrence (colon CA surveillance) – low suspicion but will obtain tumor markers (CEA) and schedule CT abdomen/pelvis.  
4. Depression / psychosocial decline – screen PHQ‑9.  

Plan:  
- Admit to Med‑Surg floor, telemetry for BP monitoring.  
- Fluid management: 1 L NS bolus then maintenance D5½ with KCl as needed, monitor intake/output.  
- Nutrition: Consult Dietetics for high‑calorie oral supplement, consider NG tube if intake <50% of needs by day 3.  
- Labs: Repeat BMP q24h, CBC q48h, CRP q48h, urine analysis, urine protein/creatinine ratio.  
- Oncology: Order CEA, CA‑19‑9, schedule CT chest/abdomen/pelvis w/ contrast within 48 h.  
- Nephrology consult for CKD progression and medication adjustment (hold lisinopril if Cr >2.0 or K >5.5).  
- Pulmonology: Continue tiotropium, consider adding low‑dose inhaled corticosteroid if dyspnea worsens.  
- Cardiology: Continue lisinopril 20 mg daily, amlodipine 5 mg daily; monitor BP q4h.  
- Psychiatry: PHQ‑9 today, consider social work for home support.  
- DVT prophylaxis: SQ enoxaparin 40 mg daily (adjust for Cr).  
- GI prophylaxis: PPI (pantoprazole 40 mg daily) given steroid‑free but for stress ulcer prophylaxis.  
- Code Status: Full Code (Presumed).  
- Disposition: Anticipate 4‑5 day stay pending work‑up; will reassess for discharge planning with PT/OT and home health.  

Signature:  
Dr. Selene K. Alvarez, MD  
Hospitalist Attending  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (54, 54, 82216014707, 82216014707, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Alex J. Mercer  
DOB: 02/14/3045  
MRN: 98765432  
PCP: Dr. Lila Hart, MD  

Date of Admission: 10/05/3079 09:02  
Location: MED01 – General Medicine Floor  
Attending Provider: Dr. Samuel K. Vance, MD  

Chief Complaint: Right forearm pain, swelling, fever  

History of Present Illness:  
58yo M with h/o IVDU (heroin, 3‑yr), chronic HCV (RNA+, untreated), COPD (GOLD 2), and prior MSSA cellulitis p/w recurrent abscesses, now presents w/ 3‑day hx of worsening right forearm pain, erythema, and swelling after recent “shoot‑up” in that arm. Pt reports injecting “speedball” (heroin + cocaine) into the antecubital fossa 2 days ago, noted increasing pain, low‑grade fever (T max 38.6 °C) and chills. Yesterday he noticed purulent drainage from a small opening over the volar forearm. Denies SOB, chest pain, cough, N/V/D. Pt states he has been using a shared needle, no recent medical care, last seen PCP 6 mo ago. He tried OTC ibuprofen with minimal relief. In the ED he was febrile 38.9 °C, HR 112, BP 118/72, RR 22, SpO₂ 96% RA. Labs showed WBC 15.2 K with left shift, CRP 12 mg/dL. Blood cultures drawn, bedside US showed a 3 cm hypoechoic collection. He was given 1 L NS, IV vancomycin 1 g bolus, and ceftriaxone 2 g. He was admitted for IV antibiotics, possible incision & drainage, and ID evaluation.

Past Medical History:  
- Chronic hepatitis C virus infection (RNA+, untreated)  
- Chronic obstructive pulmonary disease (GOLD 2)  
- Prior MSSA cellulitis (2025)  
- Hypertension (controlled)  

Past Surgical History:  
- Right forearm incision & drainage (2026)  

Family History:  
Father: HTN, died MI at 62  
Mother: Alive, DM2, CKD stage 3  
Siblings: None known  

Social History:  
Tobacco: Smokes 1 pack/day for 30 yr, currently 0.5 ppd (reduced)  
Alcohol: Social, 1‑2 drinks/week  
Illicit Drugs: Active IVDU (heroin, cocaine) – daily, last use 2 days ago, shares needles, lives in transitional housing, no stable employment.  
Sexual Activity: Heterosexual, multiple partners, inconsistent condom use.  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue.  
HEENT: Negative for sore throat, sinus pain.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Mild dyspnea on exertion, chronic cough, no wheeze.  
GI: Negative for N/V/D, normal appetite.  
GU: Negative for dysuria, hematuria.  
Musculoskeletal: Positive for right forearm pain, swelling, erythema, drainage.  
Skin: No other rashes or lesions.  
Neuro: Negative for headache, dizziness.  
Psych: Reports anxiety about housing, depression symptoms.  

Prior to Admission Medications:  
- Lisinopril 10 mg PO daily  
- Albuterol inhaler 90 mcg PRN q4‑6h PRN  
- Fluticasone propionate 250 mcg DPI 1 puff BID  
- Acetaminophen 650 mg PO q6h PRN pain  

Allergies:  
No known drug allergies (NKDA).  

Physical Examination:  
Vital Signs: T 38.7 °C, HR 110, RR 22, BP 116/70, SpO₂ 96% RA, Weight 82 kg (180 lb).  
General: Alert, appears mildly ill, in mild distress due to forearm pain.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.  
Respiratory: Clear to auscultation bilaterally, mild expiratory wheeze.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: Right forearm – erythematous, warm, 8 × 6 cm area of induration with central fluctuance and purulent drainage; limited range of motion due to pain. No cellulitis elsewhere. No edema.  
Skin: No petechiae, no Janeway lesions.  
Neuro: AO×3, grossly non‑focal.  

Data/Results:  

CBC:  
WBC 15.2 K (Neut 84%, Lymph 10%)  
Hgb 13.1 g/dL  
Hct 39%  
Plt 312 K  

BMP:  
Na 138 mmol/L  
K 4.3 mmol/L  
Cl 102 mmol/L  
CO₂ 24 mmol/L  
BUN 14 mg/dL  
Cr 0.9 mg/dL  
Glucose 112 mg/dL  

CRP: 12 mg/dL (elevated)  
Procalcitonin: 0.8 ng/mL  

Blood Cultures: 2/2 sets pending.  

Wound Culture: Sent for aerobic/anaerobic, MRSA PCR.  

Imaging:  
Bedside US right forearm – 3 cm hypoechoic collection consistent with abscess.  
Chest X‑ray – No infiltrates.  

Assessment and Plan:  
58yo M with active IVDU, chronic HCV, and new right forearm abscess with systemic signs of infection (fever, leukocytosis). Likely MSSA/MRSA skin/soft‑tissue infection, possible bacteremia.  

1. IV Antibiotics: Vancomycin 15 mg/kg q12h (target trough 15‑20 µg/mL) + Ceftriaxone 2 g q24h. Adjust based on cultures.  
2. Surgical: Consult General Surgery for bedside I&D of forearm abscess; if not feasible, OR drainage tomorrow morning.  
3. ID Consult: For guidance on antimicrobial duration, HCV evaluation, and harm‑reduction counseling.  
4. Pain Management: Acetaminophen 650 mg PO q6h PRN, consider IV morphine PRN for breakthrough pain.  
5. VTE Prophylaxis: SQ enoxaparin 40 mg SC daily.  
6. DVT/PE prophylaxis: Encourage early ambulation as tolerated.  
7. Substance Use: Initiate MAT – buprenorphine‑naloxone 4‑2 mg SL daily, arrange addiction medicine consult, provide harm‑reduction supplies (clean needles, safe injection education).  
8. Hepatitis C: Order HCV RNA quantitative, genotype, and discuss direct‑acting antiviral eligibility once infection controlled.  
9. Disposition: Admit to General Medicine floor, telemetry not required unless arrhythmia develops.  
10. Labs: CBC, BMP, CRP q48h, repeat blood cultures q24h until negative.  

Code Status: Full Code (Presumed)  

Prepared by: Dr. Samuel K. Vance, MD  
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (55, 55, 40643573055, 40643573055, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Marcus L. Whitaker  
DOB: 02/14/3015  
MRN: 98765432  
PCP: Dr. Eleanor Vance, MD  

Date of Admission: 11/29/3059  
Time: 15:38  
Location: MED01  
Attending Provider: Dr. Samuel K. Rhodes, MD  

Chief Complaint: Fever, dyspnea, and progressive weakness  

History of Present Illness:  
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2 × 10⁶ copies), chronic HCV (treated, SVR), CKD‑3b, and HTN presents from outside ED after 5‑day prodrome of low‑grade fevers, night sweats, non‑productive cough, and worsening dyspnea on exertion. Pt reports that 2 weeks ago he was seen at community clinic for “flu‑like” symptoms, given OTC benzonatate and ibuprofen, but symptoms progressed. He now notes new diffuse myalgias, anorexia, and a 6‑kg weight loss over the past month. He denies chest pain, palpitations, orthopnea, PND, or leg swelling. He reports occasional “buzzing” in his head and blurred vision for the past 3 days. He was brought by EMS after a syncopal episode at home; EMS noted HR 112, BP 94/58, RR 24, SpO₂ 88% on RA, and gave 2 L NS with modest improvement. In the ED, labs showed leukocytosis (WBC 14.2, neutrophil 84%), creatinine 2.1 mg/dL (baseline 1.8), lactate 3.1 mmol/L, and a CXR with diffuse interstitial infiltrates. Blood cultures drawn, started on cefepime, azithro, and IV fluids. Pt was placed on HFNC 30 L/min, FiO₂ 0.45, with SpO₂ now 94%. He is now admitted for further work‑up of possible opportunistic infection (PJP vs CMV vs TB) and for management of HIV‑related complications.  

Past Medical History:  
• HIV infection, diagnosed 2002, non‑adherent to ART (last meds 3 months ago)  
• Chronic hepatitis C, genotype 1a, treated 2025, SVR achieved  
• Chronic kidney disease stage 3b (baseline Cr 1.8)  
• Hypertension  
• Hyperlipidemia  
• Remote TB exposure (negative PPD 2020)  

Past Surgical History:  
• Appendectomy – 2008 – Laparoscopic  
• Right inguinal hernia repair – 2015 – Open  

Family History:  
Father – died 2070 of MI at 68  
Mother – alive, HTN, DM2  
Sister – alive, HIV+, on ART, well controlled  

Social History:  
• Tobacco: Smoked 1 pack/day from age 18 to 45, quit 2020  
• Alcohol: Social, 1‑2 drinks/week  
• Illicit drugs: No current use, prior occasional cocaine (last use 2018)  
• Sexual: Heterosexual, multiple partners, inconsistent condom use, last HIV test 2022  
• Housing: Lives alone in subsidized apartment, receives SSI  
• Employment: Unemployed, receives disability benefits  

Allergies:  
No known drug allergies (NKDA)  

Medications Prior to Admission:  
• Tenofovir/Emtricitabine/DTG 300/200/50 mg PO daily – non‑adherent, last dose 3 mo ago  
• Lisinopril 20 mg PO daily  
• Atorvastatin 40 mg PO nightly  
• Furosemide 20 mg PO daily  
• Acetaminophen 650 mg PO q6h PRN for fever  

Review of Systems:  
Constitutional: Fever, chills, night sweats, 6 kg weight loss, fatigue – positive; no recent travel.  
HEENT: Headache, blurred vision – positive; no sore throat, no nasal congestion.  
Cardiovascular: No chest pain, palpitations, orthopnea – negative.  
Respiratory: Dyspnea on exertion, non‑productive cough – positive; no wheezes reported.  
Gastrointestinal: Nausea, mild abdominal discomfort – negative for vomiting/diarrhea.  
Genitourinary: No dysuria, no flank pain.  
Musculoskeletal: Myalgias diffuse – positive; no joint swelling.  
Neurologic: Syncope episode, “buzzing” sensation – positive; no focal deficits.  
Dermatologic: No rash, no lesions.  
Psychiatric: Anxiety about health, depressive mood – noted.  

Physical Examination:  
Vital Signs (on floor, 15:45): Temp 38.2 °C (100.8 °F), HR 108 bpm, RR 22 /min, BP 102/60 mmHg, SpO₂ 94% on HFNC 30 L/0.45, Weight 78 kg (172 lb).  

General: Alert, oriented x3, appears mildly ill, in no acute distress, using accessory muscles minimally.  

HEENT: PERRLA, EOMI, sclera non‑icteric, oral mucosa moist, no thrush noted.  

Neck: Supple, no JVD, no lymphadenopathy.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Bilateral diffuse crackles, more prominent at bases, no wheezes, no pleural rub.  

Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly appreciated.  

Extremities: No edema, pulses 2+ bilaterally, no clubbing.  

Skin: No rashes, no lesions, warm, dry.  

Neurologic: Grossly non‑focal, strength 5/5 UE/LE, sensation intact, gait stable.  

Psych: Mood anxious, affect appropriate.  

Laboratory Data (most recent):  
CBC: WBC 14.2 K/µL, Hgb 11.2 g/dL, Hct 34 %, Plt 210 K/µL  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO₂ 22 mmol/L, BUN 28 mg/dL, Cr 2.1 mg/dL, Glucose 112 mg/dL  
Liver Panel: AST 48 U/L, ALT 52 U/L, ALP 112 U/L, Total Bili 0.8 mg/dL  
CD4 Count: 78 cells/µL (down from 112 3 mo ago)  
HIV Viral Load: 1.2 × 10⁶ copies/mL (up from 4.5 × 10⁴)  
Lactate: 3.1 mmol/L  
CRP: 12 mg/dL  
Procalcitonin: 0.45 ng/mL  

Microbiology:  
Blood cultures x2 – pending  
Sputum (induced) – sent for GMS stain, fungal culture, PCR panel  
Urine antigen – Legionella negative, Pneumocystis PCR pending  

Imaging:  
Chest X‑ray (11/29/3059): Bilateral diffuse interstitial infiltrates, no focal consolidation.  
CT Chest w/ contrast (ordered): Pending – to evaluate for ground‑glass opacities vs nodules.  

ECG: Sinus tachycardia 108 bpm, no ischemic changes.  

Assessment and Plan:  
58yo M with uncontrolled HIV/AIDS (CD4 78, VL 1.2 M), CKD‑3b, HTN, presenting with fever, dyspnea, and diffuse interstitial infiltrates – concern for opportunistic pneumonia (PJP vs CMV vs TB) and possible sepsis.  

1. Pneumocystis jirovecii pneumonia – start high‑dose TMP‑SMX 15 mg/kg (based on ideal body weight) IV q6h plus adjunctive prednisone 40 mg PO daily. Hold if renal function worsens; monitor Cr q12h.  

2. Empiric broad‑spectrum antibiotics – continue cefepime 2 g IV q8h and azithromycin 500 mg IV daily pending cultures.  

3. Antiretroviral therapy – re‑initiate once hemodynamically stable; start bictegravir/emtricitabine/tenofovir alafenamide 50/200/25 mg PO daily on day 3, after reviewing renal dosing.  

4. CMV pneumonitis – send plasma CMV PCR; if >10,000 IU/mL, consider ganciclovir 5 mg/kg IV q12h.  

5. TB – obtain Quantiferon‑Gold; keep airborne precautions until AFB smears negative.  

6. Renal protection – adjust furosemide to 10 mg PO daily, hold nephrotoxic agents, maintain euvolemia.  

7. Supportive care – continue HFNC, titrate FiO₂ to keep SpO₂ >92%; consider prone positioning if worsening.  

8. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  

9. Nutrition – NPO initially, advance to clear liquids when stable, then low‑residue diet.  

10. Consults: Infectious Diseases (for opportunistic infection guidance), Nephrology (CKD management), Pharmacy (ART dosing).  

Disposition: Admit to intermediate‑care unit, telemetry for arrhythmia monitoring, isolation (contact + droplet + airborne).  

Code Status: Full Code (Presumed).  

Follow‑up labs: CBC, BMP, CD4, VL q48h; repeat CXR q72h; monitor lactate and CRP daily.  

Prepared by: Dr. Samuel K. Rhodes, MD  
Pager: 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (56, 56, 97572935027, 97572935027, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

07/28/3064 03:12

PATIENT: Michael Hartwell
DOB: 02/14/3025
MRN: 98765432
PCP: Linda S. Greene, MD
ATTENDING: Samuel K. Ortiz, MD
LOCATION: CARDIO01
SERVICE: Hospital Medicine – Cardiology

CHIEF COMPLAINT: SOB, PND, LE edema

HISTORY OF PRESENT ILLNESS:
58yo M with h/o HTN, HLD, HFpEF (EF 45% on echo 06/15/3064), CKD‑3 (baseline Cr 1.4), DM2 (A1c 8.1%) and recent ADMIT 07/20/3064 for decompensated HF presents today with 3‑day history of progressive dyspnea on exertion, orthopnea to 2 pillows, paroxysmal nocturnal dyspnea x2 nights, and 2+ pitting edema to mid‑calf bilaterally. He reports 4‑5 L of water intake per day, recent NSAID use for knee pain (ibuprofen 400 mg TID for 5 days). Denies chest pain, palpitations, fever, cough, hemoptysis, syncope. He was discharged from outside hospital on oral furosemide 40 mg daily and carvedilol 12.5 mg BID, but stopped furosemide on day 2 because “felt light‑headed”. Since then weight gain ~5 lb, SOB worsened. He came to ED after wife noted increasing swelling and shortness of breath while climbing stairs. In ED vitals: HR 112, RR 22, BP 138/78, SpO2 92% RA, Temp 36.8 °C. Labs: BNP 1120 pg/mL, Cr 1.6, K 4.9. CXR: bilateral interstitial edema, small pleural effusions. Received IV furosemide 40 mg push, then 20 mg q6h, with modest diuresis. He was transferred to our floor for continued diuresis and optimization of GDMT.

PAST MEDICAL HISTORY:
• Hypertension – diagnosed 2012
• Hyperlipidemia – diagnosed 2015
• Heart failure with preserved EF – diagnosed 2028
• Type 2 diabetes mellitus – diagnosed 2025
• Chronic kidney disease stage 3 – diagnosed 2030
• Osteoarthritis – knee

PAST SURGICAL HISTORY:
• Laparoscopic cholecystectomy – 04/12/3040
• Right knee arthroscopy – 09/08/3055

FAMILY HISTORY:
Father – HTN, MI at 68
Mother – DM2, CKD
Brother – alive, no known chronic illness

SOCIAL HISTORY:
Marital status: Married
Occupation: Retired electrician
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives with spouse in single‑family home, owns a dog
Functional status: Independent ADLs, limited by dyspnea

REVIEW OF SYSTEMS:
Constitutional: Negative for fever, chills, weight loss.
HEENT: No visual changes, hearing intact.
Cardiovascular: Positive for dyspnea on exertion, orthopnea, PND; negative for chest pain, palpitations.
Respiratory: Positive for SOB, mild cough non‑productive; negative for wheeze, hemoptysis.
GI: Nausea absent, appetite decreased.
GU: No dysuria, no polyuria.
Musculoskeletal: Knee pain, uses OTC ibuprofen.
Neurologic: No headache, dizziness, syncope.
Psychiatric: Mood stable, no depression/anxiety.

PRIOR TO ADMISSION MEDICATIONS:
Medication – Sig
lisinopril 20 mg PO daily
atorvastatin 40 mg PO nightly
metformin 1000 mg PO BID
glipizide 5 mg PO daily
carvedilol 12.5 mg PO BID
furosemide 40 mg PO daily (held 2 days ago)
aspirin 81 mg PO daily
vitamin D3 2000 IU PO daily

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 36.9 °C (98.4 °F)
Heart Rate: 108 bpm
Respiratory Rate: 20/min
Blood Pressure: 136/76 mmHg
SpO2: 93% on RA
Weight: 215 lb (97.5 kg) – up 5 lb since discharge
General: Alert, NAD, appears his stated age, mild respiratory distress.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: No JVD, supple.
Cardiovascular: Regular rate, S1 S2 normal, S3 present, no murmurs, no rubs.
Respiratory: Bilateral basilar crackles 2‑3/6, decreased breath sounds at bases, no wheezes.
Abdomen: Soft, non‑tender, no hepatosplenomegaly.
Extremities: 2+ pitting edema to mid‑calf bilaterally, warm, pulses 2+.
Skin: No rashes, intact.
Neuro: AOx3, grossly non‑focal.

LABS AND IMAGING:
CBC: WBC 7.8 K/µL, Hgb 13.2 g/dL, Plt 210 K/µL
BMP: Na 138, K 5.1, Cl 102, CO2 22, BUN 28, Cr 1.6, Glucose 152
BNP: 1120 pg/mL
Troponin I: 0.02 ng/mL (reference <0.04)
Mg 2.0 mg/dL, Phos 3.2 mg/dL
CXR: Cardiomegaly, interstitial edema, small bilateral pleural effusions.
ECHO (06/15/3064): EF 45%, LV concentric hypertrophy, LA enlargement, mild MR, TR mild.
ECG: Sinus tachycardia, left axis deviation, no acute ischemia.

ASSESSMENT:
1. Acute decompensated heart failure, likely volume overload secondary to diuretic non‑adherence and NSAID use.
2. CKD stage 3 – stable but creatinine trending upward with diuresis.
3. Hypertension – currently controlled.
4. Type 2 diabetes mellitus – mild hyperglycemia.
5. Osteoarthritis – knee pain.

PLAN:
- IV furosemide 40 mg IV push now, then 20 mg IV q6h; monitor urine output, weight, electrolytes q12h.
- Add metolazone 5 mg PO daily to augment diuresis.
- Hold NSAIDs; advise acetaminophen for pain.
- Continue carvedilol 12.5 mg BID, monitor HR/BP.
- Continue lisinopril 20 mg daily; hold if K >5.5 or Cr >2.0.
- Start low‑dose spironolactone 25 mg PO daily (if K <5.0 after diuresis).
- Diabetes: Continue metformin, hold glipizide if fasting glucose <80; check fingerstick qac.
- Fluid restriction 1.5 L/day, sodium restriction <2 g/day.
- Daily weights, strict I&O.
- Electrolyte panel q12h; replace K as needed (IV KCl 20 mEq PRN).
- Consider ultrafiltration if diuresis inadequate after 48 h.
- DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
- Stress ulcer prophylaxis: PRN pantoprazole 40 mg PO daily.
- Diet: Cardiac, low‑sodium, fluid‑restricted.
- Activity: Ambulate with assistance as tolerated, monitor orthostasis.
- Code status: Full code (presumed).
- Disposition: Anticipate 3‑5 day stay, reassess for discharge planning, home health nursing, possible addition of home IV diuretic program.

FOLLOW‑UP:
- Cardiology consult today for GDMT optimization.
- Nephrology consult if creatinine rises >0.3 mg/dL.
- Endocrinology consult if glucose >200 mg/dL persistently.
- Discharge meds reconciliation and patient education on daily weights, low‑sodium diet, medication adherence.

Prepared by: Samuel K. Ortiz, MD
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (57, 57, 61645398223, 61645398223, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient:  Michael Doe  
DOB: 03/14/3045  
MRN: 98765432  
PCP: Dr. Eleanor Sample, MD  

Date of Admission: 12/26/3080  
Time: 15:14  
Location: MED01  
Attending Provider: Dr. Victor Realname, MD  

Chief Complaint: Dysuria, suprapubic pain, and fever  

History of Present Illness:  
58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), DM2 (A1c 8.9%), recent prostatitis p/w N/V/D, R flank pain, now presents w/ 2‑day hx of worsening dysuria, urgency, suprapubic pressure, and chills. Patient reports that 5 days ago he was discharged from an outside hospital where he was treated for acute prostatitis with IV ceftriaxone 2 g q24h x 3 days then switched to PO levofloxacin 750 mg daily; he completed 5 of 7 planned days before symptoms recurred. Since discharge he has been drinking plenty of water, but urine has become cloudy and foul smelling. He notes new onset of mild left flank tenderness, low‑grade fever at home ( Tmax 101.3°F ), and occasional nausea without vomiting. Denies hematuria, recent sexual activity, or new catheterization. He tried OTC phenazopyridine with minimal relief. No recent travel.  

Past Medical History:  
• Hypertension – diagnosed 3048, on lisinopril 20 mg daily  
• Type 2 Diabetes Mellitus – on metformin 1000 mg BID, insulin glargine 30 U qHS  
• Chronic Kidney Disease stage 3 – baseline eGFR ~45 mL/min/1.73 m²  
• Acute prostatitis – treated 12/20/3080, incomplete course  

Past Surgical History:  
• Appendectomy – 3035, laparoscopic  
• Right knee arthroscopy – 3042  

Family History:  
Father – HTN, died MI age 68  
Mother – DM2, alive 85  
Sister – healthy  

Social History:  
Marital Status: Married  
Occupation: IT consultant, works from home  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Sexual activity: Monogamous, condom use inconsistent  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue; negative for weight loss.  
HEENT: Negative.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea.  
Gastrointestinal: Positive for nausea, no vomiting, no diarrhea.  
Genitourinary: Positive for dysuria, urgency, suprapubic pain, left flank tenderness; negative for hematuria, incontinence.  
Musculoskeletal: Negative.  
Neurologic: Negative.  
Psychiatric: Negative.  

Prior to Admission Medications:  
Medication Sig  
lisinopril 20 mg PO daily  
metformin 1000 mg PO BID  
insulin glargine 30 U SC qHS  
levothyroxine 25 µg PO daily (for hypothyroidism)  
omeprazole 20 mg PO daily  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs: Temp 38.6 °C (101.5 °F), HR 102, RR 18, BP 138/84, SpO₂ 97% RA, Weight 92 kg (202 lb)  
General: Alert, mildly uncomfortable, NAD otherwise.  
HEENT: Normocephalic, oropharynx erythematous, no lesions.  
Neck: Supple, no lymphadenopathy.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, mild suprapubic tenderness to palpation, no rebound, no guarding.  
Genitourinary: CVA tenderness left flank, no suprapubic mass.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neuro: AOx3, grossly non‑focal.  

Recent Labs:  
CBC: WBC 14.2 ×10⁹/L (neutrophils 84%), Hgb 13.1 g/dL, Plt 312 ×10⁹/L  
BMP: Na 138 mmol/L, K 4.5 mmol/L, Cl 102 mmol/L, CO₂ 23 mmol/L, BUN 28 mg/dL, Cr 1.8 mg/dL (baseline 1.6)  
Glucose: 212 mg/dL (random)  
CRP: 12 mg/dL (elevated)  
Urinalysis: Cloudy, pH 6.0, WBC 45/hpf, RBC 5/hpf, nitrites positive, leukocyte esterase +3, bacteria numerous  
Urine culture: Pending (specimen collected on admission)  
Blood cultures: 2 sets drawn, pending  

Imaging:  
Renal US (12/26/3080): No hydronephrosis, mild cortical thinning consistent with CKD, no stones.  

Assessment and Plan:  
1. Acute uncomplicated urinary tract infection (likely ascending from prostatitis) with left flank tenderness in a patient with CKD3.  
   • Start IV ceftriaxone 1 g q24h (adjusted for Cr) pending culture sensitivities.  
   • Switch to PO levofloxacin 750 mg daily after 48 h if clinically improving and culture susceptible.  
   • Encourage oral hydration, monitor input/output.  
   • Re‑check BMP and Cr q24h.  

2. Chronic kidney disease stage 3, baseline Cr 1.6, now 1.8.  
   • Hold NSAIDs, adjust meds as needed, avoid nephrotoxic contrast.  

3. Hypertension, currently 138/84 on lisinopril.  
   • Continue lisinopril, add low‑dose thiazide if BP >140/90 after infection resolves.  

4. Diabetes mellitus type 2, hyperglycemia 212 mg/dL.  
   • Continue basal insulin glargine, add correctional rapid‑acting insulin sliding scale qPRN.  

5. Prostatitis – recent incomplete course.  
   • Ensure full 10‑day fluoroquinolone course after discharge, consider urology consult if symptoms persist.  

6. DVT prophylaxis: SQ low‑molecular‑weight heparin 40 mg SC daily (adjust for Cr).  

7. Diet: Renal diet low sodium, moderate protein.  

8. Activity: Ambulate as tolerated, bathroom safety.  

9. Code Status: Full Code (Presumed).  

10. Disposition: Admit to General Medicine floor, telemetry not required, anticipate 3‑4 day stay pending response to antibiotics and culture results.  

Signature:  
Victor Realname, MD  
Attending Hospitalist  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (58, 58, 89385289676, 89385289676, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'PATIENT: Marcus L. Whitaker
DOB: 02/14/3042
MRN: 98765432
PCP: Dr. Elaine V. Hart, MD

ADMIT DATE/TIME: 04/09/3070 06:05
LOCATION: MED01
ATTENDING: Dr. Samuel K. Rhodes, MD

CHIEF COMPLAINT: Right lower leg erythema, swelling, pain x3 days

HISTORY OF PRESENT ILLNESS:
58yo M with h/o T2DM (A1c 8.7%), CKD stage 3 (eGFR 45), HTN, PAD s/p fem‑pop stent 3065, and recent left foot ulcer p/w cellulitis now presents w/ acute onset RLE erythema, warmth, edema, and throbbing pain for 72 hrs. Pt reports that 4 days ago he sustained a minor abrasion while gardening, noted a small puncture but no bleeding. Overnight the area became increasingly red, now ~12 cm diameter, with ill‑defined margins, streaking up the calf. He denies fevers, chills, SOB, chest pain, dysuria. He took OTC ibuprofen 400 mg q6h with minimal relief. Pt was seen at urgent care 2 days ago, prescribed cephalexin 500 mg PO q6h, but compliance uncertain due to recent travel to his sister’s house (overnight stay, no known sick contacts). This morning he noted worsening pain, difficulty ambulating, and a low‑grade fever at home (T 100.2 °F). EMS was called by his wife; vitals on EMS arrival: T 38.3 °C, HR 112, BP 138/78, RR 22, SpO2 96% RA. Pt was transported to ED, where labs showed WBC 14.2 K, CRP 12 mg/dL, ESR 48 mm/hr. Bedside US of RLE showed subcutaneous edema, no abscess. He was given IV cefazolin 1 g q8h and admitted for IV antibiotics and monitoring for possible progression to necrotizing infection.

PAST MEDICAL HISTORY:
• Type 2 diabetes mellitus – diagnosed 3048
• Hypertension – diagnosed 3045
• Chronic kidney disease stage 3 – diagnosed 3060
• Peripheral arterial disease – s/p fem‑pop stent 3065
• Hyperlipidemia – on rosuvastatin
• GERD – on omeprazole

PAST SURGICAL HISTORY:
• Right femoral‑popliteal artery stent placement 3065
• Appendectomy 3030
• Left inguinal hernia repair 3048

FAMILY HISTORY:
Mother – HTN, died of stroke 3075
Father – CAD, MI at 62, alive
Sister – T2DM
No known hereditary cancers.

SOCIAL HISTORY:
Marital status: Married
Occupation: Retired electrician, now part‑time handyman
Tobacco: Former smoker, 10 pack‑years, quit 2025
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Own home, lives with wife, two adult children nearby
Travel: Recent overnight stay at sister’s house (no known sick contacts)

REVIEW OF SYSTEMS:
Constitutional: Positive for low‑grade fever, fatigue; negative for chills, weight loss.
HEENT: Negative for sore throat, visual changes.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
GI: Negative for nausea, vomiting, abdominal pain.
GU: Negative for dysuria, hematuria.
Musculoskeletal: Positive for right lower leg pain, swelling; negative for joint effusion.
Neurologic: Negative for weakness, numbness.
Skin: Positive for erythema, warmth, edema of RLE; negative for bullae, necrosis.
Psych: Negative for depression, anxiety.

PRIOR TO ADMISSION MEDICATIONS:
metformin 1000 mg PO BID
liraglutide 1.8 mg SC weekly
lisinopril 20 mg PO daily
amlodipine 10 mg PO daily
rosuvastatin 20 mg PO nightly
omeprazole 20 mg PO daily
aspirin 81 mg PO daily
insulin glargine 30 U SC qHS
acetaminophen 500 mg PO q6h PRN pain

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Vital Signs: T 38.1 °C, HR 108, RR 20, BP 136/80, SpO2 96% RA, Weight 92 kg (202 lb)

General: Alert, oriented x3, appears mildly uncomfortable, in no acute distress.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, rales.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: Right lower leg: erythema extending from mid‑calf to ankle, warm, tender to palpation, edema 2+, no fluctuance, no crepitus, no lymphangitic streaking beyond calf. Dorsalis pedis pulse 2+, posterior tibial 2+. Left lower extremity normal.
Skin: No lesions elsewhere.
Neuro: Grossly non‑focal, strength 5/5 bilaterally, sensation intact.
Psych: Cooperative, normal affect.

LABORATORY DATA (most recent):
CBC: WBC 14.2 K, Hgb 13.1 g/dL, Hct 39.5%, Plt 312 K
BMP: Na 138, K 4.6, Cl 102, CO2 24, BUN 22, Cr 1.6 (eGFR 45), Glucose 182 mg/dL
CRP: 12 mg/dL (↑)
ESR: 48 mm/hr (↑)
Lactate: 1.2 mmol/L
Procalcitonin: 0.28 ng/mL
HbA1c: 8.7% (from 3 months ago)

IMAGING:
Bedside ultrasound RLE – subcutaneous edema, no fluid collection.
X‑ray right lower leg – soft tissue swelling, no gas, no fracture.
CT lower extremity (non‑contrast) – extensive subcutaneous stranding, no abscess, no fascial thickening.

ASSESSMENT/PLAN:
58yo M with T2DM, CKD3, HTN, PAD s/p stent, now with acute cellulitis of right lower leg, likely streptococcal or staphylococcal etiology, no evidence of abscess or nec fasc, but high risk given peripheral vascular disease and CKD.

1. Cellulitis RLE – start IV cefazolin 1 g q8h (adjust for Cr 1.6). Continue for 5‑7 days, then transition to PO cephalexin to complete 10‑14 day course.
2. Diabetes – continue basal insulin glargine; add correctional sliding scale insulin (regular 4 U qSL) while on steroids (none) and infection.
3. CKD – monitor Cr, avoid nephrotoxic agents, adjust cefazolin dose.
4. Hypertension – hold lisinopril today (BP stable) to avoid hyperkalemia; resume when Cr <1.5.
5. VTE prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).
6. Wound care – daily dressing changes, monitor for progression, consider plastic surgery consult if any sign of necrosis.
7. Labs – CBC, BMP, CRP q48h, blood cultures (drawn on admission) pending.
8. Imaging – repeat US if clinical worsening.
9. Education – elevate leg, keep clean, avoid tight clothing, encourage ambulation as tolerated.
10. Disposition – admit to med‑surg floor, telemetry not required, monitor vitals q4h, reassess in 24 h.

CODE STATUS: Full Code (Presumed)

Prepared by: Dr. Samuel K. Rhodes, MD
Pager #: 22458
04/09/3070 06:20');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (59, 59, 80679713961, 80679713961, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
04/23/3085 22:37  

Patient: Evelyn Harper  
DOB: 02/14/3023  
MRN: 98765432  
PCP: Dr. Lionel Finch, MD  

CHIEF COMPLAINT: Redness, drainage, and pain at left arm PICC line site  

HISTORY OF PRESENT ILLNESS:  
62yo F with h/o CKD stage 3 (baseline Cr 1.8), HTN, T2DM (A1c 8.6% 02/3085), and recent admission for left lower extremity cellulitis (03/15/3085‑03/20/3085) now presents with 4‑day history of erythema, warmth, and purulent drainage from her peripherally inserted central catheter (PICC) in the left basilic vein. Patient reports that the line was placed during her cellulitis admission for IV vancomycin. She was discharged on oral doxycycline 100 mg BID and line was to remain in place for outpatient infusion of ertapenem. Since discharge she has noted increasing pain (8/10), swelling, and a yellow‑green ooze that stains her clothing. She denies fever, chills, rigors, shortness of breath, chest pain, or new cough. She tried to clean the site with over‑the‑counter antiseptic wipes, but drainage persists. She reports occasional low‑grade fevers at home (max 100.4 °F) but did not measure. She denies recent travel, sick contacts, or animal exposures. She has been compliant with insulin glargine 30 U nightly and metformin 500 mg BID. She reports no recent changes in diet or activity.  

ED COURSE:  
Vitals on arrival: T 38.2 °C, HR 112, BP 138/78, RR 20, SpO2 96% RA. Physical exam notable for 5 × 6 cm area of erythema with induration and purulent drainage at PICC exit site; surrounding skin warm, tender to palpation. No fluctuance or crepitus. No distal edema. Labs drawn, blood cultures obtained, line tip sent for culture. Started on IV cefazolin 2 g q8h and vancomycin loading dose pending sensitivities.  

MEDICAL & SURGICAL HISTORY:  

Past Medical History:  
• Chronic kidney disease stage 3 (diagnosed 02/3080)  
• Hypertension (diagnosed 01/3015)  
• Type 2 diabetes mellitus (diagnosed 06/3018)  
• Hyperlipidemia  
• Prior cellulitis of left lower leg (03/3085)  

Past Surgical History:  
Procedure Laterality Date  
• CHOLECYSTECTOMY – – 09/3082  
• KNEE ARTHROSCOPY – RIGHT – 07/3075  

FAMILY HISTORY:  
Problem Relation Age of Onset  
• Hypertension – Mother – 55  
• CKD – Father – 60  
• Breast cancer – Sister – 48  

SOCIAL HISTORY:  
Marital Status: Married  
Occupation: Retired schoolteacher  
Tobacco Use: Never smoker  
Alcohol Use: Social (1‑2 drinks/week)  
Illicit Drugs: Denies  
Living Situation: Lives with husband in single‑family home, owns pet cat  

REVIEW OF SYSTEMS:  
Constitutional: Positive for low‑grade fever, chills denied.  
HEENT: No sore throat, vision changes.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No dyspnea, cough.  
Gastrointestinal: Nausea denied, appetite normal.  
Genitourinary: No dysuria, frequency.  
Musculoskeletal: No new joint pain.  
Skin: Positive for erythema, drainage at PICC site; otherwise negative.  
Neurologic: No headache, dizziness.  
Psychiatric: Mood stable, no depression.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
lisinopril 20 mg PO daily  
amlodipine 5 mg PO daily  
metformin 500 mg PO BID  
insulin glargine 30 U SC nightly  
atorvastatin 40 mg PO nightly  
omeprazole 20 mg PO daily  

PHYSICAL EXAMINATION:  
Temperature: 38.2 °C (100.8 °F)  
Heart Rate: 112 bpm  
Respiratory Rate: 20/min  
Blood Pressure: 138/78 mmHg  
SpO2: 96% RA  

General: Alert, appears mildly ill, in no acute distress.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate, tachycardic, S1 S2 normal, no murmurs.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: Left arm PICC site with erythema, induration, purulent drainage; no fluctuance. No edema of lower extremities.  
Skin: Warm, no rashes elsewhere.  
Neurologic: AOx3, grossly non‑focal.  

LABS (drawn 04/23/3085):  
CBC: WBC 14.2 K/µL, Hgb 11.8 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.6, Cl 102, CO2 24, BUN 22, Cr 1.9, Glu 162  
CRP: 12.5 mg/dL (elevated)  
Procalcitonin: 0.8 ng/mL (moderately elevated)  
Blood cultures: x2 pending  
PICC tip culture: sent  

IMAGING:  
Chest X‑ray (04/23/3085): No infiltrates, cardiac silhouette normal.  
Ultrasound of left arm (04/23/3085): No abscess cavity identified, superficial soft‑tissue edema consistent with cellulitis/line infection.  

ASSESSMENT AND PLAN:  
1. PICC line–associated infection, likely cellulitis with purulent drainage.  
   • Continue IV cefazolin 2 g q8h; add vancomycin pending cultures (target trough 15‑20 µg/mL).  
   • Remove PICC line today under sterile technique; obtain peripheral cultures for future IV access.  
   • Consult Interventional Radiology for possible replacement if needed after infection cleared.  
   • Monitor vitals q4h, CBC and BMP daily.  

2. Chronic kidney disease stage 3, baseline Cr 1.8, currently 1.9 – adjust antibiotics as needed; ensure adequate hydration.  

3. Hypertension – continue lisinopril and amlodipine; BP currently controlled.  

4. Type 2 diabetes – continue metformin and insulin glargine; check finger‑stick q6h while on steroids (if added).  

5. Hyperlipidemia – continue atorvastatin.  

6. DVT prophylaxis – SQ low‑molecular‑weight heparin 40 mg SC daily.  

7. Diet – Renal diet (protein 0.8 g/kg, sodium <2 g).  

8. Activity – Ambulate as tolerated, avoid heavy lifting of left arm.  

9. Disposition – Admit to Medicine floor, telemetry not required unless arrhythmia develops.  

10. Education – Discuss line care, signs of infection, when to call.  

CODE STATUS: Full Code (Presumed)  

FOLLOW‑UP:  
• Infectious Diseases consult within 24 h.  
• Nephrology consult if Cr rises >0.5 mg/dL from baseline.  

Prepared by:  
Dr. Selene Marquez, MD  
Hospitalist  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (60, 60, 62740491806, 62740491806, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Marcus L. Rivera
DOB: 02/14/3045
MRN: 98765432
PCP: Dr. Elena V. Ortiz, MD

Date of Admission: 05/19/3079
Time of Admission: 02:40
Admitting Service: Hospital Medicine
Attending Provider: Dr. Samuel K. Whitman, MD

Chief Complaint: Fever, progressive dyspnea, non‑productive cough, oral thrush

History of Present Illness:
34yo M with h/o HIV/AIDS (diagnosed 2015, CD4 78, VL 2.5e5, non‑adherent to ART) presents w/ 10‑day hx of low‑grade fevers (T max 39.2°C), worsening dyspnea on exertion, dry cough, and new oral white plaques. Pt reports 15‑lb weight loss over past month, night sweats, and intermittent nausea. He was discharged 2 weeks ago from outside hospital after treatment for PCP pneumonia; completed 7 days of oral TMP‑SMX but stopped due to GI upset. Since discharge he has not taken any ART or prophylaxis. He notes increased shortness of breath over past 48 h, now at rest, SpO2 90% on room air. Denies chest pain, hemoptysis, recent travel, or known TB exposure. He lives in a group home, reports occasional marijuana use, no alcohol, and multiple male sexual partners with inconsistent condom use. No recent vaccinations.

Past Medical History:
• HIV infection, uncontrolled
• Prior PCP pneumonia (12/05/3079)
• Hypertension
• Chronic hepatitis C (treated, SVR achieved)
• Latent TB (treated 2025)

Past Surgical History:
• Appendectomy – Laparoscopic (2022)

Family History:
Mother – HTN, alive 68y
Father – MI at 55y (deceased)
Sister – Healthy

Social History:
Tobacco – Never smoker
Alcohol – None
Illicit drugs – Marijuana occasional
Living situation – Group home for adults with HIV
Sexual activity – MSM, multiple partners, condoms inconsistently used
Employment – Unemployed, receives disability

Review of Systems:
Constitutional: Fever, chills, night sweats, 15‑lb weight loss – positive
HEENT: Oral thrush, sore throat – positive; vision changes – negative
Respiratory: Dyspnea, dry cough – positive; wheezes – negative
Cardiovascular: Palpitations – negative; chest pain – negative
Gastrointestinal: Nausea, mild anorexia – positive; vomiting/diarrhea – negative
Genitourinary: Dysuria – negative; genital lesions – negative
Neurologic: Headache – negative; dizziness – negative
Musculoskeletal: Myalgias – negative
Skin: No rash, but oral white plaques – positive
Psychiatric: Anxiety about health – positive; depression – negative
Endocrine: Polyuria/polydipsia – negative

Prior to Admission Medications:
Medication                     Sig
Tenofovir alafenamide 25 mg    PO daily (non‑adherent)
Emtricitabine 200 mg           PO daily (non‑adherent)
Dolutegravir 50 mg             PO daily (non‑adherent)
Trimethoprim‑sulfamethoxazole 800/160 mg PO BID (stopped 5 d ago)
Fluconazole 200 mg PO daily   (started 2 d ago for thrush)
Lisinopril 10 mg PO daily      PO daily
Amlodipine 5 mg PO daily       PO daily
Allergies: No known drug allergies.

Physical Examination:
Vital Signs: Temp 38.9 °C (102 °F), HR 112 bpm, RR 24/min, BP 102/64 mmHg, SpO2 92% RA, Weight 68 kg, BMI 23.5
General: Ill‑appearing, cachectic, mild distress
HEENT: Oral cavity with white curd‑like plaques on tongue and buccal mucosa; no tonsillar erythema
Neck: Supple, no lymphadenopathy
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops
Respiratory: Bilateral diffuse crackles, worse at bases, no wheezes
Abdomen: Soft, non‑tender, normoactive bowel sounds
Extremities: Warm, no edema, no clubbing
Skin: No rashes, intact turgor
Neurologic: Alert, oriented x3, no focal deficits
Psychiatric: Anxious but cooperative

Recent Labs:
CBC: WBC 14.2 K/µL, Hgb 10.2 g/dL, Hct 30 %, Plt 210 K/µL
BMP: Na 138 mmol/L, K 4.5 mmol/L, Cl 102 mmol/L, CO2 20 mmol/L, BUN 12 mg/dL, Cr 0.9 mg/dL, Glu 112 mg/dL
LFTs: AST 48 U/L, ALT 52 U/L, ALP 110 U/L, Total bili 0.8 mg/dL
CD4 count: 78 cells/µL
HIV viral load: 2.5 × 10⁵ copies/mL
ABG (RA): pH 7.45, pCO₂ 33 mmHg, pO₂ 58 mmHg, HCO₃⁻ 24 mmol/L
Sputum PCR: Pneumocystis jirovecii positive
CXR: Diffuse bilateral interstitial infiltrates, no focal consolidation
CT Chest (without contrast): Ground‑glass opacities throughout both lungs, no PE

Assessment and Plan:
34yo M with uncontrolled HIV/AIDS (CD4 < 100, VL > 200k) presenting with PCP pneumonia, oral thrush, and possible bacterial superinfection.

1. PCP Pneumonia:
   • Start IV TMP‑SMX 15 mg/kg (based on trimethoprim component) q6h.
   • Add adjunctive prednisone 40 mg PO daily ×5 days then taper.
   • Monitor renal function, electrolytes, and CBC daily.

2. Oral Candidiasis:
   • Continue fluconazole 200 mg PO daily; consider increasing to 400 mg PO daily if no improvement in 48 h.

3. HIV Management:
   • Defer ART initiation until after 48 h of TMP‑SMX to avoid overlapping toxicities; plan to start bictegravir/emtricitabine/tenofovir alafenamide (Biktarvy) 50/200/25 mg PO daily on day 3 of admission.
   • Obtain baseline resistance panel.

4. Bacterial Superinfection (possible):
   • If fever persists >48 h or WBC rises, add cefepime 2 g IV q12h pending cultures.

5. Prophylaxis:
   • Start azithromycin 1200 mg PO once then 500 mg weekly for MAC prophylaxis (CD4 < 50).
   • Continue TMP‑SMX for PCP prophylaxis after treatment course.

6. Supportive Care:
   • Supplemental O₂ titrated to keep SpO₂ ≥ 94 % (nasal cannula 2‑4 L/min).
   • IV fluids 0.9% NS 1 L bolus then maintenance as needed.
   • DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
   • Isolation: Droplet + contact precautions.

7. Social/Disposition:
   • Social work consult for housing stability and medication assistance.
   • Case management to arrange outpatient HIV follow‑up and adherence counseling.
   • Code Status: Full Code (Presumed).

8. Labs/Imaging Follow‑up:
   • CBC, BMP, CD4, VL q48 h.
   • Repeat CXR day 3 or sooner if clinical decline.
   • Monitor ABG if O₂ requirements increase.

Plan to reassess in 24 h with attending.  

Samuel K. Whitman, MD  
Hospital Medicine Attending  
Pager: 212‑555‑0198');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (61, 61, 46856543738, 46856543738, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Hospital Admission Note  
Date of Admission: 06/20/3078 22:54  
Location: MED01 – Internal Medicine Floor  
Attending: Dr. Evelyn Hartwell, MD  
Resident: Dr. Luis Mendoza, PGY‑3  
Consults: Infectious Diseases (Dr. Carla Nguyen)  

Patient: Marcus L. Whitaker  
MRN: 00457893  
DOB: 02/14/3025 (53 y/o M)  
PCP: Dr. Samuel Ortiz, MD  

Chief Complaint: Redness, swelling, and purulent drainage from right mid‑forearm PICC line site  

History of Present Illness:  
53yo M with h/o CKD stage 3 (baseline Cr 1.8 mg/dL), HTN, DM2 (A1c 8.4%), recent admission for septic arthritis of left knee (treated 06/10‑06/15) now presents w/ 4‑day history of progressive erythema, warmth, and pain around his right mid‑forearm peripherally inserted central catheter (PICC) placed 2 weeks ago for IV antibiotics. Pt reports low‑grade fevers up to 100.8 °F, chills, and foul‑smelling yellow drainage that started 48 h ago. He notes the line dressing became damp and he had to change it himself at home; after that the site became more painful and he began to notice “little pus” oozing. Denies new trauma, recent travel, or sick contacts. He was discharged from outside hospital on 06/15 after 5 days of IV cefazolin via PICC; completed 2 days of oral amoxicillin‑clavulanate at home before presenting. He reports compliance with wound care instructions but admits occasional “slipping” of the dressing. No SOB, chest pain, abdominal pain, N/V/D.  

Review of Systems:  
Constitutional – fever, chills, fatigue.  
HEENT – no sore throat, no visual changes.  
Cardiovascular – no chest pain, palpitations.  
Respiratory – no cough, dyspnea.  
GI – N/V/D negative.  
GU – no dysuria.  
Musculoskeletal – left knee pain resolved, right forearm pain at line site.  
Skin – erythema, warmth, purulent drainage at PICC site; no other rashes.  
Neuro – no headache, no focal deficits.  

Past Medical History:  
• Chronic kidney disease stage 3 (diagnosed 04/3075)  
• Hypertension – on lisinopril 20 mg daily  
• Type 2 diabetes mellitus – on metformin 1000 mg BID, insulin glargine 30 U qHS  
• Hyperlipidemia – rosuvastatin 10 mg daily  

Past Surgical History:  
• Left knee arthroscopy (06/3075) – uncomplicated  
• PICC line insertion (right basilic vein, 06/20/3078) – current  

Family History:  
Father – HTN, MI at 62; Mother – DM2, alive 78; No known hereditary cancers.  

Social History:  
Married, lives with spouse; works as a freelance graphic designer (sedentary).  
Tobacco – never smoker.  
Alcohol – occasional wine, 1‑2 drinks/week.  
Illicit drugs – none.  
Travel – none recent.  

Allergies:  
No known drug allergies (NKDA).  

Prior to Admission Medications:  
Lisinopril 20 mg PO daily  
Metformin 1000 mg PO BID  
Insulin glargine 30 U SC qHS  
Rosuvastatin 10 mg PO nightly  
Aspirin 81 mg PO daily  

Physical Examination:  
Vital Signs (22:45): Temp 38.2 °C (100.8 °F), HR 102, RR 18, BP 138/84, SpO₂ 97% RA, Weight 92 kg (202 lb).  
General – alert, mildly uncomfortable, NAD.  
HEENT – normocephalic, atraumatic, mucous membranes moist.  
Neck – supple, no JVD.  
Cardiovascular – RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory – clear to auscultation bilaterally, no wheezes, no rales.  
Abdomen – soft, non‑tender, BS present, no hepatosplenomegaly.  
Extremities – Right forearm: 6 cm area of erythema, induration, warmth, with purulent drainage from PICC exit site; surrounding skin tender, no fluctuance. No edema elsewhere. Pulses 2+ bilaterally.  
Skin – no other lesions.  
Neuro – AO×3, grossly non‑focal.  

Laboratory Data (drawn 06/20/3078 23:10):  
CBC: WBC 14.2 ×10⁹/L (neut 84%), Hgb 13.1 g/dL, Plt 312 ×10⁹/L  
BMP: Na 138, K 4.6, Cl 102, CO₂ 23, BUN 22, Cr 2.1 mg/dL (baseline 1.8), Glucose 162 mg/dL  
CRP: 12.8 mg/dL (elevated)  
Procalcitonin: 0.9 ng/mL  
Blood cultures x2: pending  
PICC tip culture: sent for Gram stain and susceptibility  
Lactate: 1.4 mmol/L  

Imaging:  
Portable chest X‑ray – no infiltrates, lines in proper position.  
Ultrasound of right forearm – subcutaneous fluid collection 2 cm deep, no abscess cavity identified.  

Assessment and Plan:  
53yo M with recent PICC line placement now presenting with line‑associated infection (probable catheter‑related bloodstream infection, CRBSI) evidenced by local erythema, purulent drainage, leukocytosis, and elevated CRP. No definitive bacteremia yet (cultures pending).  

1. Infectious – Start empiric IV vancomycin 15 mg/kg q12h (adjust for Cr) and cefepime 2 g q8h pending sensitivities. Remove PICC line today under sterile technique; obtain tip for culture. Place new peripheral IV for antibiotics. Infectious Diseases consulted.  
2. Diabetes – Continue insulin glargine; add correctional sliding scale (regular insulin 4 U qSL for glucose >180). Monitor fingersticks q4h.  
3. Hypertension – Continue lisinopril; monitor BP.  
4. CKD – Adjust vancomycin dosing per CrCl; hold nephrotoxic agents. Monitor daily BMP.  
5. VTE prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  
6. Fluid – Maintain euvolemia; NS 75 mL/hr.  
7. Pain – Acetaminophen 650 mg PO q6h PRN; avoid NSAIDs given CKD.  
8. Wound care – Daily dressing change by nursing; monitor for progression.  
9. Labs – Repeat CBC, BMP, CRP q24h; blood cultures q12h until 2 sets negative.  
10. Disposition – Admit to telemetry floor for close monitoring of infection and renal function. Anticipate 5‑7 day IV course, then transition to oral line‑sparing regimen based on culture results.  

Code Status: Full Code (Presumed)  
Disposition: Admit to MED01, telemetry.  

Signature:  
Evelyn Hartwell, MD  
Attending Physician  
Pager 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (62, 62, 14884979831, 14884979831, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL  

06/17/3064 18:48  

Patient: Marcus L. Whitaker  
DOB: 02/14/3002  
MRN: 98765432  
PCP: Dr. Elaine V. Kline, MD  

CHIEF COMPLAINT: SOB, LEg edema  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o HFrEF (EF 32% on 06/01/3063 echo), CAD s/p PCI 2019, HTN, CKD3, DM2 (A1c 8.7% 02/3064), and recent admission for decompensated HF (04/28/3064 – 05/04/3064) p/w progressive dyspnea on exertion, orthopnea, PND, 2+ LE edema. Discharged on furosemide 40 mg PO BID, carvedilol 12.5 mg BID, lisinopril 20 mg daily, spironolactone 25 mg daily, and sacubitril/valsartan 97/103 mg BID. Since discharge, he reports worsening SOB after climbing a single flight of stairs, now needing 2 pillows, and new 1+ pitting edema to mid‑calf bilaterally. Denies chest pain, palpitations, fever, cough, or recent travel. He missed his furosemide dose on 06/15 due to “forgetting” and has been drinking 2–3 beers nightly. No recent weight loss. He presents from home via EMS after wife called for “breathing trouble.” EMS notes HR 112, RR 24, SpO2 88% RA, BP 158/92, given 40 mg IV furosemide en route with modest improvement.  

MEDICAL & SURGICAL HX:  

Past Medical History:  
• HFrEF (diagnosed 01/3062)  
• CAD s/p PCI (LAD 2019)  
• Hypertension  
• Type 2 Diabetes Mellitus  
• CKD Stage 3 (eGFR 45 mL/min)  
• Hyperlipidemia  

Past Surgical History:  
• Cholecystectomy – L – 03/3060  
• Right knee arthroscopy – 07/3061  

FAMILY HX:  
Father – MI at 62, HTN, deceased 3055  
Mother – DM2, alive 84y  
Brother – CKD, on dialysis  

SOCIAL HX:  
Marital status: Married  
Occupation: Retired electrician  
Tobacco: Never smoker  
Alcohol: 2–3 beers nightly, no binge  
Illicit drugs: Denies  
Living situation: Lives with spouse in single‑family home, owns a dog  

REVIEW OF SYSTEMS:  
Constitutional: Negative for fever, chills, weight loss.  
Cardiovascular: Positive for dyspnea on exertion, orthopnea, PND, LE edema. No chest pain.  
Respiratory: Negative for cough, wheeze, hemoptysis.  
GI: Negative for N/V, abdominal pain, melena.  
GU: Negative for dysuria, hematuria.  
Neuro: Negative for dizziness, syncope.  
Psych: Negative for depression/anxiety.  

PRIOR TO ADMISSION MEDICATIONS:  

Medication – Sig  
furosemide 40 mg PO BID  
carvedilol 12.5 mg PO BID  
lisinopril 20 mg PO daily  
spironolactone 25 mg PO daily  
sacubitril/valsartan 97/103 mg PO BID  
metformin 1000 mg PO BID  
atorvastatin 40 mg PO nightly  
aspirin 81 mg PO daily  

Allergies: NKDA  

PHYSICAL EXAMINATION:  

Vital Signs:  
Temp 36.8 °C (98.2 °F)  
HR 108 (irregularly irregular)  
RR 22  
BP 152/88  
SpO2 89% RA (improved to 94% on 2 L NC)  
Weight 112 kg (247 lb) – up 4 kg since last discharge  

General: Alert, mildly diaphoretic, in mild respiratory distress, NAD otherwise.  
HEENT: PERRLA, moist mucosa, no JVD.  
Neck: No thyromegaly, no carotid bruits.  
Cardiovascular: Irregularly irregular rhythm, S1 S2 normal, S3 present, no murmurs, no rubs.  
Respiratory: Bilateral basilar crackles up to mid‑lung fields, decreased breath sounds at bases, no wheezes.  
Abdomen: Soft, non‑tender, BS present, no hepatosplenomegaly.  
Extremities: 2+ pitting edema to mid‑calf bilaterally, warm, pulses 2+ bilat.  
Skin: No rashes, intact.  
Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.  

LABS (most recent):  

CBC: WBC 9.2 K/µL, Hgb 13.1 g/dL, Hct 39.2%, Plt 210 K/µL  
BMP: Na 138, K 5.1, Cl 102, CO2 22, BUN 28, Cr 1.6 (eGFR 45), Glu 162  
BNP: 1120 pg/mL (↑)  
Troponin I: 0.04 ng/mL (baseline)  
LFTs: AST 28, ALT 32, Alk Phos 78, Bilirubin total 0.8  
ABG on 2 L NC: pH 7.36, pCO2 38, pO2 68, HCO3 22  

EKG: A‑fib with RVR, ventricular rate ~110, no acute ST changes.  

Chest X‑ray: Cardiomegaly, pulmonary venous congestion, bilateral interstitial edema, small pleural effusions.  

IMPRESSION / PLAN:  

1. ACUTE DECOMPENSATED HFrEF, A‑fib with RVR – likely precipitated by missed diuretic dose & volume overload.  
   • Continue IV furosemide 40 mg q6h PRN, titrate to net negative 1‑1.5 L/24h.  
   • Add IV metoprolol 2.5 mg q15min x2 then infusion 2 mg/hr, transition to oral carvedilol when HR <100.  
   • Initiate IV amiodarone loading 150 mg over 10 min then 1 mg/min for 6 h, then 0.5 mg/min; consider cardioversion if unstable.  
   • Continue sacubitril/valsartan, hold ACE‑I while on ARNI.  
   • Monitor electrolytes q6h, replace K+ to 4.5‑5.0 mEq/L, Mg >2.0.  
   • Strict I&O, daily weights, consider ultrafiltration if diuresis inadequate.  

2. CKD Stage 3 – adjust diuretic dosing, avoid nephrotoxic agents, monitor Cr q12h.  

3. DM2 – hold metformin while AKI risk, start insulin sliding scale pending glucose control.  

4. HTN – target <130/80 once euvolemic, continue carvedilol, add hydralazine if needed.  

5. Hyperlipidemia – continue atorvastatin.  

6. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (hold if Cr <30).  

7. Diet – Low‑sodium (<2 g/day), fluid restriction 1.5 L/day.  

8. Code status – Full Code (Presumed).  

9. Consults: Cardiology (HF & A‑fib management), Nephrology (CKD optimization), Pharmacy (med reconciliation).  

10. Disposition: Admit to telemetry floor, anticipate ICU if hemodynamic instability persists.  

Prepared by:  
Dr. Nathaniel P. Rhodes, MD  
Hospitalist – Internal Medicine  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (63, 63, 24979281618, 24979281618, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Evelyn Harper
DOB: 07/14/3002
MRN: 84276109
PCP: Dr. Lionel Finch, MD

Date of Admission: 03/21/3074
Time: 00:58
Location: MED01 – General Medicine Floor
Attending Provider: Dr. Selene Marquez, MD
Admitting Intern: Dr. Omar Vance, MD
Code Status: Full Code (Presumed)

Chief Complaint: “I feel weak all the time, can’t keep any food down.”

History of Present Illness:
72yo F with h/o COPD (GOLD II), CKD‑3 (baseline Cr 1.6), anemia of chronic disease, major depressive disorder s/p SSRI therapy, and recent 12 lb weight loss over 6 weeks presents for progressive malaise, anorexia, and generalized weakness. Pt reports that 2 months ago she began feeling “run down,” with low energy, occasional light‑headedness on standing, and a loss of appetite. She has been eating <½ of meals, mostly crackers and tea, and has unintentionally lost ~12 lb (BMI now 18.2). Denies fever, chills, night sweats, cough, dyspnea at rest, chest pain, abdominal pain, N/V/D, dysuria, or recent falls. No new meds. She was seen at an urgent care 1 week ago; labs showed mild normocytic anemia (Hgb 10.2) and BUN/Cr 28/1.7; she was advised to increase oral intake and follow‑up with PCP, but symptoms worsened. She lives alone in an apartment, uses a walker for ambulation, and has limited social support. Family reports she has become “quiet” and “doesn’t get out of bed.” No recent travel, sick contacts, or known COVID‑19 exposure. No alcohol, tobacco (quit 15 yr ago), no illicit drugs.

Review of Systems:
Constitutional: +weight loss, +fatigue, -fever, -chills.
HEENT: -headache, -vision changes, -sore throat.
Cardiovascular: -chest pain, -palpitations, -edema.
Respiratory: -cough, -dyspnea at rest, -wheezes.
Gastrointestinal: +decreased appetite, -nausea, -vomiting, -diarrhea, -abdominal pain.
Genitourinary: -dysuria, -frequency, -hematuria.
Musculoskeletal: +weakness, -myalgias, -joint pain.
Neurologic: -dizziness, -syncope, -headache.
Psychiatric: +depressed mood, -SI/HI, -hallucinations.
Skin: -rashes, -lesions.
Endocrine: -polyuria, -polydipsia.
Hematologic/Lymphatic: -bleeding, -bruising.

Past Medical History:
• COPD, diagnosed 2008
• Chronic Kidney Disease stage 3 (baseline eGFR ~45)
• Anemia of chronic disease
• Major Depressive Disorder
• Hypertension
• Osteoarthritis of knees

Past Surgical History:
• Cholecystectomy – 2015
• Right total knee arthroplasty – 2022

Family History:
Mother – HTN, died of stroke @84
Father – COPD, died of MI @78
Sister – alive, HTN, DM2

Social History:
Marital Status: Widowed
Living Situation: Lives alone, walker for ambulation
Tobacco: Never smoker (quit 15 yr ago, 0 pack‑years)
Alcohol: Social, 1‑2 drinks/week
Illicit Drugs: Denies
Employment: Retired schoolteacher
Support: Daughter lives 45 mi away, visits weekly

Allergies:
No known drug allergies (NKDA)

Medications Prior to Admission:
Metoprolol succinate 50 mg PO daily
Lisinopril 20 mg PO daily
Albuterol inhaler 90 mcg PRN q4h PRN SOB
Tiotropium inhaler 18 mcg PO daily
Sertraline 100 mg PO daily
Furosemide 20 mg PO daily
Ferrous sulfate 325 mg PO daily
Vitamin D3 2000 IU PO daily
Alendronate 70 mg PO weekly

Physical Examination:
Vital Signs: T 36.7 °C (98.1 °F), HR 92 bpm, RR 18/min, BP 118/68 mmHg, SpO2 95% RA, Weight 48 kg (105.8 lb), Height 162 cm (5’4”), BMI 18.2
General: Elderly female, appears thin, mildly frail, in no acute distress, alert, oriented x3.
HEENT: Normocephalic, atraumatic, mucous membranes dry, oropharynx mildly erythematous, no exudate.
Neck: Supple, no JVD, no thyromegaly.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Bilateral breath sounds diminished at bases, mild expiratory wheezes, no crackles.
Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly.
Extremities: Warm, no edema, mild calf muscle wasting, gait unstable with walker.
Skin: Turgor decreased, dry, no rashes or lesions.
Neurologic: Alert, oriented, CN II‑XII grossly intact, strength 4/5 proximal, 5/5 distal, gait assisted.
Psych: Depressed affect, cooperative.

Recent Labs (drawn 03/20/3074):
CBC: WBC 6.8 K/µL, Hgb 9.8 g/dL, Hct 30 %, MCV 88 fL, Plt 210 K/µL
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 24 mmol/L, BUN 28 mg/dL, Cr 1.7 mg/dL, Glucose 112 mg/dL, Ca 9.1 mg/dL
eGFR: 44 mL/min/1.73 m²
LFTs: AST 22 U/L, ALT 18 U/L, ALP 78 U/L, Total bili 0.6 mg/dL
CRP: 4.2 mg/L (elevated)
TSH: 2.1 µIU/mL
Vitamin B12: 420 pg/mL
Urinalysis: Specific gravity 1.015, pH 6, no protein, no glucose, no leukocyte esterase.

Imaging:
Chest X‑ray (03/20/3074): Hyperinflated lungs, flattened diaphragms, mild bibasilar interstitial markings, no acute infiltrate.
Abdominal US (03/20/3074): Unremarkable, kidneys mildly echogenic consistent with CKD.

Assessment and Plan:
72yo F with COPD, CKD‑3, anemia of chronic disease, and major depressive disorder presenting with progressive malaise, anorexia, and failure to thrive (FTT) without fever.

1. Failure to Thrive / Malnutrition:
   - Initiate high‑calorie, high‑protein oral nutritional supplement (Boost® 1.5 Cal) qid.
   - Consult Dietetics for individualized meal plan and possible enteral feeding if intake <500 kcal/d by day 3.
   - Monitor weight daily, labs q48h (CBC, BMP, albumin).

2. Anemia of Chronic Disease:
   - Continue ferrous sulfate; re‑check iron studies in 2 weeks.
   - Consider IV iron if Hgb <9 g/dL or symptomatic.
   - Transfusion threshold Hgb <7 g/dL (or <8 g/dL with symptomatic CAD/CHF).

3. COPD:
   - Continue metoprolol, lisinopril, albuterol PRN, tiotropium.
   - Initiate nebulized ipratropium/albuterol q4h while inpatient.
   - Encourage incentive spirometry qhourly.
   - Assess need for home oxygen on discharge.

4. CKD‑3:
   - Hold nephrotoxic agents; avoid NSAIDs.
   - Adjust furosemide dose if volume overloaded.
   - Monitor electrolytes q24h.

5. Depression:
   - Continue sertraline; assess mood daily.
   - Psychiatry consult for possible augmentation (bupropion) given poor intake.

6. Fall risk / Mobility:
   - PT consult for gait training, assistive device assessment.
   - Fall precautions: bed alarm, non‑skid socks.

7. Disposition:
   - Admit to General Medicine floor, telemetry not required.
   - DVT prophylaxis: SQ low‑molecular‑weight heparin 40 mg SC daily.
   - Stress ulcer prophylaxis: Pantoprazole 40 mg PO daily.
   - Continue routine labs q48h, vitals q4h.

Patient and daughter (via phone) counseled on plan, goals of care, and expected length of stay (~5‑7 days). All orders placed.

Selene Marquez, MD
Attending Physician
Pager: 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (64, 64, 96269039595, 96269039595, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION NOTE

PATIENT: Ethan Marlowe
MRN: 98765432
DOB: 03/22/3045
AGE: 34
PCP: Dr. Lila Hart, MD
DATE OF ADMISSION: 12/14/3079
TIME: 02:04
ATTENDING: Dr. Victor Selby, MD
LOCATION: MED01
CODE STATUS: Full Code (Presumed)

CHIEF COMPLAINT:
Left foot pain, swelling, and purulent drainage.

HISTORY OF PRESENT ILLNESS:
34yo M with h/o T2DM (A1c 9.8% recent), HTN, CKD‑3, peripheral neuropathy, and prior left hallux ulcer p/w worsening left foot infection over the past 5 days. Patient reports a “small sore” that he noticed after a minor cut while gardening 7 days ago. Initially painless, but over the last 48 h he noted increasing erythema extending to the mid‑foot, foul smelling drainage, throbbing pain despite “taking ibuprofen”. He also developed low‑grade fevers (T max 38.3 °C) and chills. He went to an urgent care clinic on 12/09 where he was prescribed oral clindamycin 300 mg TID and instructed to keep the wound clean. No improvement; on 12/11 he presented to St. Orion Hospital ED. There he was febrile (T 38.9 °C), tachycardic (HR 112), BP 138/78, RR 22, SpO2 96% RA. Labs showed WBC 15.2 K, CRP 12 mg/dL. X‑ray of the left foot showed soft‑tissue swelling, no obvious fracture. He was started on IV cefazolin 1 g q8h and admitted to the orthopedic service. Orthopedic consult on 12/12 recommended MRI, which demonstrated marrow edema of the 2nd metatarsal consistent with early osteomyelitis. He was transferred to our facility for higher‑level care and possible surgical debridement. He denies recent travel, sick contacts, or new medications. No known drug allergies.

PAST MEDICAL HISTORY:
• Type 2 Diabetes Mellitus – diagnosed 2015
• Hypertension – diagnosed 2018
• Chronic Kidney Disease – stage 3 (baseline Cr 1.6 mg/dL)
• Peripheral Neuropathy – bilateral lower extremities
• Hyperlipidemia
• GERD

PAST SURGICAL HISTORY:
• Appendectomy – 2022
• Left plantar wart removal – 2026

FAMILY HISTORY:
Father – HTN, MI at 58 y
Mother – T2DM, CKD
Sibling – healthy

SOCIAL HISTORY:
Marital status: Single
Occupation: Maintenance technician (works in a warehouse)
Tobacco: Never smoker
Alcohol: Social drinker, 1‑2 beers/week
Illicit drugs: Denies
Living situation: Lives alone in an apartment, uses a cane for ambulation due to neuropathy
Sexual activity: Heterosexual, monogamous, uses condoms intermittently

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.
HEENT: Negative
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
GI: Negative for nausea, vomiting, abdominal pain.
GU: Negative for dysuria, flank pain.
Musculoskeletal: Positive for left foot pain, swelling, drainage. Negative for other joint pain.
Neurologic: Positive for peripheral numbness in feet. Negative for headache, dizziness.
Skin: Positive for ulcer with purulent drainage on left foot. Negative for rashes elsewhere.
Psych: Negative for depression, anxiety.

PRIOR TO ADMISSION MEDICATIONS:
Medication                Sig
insulin glargine 30 U SC qHS   TAKE 30 UNITS BY SUBCUTANEOUS INJECTION EVERY NIGHT
metformin 1000 mg PO BID      TAKE 1 TABLET BY MOUTH TWICE DAILY
lisinopril 20 mg PO daily      TAKE 1 TABLET BY MOUTH DAILY
atorvastatin 40 mg PO nightly  TAKE 1 TABLET BY MOUTH AT NIGHT
aspirin 81 mg PO daily         TAKE 1 TABLET BY MOUTH DAILY
omeprazole 20 mg PO daily      TAKE 1 TABLET BY MOUTH DAILY

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Vital Signs (at time of exam):
Temp 37.9 °C, HR 106, RR 20, BP 132/76, SpO2 97% RA, Pain score 7/10.

General: Alert, oriented x3, appears mildly ill, in no acute distress.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities:
  Left foot: 3 cm x 2 cm ulcer over dorsal aspect of 2nd metatarsal head, erythematous halo, foul‑smelling purulent drainage, warmth to touch, edema extending to mid‑foot. No crepitus. Pedal pulses 1+ dorsalis pedis bilaterally, cap refill <3 s.
  Right foot: No lesions, pulses 2+.
Skin: No other rashes or lesions.
Neurologic: Grossly non‑focal, decreased sensation to monofilament in both feet distal to the ankle.
Psych: Mood appropriate.

LABORATORY DATA (most recent):
CBC: WBC 15.2 K, Hgb 12.4 g/dL, Hct 37.1%, Plt 312 K.
BMP: Na 138 mmol/L, K 4.3 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 22 mg/dL, Cr 1.7 mg/dL (eGFR ~45 mL/min), Glu 212 mg/dL.
CRP: 12 mg/dL (ref <0.5)
ESR: 68 mm/hr
Lactate: 1.8 mmol/L
HbA1c (from 12/01): 9.8%
Blood cultures x2: pending
Wound culture (deep tissue): pending
MRI left foot (12/12): marrow edema of 2nd metatarsal with cortical breach suggestive of early osteomyelitis.

IMPRESSION/PLAN:
1. DIABETIC FOOT INFECTION w/ possible osteomyelitis of left 2nd metatarsal.
   • Start empiric IV antibiotics: Vancomycin 15 mg/kg q12h (adjust for Cr) + Cefepime 2 g q8h.
   • Obtain intra‑operative deep tissue cultures during debridement.
   • Orthopedic surgery consult for possible incision & drainage / partial ray resection – OR scheduled tomorrow morning.
   • Wound care team to apply moist gauze dressing, off‑load with total contact cast after surgery.
   • Tight glucose control: insulin sliding scale qHS and basal glargine titration to keep glucose 140‑180 mg/dL.
2. SEPSIS‑LEVEL 2 (SBP >90, lactate <2) – monitor vitals q1h, labs q12h, consider ICU if hemodynamic instability.
3. CKD‑3 – adjust vancomycin dosing per trough, avoid nephrotoxic agents, monitor Cr daily.
4. HTN – continue lisinopril, hold if Cr >2.0 or K >5.5.
5. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).
6. Stress ulcer prophylaxis – PO pantoprazole 40 mg daily.
7. Diet – Diabetic, cardiac: low sodium, moderate carbs, protein 1.2 g/kg.
8. Education – foot care, off‑loading, signs of worsening infection.
9. Disposition – Admit to Med‑Surg floor with telemetry for cardiac monitoring; anticipate possible step‑down to orthopedic floor post‑op.

FOLLOW‑UP:
- Labs (CBC, BMP, CRP) q12h until stable.
- Repeat wound cultures day 3.
- Orthopedic re‑eval post‑op day 1.
- Endocrinology consult for inpatient diabetes management.

Prepared by: Dr. Victor Selby, MD
Pager: 84231
02:04 AM, 12/14/3079');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (65, 65, 23644092566, 23644092566, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Michael Doe  
DOB: 02/14/2985  
MRN: 98765432  
PCP: Dr. Jane Sample, MD  

Date of Admission: 06/30/3054  
Time of Admission: 21:38  
Location: EXAMP01  
Attending Provider: Dr. Samuel Realname, MD  

Chief Complaint: Fever, dyspnea, productive cough, 15‑lb weight loss over 4 weeks  

History of Present Illness:  
69yo M with uncontrolled HIV/AIDS (CD4 78 cells/µL, VL 250 k copies/mL), chronic HCV (RNA + ), CKD‑3 (eGFR 42 mL/min), HTN, and recent PCP pneumonia p/w fever, SOB, productive cough. Patient reports that 4 weeks ago he began feeling “run down,” lost appetite, and dropped ~15 lb despite no change in diet. Two weeks ago he developed low‑grade fevers (T 38.2‑38.7 °C) and a dry cough that progressed to purulent sputum (yellow‑green). Over the past 48 h he noted worsening dyspnea on minimal exertion, orthopnea, and chills. He denies chest pain, palpitations, hemoptysis, or recent travel. He reports poor adherence to his ART regimen (tenofovir/lamivudine/dolutegravir) for the past 3 months due to homelessness and lack of pharmacy access. He also admits to intermittent IV heroin use (last use 5 days ago) and smoking 1 pack/day for 30 years. He was seen at an urgent care 2 days ago, given azithromycin 500 mg PO daily x3 days, but symptoms worsened, prompting ED presentation. In the ED he was tachypneic (RR 28), tachycardic (HR 112), febrile (T 38.9 °C), O2 sat 88 % on RA, requiring 2 L NC. Labs showed leukocytosis (WBC 14.2 ×10⁹/L, neutrophils 84 %), anemia (Hgb 9.8 g/dL), creatinine 1.8 mg/dL (baseline 1.5). CXR demonstrated bilateral diffuse interstitial infiltrates. Given CD4 <100, PJP was high on differential; bronchoscopy with BAL was ordered. He was started on IV cefepime, TMP‑SMX, and methylprednisolone 40 mg q8h. He was admitted for further work‑up and management of opportunistic infection, sepsis, and ART non‑adherence.  

Past Medical History:  
• HIV infection, diagnosed 2005 – uncontrolled, non‑adherent  
• Chronic hepatitis C infection, genotype 1a, RNA +   
• Chronic kidney disease stage 3 (eGFR 42)  
• Hypertension  
• Anemia of chronic disease  

Past Surgical History:  
• Appendectomy – 1992  

Family History:  
Father – died of MI at 62; Mother – alive, HTN; No known HIV in family.  

Social History:  
• Homeless, currently residing in a shelter  
• IV heroin use, last 5 days ago; shares needles  
• Tobacco: 1 pack/day for 30 years, currently smoking  
• Alcohol: occasional binge (≈4 drinks/week)  
• No recent travel; sexually active with multiple male partners, inconsistent condom use  

Allergies:  
No known drug allergies (NKDA)  

Review of Systems:  
Constitutional – fever, weight loss, fatigue; negative chills.  
HEENT – sore throat resolved, no oral lesions.  
Respiratory – dyspnea, productive cough, no hemoptysis.  
Cardiovascular – palpitations denied, no edema.  
Gastrointestinal – nausea, no vomiting, no diarrhea.  
Genitourinary – dysuria denied.  
Musculoskeletal – myalgias, no arthralgia.  
Neurologic – headache, no seizures.  
Psychiatric – anxiety, depressive symptoms, no SI.  
Skin – track marks on forearms, no rashes.  

Physical Examination:  
Vital Signs: T 38.6 °C, HR 110 bpm, RR 26 /min, BP 132/78 mmHg, SpO₂ 89 % on RA, Weight 78 kg (172 lb).  
General: Ill‑appearing, thin, in mild respiratory distress, oriented to person only.  
HEENT: Mucous membranes dry, oropharynx erythematous, no thrush.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Diffuse crackles bilaterally, worse at bases, decreased breath sounds, no wheezes.  
Abdomen: Soft, non‑tender, normoactive bowel sounds, no hepatosplenomegaly.  
Extremities: Warm, track marks noted bilaterally, no edema, pulses 2+ bilaterally.  
Skin: No rashes, bruising, or lesions aside from track marks.  
Neurologic: Alert but only oriented to person, pupils equal/reactive, no focal deficits.  

Recent Labs:  
CBC: WBC 14.2 ×10⁹/L, Hgb 9.8 g/dL, Hct 30 %, Plt 210 ×10⁹/L  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO₂ 22 mmol/L, BUN 28 mg/dL, Cr 1.8 mg/dL, Glu 112 mg/dL  
LFTs: AST 48 U/L, ALT 55 U/L, Alk Phos 112 U/L, Total Bili 0.8 mg/dL  
CD4 Count: 78 cells/µL (5 %); HIV Viral Load: 250,000 copies/mL  
Lactate: 2.4 mmol/L  
Procalcitonin: 0.12 ng/mL  
Arterial Blood Gas (on 2 L NC): pH 7.45, PaCO₂ 32 mmHg, PaO₂ 68 mmHg, HCO₃⁻ 23 mmol/L  

Imaging:  
Chest X‑ray (06/30/3054): Bilateral diffuse interstitial infiltrates, no focal consolidation.  
CT Chest (pending): To evaluate for PJP vs bacterial pneumonia.  

Microbiology:  
Sputum Gram stain: many neutrophils, few Gram‑negative rods.  
Blood cultures: drawn x2, pending.  
BAL (ordered): pending GMS stain, PCR for P. jirovecii, bacterial/fungal cultures.  

Assessment and Plan:  
69yo M with uncontrolled HIV/AIDS (CD4 78, VL 250k), chronic HCV, CKD‑3, now admitted for presumed opportunistic pneumonia (PJP vs bacterial) with sepsis, acute hypoxic respiratory failure, and ART non‑adherence.  

1. Pneumocystis jirovecii pneumonia: Start TMP‑SMX 15 mg/kg (based on actual weight) IV q6h + adjunctive methylprednisolone 40 mg IV q8h. Hold steroids if hyperglycemia worsens.  
2. Empiric bacterial coverage: Continue cefepime 2 g IV q8h pending cultures.  
3. ART: Defer initiation until hemodynamically stable and renal function optimized; plan to restart once CD4 >100 and no active infection, using a renal‑adjusted regimen (e.g., dolutegravir + lamivudine).  
4. HCV: Consult hepatology; consider initiating ledipasvir/sofosbuvir once renal function stable.  
5. CKD‑3: Adjust cefepime dose, monitor creatinine q24h, avoid nephrotoxic agents.  
6. Anemia: Evaluate iron studies; consider transfusion if Hgb <7 g/dL or symptomatic.  
7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily (adjust for Cr >1.5).  
8. Isolation: Airborne + contact precautions for PJP; N95 respirator for staff.  
9. Supportive care: Supplemental O₂ titrated to SpO₂ ≥ 92 % (NC, then HFNC if needed).  
10. Social work: Arrange temporary housing, substance use counseling, needle exchange referral.  
11. Labs: Daily CBC, BMP, CD4, VL; repeat ABG q12h until stable.  
12. Imaging: Repeat CXR q48h; CT chest pending.  
13. Code Status: Full Code (presumed). Discuss goals of care with patient and surrogate once clinically stable.  

Disposition: Admit to Medicine Service, telemetry floor, continue monitoring, reassess in 24 h.  

Signature:  
Dr. Samuel Realname, MD  
Attending Hospitalist  
Pager 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (66, 66, 69508600176, 69508600176, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Elliot Marlowe
DOB: 03/22/3025
MRN: 98765432
PCP: Selma Kline, MD

Date of Admission: 01/16/3067
Time: 06:12
Location: CARDIO01
Attending Provider: Dr. Harold Finch, MD

Chief Complaint: Fever, chills, night sweats, dyspnea

History of Present Illness:
42yo M with h/o IV drug use (last use 2 mo ago), chronic HCV (RNA+), prior MRSA SSTI, now p/w 3 days of intermittent high‑grade fevers (Tmax 103°F), chills, night sweats, progressive SOB on exertion, and new onset left‑sided chest discomfort. Pt reports a harsh, new systolic murmur heard yesterday while at home. Denies cough, hemoptysis, abdominal pain, N/V/D. Pt was seen at County General on 01/13/3067 for fever; blood cultures drawn (pre‑antibiotic), CXR normal, started on IV vancomycin 1 g q12h and transferred for possible endocarditis. At our facility, vitals on arrival: T 101.8°F, HR 112, BP 118/72, RR 22, SpO2 94% on RA. Pt appears ill, diaphoretic, but alert. No focal neuro deficits. Review of systems otherwise negative.

Past Medical History:
- Chronic hepatitis C (RNA+), diagnosed 2029
- IV drug use (heroin, last 2 mo)
- MRSA skin abscess 2028, surgically drained
- Hypertension (controlled)
- Depression

Past Surgical History:
- Incision & drainage of right forearm abscess 2028
- Appendectomy 3015 (lap)

Family History:
Mother alive, HTN; Father deceased (MI 3055); No known hereditary disease.

Social History:
- Homeless, lives in shelter
- Tobacco: 1 pack/day for 20 yr
- Alcohol: binge weekend use, ~6 drinks
- Illicit drugs: IV heroin, last use 2 mo ago
- No current employment
- Sexual activity: intermittent, uses condoms inconsistently

Allergies:
NKDA

Review of Systems:
Constitutional: +fever, +chills, +night sweats, -weight loss, -fatigue
HEENT: -headache, -vision changes, -sore throat
Cardiovascular: +new murmur, -chest pain (except mild left‑sided discomfort)
Respiratory: +dyspnea on exertion, -cough, -hemoptysis
GI: -N/V/D, -abdominal pain
GU: -dysuria, -hematuria
Musculoskeletal: -myalgias, -arthralgias
Skin: +track marks on antecubital fossae, -rashes
Neurologic: -dizziness, -syncope
Psych: +depression, -suicidal ideation

Prior to Admission Medications:
Medication                Sig
methadone                 30 mg PO daily
sofosbuvir/velpatasvir    1 tablet PO daily
lisinopril                10 mg PO daily
hydroxyzine               25 mg PO qHS PRN anxiety
acetaminophen             650 mg PO q6h PRN pain/fever

Physical Examination:
Vital Signs: T 101.8°F, HR 112, RR 22, BP 118/72, SpO2 94% RA, Weight 78 kg (172 lb)
General: Ill‑appearing, diaphoretic, alert, oriented x3
HEENT: Normocephalic, PERRLA, mucous membranes moist, no oral lesions
Neck: Supple, no JVD, no carotid bruits
Cardiovascular: Regular rhythm, grade 3/6 harsh systolic murmur best heard at left lower sternal border, radiates to apex, no gallops, no rubs
Respiratory: Clear to auscultation bilaterally, mild bibasilar crackles
Abdomen: Soft, non‑tender, normoactive bowel sounds
Extremities: Track marks on both antecubital fossae, no edema, pulses 2+ bilaterally
Skin: No petechiae, no Janeway lesions, no Osler nodes
Neurologic: Grossly non‑focal, strength 5/5 UE/LE, sensation intact
Psych: Mood depressed but cooperative

Recent Labs:
CBC:
WBC 14.2 K/µL (neut 82%, lymph 12%)
Hgb 12.1 g/dL
Hct 36%
Plt 210 K/µL

BMP:
Na 138 mmol/L
K 4.6 mmol/L
Cl 102 mmol/L
CO2 24 mmol/L
BUN 16 mg/dL
Cr 0.9 mg/dL
Glucose 112 mg/dL

Liver Panel:
AST 48 U/L
ALT 55 U/L
ALP 92 U/L
Total Bilirubin 0.8 mg/dL

Blood Cultures (2/2) – Positive for MSSA (sensitive to oxacillin, cefazolin)
Repeat cultures pending

Inflammatory Markers:
CRP 12 mg/dL (elevated)
ESR 68 mm/hr

Urinalysis: Clear, no leukocyte esterase, no nitrites

Imaging:
Transthoracic Echo (TTE) 01/16/3067: LVEF 55%, mobile vegetation ~1.2 cm on anterior mitral leaflet, moderate MR, no pericardial effusion.
Chest X‑ray: Mild interstitial infiltrates bilaterally, no effusion.

Assessment and Plan:
1. Infective Endocarditis – MSSA, mitral valve vegetation 1.2 cm, new murmur, systemic symptoms.
   • Continue IV cefazolin 2 g q8h (adjust for renal function) + add gentamicin 1 mg/kg q8h for synergistic effect (monitor troughs).
   • Infectious Diseases consult – recommended 6‑week IV therapy, consider early surgical evaluation given vegetation size >1 cm.
   • Cardiology consult – repeat TEE in 48 h to assess for embolic risk.
   • Monitor CBC, CMP, drug levels q48h; repeat blood cultures daily until clearance.
   • DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
   • NPO except meds; advance diet as tolerated.

2. Hepatitis C – chronic, RNA+, currently on sofosbuvir/velpatasvir.
   • Continue antiviral therapy; monitor LFTs.

3. Hypertension – controlled.
   • Continue lisinopril 10 mg daily; hold if K >5.5.

4. Substance Use – IV drug use in remission 2 mo, but high relapse risk.
   • Addiction Medicine consult for MAT (buprenorphine) and housing resources.
   • Counsel on needle exchange, safe injection practices.

5. Depression.
   • Psychiatry consult; consider SSRI (sertraline 50 mg daily) after stabilization.

Disposition:
Admit to Cardiology Service, telemetry floor. Code Status: Full Code (Presumed). Anticipated LOS 4‑6 weeks pending surgical decision.  

Dr. Harold Finch, MD
Attending Hospitalist  
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (67, 67, 97968021955, 97968021955, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Evelyn Hartwell
DOB: 03/22/3060
MRN: 84276109
PCP: Dr. Lionel Finch, MD

Date of Admission: 01/04/3089
Time: 19:05
Location: WARD12B
Attending Provider: Dr. Maya L. Ortiz, MD

Chief Complaint: Cough, fever, dyspnea

History of Present Illness:
29yo F w/ hx intermittent asthma (SABA PRN), recent URTI 5d ago now p/w productive cough w/ yellow sputum, subjective fevers up to 102°F, chills, pleuritic chest pain R side, SOB on exertion. Pt reports she was seen at urgent care 3d ago, given azithro 500 mg PO daily x3 and albuterol inhaler, but symptoms progressed, now w/ increased work of breathing, tachypnea, and fatigue. Denies hemoptysis, orthopnea, PND, leg swelling. Pt traveled to coastal resort 10d ago, stayed in hotel, no known sick contacts. No recent COVID‑19 exposure. Pt states she stopped her inhaler after 2 days because felt better, but now feels “tight chest”. In ED vitals: T 101.8°F, HR 112, RR 24, BP 118/72, SpO2 92% RA. Labs showed WBC 14.2 with left shift, CRP 12.5 mg/dL. CXR read LLL infiltrate. Pt was started on ceftriaxone 1 g IV q24h and continued azithro, but after 12h still febrile, so admitted for IV antibiotics, telemetry, and further work‑up.

Past Medical History:
• Intermittent asthma
• Seasonal allergic rhinitis
• GERD (on PRN ranitidine)

Past Surgical History:
• Appendectomy (lap, 3072)

Family History:
Mother – HTN, DM2
Father – CAD s/p stent 3065
Sister – healthy

Social History:
Marital Status: Single, lives alone in apartment
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit Drugs: Denies
Occupation: Graphic designer, works from home
Travel: Coastal resort 10d ago, no international travel

Review of Systems:
Constitutional: +Fever, +Chills, +Fatigue, –Weight loss
HEENT: +Sore throat 5d ago, –Vision changes
Respiratory: +Cough productive, +Dyspnea on exertion, +Pleuritic chest pain, –Wheezes at rest
Cardiovascular: –Chest pain at rest, –Palpitations
GI: +Nausea occasional, –Vomiting, –Diarrhea
GU: –Dysuria, –Frequency
Musculoskeletal: –Myalgias
Neurologic: –Headache, –Dizziness
Skin: –Rash
Psych: –Anxiety, –Depression

Prior to Admission Medications:
Medication                Sig
Albuterol inhaler         2 puffs q4‑6h PRN
Fluticasone propionate   1 inhalation BID
Ranitidine 150 mg PO     BID PRN heartburn
Azithromycin 500 mg PO   Daily x3 (started 3d ago)

Allergies:
No known drug allergies (NKDA)

Physical Examination:
Vital Signs:
Temp 101.6°F
HR 110 bpm
RR 22 breaths/min
BP 120/70 mmHg
SpO2 93% on RA
Weight 62 kg (136 lb)

General: Alert, appears mildly ill, in mild respiratory distress, speaking in full sentences.
HEENT: Normocephalic, oropharynx erythematous, no exudates.
Neck: Supple, no JVD, no lymphadenopathy.
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Decreased breath sounds L lower lobe, crackles + at LLL, scattered wheezes R upper fields, no pleural rub.
Abdomen: Soft, NT, BS present bilaterally.
Extremities: No edema, pulses 2+ bilat.
Skin: Warm, dry, no rashes.
Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.

Labs:
CBC: WBC 14.2 K/µL (Neut 82%), Hgb 12.8 g/dL, Plt 312 K/µL
BMP: Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.78, Glu 112
CRP: 12.5 mg/dL
Procalcitonin: 0.68 ng/mL
Liver panel: within normal limits
ABG (room air): pH 7.45, PaCO2 34, PaO2 68, HCO3 24

Imaging:
Chest X‑ray (01/04/3089): LLL patchy infiltrate consistent with pneumonia, no effusion.
CT Chest (pending): ordered to rule out PE given elevated D‑dimer 1320 ng/mL.

Assessment and Plan:
1. Community‑acquired pneumonia, likely bacterial LLL focus.
   • Continue ceftriaxone 1 g IV q24h.
   • Azithromycin 500 mg IV q24h (complete 5‑day course).
   • Obtain sputum culture, blood cultures x2.
   • Monitor vitals q4h, repeat CXR in 48h.
   • Telemetry for arrhythmia monitoring given tachycardia.
2. Asthma, intermittent – resume inhaled fluticasone BID and albuterol PRN; consider step‑up if wheezing persists.
3. Fever, chills – antipyretics Tylenol 650 mg PO q6h PRN.
4. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
5. Code Status: Full Code (presumed).
6. Diet: Regular, encourage oral hydration.
7. Disposition: Admit to medical floor, anticipate 3‑5 day stay pending clinical response.
8. Follow‑up labs: CBC, BMP, CRP q24h; repeat procalcitonin if no improvement.
9. Education: Discuss importance of completing antibiotics, inhaler technique, signs of worsening dyspnea.

Signature:
Maya L. Ortiz, MD
Attending Hospitalist
Pager # 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (68, 68, 77785832224, 77785832224, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, '08/28/3059 02:37

Patient: Miguel Alvarez
DOB: 04/12/3025
MRN: 98765432
PCP: Dr. Lucia Ramos, MD

Chief Complaint: dysuria, suprapubic pain, fever

History of Present Illness:
58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 45), BPH, recent prostatitis p/w N/V/D and R flank pain. Patient reports 3‑day history of worsening dysuria, cloudy urine, urgency and suprapubic pressure. Yesterday night he noted fever to 101.8°F, chills, and a single episode of emesis. He denies any recent sexual activity, new sexual partners, or condom use. He says he completed a 5‑day course of ciprofloxacin for prostatitis 2 weeks ago, but stopped early because of GI upset. He went to urgent care 2 days ago, was given nitrofurantoin 100 mg BID but stopped after 2 doses due to nausea. He now presents to ED after a friend called EMS because his temp spiked to 103°F at home. He also notes mild right flank tenderness, no CVA tenderness, no gross hematuria. He has a history of intermittent urinary retention secondary to BPH, uses tamsulosin 0.4 mg daily. He reports baseline creatinine ~1.6 mg/dL, baseline glucose 180‑200 mg/dL. He is compliant with insulin glargine 30 U qHS and metformin 500 mg BID (held on admission). He denies cough, SOB, chest pain, GI bleed, or recent travel. He lives with wife, works as a forklift operator in a warehouse, no recent hospitalizations other than the prostatitis episode. He drinks 2‑3 beers/week, never smoked, no illicit drugs.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2015
• Chronic Kidney Disease stage 3 – 2022
• Benign Prostatic Hyperplasia – 2020
• Hypertension – 2018
• Hyperlipidemia – 2019
• Prior prostatitis – 08/3059 (treated with ciprofloxacin)

Past Surgical History:
• Appendectomy – 03/3050
• Right knee arthroscopy – 11/3055

Family History:
Father – HTN, died MI age 68
Mother – DM2, alive 84
Sister – breast CA dx 3052
No known hereditary kidney disease.

Social History:
Marital Status: Married
Occupation: Forklift operator, warehouse
Tobacco: Never
Alcohol: 2‑3 beers/week
Illicit Drugs: None
Living Situation: Lives with spouse, no pets
Travel: None recent
Sexual Activity: Heterosexual, monogamous, uses condoms inconsistently.

Review of Systems:
Constitutional: +fever, +fatigue, -weight loss, -night sweats.
HEENT: -headache, -vision changes.
Cardiovascular: -chest pain, -palpitations.
Respiratory: -cough, -dyspnea.
GI: +nausea, -vomiting (except 1 episode), -diarrhea.
GU: +dysuria, +suprapubic pain, +urgency, -hematuria, -flank pain (mild R).
Musculoskeletal: -myalgias.
Neurologic: -dizziness, -syncope.
Psych: -depression, -anxiety.

Prior to Admission Medications:
Medication                Sig
Metformin 500 mg          BID PO
Insulin glargine 30 U     QHS SC
Lisinopril 20 mg          QD PO
Amlodipine 5 mg          QD PO
Atorvastatin 40 mg       QHS PO
Tamsulosin 0.4 mg        QD PO
Vitamin D3 2000 IU       QD PO
Albuterol inhaler PRN    2 puffs q4h PRN SOB

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 102.4°F, HR 112, RR 20, BP 138/78, SpO2 97% RA, Weight 92 kg (202 lb)
General: Appears ill, diaphoretic, in mild distress.
HEENT: Normocephalic, atraumatic, mucous membranes dry.
Neck: Supple, no JVD.
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.
Abdomen: Soft, mildly tender suprapubic, no rebound, no guarding. No CVA tenderness.
Genitourinary: External genitalia normal, mild suprapubic tenderness on palpation.
Extremities: No edema, pulses 2+ bilat.
Skin: Warm, diaphoretic, no rashes.
Neuro: AOx3, grossly non‑focal.

Laboratory Data (drawn 08/28/3059):
CBC:
WBC 14.8 K/µL (neut 84%)
Hgb 13.2 g/dL
Hct 39.5%
Plt 312 K/µL

BMP:
Na 138 mmol/L
K 4.6 mmol/L
Cl 102 mmol/L
CO2 22 mmol/L
BUN 28 mg/dL
Cr 1.8 mg/dL (baseline 1.6)
Glucose 212 mg/dL

CRP 12 mg/dL
Procalcitonin 0.9 ng/mL

Urinalysis (dipstick):
Leukocyte esterase +++
Nitrite + (positive)
Blood trace
Protein negative
pH 6.5
Microscopy: WBC 45/hpf, RBC 5/hpf, bacteria many.

Urine culture: pending.

Blood cultures: x2 sets pending.

Imaging:
Renal US (08/28/3059): No hydronephrosis, kidneys normal size, mild cortical echogenicity consistent with CKD.

Assessment and Plan:
58yo M with DM2, CKD3, BPH presenting with acute uncomplicated cystitis likely secondary to resistant uropathogen (recent fluoroquinolone exposure). Fever, leukocytosis, positive nitrite, UA consistent with UTI. No evidence of pyelonephritis (no CVA tenderness, US negative). Plan:

1. Antibiotics: Start IV ceftriaxone 2 g q24h now; after culture results, de‑escalate to oral nitrofurantoin 100 mg BID for 7 days if susceptible, otherwise consider oral fosfomycin single dose or oral fluoroquinolone if sensitivities allow (caution given prior exposure).
2. Fluids: NS 125 mL/hr IV to maintain urine output >0.5 mL/kg/hr.
3. Glycemic control: Continue insulin glargine; start sliding scale regular insulin qac PRN for glucose >180.
4. Renal function: Monitor Cr q12h, adjust meds as needed; hold metformin.
5. BPH: Continue tamsulosin; consider short course of phenazopyridine for dysuria comfort.
6. Pain/fever: Acetaminophen 650 mg PO q6h PRN; avoid NSAIDs given CKD.
7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily (adjust for Cr if <30).
8. Diet: NPO initially, advance to regular as tolerated.
9. Education: Counsel on completing full antibiotic course, hydration, and follow‑up UA in 1‑2 weeks.
10. Disposition: Admit to Med floor, telemetry not required, monitor vitals q4h, labs q24h. Anticipate discharge in 3‑4 days if afebrile >48 h and clinically improving.

Code Status: Full Code (Presumed)

Attending: Dr. Rafael Mendoza, MD
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (69, 69, 75325652810, 75325652810, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 05/13/3065 15:40  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  

Patient: Marcus L. Whitaker  
DOB: 02/14/3015  
MRN: 98765432  
PCP: Dr. Samuel Greene, MD  

Chief Complaint: SOB and increased sputum production  

History of Present Illness:  
58yo M with h/o COPD (GOLD stage III, chronic bronchitis phenotype), HTN, and remote 20‑pack‑yr smoking (quit 5 y ago) p/w worsening dyspnea, productive cough, and low‑grade fever x3 days. He reports a change from his baseline “white frothy” sputum to thick yellow‑green sputum, increased work of breathing, and use of accessory muscles. Yesterday he self‑administered albuterol MDI q4h PRN with minimal relief, and took 2 L O₂ at home via nasal cannula (baseline 2 L). He denies chest pain, palpitations, calf pain, or recent travel. He was seen at an urgent care 2 days ago, given a 5‑day course of azithromycin which he completed, but symptoms progressed. EMS was called this morning after he became unable to speak full sentences; vitals on scene: HR 112, RR 28, SpO₂ 84% on 2 L O₂, BP 138/78. He was placed on non‑rebreather 15 L en route and brought to ED where he was placed on BiPAP (IPAP 12, EPAP 5). Labs showed mild leukocytosis, ABG with pH 7.32, PaCO₂ 58 mmHg, PaO₂ 68 mmHg on 15 L O₂. CXR demonstrated hyperinflated lungs with bibasilar infiltrates. He was started on IV methylprednisolone 60 mg q12h, nebulized ipratropium‑albuterol q4h, and ceftriaxone 1 g q24h. He was admitted for COPD exacerbation with possible bacterial superinfection.  

Past Medical History:  
• COPD (diagnosed 2005)  
• Hypertension  
• Hyperlipidemia  
• GERD  

Past Surgical History:  
• Appendectomy (2002)  

Family History:  
Father: HTN, died MI age 68  
Mother: COPD, alive 82  
Brother: T2DM  

Social History:  
Tobacco: Never smoker after quitting 5 y ago (20‑pack‑yr)  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Occupation: Retired electrician, lives with spouse, owns a dog, independent ADLs  

Review of Systems:  
Constitutional: +fever 100.8 °F, +fatigue, –weight loss.  
HEENT: –sore throat, –sinus pain.  
Respiratory: +dyspnea at rest, +productive cough, +wheezing, –hemoptysis.  
Cardiovascular: –chest pain, –palpitations, –edema.  
GI: –nausea, –vomiting, –diarrhea.  
GU: –dysuria, –frequency.  
Neuro: –headache, –dizziness.  
Psych: –anxiety, –depression.  

Prior to Admission Medications:  
Medication                Sig  
Albuterol Inhaler         2 puffs q4h PRN  
Ipratropium Inhaler      2 puffs q4h PRN  
Tiotropium Respimat       1 inhalation daily  
Fluticasone/Salmeterol   1 inhalation BID  
Lisinopril                20 mg PO daily  
Atorvastatin             40 mg PO nightly  
Omeprazole               20 mg PO daily  

Allergies: No known drug allergies  

Physical Examination:  
Temperature: 37.8 °C (100.0 °F)  
Heart Rate: [90‑120] 108 bpm  
Respiratory Rate: [20‑30] 26 bpm (on BiPAP)  
BP: (120‑150)/(70‑90) 138/78 mmHg  
SpO₂: 92% on BiPAP FiO₂ 0.5  

General: Alert, in mild respiratory distress, using accessory muscles.  
HEENT: Normocephalic, oropharynx clear, no tonsillar exudate.  
Neck: Supple, no JVD.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Diffuse wheezes bilaterally, coarse crackles at bases, decreased breath sounds hyperinflated.  
Abdomen: Soft, NT, BS present.  
Extremities: No edema, pulses 2+ bilat.  
Skin: Warm, no rashes.  
Neuro: AOx3, CN II‑XII grossly intact.  

Recent Labs:  
CBC‑Diff (05/13/3065)  
WBC 13.2 K/µL  
Hgb 13.5 g/dL  
Hct 40.2 %  
Plt 245 K/µL  

BMP (05/13/3065)  
Na 138 mmol/L  
K 4.3 mmol/L  
Cl 102 mmol/L  
CO₂ 28 mmol/L  
BUN 16 mg/dL  
Cr 0.9 mg/dL  
Glucose 112 mg/dL  

ABG (on BiPAP)  
pH 7.32, PaCO₂ 58 mmHg, PaO₂ 68 mmHg, HCO₃⁻ 28 mmol/L  

CXR (05/13/3065)  
Hyperinflated lungs, flattened diaphragms, bibasilar infiltrates suggestive of infectious component.  

Assessment and Plan:  
1. COPD Exacerbation, GOLD III, with suspected bacterial superinfection.  
   • Continue IV methylprednisolone 60 mg q12h, transition to PO prednisone 40 mg daily when stable.  
   • Continue nebulized ipratropium‑albuterol q4h, add nebulized budesonide 0.5 mg q6h.  
   • Continue ceftriaxone 1 g IV q24h; obtain sputum culture, consider de‑escalation based on sensitivities.  
   • Maintain BiPAP support; wean to HFNC when ABG improves.  
   • DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
   • Incentive spirometry, early ambulation.  

2. Hypertension – continue lisinopril 20 mg PO daily, monitor BP q8h.  

3. Hyperlipidemia – continue atorvastatin 40 mg nightly.  

4. GERD – continue omeprazole 20 mg daily.  

5. Vaccinations – verify pneumococcal 23‑valent up to date, schedule influenza if seasonally indicated.  

Disposition: Admit to Med‑Surg floor, telemetry for arrhythmia monitoring, goal to transition to oral steroids and step‑down oxygen within 48 h.  

Code Status: Full Code (Presumed)  

Attending: Dr. Evelyn Hartwell, MD  
Pager: 67890');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (70, 70, 23897679986, 23897679986, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
05/30/3079 06:31  

Patient: Marcus L. Whitaker  
DOB: 02/14/3045  
MRN: 98765432  
PCP: Dr. Elaine V. Kline, MD  

Chief Complaint: Right forearm swelling, erythema, pain  

History of Present Illness:  
58yo M with h/o HTN, T2DM (A1c 8.7% 02/3078), CKD stage 3, and remote cellulitis p/w left lower leg cellulitis 2 y ago, now presents w/ 3‑day history of progressive right forearm pain, swelling, and warmth. Patient reports that 4 days ago he sustained a minor laceration while chopping wood (sharp edge of a hand‑saw) on his right forearm; he cleaned it with water and soap, applied over‑the‑counter bacitracin, but noted increasing redness and a “stinging” sensation. Yesterday he noted the area became tense, with a “tight” feeling, and he started having low‑grade fevers (T max 38.2 °C) and chills. He went to urgent care on 05/28/3079 where a rapid strep test was negative; they gave him a 5‑day course of cephalexin 500 mg PO q6h and instructed to return if worsening. He took 2 doses, then stopped due to nausea. Over the past 24 h the swelling extended proximally to the elbow, the skin is now erythematous, indurated, and tender to light touch. He denies any drainage, bullae, or lymphangitic streaks. No recent travel, no known sick contacts, no animal bites. He works as a carpenter, frequently uses his hands, and reports that his gloves were soaked in water during the incident. He denies IV drug use. He reports mild dyspnea on exertion (climbing stairs) but attributes to deconditioning. He is afebrile now (T 36.9 °C) but feels “ill”.  

Past Medical History:  
- Hypertension (diagnosed 04/3065)  
- Type 2 Diabetes Mellitus (diagnosed 06/3068)  
- Chronic Kidney Disease stage 3 (baseline Cr 1.6 mg/dL)  
- Hyperlipidemia  
- GERD  

Past Surgical History:  
- Appendectomy (laparoscopic) 07/3060  
- Right carpal tunnel release 03/3072  

Family History:  
- Mother: HTN, died of MI at 68  
- Father: CKD secondary to diabetes, alive 78  
- Sister: Healthy  

Social History:  
Marital Status: Married, spouse Jane Whitaker (no med hx)  
Children: 2 (ages 12 and 9)  
Occupation: Carpenter (full‑time, uses power tools)  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit Drugs: Denies  
Living Situation: Owns single‑family home, no pets  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue; negative for weight loss.  
HEENT: Negative for sore throat, sinus pain.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, SOB at rest.  
GI: Negative for N/V, abdominal pain.  
GU: Negative for dysuria.  
Musculoskeletal: Positive for right forearm pain, swelling; negative for joint pain elsewhere.  
Skin: Positive for erythema, warmth, induration of right forearm; negative for rash elsewhere.  
Neuro: Alert, oriented x3, no focal deficits.  
Psych: Mood “okay”, no depression.  

Prior to Admission Medications:  
Medication                Sig  
lisinopril 20 mg PO daily  
metformin 1000 mg PO BID  
atorvastatin 40 mg PO nightly  
omeprazole 20 mg PO daily  
insulin glargine 30 U SC qHS  

Allergies: No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs:  
Temp 36.9 °C (98.4 °F)  
HR 92 bpm (regular)  
RR 18/min  
BP 138/84 mmHg  
SpO2 97 % RA  

General: Alert, NAD, appears mildly ill.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  
GI: Soft, non‑tender, BS +, no hepatosplenomegaly.  
Extremities: Right forearm – 12 × 8 cm area of erythema, warm, indurated, tender to palpation, no fluctuance, no crepitus, no overt drainage. No lymphangitic streaks. No edema of hand or elbow. Left extremities normal.  
Skin: No rashes elsewhere.  
Neuro: AOx3, CN II‑XII grossly intact, strength 5/5 UE/LE, sensation intact.  

Laboratory Data (drawn 05/30/3079):  

CBC:  
WBC 14.2 K/µL (Neut 86 %)  
Hgb 13.1 g/dL  
Hct 39 %  
Plt 312 K/µL  

BMP:  
Na 138 mmol/L  
K 4.5 mmol/L  
Cl 102 mmol/L  
CO2 24 mmol/L  
BUN 22 mg/dL  
Cr 1.7 mg/dL (baseline 1.6)  
Glucose 212 mg/dL  

CRP 12.4 mg/dL (elevated)  
ESR 48 mm/hr  

Lactate 1.2 mmol/L  

Blood cultures x2: pending  

Imaging:  
Portable X‑ray right forearm (05/30/3079): No fracture, soft‑tissue swelling noted, no gas.  

Bedside ultrasound of right forearm: Subcutaneous edema, no abscess cavity identified.  

Assessment and Plan:  
58yo M with HTN, T2DM, CKD3 presenting with acute right forearm cellulitis likely secondary to minor laceration, now with systemic signs (fever, leukocytosis, elevated CRP). No evidence of abscess on US.  

1. Cellulitis – start IV cefazolin 2 g q8h (adjust for Cr; will monitor renal function). Consider adding vancomycin 15 mg/kg q12h if MRSA risk (recent carpentry work, possible environmental exposure) – pending MRSA swab.  
2. Diabetes – continue home metformin (hold if renal function worsens), start sliding scale insulin (regular insulin 4 U qSC qAC and qPRN >180).  
3. Hypertension – continue lisinopril, monitor BP.  
4. CKD – monitor Cr, avoid nephrotoxic agents, ensure adequate hydration.  
5. Pain – acetaminophen 650 mg PO q6h PRN; avoid NSAIDs given CKD.  
6. VTE prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  
7. DVT prophylaxis, Foley not needed.  
8. Labs: CBC, BMP, CRP q24h, blood cultures q12h until negative.  
9. Consults: Infectious Diseases for guidance on MRSA coverage; Surgery if any sign of evolving abscess.  
10. Disposition: Admit to Med‑Surg floor, telemetry not required.  
11. Code Status: Full Code (Presumed).  

Patient and spouse educated on cellulitis signs, wound care, importance of completing IV antibiotics, and follow‑up.  

Patrick W. Hargrove, MD  
Hospitalist, Example Medical Center  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (71, 71, 25332600647, 25332600647, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
09/21/3059 17:35  

Patient: Marcus L. Whitaker  
DOB: 04/12/3025  
MRN: 98765432  
PCP: Dr. Elaine V. Hart, MD  

Chief Complaint:  
productive cough, dyspnea, fever x4 days  

History of Present Illness:  
58yo M with h/o HTN, HLD, T2DM (A1c 8.1%), CKD stage 3, and recent right‑sided CAP p/w SOB, pleuritic chest pain, and chills. He was seen at an urgent care 2 days ago, given azithro 500 mg PO x5d, but symptoms progressed. Yesterday night he developed fever 39.4 °C (103 °F), chills, and a “rusty” sputum. He reports increased dyspnea on exertion, now at rest, and a non‑productive cough earlier that turned productive this morning. Denies orthopnea, PND, leg swelling, or calf pain. No recent travel; works as a construction foreman, lives with wife and two teenage kids. He quit smoking 5 y ago (20 pack‑yr hx). No known drug allergies. He took his home meds (lisinopril, atorvastatin, metformin, insulin glargine) up until this morning; missed insulin dose yesterday due to nausea. He presented to the ED at 14:20, where vitals showed HR 112, RR 24, SpO2 92% RA, BP 138/78. Labs: WBC 16.2 K with left shift, procalcitonin 1.8 ng/mL, lactate 1.9 mmol/L. CXR: LLL infiltrate, possible consolidation. Started on IV cefepime 2 g q8h, azithro 500 mg IV q24h, and supplemental O₂ 2 L NC. He was admitted for inpatient management of community‑acquired pneumonia with possible sepsis.  

Past Medical History:  
- Hypertension – diagnosed 2015, on lisinopril 20 mg daily  
- Hyperlipidemia – on atorvastatin 40 mg daily  
- Type 2 Diabetes Mellitus – on metformin 1000 mg BID, insulin glargine 30 U qHS  
- Chronic Kidney Disease stage 3 (eGFR 48 mL/min)  
- Obstructive Sleep Apnea – uses APAP nightly  

Past Surgical History:  
- Appendectomy – 2008, laparoscopic  
- Right inguinal hernia repair – 2019, open mesh  

Family History:  
Father – HTN, MI at 62; Mother – DM2, CKD; Sister – healthy  

Social History:  
Marital Status: Married  
Occupation: Construction foreman (outdoor work, occasional dust exposure)  
Tobacco: Former smoker, quit 5 y ago, 20 pack‑yr total  
Alcohol: Social, 1‑2 drinks/week, no binge  
Illicit Drugs: Denies  
Living Situation: Single‑family home, wife and two children (15, 12)  

Review of Systems:  
Constitutional: +fever, chills, fatigue; -weight loss, night sweats.  
HEENT: +sore throat 2 d ago, -vision changes.  
Respiratory: +productive cough, dyspnea, pleuritic chest pain; -hemoptysis, wheezes.  
Cardiovascular: +palpitations occasional, -chest pressure, -edema.  
GI: +nausea, -vomiting, -diarrhea.  
GU: -dysuria, -frequency.  
Musculoskeletal: -myalgias, -joint pain.  
Neurologic: -headache, -dizziness.  
Psychiatric: -anxiety, -depression.  

Medications Prior to Admission:  
lisinopril 20 mg PO daily  
atorvastatin 40 mg PO nightly  
metformin 1000 mg PO BID  
insulin glargine 30 U SC qHS  
vitamin D3 2000 IU PO daily  

Allergies:  
No known drug allergies (NKDA)  

Physical Exam:  

Vital Signs:  
Temp 38.9 °C (102 °F)  
HR 108 bpm (regular)  
RR 22 /min  
BP 136/80 mmHg  
SpO2 93 % on 2 L NC  
Weight 92 kg (202 lb)  

General: Alert, mildly diaphoretic, appears his stated age, in mild respiratory distress.  
HEENT: Normocephalic, oropharynx erythematous, no exudates.  
Neck: Supple, no JVD, no cervical adenopathy.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Decreased breath sounds LLL, crackles coarse, egophony present, no wheezes.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.  

Labs:  
CBC: WBC 16.2 K (neut 84%), Hgb 13.1 g/dL, Plt 245 K.  
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 18, Cr 1.3 (eGFR 48), Glu 212 mg/dL.  
CRP: 12.5 mg/dL.  
Procalcitonin: 1.8 ng/mL.  
Lactate: 1.9 mmol/L.  
Blood cultures x2: pending.  

Imaging:  
Chest X‑ray (09/21/3059): LLL infiltrate with air bronchograms, consistent with bacterial pneumonia.  
CT chest (if performed): not obtained yet.  

Assessment and Plan:  
58yo M with HTN, HLD, DM2, CKD3 and community‑acquired pneumonia LLL, now febrile, tachycardic, O2 sat <94% on low‑flow O2 → CAP with possible sepsis.  

1. Pneumonia – continue cefepime 2 g IV q8h, azithro 500 mg IV daily; reassess cultures at 48 h; consider de‑escalation to ceftriaxone + azithro if sensitivities allow and renal function stable.  
2. Oxygen – titrate NC to maintain SpO2 ≥94%; consider HFNC if worsening.  
3. Diabetes – hold metformin (AKI risk), start insulin sliding scale; resume basal insulin glargine at 20 U qHS pending glucose trends.  
4. Hypertension – continue lisinopril; monitor BP q8h.  
5. CKD – monitor Cr, avoid nephrotoxic agents; adjust cefepime dose per eGFR.  
6. Fluid – maintain euvolemia, 1 L NS bolus if MAP <65, then D5W as needed.  
7. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  
8. Nutrition – NPO initially, advance to clear liquids when afebrile, then regular diet.  
9. Monitoring – telemetry for arrhythmia risk, q4h vitals, labs q24h, repeat CXR day 3.  
10. Disposition – admit to Med‑Surg floor, low‑acuity telemetry; anticipate 4‑5 day stay if clinical response.  

Code Status: Full Code (Presumed)  

Attending: Dr. Victor L. Ramos, MD  
Pager: 84210');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (72, 72, 28948901188, 28948901188, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Evelyn Hartwell  
DOB: 11/03/3065  
MRN: 84276109  
PCP: Dr. Lionel Marlowe, MD  

Date of Admission: 05/21/3091  
Time: 02:43  
Attending Provider: Dr. Selene Voss, MD  
Location: CARDIO01  
Service: Hospital Medicine  

Chief Complaint: Dyspnea, orthopnea, lower extremity edema  

History of Present Illness:  
58yo F with h/o HFrEF (EF 30% on echo 04/3090), CAD s/p PCI to RCA 06/3088, HTN, CKD stage 3, and chronic atrial fibrillation on warfarin, presents w/ progressive dyspnea x5 days, now SOB at rest, 2‑LPM O2 required to keep sats >92%. Reports worsening PND, 2‑night awakenings, and 2++ pitting edema to mid‑calves. Denies chest pain, fever, cough, hemoptysis. She was discharged from outside hospital 03/3091 after treatment for acute decompensated HF; was on IV furosemide 40 mg q8h, transitioned to oral bumetanide 2 mg daily, but stopped meds after discharge due to “feeling better”. Over past 48 h she resumed fluid intake (≈3 L/day) and noted weight gain ~4 lb. No recent travel, no sick contacts. Home meds were held for 2 days prior to admission. In ED vitals: HR 112 (irregular), BP 158/92, RR 24, SpO2 88% on RA, Temp 36.8 °C. Labs: BNP 1120 pg/mL, creatinine 1.8 mg/dL (baseline 1.4). CXR: bilateral interstitial edema, Kerley B lines. Started on IV furosemide 80 mg bolus, then infusion 10 mg/h, and nitroglycerin drip. Cardiology consulted; plan for diuresis and possible inotrope.  

Past Medical History:  
- Heart Failure, HFrEF (EF 30%) – diagnosed 07/3085  
- Coronary Artery Disease, s/p PCI (RCA) 06/3088  
- Atrial Fibrillation, chronic, on warfarin  
- Hypertension  
- Chronic Kidney Disease stage 3 (baseline Cr 1.4)  
- Hyperlipidemia  

Past Surgical History:  
- Cholecystectomy – laparoscopic – 02/3079  
- Right knee arthroscopy – 11/3080  

Family History:  
- Mother: HTN, died of stroke at 78  
- Father: CAD, MI at 65, alive  
- Sister: Diabetes mellitus type 2  

Social History:  
Tobacco Use: Never smoker  
Alcohol Use: Social, 1‑2 drinks/week, no binge  
Illicit Drugs: Denies  
Living Situation: Lives alone in apartment, daughter visits weekly  
Employment: Retired elementary school teacher  
Functional Status: Ambulates with cane, limited by dyspnea  

Review of Systems:  
Constitutional: +fatigue, +weight gain 4 lb, -fever, -chills  
HEENT: -headache, -vision changes  
Cardiovascular: +dyspnea on exertion, +PND, +orthopnea, -chest pain, -palpitations (baseline AF)  
Respiratory: +shortness of breath at rest, -cough, -hemoptysis  
Gastrointestinal: -N/V, -abdominal pain, -diarrhea  
Genitourinary: -dysuria, -frequency  
Musculoskeletal: +bilateral calf edema, -joint pain  
Neurologic: -dizziness, -syncope  
Psychiatric: +anxiety about hospitalization, -depression  

Prior to Admission Medications:  
Medication                Sig  
Lisinopril 20 mg PO daily  
Metoprolol succinate 100 mg PO daily  
Warfarin 5 mg PO daily (target INR 2‑3)  
Bumetanide 2 mg PO daily (held 2 days)  
Spironolactone 25 mg PO daily  
Atorvastatin 40 mg PO nightly  
Furosemide 40 mg PO daily (held)  
Carvedilol 12.5 mg PO BID  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs: T 36.8 °C, HR 112 irregular, RR 24, BP 158/92, SpO2 88% RA (on 2 L NC 94%), Weight 172 lb (78 kg) – up 4 lb since last admission.  

General: Alert, mildly diaphoretic, in mild respiratory distress, sitting upright.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: JVD present at 45°, no thyromegaly.  

Cardiovascular: Irregularly irregular rhythm, S1,S2 audible, S3 present, no murmurs, no rubs.  

Respiratory: Bilateral basilar crackles up to mid‑lung fields, decreased breath sounds at bases, no wheezes.  

Abdomen: Soft, non‑tender, nondistended, bowel sounds present.  

Extremities: 2+ pitting edema to mid‑calves bilaterally, warm, pulses 2+ dorsalis pedis.  

Skin: No rashes, no ulcerations.  

Neuro: AOx3, grossly non‑focal.  

Labs (most recent):  
CBC: WBC 9.2 K/µL, Hgb 12.1 g/dL, Plt 210 K/µL  
BMP: Na 138, K 5.1, Cl 102, CO2 22, BUN 28, Cr 1.8, Glucose 112  
BNP: 1120 pg/mL  
Troponin I: 0.02 ng/mL (reference <0.04)  
INR: 2.4  
ABG (on 2 L NC): pH 7.32, pCO2 48, pO2 68, HCO3‑ 24  

Imaging:  
Chest X‑ray (05/21/3091): Cardiomegaly, bilateral interstitial edema, Kerley B lines, small pleural effusions.  
Echocardiogram (04/3090): LVEF 30%, severe LV dilation, moderate MR, RV systolic pressure 45 mmHg.  

Assessment and Plan:  
58yo F with HFrEF (EF 30%) s/p recent ADHF admission, now presents with recurrent decompensation likely due to medication non‑adherence and excess fluid intake.  

1. Acute Decompensated Heart Failure – continue IV furosemide 80 mg bolus then 10 mg/h infusion, monitor urine output, daily weights, electrolytes. Add metolazone 5 mg PO qD if diuresis inadequate.  
2. Atrial Fibrillation – rate control with IV diltiazem drip targeting HR 80‑90, transition to oral metoprolol once stable. Continue warfarin; check INR q12h until therapeutic.  
3. Hypertension – hold lisinopril while AKI risk; resume when Cr <2.0 and K <5.0.  
4. CKD stage 3 – monitor Cr, K, adjust diuretics accordingly.  
5. Hyperlipidemia – continue atorvastatin 40 mg.  
6. DVT prophylaxis – SQ enoxaparin 40 mg daily (adjust for Cr).  
7. Fluid management – restrict Na <2 g/day, fluid restriction 1.5 L/day.  
8. Education – reinforce medication adherence, daily weight monitoring, low‑salt diet.  
9. Disposition – admit to Cardiology service, telemetry, target diuresis 3‑4 L net negative over 48 h, reassess for possible inotrope (dobutamine) if MAP <65 despite diuresis.  

Code Status: Full Code (Presumed)  

Disposition: Admit to Cardiology floor, telemetry, anticipate LOS 4‑5 days.  

Provider: Selene Voss, MD  
Pager: 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (73, 73, 18597492476, 18597492476, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 11/29/3083 20:27  
Location: CARDIO01  
Attending: Dr. Selma V. Hartwell, MD  

Patient: Elias M. Kline  
DOB: 04/12/3045  
MRN: 98765432  
PCP: Dr. Omar L. Reyes, MD  

Chief Complaint: Fever, chills, night sweats, dyspnea on exertion  

History of Present Illness:  
58yo M with h/o IV drug use (last use 2 mo ago), chronic HCV (treated), CKD stage 3, and recent left knee arthroplasty p/w 3 wk of intermittent fevers, rigors, new murmur, and progressive SOB. He reports low‑grade fevers (T max 101.5°F) daily, night sweats, and a sharp, pleuritic chest pain that started 5 days ago. Denies cough, hemoptysis, or recent travel. He was seen at an outside urgent care 10 days ago for a “possible skin infection” on his forearm; was prescribed TMP‑SMX but stopped after 2 days due to nausea. Since then, he has noticed increasing fatigue, mild palpitations, and a new holosystolic murmur heard at the left lower sternal border. He reports occasional dark urine and mild ankle edema. No known drug allergies. He was transferred from a community ED where blood cultures were drawn (2/4 positive for gram‑positive cocci in chains) and a transthoracic echo showed a 1.2 cm mobile vegetation on the mitral valve with mild regurgitation. He was started on IV vancomycin and ceftriaxone in the ED, but his blood pressure dropped to 92/58 mmHg, prompting transfer for higher level care.  

Review of Systems:  
Constitutional: Positive for fever, chills, night sweats, weight loss ~4 lb.  
HEENT: No headache, vision changes, or sore throat.  
Cardiovascular: Positive for new murmur, palpitations, mild chest discomfort.  
Respiratory: Dyspnea on exertion, no cough or wheeze.  
GI: Nausea, no vomiting, no abdominal pain, no melena.  
GU: Dark urine, no dysuria.  
Musculoskeletal: Knee arthroplasty site healing well, no joint pain.  
Neurologic: No focal deficits, mild dizziness.  
Skin: No rash, but forearm erythema resolved.  
Psych: Anxious about hospitalization.  

Past Medical History:  
• Chronic hepatitis C (RNA negative, post‑treatment)  
• Chronic kidney disease stage 3 (baseline Cr 1.6)  
• IV drug use (last 2 mo)  
• Left total knee arthroplasty 03/15/3082  
• Hypertension (controlled)  

Past Surgical History:  
• Left knee arthroplasty – 03/15/3082  
• Appendectomy – 02/10/3060  

Family History:  
Father – HTN, died of MI at 68. Mother – alive, DM2. No known hereditary cardiac disease.  

Social History:  
Tobacco: Never smoker.  
Alcohol: Social, 1‑2 drinks/week.  
Illicit drugs: IV heroin, last use 2 mo ago; in recovery program.  
Occupation: Unemployed, currently in a sober living facility.  
Living situation: Lives in group home, no pets.  

Allergies: No known drug allergies (NKDA).  

Medications Prior to Admission:  
- Lisinopril 10 mg PO daily  
- Amlodipine 5 mg PO daily  
- Furosemide 20 mg PO daily  
- Lactulose 20 g PO daily PRN constipation  
- Vitamin D3 2000 IU PO daily  

Vital Signs on Admission:  
Temp 38.9 °C (102 °F)  
HR 112 bpm (irregular)  
RR 22/min  
BP 94/58 mmHg (on arrival)  
SpO2 95 % on RA  
Weight 82 kg (180 lb)  

Physical Examination:  
General: Ill‑appearing, diaphoretic, mild distress, oriented x3.  
HEENT: Normocephalic, mucous membranes dry, no scleral icterus.  
Neck: Supple, JVD absent, no carotid bruits.  
Cardiovascular: Irregularly irregular rhythm, grade 3/6 holosystolic murmur loudest at apex radiating to axilla, new. No S3/4.  
Pulmonary: Clear to auscultation bilaterally, mild bibasilar crackles.  
Abdomen: Soft, non‑tender, no hepatosplenomegaly.  
Extremities: 1+ pitting edema bilat ankles, no Janeway lesions, no Osler nodes.  
Skin: No petechiae, no rashes.  
Neurologic: Alert, CN II‑XII intact, no focal deficits.  

Laboratory Data (most recent):  
CBC: WBC 14.2 K/µL (neutrophils 82%), Hgb 11.3 g/dL, Plt 210 K/µL.  
BMP: Na 138, K 4.8, Cl 102, CO2 22, BUN 28, Cr 1.8 (baseline 1.6), Glucose 112.  
Liver panel: AST 45, ALT 38, Alk Phos 92, Total bili 0.9.  
CRP: 12.4 mg/dL (elevated).  
ESR: 68 mm/hr.  
Blood cultures: 2/4 bottles positive for Streptococcus mitis (gram‑positive cocci in chains).  
Urinalysis: Dark urine, 2+ blood, 1+ protein, no leukocyte esterase.  
Transthoracic Echo (ED): Mobile 1.2 cm vegetation on anterior mitral leaflet, moderate MR, LVEF 55 %.  
Transesophageal Echo (ordered, pending): To assess for abscess.  

Imaging:  
Chest X‑ray: Mild interstitial infiltrates bilaterally, no effusion.  
CT chest (PE protocol): No PE, scattered ground‑glass opacities, no cavitary lesions.  

Assessment and Plan:  
1. Infective Endocarditis – native mitral valve, S. mitis, vegetation 1.2 cm, moderate MR.  
   • Continue IV vancomycin (target trough 15‑20 µg/mL) and ceftriaxone 2 g q24h.  
   • Add gentamicin 1 mg/kg q8h for synergistic effect (monitor trough).  
   • Obtain TEE within 24 h to rule out peri‑valvular abscess.  
   • Cardiology consult for valve assessment, possible surgical intervention.  
   • Infectious Diseases consult – duration planned 6 weeks IV therapy, adjust per sensitivities.  
   • Monitor CBC, CMP, drug levels q48h.  

2. Hemodynamic instability – borderline hypotension.  
   • Initiate norepinephrine drip titrated to MAP >65.  
   • IVF 30 mL/kg crystalloid bolus, then reassess.  

3. Acute kidney injury on CKD.  
   • Adjust vancomycin dosing per CrCl, hold nephrotoxic agents.  
   • Daily urine output chart, consider renal consult if creatinine rises >0.5 mg/dL.  

4. Anemia of chronic disease vs. hemolysis.  
   • Transfuse PRBCs if Hgb <8 g/dL or symptomatic.  

5. Heart failure risk – mild bibasilar crackles, edema.  
   • Continue furosemide 20 mg PO daily, hold if MAP <65.  
   • Low‑salt diet, daily weights.  

6. Pain and fever control.  
   • Acetaminophen 650 mg PO q6h PRN, avoid NSAIDs (CKD).  

7. Disposition: Admit to Cardiology step‑down unit with telemetry.  

Code Status: Full Code (Presumed).  

Orders:  
- IV vancomycin, ceftriaxone, gentamicin as above.  
- Blood cultures q48h until 2 sets negative.  
- TEE scheduled for tomorrow morning.  
- Norepinephrine infusion, IVF bolus.  
- Daily labs: CBC, BMP, CRP, vancomycin level.  
- Cardiology, ID, Nephrology consults.  
- DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
- Fall precautions, telemetry.  

Signature:  
Dr. Selma V. Hartwell, MD  
Attending Hospitalist  
Pager 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (74, 74, 46429751289, 46429751289, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
01/12/3052 20:31  

Patient: Marcus L. Whitaker  
DOB: 03/04/2989  
MRN: 84276109  
PCP: Dr. Elaine V. Kline, MD  

Chief Complaint: Left foot gangrene with increasing pain and foul drainage  

History of Present Illness:  
62yo M with h/o T2DM (A1c 9.4% 2mo ago), PAD s/p fem‑pop bypass 2018, CKD‑3, HTN, and prior left toe amputation (2020) p/w worsening left forefoot gangrene. Pt reports that 5 days ago he noticed a blackened area on the plantar aspect of the left 2nd toe that progressed to involve the entire forefoot. He describes throbbing pain 8/10, worse with elevation, partially relieved by OTC ibuprofen. Yesterday he noted foul, malodorous drainage and a low‑grade fever (T 100.2 °F) at home. He went to an outside ED (St. Mercy) where labs showed WBC 16.2, CRP 12.4, and foot X‑ray suggested possible osteomyelitis of the 2nd metatarsal. He received one dose of IV cefazolin and was transferred for definitive care and possible surgical debridement. Pt denies chest pain, SOB, dysuria, or recent trauma. He reports compliance with insulin glargine 30 U nightly and lisinopril 20 mg daily, but admits occasional missed doses of metformin due to poor appetite.  

ED Course (outside):  
Vitals on arrival: T 100.2 °F, HR 112, BP 138/78, RR 22, SpO2 96% RA. Received 1 L NS, cefazolin 1 g IV, and analgesia with morphine 4 mg IV. Foot exam: black necrotic tissue extending from distal 2nd toe to mid‑forefoot, edema, erythema, foul drainage. No palpable pulses distal to the ankle. Vascular US showed monophasic flow in posterior tibial artery.  

He was placed on broad‑spectrum antibiotics (piperacillin‑tazobactam 4.5 g q6h) and transferred.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2005  
• Peripheral Arterial Disease – s/p fem‑pop bypass 2018  
• Hypertension – on lisinopril  
• Chronic Kidney Disease Stage 3 – baseline Cr 1.6 mg/dL  
• Hyperlipidemia – on rosuvastatin 10 mg daily  
• Prior left great toe amputation 2020 (complication of DFU)  

Past Surgical History:  
• Left great toe amputation – 2020  
• Femoral‑popliteal bypass – 2018  

Family History:  
Father – HTN, MI at 62  
Mother – DM2, CKD  
Sister – healthy  

Social History:  
Marital Status: Married, spouse Jane Whitaker  
Occupation: Retired electrician  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Own home, lives with spouse, independent ADLs  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue.  
HEENT: Negative.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for dyspnea, cough.  
GI: Negative for N/V, abdominal pain.  
GU: Negative for dysuria, hematuria.  
Musculoskeletal: Positive for left foot pain, swelling, foul drainage.  
Skin: Positive for black necrotic tissue on left foot.  
Neurologic: Negative for weakness, numbness above ankle.  
Psych: Negative for depression/anxiety.  

Prior to Admission Medications:  
Medication Sig  
insulin glargine 30 U SC nightly  
metformin 1000 mg PO BID  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
aspirin 81 mg PO daily  
glipizide 5 mg PO daily (as needed)  

Allergies: No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs:  
Temp 37.9 °C (100.2 °F)  
HR 108 bpm (irregularly irregular)  
RR 22 /min  
BP 136/76 mmHg  
SpO2 96% RA  

General: Alert, oriented x3, in mild distress due to foot pain.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Irregularly irregular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: Left foot – black necrotic tissue involving plantar 2nd toe to mid‑forefoot, edema, foul odor, purulent drainage, no palpable dorsalis pedis or posterior tibial pulses; right foot – warm, 2+ pulses, no lesions.  
Skin: No other rashes or lesions.  
Neurologic: Grossly non‑focal, sensation decreased to light touch distal left foot.  

Data/Results:  
Laboratory:  
CBC – WBC 16.2 K/µL, Hgb 11.8 g/dL, Plt 312 K/µL  
BMP – Na 138, K 4.5, Cl 102, CO2 22, BUN 28, Cr 1.7, Glu 212 mg/dL  
CRP 12.4 mg/dL, ESR 78 mm/hr  
Lactate 1.2 mmol/L  
ABG – pH 7.32, pCO2 30, HCO3‑ 16 (consistent with metabolic acidosis from DKA? but glucose not >250)  

Microbiology:  
Wound culture pending (collected in ED).  
Blood cultures x2 – no growth at 24 h.  

Imaging:  
Foot X‑ray (left) – soft tissue gas, cortical irregularity of 2nd metatarsal suggestive of early osteomyelitis.  
Duplex US – monophasic flow in posterior tibial artery, absent dorsalis pedis flow.  

Assessment and Plan:  
1. Left foot gangrene with probable osteomyelitis, secondary to diabetic foot infection.  
   • Vascular surgery consult for possible revascularization vs. amputation.  
   • Orthopedic surgery/foot & ankle consult for urgent debridement/amputation.  
   • Continue broad‑spectrum IV antibiotics: piperacillin‑tazobactam 4.5 g q6h; add vancomycin pending MRSA risk (dose per PK).  
   • Wound care team to apply wet‑to‑dry dressings, monitor drainage.  
   • Serial labs q24h, CRP trend, CBC.  
   • NPO until surgical plan finalized; start IVF 0.9% NS at 125 mL/hr, adjust for CKD.  

2. Diabetes mellitus – hyperglycemia on admission.  
   • Start insulin drip (regular insulin 0.1 U/kg/hr) with target glucose 140‑180 mg/dL.  
   • Transition to basal‑bolus regimen when stable.  

3. Hypertension – continue lisinopril 20 mg daily; monitor BP.  

4. CKD‑3 – adjust meds as needed, avoid nephrotoxic agents.  

5. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  

6. Nutrition – consult dietitian for diabetic renal diet, protein 1.2 g/kg.  

7. Code status – Full Code (presumed).  

8. Disposition – Admit to surgical floor with telemetry for arrhythmia monitoring (irregularly irregular rhythm).  

9. Patient education – discussed nature of gangrene, need for possible amputation, importance of glucose control, smoking cessation (though never smoked).  

Signature:  
Dr. Nathaniel P. Rhodes, MD  
Hospitalist Attending  
Pager # 8421  

"A portion of this record may have been created with voice recognition software; occasional transcription errors may be present. Please verify all data."');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (75, 75, 41260837596, 41260837596, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
Date of Admission: 03/26/3054 22:33  
Location: MED01  
Attending: Dr. Eleanor V. Sample, MD  

Patient: Marcus J. Whitaker  
DOB: 07/14/2996  
MRN: 45278901  
PCP: Dr. Harold K. Greene, MD  

Chief Complaint: Fever, chills, generalized malaise  

History of Present Illness:  
58yo M with h/o T2DM (A1c 9.2%), CKD3 (eGFR 45), HTN, COPD s/p tobacco cessation 5 y ago, and recent discharge from outside hospital (03/20/3054) for uncomplicated UTI now presents w/ 3‑day history of non‑localizing fever up to 39.4°C, rigors, diffuse myalgias and fatigue. Patient reports that after completing a 5‑day course of oral ciprofloxacin he felt “better” but on day 2 post‑therapy he developed low‑grade fevers again, now higher, associated with night sweats. Denies cough, dyspnea, chest pain, dysuria, abdominal pain, nausea/vomiting, diarrhea, rash, or focal pain. No recent travel, no known sick contacts. He notes that his home glucose logs have been 180‑250 mg/dL despite usual metformin/glipizide regimen. He has been drinking water but feels “dehydrated”. No change in mental status.  

Patient was seen in the ED of this facility at 20:15, where vitals showed T 38.9°C, HR 112, BP 138/78, RR 22, SpO2 95% on RA. Labs drawn showed leukocytosis with left shift, mild AKI on top of CKD, and hyperglycemia. Blood cultures and urinalysis were obtained. Empiric IV ceftriaxone 1 g q24h and IV normal saline bolus were started. He was admitted for further work‑up of fever of unknown origin (FUO) and possible sepsis.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2008  
• Chronic Kidney Disease Stage 3 – baseline Cr 1.6 mg/dL (eGFR ~45)  
• Hypertension – on lisinopril 20 mg daily  
• COPD – former smoker 30 pack‑yr, quit 5 y ago, on tiotropium inhaler daily  
• Hyperlipidemia – on rosuvastatin 10 mg daily  
• Osteoarthritis – knees  

Past Surgical History:  
• Right total knee arthroplasty – 04/12/3049  
• Appendectomy – 06/03/3002  

Family History:  
Father – HTN, died MI age 68  
Mother – CKD secondary to diabetes, alive 78  
Brother – alive, no major illness  

Social History:  
Marital Status: Married, spouse Jane Whitaker  
Children: 2 adult daughters, both living at home  
Employment: Retired electrician, now part‑time handyman  
Tobacco: Never smoker (quit 5 y ago)  
Alcohol: Social, 1‑2 drinks/week, no binge  
Illicit Drugs: Denies  
Living Situation: Single‑family home, owns home, has air conditioning, no pets  

Review of Systems:  
Constitutional: Positive for fever, chills, night sweats, fatigue; negative for weight loss.  
HEENT: No sore throat, no visual changes.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No cough, dyspnea, sputum.  
Gastrointestinal: No abdominal pain, N/V, diarrhea.  
Genitourinary: No dysuria, flank pain.  
Musculoskeletal: Generalized myalgias, no joint swelling.  
Neurologic: No headache, no focal deficits.  
Dermatologic: No rash.  
Psychiatric: No anxiety or depression noted.  

Prior to Admission Medications:  
metformin 1000 mg PO BID  
glipizide 10 mg PO daily  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
tiotropium inhaler 1 puff daily  
acetaminophen 500 mg PO q6h PRN for pain  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs (at time of exam): T 38.7°C, HR 108, RR 20, BP 136/76, SpO2 96% RA, Weight 92 kg (202 lb)  
General: Alert, oriented x3, appears mildly ill, diaphoretic, no acute distress.  
HEENT: Normocephalic, atraumatic, mucous membranes moist, oropharynx clear.  
Neck: Supple, no lymphadenopathy, no JVD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales or rhonchi.  
Abdomen: Soft, non‑tender, nondistended, bowel sounds present in all quadrants, no hepatosplenomegaly.  
Extremities: Warm, no edema, no cyanosis, pulses 2+ bilaterally.  
Skin: No rash, no lesions, diaphoresis noted.  
Neurologic: Grossly non‑focal, strength 5/5 in all extremities, sensation intact, reflexes 2+ symmetric.  

Laboratory Data (ED draw, 03/26/3054):  
CBC: WBC 14.2 K/µL (neutrophils 84%), Hgb 13.1 g/dL, Hct 39.2%, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 28 mg/dL, Cr 1.9 mg/dL (baseline 1.6), Glucose 242 mg/dL, Ca 9.1 mg/dL  
Lactate: 2.1 mmol/L  
CRP: 12 mg/dL (elevated)  
Procalcitonin: 0.8 ng/mL (moderately elevated)  
Urinalysis: Specific gravity 1.015, pH 6, trace protein, no leukocyte esterase, no nitrites, 2‑3 WBC/hpf, no bacteria seen.  
Blood cultures: x2 sets drawn, pending.  

Imaging:  
Chest X‑ray (03/26/3054 20:45): No infiltrates, cardiac silhouette normal, no effusion.  
Abdominal US (ordered, pending): To evaluate kidneys and biliary tree.  

Assessment and Plan:  
58yo M with T2DM, CKD3, HTN, COPD presenting with 3‑day fever of unknown origin, leukocytosis, mild AKI, hyperglycemia. Differential includes:  
1. Bacterial infection – possible occult urinary source despite negative UA, consider pyelonephritis, consider intra‑abdominal source, consider line‑associated infection (no lines placed yet).  
2. Viral infection – influenza, COVID‑19 (pending PCR), other respiratory viruses.  
3. Non‑infectious – drug fever (unlikely), autoimmune, malignancy (less likely acutely).  

Plan:  
- Continue IV ceftriaxone 1 g q24h; add vancomycin pending cultures and MRSA risk (recent hospitalization).  
- Obtain SARS‑CoV‑2 PCR (nasopharyngeal) and respiratory viral panel.  
- Repeat CBC, BMP, lactate q12h until stable.  
- Initiate insulin sliding scale for glucose >180 mg/dL; hold metformin while AKI present.  
- Fluid management: 1 L NS bolus completed, then maintenance 125 mL/hr; monitor intake/output, avoid fluid overload given CKD.  
- Consult Nephrology for AKI on CKD management.  
- Infectious Diseases consult for FUO work‑up if cultures remain negative after 48 h.  
- DVT prophylaxis: SQ enoxaparin 40 mg daily (adjust for renal function).  
- Stress ulcer prophylaxis: PO pantoprazole 40 mg daily.  
- Continue home inhaler (tiotropium) and add PRN albuterol inhaler q4h PRN wheeze.  
- Monitor vitals q4h, telemetry not required at this time.  
- Education: Discuss signs of worsening infection, glucose control, importance of hydration.  

Disposition: Admit to General Medicine floor, low‑acuity, full code.  

Signature:  
Dr. Eleanor V. Sample, MD  
Attending Physician  
Pager: 84210');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (76, 76, 25180260459, 25180260459, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Hospital Admission History and Physical  
Date of Admission: 02/06/3087  
Time: 23:03  

Patient: Ethan Caldwell  
DOB: 09/15/3049  
MRN: 84276109  
PCP: Dr. Lila Monroe, MD  

Chief Complaint:  
Shortness of breath, bilateral lower extremity edema x3 days  

History of Present Illness:  
68yo M with h/o HTN, HLD, HFrEF (EF 30%), CKD stage 3, and recent URI p/w cough now presents with worsening dyspnea, orthopnea (2 pillows), PND, and 2+ pitting edema to mid‑calves for 3 days. Pt reports that 2 days ago he was seen at an urgent care where he received oral furosemide 40 mg and azithro for presumed bronchitis; symptoms minimally improved. This morning he awoke feeling “tight” in chest, unable to climb a flight of stairs without stopping, and noted weight gain of ~4 lb since yesterday. Denies chest pain, palpitations, fever, chills, syncope, or calf pain. No recent travel, no sick contacts. He reports compliance with metoprolol 100 mg daily, lisinopril 20 mg daily, and furosemide 40 mg BID at home. He has been restricting fluids but admits to “a few glasses of water” each night.  

Past Medical History:  
HTN – diagnosed 2005  
Hyperlipidemia – on rosuvastatin 10 mg daily  
Heart Failure, HFrEF – EF 30% (2025 echo)  
Chronic Kidney Disease – stage 3 (baseline Cr 1.6)  
Type 2 Diabetes Mellitus – A1c 7.8% (2024)  
Atrial Fibrillation – paroxysmal, on apixaban  

Past Surgical History:  
Cholecystectomy – 2012 laparoscopic  
Left total knee arthroplasty – 2020  

Family History:  
Father – MI at 62, HTN  
Mother – CKD, died of stroke at 78  
Brother – alive, HTN  

Social History:  
Marital Status: Married, lives with spouse  
Occupation: Retired electrician  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Single‑family home, stairs 2 flights  

Review of Systems:  
Constitutional – +fatigue, -fever, -weight loss  
HEENT – -headache, -vision changes  
Cardiovascular – +DOE, +orthopnea, +PND, -chest pain, -palpitations  
Respiratory – +dyspnea, -cough (now resolved), -hemoptysis  
GI – -nausea, -vomiting, -abdominal pain  
GU – -dysuria, -hematuria  
Musculoskeletal – +LE edema, -joint pain (except prior knee)  
Neurologic – -dizziness, -syncope  
Psych – -depression, -anxiety  

Prior to Admission Medications:  
metoprolol succinate 100 mg PO daily  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
furosemide 40 mg PO BID  
apixaban 5 mg PO BID  
metformin 1000 mg PO BID  
insulin glargine 20 U SC nightly  

Allergies:  
No known drug allergies  

Physical Examination:  
Vital Signs: Temp 36.8 °C (98.2 °F) | HR 112 bpm (irregularly irregular) | RR 22/min | BP 138/78 mmHg | SpO2 92% on RA | Weight 215 lb (97 kg) (up 4 lb)  

General: Alert, NAD, appears mildly dyspneic, sitting upright, using accessory muscles.  

HEENT: NC/AT, PERRLA, mucous membranes moist.  

Neck: JVD present, no thyromegaly.  

Cardiovascular: Irregularly irregular rhythm, S1,S2 normal, S3 present, no murmurs, no rubs.  

Respiratory: Bilateral basilar crackles 2/3, decreased breath sounds at bases, no wheezes.  

Abdomen: Soft, non‑tender, BS present, no hepatosplenomegaly.  

Extremities: 2+ pitting edema to mid‑calves bilaterally, warm, pulses 2+ bilat.  

Skin: No rashes, no ulcerations.  

Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.  

Labs (drawn 02/06/3087):  
CBC: WBC 9.2 K/µL, Hgb 13.1 g/dL, Hct 39.2%, Plt 210 K/µL  
BMP: Na 138 mmol/L, K 5.1 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 28 mg/dL, Cr 1.7 mg/dL (eGFR 45)  
Glucose 162 mg/dL (random)  
BNP 1120 pg/mL (elevated)  
Troponin I 0.04 ng/mL (reference <0.03)  
HbA1c 7.8% (2024)  

ECG: Atrial fibrillation with rapid ventricular response (~110 bpm), left axis deviation, no acute ST‑T changes.  

Chest X‑ray (PA): Cardiomegaly, pulmonary venous congestion, interstitial edema, small bilateral pleural effusions.  

Echocardiogram (2025): LVEF 30%, LV dilated, moderate MR, RV normal.  

Assessment and Plan:  
68yo M with h/o HTN, HLD, HFrEF (EF 30%), CKD‑3, AFib RVR, and recent URI now presents with acute decompensated heart failure (ADHF) manifested by dyspnea, orthopnea, PND, and new 2+ LE edema.  

1. ADHF – initiate IV furosemide 40 mg bolus then continuous infusion 10 mg/hr, monitor urine output, daily weights, electrolytes. Hold ACE‑I today (risk of AKI). Continue metoprolol, consider rate control with diltiazem if HR >110 after diuresis.  
2. Atrial fibrillation – rate control as above, continue apixaban (Cr 1.7 acceptable).  
3. CKD‑3 – monitor Cr, avoid NSAIDs, adjust diuretic as needed.  
4. Hypertension – BP currently 138/78; will re‑initiate lisinopril once Cr <1.5 and K <5.0.  
5. Diabetes – continue metformin (hold if lactic acidosis risk), insulin glargine nightly; check fingersticks q4h.  
6. Anemia – Hgb 13.1, no transfusion needed.  
7. Nutrition – low‑sodium diet (<2 g Na/day), fluid restriction 1.5 L/day.  
8. VTE prophylaxis – SQ enoxaparin 40 mg daily (adjust for Cr).  
9. Monitoring – telemetry for AFib, daily BMP, daily BNP trend, repeat CXR if clinically indicated.  
10. Disposition – admit to telemetry floor, anticipate 4‑5 day stay for diuresis and optimization.  

Code Status: Full Code (Presumed)  

Attending: Dr. Mara Whitfield, MD  
Pager: 8421  

--- End of Note ---');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (77, 77, 59949125785, 59949125785, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
12/04/3059  
16:19  

Patient: Miguel Alvarez  
DOB: 03/22/3019  
PCP: Dr. Lucia Ramos, MD  

Chief Complaint: Redness, purulent drainage, and pain at recent abdominal incision  

History of Present Illness:  
58yo M with h/o HTN, DM2 (A1c 8.7%), CKD stage 3, recent laparoscopic cholecystectomy (post‑op day 7) p/w erythema, warmth, serosanguinous drainage from RUQ port site, low‑grade fever 38.2°C, chills, N/V x1 day. Pt reports incision was fine first 3 days, then started to ooze thin yellow fluid on POD 5, now thicker purulent material with foul odor. Denies SOB, chest pain, dysuria. Pt took ibuprofen at home, no antibiotics. Presented to ED after wife noted increasing swelling and foul smell. In ED vitals: T 38.2, HR 112, BP 138/78, RR 20, SpO2 96% RA. Labs drawn, CT abdomen/pelvis showed fluid collection superficial to fascia, no intra‑abdominal abscess. Started on IV cefazolin 1 g q8h, wound cultures obtained. Pt now on telemetry for tachyarrhythmia risk due to HTN/DM.  

Past Medical History:  
• Hypertension – diagnosed 2015, on lisinopril 20 mg daily  
• Type 2 Diabetes Mellitus – on metformin 1000 mg BID, insulin glargine 30 U qHS  
• Chronic Kidney Disease stage 3 – baseline Cr 1.6 mg/dL  
• Hyperlipidemia – rosuvastatin 10 mg daily  

Past Surgical History:  
Procedure Laterality Date  
• Laparoscopic Cholecystectomy – RUQ – 12/27/3058  

Family History:  
Father – HTN, MI @ 62  
Mother – DM2, CKD  
Sister – healthy  

Social History:  
Marital Status: Married  
Occupation: Construction foreman  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Lives with spouse, two adult children, owns home  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.  
HEENT: Negative.  
Cardiovascular: Positive for palpitations (HR 112). Negative chest pain.  
Respiratory: Negative cough, dyspnea.  
GI: Positive for N/V x1 day, mild epigastric discomfort. No melena.  
GU: Negative dysuria, flank pain.  
Musculoskeletal: Negative joint pain.  
Skin: Positive for erythema, warmth, purulent drainage at RUQ incision. No other rashes.  
Neuro: Negative.  
Psych: Negative.  

Prior to Admission Medications:  
Medication Sig  
lisinopril 20 MG tablet TAKE 1 TABLET BY MOUTH DAILY  
metformin 1000 MG tablet TAKE 1 TABLET BY MOUTH BID  
insulin glargine 30 UNITS/ML injection SUBCUTANEOUS Inject 30 Units at bedtime  
rosuvastatin 10 MG tablet TAKE 1 TABLET BY MOUTH DAILY  
aspirin 81 MG EC tablet TAKE 1 TABLET BY MOUTH DAILY  

Allergies:  
No known drug allergies  

Physical Examination:  
Temperature: 38.2 °C (100.8 °F)  
Heart Rate: 112 bpm  
Respiratory Rate: 20/min  
Blood Pressure: 138/78 mmHg  
SpO2: 96% RA  
General: Alert, appears mildly ill, diaphoretic, in mild discomfort.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate, tachycardic, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  
Abdomen: Midline laparoscopic ports healed except RUQ 10‑mm port site: erythematous, 4 cm × 3 cm, warm, with purulent drainage noted on gauze. No rebound, no guarding. Bowel sounds present.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: As above, no other lesions.  
Neuro: AO×3, grossly non‑focal.  

Recent Labs:  
CBC –  
WBC 14.2 ×10^3/µL (Neut 86%)  
Hgb 12.8 g/dL  
Hct 38%  
Plt 312 ×10^3/µL  

BMP –  
Na 138 mmol/L  
K 4.5 mmol/L  
Cl 102 mmol/L  
CO2 24 mmol/L  
BUN 22 mg/dL  
Cr 1.7 mg/dL (baseline)  
Glucose 212 mg/dL  

CRP 12 mg/dL (elevated)  
Procalcitonin 0.8 ng/mL  

Wound culture: pending  

Imaging:  
CT Abdomen/Pelvis w/ contrast – superficial fluid collection along RUQ port tract, no intra‑abdominal abscess, no free air.  

Assessment and Plan:  
58yo M post‑op day 7 laparoscopic cholecystectomy with surgical site infection (SSI) of RUQ port, febrile, leukocytosis, purulent drainage – likely polymicrobial skin flora.  

1. SSI – start IV cefazolin 1 g q8h (adjust if culture shows MRSA → vancomycin). Continue wound care: daily dressing change, irrigation with normal saline, monitor output.  
2. Diabetes – glucose control: insulin sliding scale q4h, continue basal glargine, target BG 140‑180.  
3. Hypertension – continue lisinopril, monitor BP q8h.  
4. CKD – avoid nephrotoxic agents, monitor Cr daily, adjust antibiotics if needed.  
5. Pain – acetaminophen 650 mg q6h PRN, avoid NSAIDs given CKD.  
6. DVT prophylaxis – SQ enoxaparin 40 mg SC daily.  
7. Telemetry – for tachyarrhythmia risk, discontinue when HR <100 and stable.  
8. Labs – CBC, BMP, CRP q24h, wound culture results in 48 h.  
9. Diet – Diabetic/renal appropriate, low sodium, moderate protein.  
10. Code Status – Full Code (Presumed).  
11. Disposition – Admit to Med‑Surg floor, anticipate 4‑5 day stay pending response to antibiotics and wound healing.  

Attending: Dr. Rafael Mendoza, MD  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (78, 78, 43835184434, 43835184434, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 03/19/3077 07:19  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  
Resident: Dr. Luis Mendoza, MD  

Patient: Marcus L. Whitaker  
DOB: 11/02/3045 (31 y/o M)  
MRN: 84276109  
PCP: Dr. Sandra Kline, MD  

Chief Complaint: Redness, drainage, and increasing pain at laparoscopic cholecystectomy incision site  

History of Present Illness:  
31yo M with h/o laparoscopic cholecystectomy 10 days ago (post‑op day #10) now presents w/ erythema, serosanguinous drainage, and throbbing pain at RUQ port site. Pt reports that incision was clean on POD #3, but over the past 48 h he noted increasing warmth, purulent yellow‑green discharge, and low‑grade fevers up to 100.8°F (38.2°C) measured at home. Denies SOB, chest pain, N/V/D, or abdominal distention. Pt states he has been taking ibuprofen 600 mg q6h PRN for pain, but relief minimal. He stopped his prophylactic cefazolin 24 h ago per discharge instructions. No recent travel. He visited urgent care on POD #7 for mild wound irritation; they prescribed topical bacitracin and told him to monitor. Since then symptoms have progressed despite topical therapy. Pt reports mild fatigue, but no chills, rigors, or night sweats. He is afebrile on arrival (36.9°C) but appears uncomfortable, guarding the incision when palpated.  

Past Medical History:  
• Cholelithiasis – status post laparoscopic cholecystectomy 10 d ago  
• Hypertension – controlled on lisinopril 10 mg daily  
• Obesity (BMI 32)  

Past Surgical History:  
Procedure Laterality Date  
• Laparoscopic cholecystectomy – RUQ – 03/09/3077  

Family History:  
Father – HTN, MI at 58 y; Mother – DM2; Sister – healthy  

Social History:  
Marital Status: Single, lives alone in apartment.  
Employment: Software engineer, works from home.  
Tobacco: Never smoker.  
Alcohol: Social, 1‑2 drinks/week.  
Illicit drugs: Denies.  
Sexual activity: Heterosexual, monogamous, uses condoms intermittently.  

Review of Systems:  
Constitutional: Positive for low‑grade fever, fatigue; negative for weight loss, night sweats.  
HEENT: Negative.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea.  
GI: Positive for RUQ tenderness; negative for N/V/D, melena.  
GU: Negative.  
Musculoskeletal: Negative except for localized wound pain.  
Skin: Positive for erythema, purulent drainage at incision; negative for rash elsewhere.  
Neurologic: Negative.  
Psych: Negative.  

Medications Prior to Admission:  
Lisinopril 10 mg PO daily  
Ibuprofen 600 mg PO q6h PRN for pain (taken x3 days)  
Cefazolin 1 g IV q8h x24 h (post‑op prophylaxis, completed)  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs: T 36.9 °C, HR 94, RR 18, BP 128/76, SpO2 98% RA, Pain 7/10.  
General: Alert, oriented x3, appears mildly uncomfortable, no acute distress.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, mildly tender RUQ, surgical staples intact, incision 5 cm right subcostal with erythema extending 2 cm, serosanguinous purulent drainage noted, no fluctuance.  
Extremities: No edema, pulses 2+ bilat.  
Skin: As above, no other lesions.  
Neuro: Grossly non‑focal, AOx3.  

Labs (drawn 03/19/3077 07:45):  
CBC: WBC 14.2 K/µL (neutrophils 84%), Hgb 13.1 g/dL, Plt 312 K/µL  
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 112  
CRP: 12.8 mg/dL (elevated)  
ESR: 38 mm/hr  
Lactate: 1.2 mmol/L  

Imaging:  
Wound ultrasound (03/19/3077 08:10) – shows 1.2 cm hypoechoic collection superficial to fascia with internal echoes consistent with abscess; no deep fluid collection.  

Assessment and Plan:  
31yo M s/p laparoscopic cholecystectomy now with surgical site infection (SSI) w/ superficial abscess formation at RUQ port site.  
- Start IV ceftriaxone 2 g q24h + metronidazole 500 mg q8h for broad gram‑positive/anaerobic coverage.  
- Incision & drainage performed at bedside under sterile technique; 15 mL purulent material evacuated, wound packed with iodo‑drape. Send culture & sensitivity.  
- Pain control: Acetaminophen 1 g PO q6h PRN, continue ibuprofen 600 mg PO q8h if renal function stable.  
- Monitor vitals q4h, WBC daily, wound inspection q12h.  
- DVT prophylaxis: SQ enoxaparin 40 mg SC daily.  
- Continue lisinopril 10 mg PO daily.  
- Advise wound care: daily dressing changes, keep area dry, avoid heavy lifting >10 lb for 2 weeks.  
- Discharge planning: anticipate discharge on POD #3 after clinical improvement, oral antibiotics (cephalexin 500 mg PO q6h x7 d) pending culture results.  
- Education: signs of worsening infection (increasing pain, fever, spreading erythema) to return to ED.  

Code Status: Full Code (Presumed)  
Disposition: Admit to Med‑Surg floor, telemetry not required.  

Evelyn Hartwell, MD  
Attending Physician  
Pager: 22457');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (79, 79, 72840360570, 72840360570, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 08/16/3055 15:20  
Location: EXAMP04B  
Service: Internal Medicine  

Patient: Michael J. Sample  
MRN: 98765432  
DOB: 02/14/3015 (40 y/o M)  
PCP: Dr. Laura Example, MD  

Chief Complaint: Dysuria, suprapubic pain, low‑grade fever  

History of Present Illness:  
40yo M with h/o T2DM (A1c 8.7%), HTN, CKD‑3, recent prostatitis p/w dysuria, urgency, nocturia, mild suprapubic tenderness, N/V/D and low‑grade fever x3 days. Pt reports that 5 days ago he completed a 10‑day course of ciprofloxacin for presumed UTI prescribed by his PCP; symptoms improved briefly then recurred with worsening pain and now occasional hematuria. He denies flank pain, chills, rigors, or recent catheterization. Pt states he had a similar episode 2 yr ago that resolved with TMP‑SMX. He went to urgent care 2 days ago, was given a PO levofloxacin 500 mg daily, but stopped after 2 doses because of GI upset. He now presents to ED after a febrile episode (T 38.3 °C) at home and worsening dysuria.  

Review of Systems:  
Constitutional: +fever, +fatigue, –weight loss, –chills.  
HEENT: –sore throat, –visual changes.  
Cardiovascular: –chest pain, –palpitations.  
Respiratory: –cough, –dyspnea.  
GI: +N/V, –diarrhea, –abdominal pain.  
GU: +dysuria, +suprapubic pain, +hematuria, –frequency change.  
Musculoskeletal: –myalgias, –arthralgias.  
Neurologic: –headache, –dizziness.  
Psych: –depression, –anxiety.  

Past Medical History:  
• Type 2 Diabetes Mellitus (diagnosed 2015)  
• Hypertension  
• Chronic Kidney Disease stage 3 (baseline Cr 1.6)  
• Hyperlipidemia  
• Prior acute prostatitis 2022 (treated with TMP‑SMX)  

Past Surgical History:  
• Appendectomy (2008)  
• Right inguinal hernia repair (2019)  

Family History:  
Father: HTN, MI at 62.  
Mother: DM2, CKD.  
Brother: Healthy.  

Social History:  
Marital Status: Married.  
Occupation: Software engineer, works from home.  
Tobacco: Never smoker.  
Alcohol: Social, 1‑2 drinks/week.  
Illicit drugs: Denies.  
Sexual activity: Heterosexual, monogamous, last intercourse 3 days ago, uses condoms inconsistently.  

Allergies: No known drug allergies (NKDA).  

Medications Prior to Admission:  
metformin 1000 mg PO BID  
lisinopril 20 mg PO daily  
atorvastatin 40 mg PO nightly  
amlodipine 5 mg PO daily  
furosemide 20 mg PO daily  
tamsulosin 0.4 mg PO nightly (for BPH)  

Physical Examination:  
Vital Signs: T 38.2 °C, HR 102, RR 18, BP 138/84, SpO2 98% RA, Weight 92 kg (202 lb).  
General: Alert, appears mildly uncomfortable, NAD otherwise.  
HEENT: Normocephalic, oropharynx erythematous, no exudate.  
Neck: Supple, no lymphadenopathy.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  
Abdomen: Soft, mild suprapubic tenderness to palpation, no rebound, no guarding, no CVA tenderness.  
Genitourinary: No external lesions, prostate not examined (patient supine, deferred).  
Extremities: No edema, pulses 2+ bilat.  
Skin: Warm, dry, no rashes.  
Neuro: AOx3, CN II‑XII grossly intact.  

Laboratory Data (drawn 08/16/3055):  
CBC: WBC 13.2 K/µL (neut 84%), Hgb 13.5 g/dL, Plt 312 K/µL.  
BMP: Na 138, K 4.5, Cl 102, CO2 24, BUN 28, Cr 1.8 (baseline 1.6), Glu 162 mg/dL.  
CRP: 12 mg/dL (elevated).  
Urinalysis: Cloudy, pH 6.5, WBC 45/hpf, RBC 12/hpf, nitrite positive, leukocyte esterase +++.  
Urine culture: pending.  
Prostate specific antigen (PSA): 2.1 ng/mL (baseline 1.8).  

Imaging:  
Renal/bladder ultrasound (08/16/3055): No hydronephrosis, bladder wall mildly thickened, prostate size 32 cc, no focal lesions.  

Assessment and Plan:  
40yo M with h/o DM2, HTN, CKD‑3 and recent prostatitis now presenting with acute bacterial prostatitis (ABP) complicated by possible resistant uropathogen, mild sepsis, and CKD‑exacerbated renal insufficiency.  

1. Acute bacterial prostatitis – start IV ceftriaxone 2 g q24h + oral levofloxacin 750 mg daily (adjust for Cr). Hold ciprofloxacin due to prior course. Monitor renal function, adjust dosing.  
2. Diabetes – continue metformin, hold if Cr >1.8; check fingerstick q6h, insulin sliding scale as needed.  
3. Hypertension – continue lisinopril, monitor BP; consider holding furosemide if volume status stable.  
4. CKD – maintain euvolemia, avoid nephrotoxic agents, repeat BMP q24h.  
5. Pain control – acetaminophen 650 mg PO q6h PRN, avoid NSAIDs given CKD.  
6. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  
7. Diet – NPO initially for IV antibiotics, then advance to low‑salt renal diet.  
8. Monitoring – telemetry not required, but continuous cardiac monitor for tachyarrhythmia given HR 102. Repeat vitals q4h, urine output strict I/O.  
9. Disposition – admit to Med‑Surg floor, anticipate 5‑7 day course of IV antibiotics then step‑down to PO.  
10. Education – counsel on completing full antibiotic course, fluid intake, follow‑up Urology as outpatient.  

Code Status: Full Code (Presumed)  

Attending: Dr. Samantha Realname, MD  
Pager: 67890  

Prepared by: Resident Physician, Internal Medicine  
08/16/3055 15:45');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (80, 80, 77435497885, 77435497885, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
05/01/3095 22:26  

Patient: Marcus L. Whitaker  
DOB: 02/14/3065  
MRN: 98765432  
PCP: Dr. Evelyn Hart, MD  

Chief Complaint: Right forearm swelling, erythema, pain  

History of Present Illness:  
58yo M with h/o T2DM (A1c 9.1% 03/15/3095), HTN, CKD stage 3, and recent PICC line removal p/w cellulitis of R forearm presents to ED after 2 days of progressive swelling, warmth, and throbbing pain. Pt reports the area started as a small “red spot” after a minor laceration while gardening 48 h ago, then rapidly expanded to involve the entire distal forearm and dorsal hand. He notes feverish chills, subjective fever up to 101°F, and malaise. Denies any trauma beyond the initial scratch, no known bites, no IV drug use. He took OTC ibuprofen 400 mg q6h with minimal relief. Pt was seen at an urgent care 24 h ago, prescribed cephalexin 500 mg PO q6h, but compliance poor due to nausea; he stopped meds after one dose. In the ED, vitals: T 38.9 °C, HR 112, BP 138/84, RR 22, SpO2 97% RA. Labs showed WBC 15.2 K with left shift, CRP 12 mg/dL. Bedside US of the forearm showed subcutaneous edema, no abscess. Pt was given IV cefazolin 1 g q8h and admitted for IV antibiotics and close monitoring.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2015, insulin‑requiring  
• Hypertension – on lisinopril  
• Chronic Kidney Disease stage 3 – baseline Cr 1.6 mg/dL  
• Hyperlipidemia – on rosuvastatin  
• GERD – on omeprazole  

Past Surgical History:  
• Appendectomy – 12/02/3070  
• Right knee arthroscopy – 06/15/3085  

Family History:  
Father – HTN, MI at 62  
Mother – DM2, CKD  
Sister – healthy  

Social History:  
Marital Status: Married, spouse Jane Whitaker  
Children: 2 (ages 12 & 9)  
Occupation: Maintenance supervisor at municipal building  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Single‑family home, owns pet dog  

Review of Systems:  
Constitutional – fever, chills, fatigue.  
HEENT – no sore throat, no visual changes.  
Cardiovascular – no chest pain, palpitations.  
Respiratory – no cough, dyspnea.  
GI – N/V mild, no abdominal pain.  
GU – no dysuria.  
Musculoskeletal – right forearm pain, swelling, erythema; no other joint pain.  
Skin – localized cellulitis, no rash elsewhere.  
Neuro – no headache, no focal deficits.  
Psych – mild anxiety about infection.  

Prior to Admission Medications:  
Medication Sig  
metformin 500 mg PO BID  
insulin glargine 30 U SC nightly  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
omeprazole 20 mg PO daily  
aspirin 81 mg EC PO daily  

Allergies:  
Penicillin – rash (hives)  

Physical Examination:  
Vital Signs: Temp 38.9 °C, HR 112, RR 22, BP 138/84, SpO2 97% RA, Weight 102 kg (225 lb)  
General: Alert, appears mildly ill, in no acute distress aside from forearm pain.  
HEENT: Normocephalic, PERRLA, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate, regular rhythm, S1 S2 normal, no murmurs.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: Right forearm – diffuse erythema, warmth, edema extending from wrist to mid‑forearm, tender to palpation, no fluctuance, no crepitus. No lymphangitic streaking noted. No cellulitis elsewhere. No edema of lower extremities.  
Skin: No rashes, lesions, or ulcerations elsewhere.  
Neurologic: AOx3, grossly non‑focal.  

Recent Labs:  
CBC – WBC 15.2 K (Neut 84%), Hgb 13.1 g/dL, Hct 39%, Plt 312 K  
BMP – Na 138, K 4.3, Cl 102, CO2 24, BUN 22, Cr 1.7 mg/dL (eGFR ~38 mL/min), Glu 212 mg/dL  
CRP – 12 mg/dL (ref <0.5)  
ESR – 48 mm/hr  
Liver panel – within normal limits  
Blood cultures – drawn x2, pending  

Imaging:  
Bedside ultrasound – subcutaneous edema, no discrete fluid collection.  
Plain radiograph of forearm – no foreign body, no gas.  

Assessment and Plan:  
1. Right forearm cellulitis, likely streptococcal/ staphylococcal, no abscess.  
   • Continue IV cefazolin 1 g q8h; monitor renal function, adjust dose if Cr >2.0.  
   • Add IV vancomycin 15 mg/kg q12h pending MRSA risk (penicillin allergy, recent healthcare exposure).  
   • Re‑evaluate for need of surgical drainage if fluctuance develops.  
   • Elevate limb, apply warm compresses, analgesia with acetaminophen 650 mg PO q6h PRN.  

2. Diabetes mellitus – hyperglycemia on admission.  
   • Hold metformin (renal insufficiency).  
   • Start insulin sliding scale: 4 U regular insulin qSC q6h PRN BG >180, adjust basal glargine to 35 U nightly.  

3. Hypertension – BP currently controlled; continue lisinopril 20 mg daily, monitor K.  

4. CKD stage 3 – avoid nephrotoxic agents, monitor Cr daily, adjust antibiotics accordingly.  

5. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  

6. Nutrition – Diabetic diet, glucose target 80‑180 mg/dL.  

7. Activity – Encourage ambulation as tolerated, keep forearm elevated.  

8. Disposition – Admit to Medicine floor, telemetry not required.  

9. Labs/Imaging – CBC, BMP, CRP q24h, repeat blood cultures in 48 h, consider repeat US if clinical change.  

10. Education – Discuss wound care, signs of worsening infection, importance of completing IV antibiotics.  

Code Status: Full Code (Presumed)  

Attending: Dr. Samuel K. Rivera, MD  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (81, 81, 43016647224, 43016647224, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
04/24/3087 11:16  

Patient: Marcus L. Whitaker  
DOB: 02/14/3049 (38 y/o)  
PCP: Dr. Elaine V. Harrow, MD  

CHIEF COMPLAINT: Dysuria, suprapubic pain, low‑grade fever  

HISTORY OF PRESENT ILLNESS:  
38yo M with h/o T2DM (A1c 8.7%), HTN, and recent prostatitis p/w dysuria, urgency, nocturia, suprapubic tenderness, N/V/D and mild left flank discomfort. Symptoms began 4 days ago after a weekend camping trip; he reports “burning” on urination, cloudy urine, and intermittent chills. He self‑started ibuprofen 400 mg PO q6h and a 5‑day course of ciprofloxacin 500 mg BID prescribed by his urgent‑care clinic 2 days ago, but reports worsening pain and now a Tmax of 38.4 °C (101.1 °F) at home. Denies gross hematuria, penile discharge, or recent sexual partners. He was seen at an outside ED on 04/22/3087 where a UA showed WBC 45/hpf, nitrites positive, and a non‑contrast CT abdomen/pelvis was negative for stones. He was discharged on oral levofloxacin 750 mg daily for 7 days and instructed to follow up with urology. He returned to the ED because pain persisted, now with new left flank “pressure” and a single episode of vomiting. No travel, no known sick contacts.  

ED COURSE: Vitals on arrival: T 38.2 °C, HR 102, BP 138/84, RR 20, SpO2 98% RA. Labs: CBC w/ diff, BMP, CRP, UA, blood cultures. Imaging: bedside renal US – no hydronephrosis. Started on IV ceftriaxone 1 g q24h, analgesia with IV ketorolac, NPO. Urology consulted; recommendation for admission for IV antibiotics and close monitoring of possible acute bacterial prostatitis with possible progression to prostatitis‑related sepsis.  

PAST MEDICAL HISTORY:  
• Type 2 Diabetes Mellitus – diagnosed 2018, on metformin 1000 mg BID  
• Hypertension – on lisinopril 20 mg daily  
• Hyperlipidemia – on rosuvastatin 10 mg nightly  
• Obstructive Sleep Apnea – CPAP nightly  

PAST SURGICAL HISTORY:  
• Appendectomy – Laparoscopic – 03/12/3065  
• Right inguinal hernia repair – Open – 07/08/3072  

FAMILY HISTORY:  
Father – HTN, MI at 55  
Mother – DM2, CKD stage 3  
Brother – Healthy  

SOCIAL HISTORY:  
Marital Status: Married, spouse Jane Whitaker (no med hx)  
Children: 2 (ages 5 and 8)  
Occupation: Software engineer, works from home  
Tobacco: Never smoker  
Alcohol: Social – 1‑2 drinks/week  
Illicit drugs: Denies  
Sexual activity: Heterosexual, monogamous, uses condoms intermittently  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.  
HEENT: Negative.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea.  
GI: Positive for nausea, vomiting x1; negative for abdominal pain aside from suprapubic.  
GU: Positive for dysuria, urgency, suprapubic pain, left flank pressure; negative for hematuria, discharge.  
Musculoskeletal: Negative.  
Neurologic: Negative.  
Psychiatric: Negative.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
metformin 1000 mg PO BID  
lisinopril 20 mg PO daily  
rosuvastatin 10 mg PO nightly  
ciprofloxacin 500 mg PO BID (started 04/22, discontinued)  
ibuprofen 400 mg PO q6h PRN  

ALLERGIES: No known drug allergies  

PHYSICAL EXAMINATION:  
Temperature: 38.2 °C (100.8 °F)  
Heart Rate: 102 bpm  
Respiratory Rate: 20/min  
Blood Pressure: 138/84 mmHg  
SpO2: 98% RA  

General: Alert, oriented x3, appears mildly uncomfortable, no acute distress.  
HEENT: Normocephalic, atraumatic, oropharynx clear, no lesions.  
Neck: Supple, no lymphadenopathy, no jugular venous distention.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.  
Abdomen: Soft, mildly tender suprapubic region, no rebound, no guarding, bowel sounds present.  
Genitourinary: Tenderness on palpation of prostate via digital exam – prostate enlarged, boggy, tender to pressure. No scrotal swelling.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neuro: Grossly non‑focal, strength 5/5 all extremities.  

LABS (drawn 04/24/3087):  
CBC WBC 13.2 ×10^3/µL, Hgb 13.5 g/dL, Hct 40.2%, Plt 312 ×10^3/µL  
BMP Na 138, K 4.3, Cl 102, CO2 24, BUN 16, Cr 0.9, Glu 162 mg/dL  
CRP 12 mg/dL (elevated)  
Procalcitonin 0.42 ng/mL (moderately elevated)  
UA WBC 45/hpf, RBC 2‑3/hpf, Nitrites positive, Leukocyte esterase +++  
Blood cultures x2 pending  

IMAGING:  
Renal US (04/24) – No hydronephrosis, kidneys normal size, no stones.  
CT Abdomen/Pelvis w/ contrast (performed 04/22) – Prostate enlarged (~45 cc), periprostatic fat stranding, no abscess, no obstruction.  

ASSESSMENT AND PLAN:  
1. Acute bacterial prostatitis – likely E. coli, presenting with dysuria, suprapubic pain, low‑grade fever, and periprostatic inflammation on CT. Admit for IV ceftriaxone 1 g q24h × 5‑7 days, transition to oral fluoroquinolone (levofloxacin 750 mg daily) to complete 14‑day course. Monitor vitals q4h, repeat CBC and BMP daily.  

2. Type 2 Diabetes Mellitus – glucose 162 mg/dL on admission; continue metformin, add sliding‑scale insulin (regular 4 U qSC qAC) pending glucose trends.  

3. Hypertension – BP currently controlled; continue lisinopril.  

4. Hyperlipidemia – continue rosuvastatin.  

5. Pain control – IV ketorolac 15 mg q6h PRN, transition to PO ibuprofen 400 mg q6h PRN when tolerating PO.  

6. DVT prophylaxis – SQ enoxaparin 40 mg SC daily.  

7. Diet – NPO initially, advance to clear liquids when afebrile, then regular diet as tolerated.  

8. Activity – Bed rest with bathroom privileges; ambulate as tolerated after pain control.  

9. Disposition – Admit to General Medicine floor, telemetry not required unless arrhythmia develops.  

10. Follow‑up – Urology to reassess prostate exam on day 3; repeat UA and cultures in 48 h.  

CODE STATUS: Full Code (Presumed)  

Prepared by: Dr. Nathaniel K. Sloane, MD  
Hospitalist, Example Medical Center  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (82, 82, 24986201085, 24986201085, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Alex J. Rivera
DOB: 03/14/3053
MRN: 98765432
PCP: Dr. Maya L. Ortiz, MD

Date of Admission: 12/22/3081
Time: 14:57
Location: MED01
Attending Provider: Dr. Samuel K. Whitman, MD

Chief Complaint: Penile discharge and dysuria

History of Present Illness:
28yo M with h/o multiple unprotected sexual encounters (M/F) over past 2 mo, recent onset of purulent urethral discharge, burning dysuria, mild suprapubic discomfort, and low grade fever (~38.2°C) presents to ED. Pt reports that symptoms began 3 days ago after a weekend “hook‑up” with a new partner; initially noted clear discharge that became yellow‑green and thick. Denies hematuria, testicular pain, or rash. Pt tried OTC phenazopyridine with minimal relief. He also notes mild fatigue and occasional chills but no nausea/vomiting. No prior history of STIs; last STI screen 1 yr ago was negative. Pt reports occasional marijuana use, denies tobacco or alcohol. No recent travel. He was evaluated at an urgent care 1 day ago, given a presumptive dose of azithromycin for presumed chlamydia; symptoms persisted, prompting ED visit. In ED, vitals: T 38.2°C, HR 96, BP 122/78, RR 18, SpO2 99% RA. Labs drawn, urine NAAT pending. Physical exam notable for copious yellow‑green urethral discharge on gentle expression, mild penile erythema, no lesions. No inguinal adenopathy. Abdomen soft, non‑tender. No CVA tenderness.

Past Medical History:
- Hypertension (diagnosed 3075) – controlled on lisinopril
- Seasonal allergic rhinitis

Past Surgical History:
- Appendectomy (3060)

Family History:
Mother – HTN, alive 68
Father – CAD, deceased 3078 MI
Sister – healthy

Social History:
Marital Status: Single
Occupation: Software developer (remote)
Tobacco: Never
Alcohol: Social occasional (1‑2 drinks/week)
Illicit Drugs: Marijuana occasional
Sexual Activity: Heterosexual, 3 partners past 6 mo, uses condoms inconsistently
Living Situation: Lives alone in apartment

Review of Systems:
Constitutional: +Fever, +Fatigue, -Weight loss
HEENT: -Sore throat, -Vision changes
Cardiovascular: -Chest pain, -Palpitations
Respiratory: -Cough, -Dyspnea
GI: -Nausea, -Vomiting, -Diarrhea
GU: +Urethral discharge, +Dysuria, -Hematuria, -Testicular pain
Skin: -Rash, -Lesions
Neurologic: -Headache, -Dizziness
Psych: -Depression, -Anxiety

Prior to Admission Medications:
Medication                Sig
Lisinopril 10 MG tablet   TAKE 1 TABLET BY MOUTH DAILY
Cetirizine 10 MG tablet   TAKE 1 TABLET BY MOUTH DAILY PRN for allergies

Allergies:
No known drug allergies.

Physical Examination:
Temperature: 38.2°C
Heart Rate: 96 bpm
Respiratory Rate: 18/min
Blood Pressure: 122/78 mmHg
SpO2: 99% RA
General: Alert, oriented x3, appears mildly uncomfortable due to urethral pain.
HEENT: Normocephalic, PERRLA, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: RRR, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes.
Abdomen: Soft, non‑tender, no masses.
Genitourinary: External genitalia with erythematous meatus, copious yellow‑green discharge on gentle pressure; no lesions, no inguinal adenopathy.
Extremities: No edema, pulses 2+ bilaterally.
Skin: No rashes.
Neuro: AOx3, CN II‑XII grossly intact.

Data/Results:
CBC:
WBC 9.8 K/uL
Hgb 14.2 g/dL
Hct 42%
Plt 245 K/uL

BMP:
Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.9, Glucose 96

Urinalysis:
WBC 15/hpf, RBC 2/hpf, Nitrite negative, Leukocyte esterase +, Bacteria moderate

Urine NAAT (pending): Chlamydia trachomatis, Neisseria gonorrhoeae

Serum RPR: Non‑reactive
HIV 1/2 Ag/Ab: Negative

Impression and Plan:
28yo M with probable acute urethritis secondary to N. gonorrhoeae and/or C. trachomatis, presenting with purulent discharge, dysuria, and low grade fever. Plan: 
- Empiric CDC‑recommended therapy: Ceftriaxone 500 mg IM single dose + Doxycycline 100 mg PO BID x 7 days (cover chlamydia). 
- Counsel on safe sex practices, condom use, and partner notification; advise all recent sexual partners (within 60 days) to seek testing and treatment.
- Obtain urine NAAT results; if gonorrhea only, continue ceftriaxone alone; if chlamydia only, continue doxycycline alone.
- Repeat CBC and BMP in 48 hrs to monitor for any adverse effects.
- Provide education on potential side effects of doxycycline (photosensitivity, GI upset) and advise taking with food.
- Discharge planning: outpatient follow‑up with Infectious Diseases clinic in 3‑5 days, or return to ED if worsening pain, fever >38.5°C, or new scrotal swelling.
- DVT prophylaxis: SQ low‑dose heparin q8h while inpatient (though anticipated LOS <24h).
- Code Status: Full Code (Presumed)
- Diet: Regular
- Activity: Ambulate as tolerated.

Signature:
Samuel K. Whitman, MD
Attending Hospitalist
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (83, 83, 85174402248, 85174402248, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
01/17/3060  
20:15  

Patient: Michael Doe  
DOB: 03/22/3015  
MRN: 98765432  
PCP: Dr. Linda Sample, MD  

Chief Complaint: Dysuria, suprapubic pain, fever  

History of Present Illness:  
58yo M with h/o HTN, DM2 (A1c 8.7%), CKD‑3, recent Foley removal p/w dysuria, urgency, suprapubic tenderness, chills, N/V. Symptoms began ~48 h ago after discharge from outside acute care where he was treated for a complicated UTI/prostatitis. He reports 3‑4 episodes of burning on voiding per day, cloudy urine with occasional gross hematuria, low‑grade fever now up to 38.9 °C, chills, left flank discomfort. He completed 3 days of ciprofloxacin 500 mg BID but stopped due to nausea and vomiting; no other antibiotics since. He was admitted to a skilled‑nursing facility 5 days ago after a fall, had indwelling Foley for 7 days, removed 2 days prior to symptom onset. Denies recent sexual activity, no known sick contacts, no travel. Reports nocturia x3, mild lower abdominal cramping, and new‑onset mild confusion. He states he has been drinking ~2 cups of water daily, no alcohol or illicit drug use.  

Past Medical History:  
• Hypertension – diagnosed 2025, on lisinopril 20 mg daily  
• Type 2 Diabetes Mellitus – on metformin 1000 mg BID, A1c 8.7 % (03/3060)  
• Chronic Kidney Disease stage 3 (eGFR ~45 mL/min)  
• Benign Prostatic Hyperplasia – on tamsulosin 0.4 mg daily  
• Osteoarthritis of knees  

Past Surgical History:  
• Right total knee arthroplasty – 04/3055  
• Endoscopic sinus surgery – 11/3048  

Family History:  
Father – HTN, MI at 62  
Mother – DM2, CKD  
Brother – alive, no major illness  

Social History:  
Marital status: Married  
Living situation: Lives with spouse in single‑family home, independent ADLs  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Occupational: Retired electrician  

Allergies:  
No known drug allergies (NKDA)  

Medications Prior to Admission:  
lisinopril 20 mg PO daily  
metformin 1000 mg PO BID  
tamsulosin 0.4 mg PO daily  
aspirin 81 mg PO daily  
atorvastatin 20 mg PO nightly  

Review of Systems:  
Constitutional – fever, chills, mild fatigue, no weight loss.  
HEENT – no sore throat, no visual changes.  
Cardiovascular – no chest pain, palpitations.  
Respiratory – no cough, dyspnea.  
Gastrointestinal – N/V as above, no abdominal distention.  
Genitourinary – dysuria, suprapubic pain, urgency, nocturia, hematuria, no flank mass.  
Musculoskeletal – baseline OA pain, no new joint swelling.  
Neurologic – mild confusion, no focal deficits.  
Psychiatric – mood stable.  

Physical Examination:  
Vital Signs: Temp 38.9 °C, HR 112, RR 20, BP 138/78, SpO₂ 96 % RA, Weight 92 kg (202 lb).  
General: Appears mildly ill, alert but slightly disoriented to time.  
HEENT: Normocephalic, PERRLA, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.  
Abdomen: Soft, mild suprapubic tenderness, no rebound, no guarding, CVA tenderness left mild.  
Genitourinary: External genitalia normal, prostate non‑tender on DRE, no discharge.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, dry, no rashes.  
Neuro: AO×3 (person, place, time), mild confusion, no focal deficits.  

Laboratory Data (drawn 01/17/3060):  
CBC: WBC 14.2 ×10⁹/L (neut 88 %), Hgb 12.4 g/dL, Plt 312 ×10⁹/L.  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO₂ 22 mmol/L, BUN 28 mg/dL, Cr 1.8 mg/dL (baseline 1.5), Glucose 162 mg/dL.  
CRP: 12 mg/dL (elevated).  
Urinalysis: Cloudy, pH 6.0, WBC > 50/hpf, RBC 10‑15/hpf, nitrites positive, leukocyte esterase ++, bacteria many.  
Urine culture: pending.  
Blood cultures: x2 sets pending.  
Procalcitonin: 0.9 ng/mL.  

Imaging:  
Renal ultrasound (01/17/3060): No hydronephrosis, kidneys normal size, mild cortical echogenicity consistent with CKD.  

Assessment and Plan:  
58yo M with h/o HTN, DM2, CKD‑3, recent Foley removal p/w acute uncomplicated cystitis complicated by possible prostatitis → febrile UTI, likely ESBL‑producing organism pending culture.  

1. Urinary Tract Infection – start empiric IV cefepime 2 g q8h (adjust for Cr) and oral levofloxacin 750 mg daily for 7 days; hold if culture shows susceptibility to narrower agent.  
2. Diabetes – continue metformin; monitor glucose q4h, insulin sliding scale if >180 mg/dL.  
3. Hypertension – continue lisinopril; monitor BP q8h.  
4. CKD – avoid nephrotoxic agents, adjust cefepime dose (Cr 1.8 → 1 g q12h).  
5. BPH – continue tamsulosin; consider urology consult if urinary retention recurs.  
6. Fluid Management – IVF NS 1 L bolus then maintenance 75 mL/hr; monitor I/O.  
7. DVT Prophylaxis – SQ enoxaparin 40 mg daily (adjust for Cr).  
8. Monitoring – telemetry not required, but q8h vitals, daily CBC, BMP, repeat UA in 48 h.  
9. Education – counsel on completing full antibiotic course, hydration, signs of worsening infection.  

Disposition: Admit to Medicine floor, telemetry not needed. Code Status: Full Code.  

Michael Doe, MD  
Attending Hospitalist  
Pager 11223');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (84, 84, 57257157860, 57257157860, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Ethan Marlowe
DOB: 02/14/3062
MRN: 87432109
PCP: Lila Hart, MD
Date of Admission: 06/26/3087
Time: 19:56
Location: MedFloor 3B
Attending: Dr. Victor Selby, MD
Admitting Resident: Dr. Maya Chen, MD
Code Status: Full Code (Presumed)

Chief Complaint: Genital ulcer w/ dysuria and urethral discharge

History of Present Illness:
25yo M w/ hx of prior chlamydia (treated 2y ago) and HSV‑1 oral, now presents w/ 4‑day hx of painful ulcer on glans penis + copious yellow‑green urethral discharge, dysuria, and mild suprapubic discomfort. Denies fever, chills, N/V, or rash elsewhere. Reports unprotected vaginal intercourse 5 days ago with a new partner (female, age 23) who also reports recent “sores”. He also had oral sex with another partner 2 weeks ago. He took OTC ibuprofen x2 days with minimal relief. Went to urgent care 2 days ago, was given a single dose of cefixime and told to follow‑up; symptoms worsened, prompting ED visit where a rapid HIV test was negative and a NAAT was pending. In ED he was given PO doxy 100 mg BID and topical acyclovir cream, but discharge persisted. He now presents for admission for IV antibiotics, definitive STI work‑up, and pain control. No known drug allergies. No recent hospitalizations.

Past Medical History:
• Prior Chlamydia trachomatis infection (treated 2y ago)
• HSV‑1 oral infection
• Seasonal allergic rhinitis
• No chronic illnesses

Past Surgical History:
• Circumcision (elective) – 2005
• Appendectomy – 3070

Family History:
Mother – HTN, alive 58
Father – DM2, alive 60
Sister – healthy
No known hereditary diseases.

Social History:
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Sexual activity: Heterosexual, 3 partners past 6 mo, uses condoms inconsistently
Living situation: Lives with roommate in apartment
Employment: Retail associate, works evenings
Travel: None recent
Legal: No arrests

Review of Systems:
Constitutional: Negative for fever, weight loss, night sweats.
HEENT: Negative for sore throat, vision changes.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
GI: Mild suprapubic discomfort, no N/V, no melena.
GU: Positive for painful penile ulcer, urethral discharge, dysuria. No hematuria.
Skin: No rashes, lesions elsewhere.
Neurologic: Negative for headache, weakness.
Psych: Mild anxiety about STI, otherwise stable.

Prior to Admission Medications:
Medication                Sig
Doxycycline 100 mg PO BID   Start 06/24/3087 – ongoing
Acyclovir 400 mg PO TID    Start 06/24/3087 – ongoing
Ibuprofen 200 mg PO PRN    As needed for pain
Loratadine 10 mg PO daily  Seasonal allergies

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 37.8 °C (100.0 °F), HR 102, RR 18, BP 128/76, SpO2 98% RA, Pain 7/10.
General: Alert, mildly distressed by genital pain, NAD otherwise.
HEENT: Normocephalic, PERRLA, oropharynx clear, no lesions.
Neck: Supple, no LAD.
Cardiovascular: RRR, S1S2 normal, no murmurs.
Respiratory: Clear bilaterally, no wheezes or rales.
Abdomen: Soft, mild suprapubic tenderness, no rebound, no organomegaly.
Genitourinary: External genitalia: 1.5 cm shallow ulcer on dorsal glans, erythematous base, serosanguinous exudate. Urethral meatus with copious yellow‑green discharge. No inguinal adenopathy noted. Scrotum normal.
Extremities: Warm, no edema, pulses 2+.
Skin: No rashes, no petechiae.
Neuro: AOx3, CN II‑XII grossly intact.
Psych: Anxious but cooperative.

Labs and Diagnostics (drawn 06/26/3087):
CBC:
  WBC 12.4 K/µL (neut 78%, lymph 15%)
  Hgb 13.8 g/dL
  Plt 312 K/µL
BMP:
  Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.78, Glucose 96
Liver Panel: within normal limits
CRP 4.2 mg/dL (elevated)
RPR (Rapid Plasma Reagin): Reactive, titer 1:64
TPPA (Treponemal): Positive
HIV 4th gen Ag/Ab: Negative
NAAT (urine): Positive for Neisseria gonorrhoeae, Positive for Chlamydia trachomatis
HSV PCR (ulcer swab): Positive for HSV‑2
Blood cultures: No growth at 24 h
Urinalysis: Cloudy, WBC 15‑20/hpf, nitrite positive

Imaging:
None indicated; bedside genital exam sufficient.

Assessment and Plan:
1. Primary syphilis (RPR 1:64, TPPA +) – Start IM Benzathine Penicillin G 2.4 MU weekly × 1 dose (single dose) with plan for follow‑up RPR at 6 mo.
2. Gonococcal urethritis (NAAT +) – Start IV Ceftriaxone 1 g q24h x 5 days, then PO cefixime 400 mg BID to complete 7‑day course.
3. Chlamydial co‑infection – Doxycycline 100 mg PO BID x 7 days (already started, continue).
4. HSV‑2 genital ulcer – Start IV Acyclovir 5 mg/kg q8h x 48 h then transition to PO Valacyclovir 1 g BID x 7 days.
5. Pain control – IV Ketorolac 15 mg q6h PRN, PO Acetaminophen 650 mg q6h PRN.
6. STI counseling, partner notification, and expedited partner therapy (EPP) for both gonorrhea/chlamydia – prescribe single‑dose cefixime 800 mg + doxy 100 mg BID x 7 days for partner.
7. DVT prophylaxis – SQ Enoxaparin 40 mg SC daily.
8. Diet – Regular, encourage hydration.
9. Disposition – Admit to MedFloor 3B, telemetry not required, monitor vitals, pain, and urine output. Anticipate discharge in 48‑72 h if clinical improvement and no complications.

Orders placed: labs repeat CBC q24h, BMP q24h, RPR titer in 6 mo, cultures, IV access, medication administration set, isolation precautions (standard + contact).  

Signature: Victor Selby, MD  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (85, 85, 32230500492, 32230500492, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Hospitalist Admission History and Physical  
06/24/3069  
04:25  

Patient: Miguel Alvarez  
DOB: 02/14/3045  
PCP: Dr. Lucia Ramos, MD  

Chief Complaint: Penile discharge and dysuria  

History of Present Illness:  
58yo M with h/o HIV (CD4 420, VL undetectable), prior chlamydia (treated 2y ago), and recent unprotected intercourse p/w urethral discharge, dysuria, and mild suprapubic pain. Symptoms began ~48 h ago after a weekend trip to the coast where he had 3 sexual partners (2 female, 1 male) and reported condom breakage with one partner. He notes a thin, yellowish discharge that is worse with erection, burning on urination, and occasional low‑grade fever (max 100.4°F). Denies flank pain, hematuria, or rash. He self‑started OTC phenazopyridine with minimal relief. Presented to ED after worsening discharge and new mild inguinal lymphadenopathy. Vitals in ED: T 38.2 °C, HR 102, BP 128/76, RR 18, SpO2 98% RA. Labs drawn, urine NAAT pending. Physical exam in ED noted erythematous urethral meatus with discharge, tender bilateral inguinal nodes. No oral lesions. He was given ceftriaxone 250 mg IM and azithromycin 1 g PO per CDC STD protocol and admitted for observation and further work‑up given HIV status and concern for possible gonococcal infection with possible disseminated disease.  

Past Medical History:  
• HIV infection (diagnosed 2015) – on bictegravir/emtricitabine/tenofovir (Biktarvy) qd, adherent  
• Prior chlamydia urethritis 2027 – treated  
• Hypertension – controlled on lisinopril 10 mg qd  

Past Surgical History:  
• Appendectomy – 3030, Laparoscopic  

Family History:  
Mother – HTN, alive 78y  
Father – deceased MI at 62y  

Social History:  
Marital Status: Single, lives alone  
Occupation: Graphic Designer, works from home  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit Drugs: No current use, denies past IV drug use  
Sexual History: Hetero‑ and MSM, 4‑6 partners past year, inconsistent condom use, last STI screen 6 mo ago (negative)  

Review of Systems:  
Constitutional: Positive for low‑grade fever, fatigue. Negative for weight loss.  
HEENT: Negative for sore throat, oral lesions.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea.  
GI: Negative for nausea, vomiting, diarrhea.  
GU: Positive for urethral discharge, dysuria, suprapubic discomfort, inguinal lymphadenopathy.  
Skin: No rash, no lesions.  
Neurologic: Negative for headache, focal deficits.  
Psych: Negative for depression or anxiety.  

Prior to Admission Medications:  
Medication Sig  
bictegravir/emtricitabine/tenofovir (Biktarvy) 1 tablet PO daily  
lisinopril 10 mg PO daily  
vitamin D3 2000 IU PO daily  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Temperature: 38.2 °C (100.8 °F)  
Heart Rate: 102 bpm  
Respiratory Rate: 18/min  
Blood Pressure: 128/76 mmHg  
SpO2: 98% RA  
General: Alert, mildly uncomfortable, NAD otherwise  
HEENT: Normocephalic, atraumatic, oropharynx clear, no lesions  
Neck: Supple, no JVD, bilateral inguinal nodes 1 cm, tender  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales  
Abdomen: Soft, non‑tender, no masses, mild suprapubic tenderness on deep palpation  
Genitourinary: Urethral meatus erythematous with thin yellow discharge, no ulcerations, prostate non‑palpable per rectum (patient declined DRE)  
Extremities: No edema, pulses 2+ bilaterally  
Skin: No rashes, no petechiae  
Neuro: AOx3, CN II‑XII grossly intact, no focal deficits  

Labs (drawn 06/24/3069):  
CBC: WBC 9.8 K/µL, Hgb 13.2 g/dL, Plt 210 K/µL  
BMP: Na 138, K 4.1, Cl 102, CO2 24, BUN 14, Cr 0.9, Glu 112  
HIV Panel: CD4 420, HIV‑1 RNA <20 copies/mL (most recent 2 mo ago)  
Urine NAAT: pending for N. gonorrhoeae, C. trachomatis, Mycoplasma genitalium  
Serum RPR: pending  
Liver panel: AST 32, ALT 28, ALP 78, TBIL 0.6  

Imaging:  
None indicated at this time.  

Assessment and Plan:  
58yo M with HIV (well‑controlled) presenting with acute urethritis likely gonococcal vs chlamydial infection, currently on ceftriaxone 250 mg IM x1 and azithromycin 1 g PO x1 per CDC STD guidelines. Plan:  

1. Continue ceftriaxone 250 mg IM q24h x 3 days (or switch to IV ceftriaxone 1 g q24h if clinical worsening).  
2. Complete azithromycin 1 g PO single dose (already given).  
3. Pending urine NAAT results – if positive for C. trachomatis, add doxycycline 100 mg PO BID x7 days (or continue azithro if already given).  
4. Counsel on safe sex, condom use, partner notification; arrange expedited partner therapy (EPT) for recent partners.  
5. HIV: Continue current ART, check CD4/VL in 3 months; no change.  
6. STI screening: RPR, syphilis serology, hepatitis B/C panel – pending.  
7. Discharge planning: Anticipate discharge in 48 h if afebrile, stable, able to tolerate PO, and NAAT negative for gonorrhea resistant strain. Provide prescription for cefixime 400 mg PO BID x7 days if discharge before completing IM ceftriaxone course.  
8. DVT prophylaxis: SQ low‑molecular‑weight heparin 40 mg SC daily.  
9. Diet: Regular, encourage hydration.  
10. Code Status: Full Code (Presumed).  

Signature:  
Dr. Elena Vázquez, MD  
Hospitalist, Example Medical Center  
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (86, 86, 12680457646, 12680457646, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'PATIENT: Michael J. Aldridge  
MRN: 84276109  
DATE OF ADMISSION: 01/05/3080  
TIME: 09:29  
ADMITTING ATTENDING: Dr. Lena K. Voss, MD  
LOCATION: MED01  
PCP: Dr. Omar L. Reyes, MD  
CODE STATUS: Full Code (Presumed)  

CHIEF COMPLAINT: SOB and increased sputum production  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o COPD (GOLD D, home O2 2Lpm qhs), HTN, chronic atrial fibrillation on apixaban, and remote 30‑pack‑yr smoking (quit 5 y ago) presents w/ 3‑day worsening dyspnea, productive cough w/ thick yellow sputum, low‑grade fever (Tmax 38.2 °C at home) and mild pleuritic chest pain on left side. Pt reports that his baseline dyspnea is 2‑3 L/min O2 at rest, but over the past 48 h he has required 4 L/min to stay >90% sat, and now feels “unable to catch his breath” even at rest. Denies recent travel, sick contacts, or change in inhaler technique. He was seen at an urgent care 2 days ago, given a short course of oral steroids (prednisone 40 mg x5 d) and instructed to increase albuterol/ipratropium q4h PRN; compliance uncertain. Yesterday night he noted “bubbles” in sputum and woke up coughing profusely, prompting EMS call. EMS noted RR 28, HR 112, SpO2 84% on room air, placed on non‑rebreather 15 L, and transported to ED. In ED, ABG showed pH 7.32, PaCO2 58 mmHg, PaO2 58 mmHg on 15 L NRB; started on BiPAP, IV methylpred 40 mg q8h, and ceftriaxone 1 g q24h + azithro 500 mg q24h. Chest X‑ray read as “bilateral hyperinflation with new right lower lobe infiltrate”. Pt reports chronic use of tiotropium inhaler daily, albuterol PRN, and occasional oral steroids. No recent hospitalizations.  

PAST MEDICAL HISTORY:  
• COPD (diagnosed 2005)  
• Hypertension  
• Atrial fibrillation (paroxysmal)  
• Hyperlipidemia  

PAST SURGICAL HISTORY:  
• Appendectomy (1998)  

FAMILY HISTORY:  
Father – CAD, died 2075 at age 68  
Mother – HTN, alive 2092  
Brother – COPD, alive  

SOCIAL HISTORY:  
Marital status: Married, spouse Jane (58)  
Occupation: Retired electrician  
Tobacco: Never smoker since 2075 (30‑pack‑yr prior)  
Alcohol: 1‑2 drinks/week, socially  
Illicit drugs: Denies  
Living situation: Owns single‑family home, lives with spouse, no pets  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills, fatigue.  
HEENT: No sore throat, sinus pain.  
Respiratory: Positive for dyspnea, cough, sputum production, pleuritic chest pain.  
Cardiovascular: Palpitations (baseline AF), no chest pressure.  
GI: Nausea denied, appetite decreased.  
GU: No dysuria.  
Neuro: No headache, dizziness.  
Skin: No rashes.  
Psych: Anxious about breathing.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication                Sig  
tiotropium Respimat 2.5 mcg inhalation DAILY  
albuterol/ipratropium 90 mcg/0.5 mg inhalation q4h PRN  
lisinopril 20 mg PO DAILY  
apixaban 5 mg PO BID  
atorvastatin 40 mg PO DAILY  
omeprazole 20 mg PO DAILY  

PHYSICAL EXAMINATION:  
Vital Signs (09:30): T 37.8 °C, HR 108 bpm (irregularly irregular), RR 26 /min, BP 138/78 mmHg, SpO2 88% on NRB 15 L, Weight 84 kg, Height 175 cm, BMI 27.4.  

General: Alert, in mild respiratory distress, using accessory muscles.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: Supple, no JVD, trachea midline.  

Cardiovascular: Irregularly irregular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Diffuse wheezes bilaterally, coarse crackles at right lower lung field, decreased breath sounds posteriorly, hyperresonance to percussion.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: No edema, pulses 2+ bilaterally.  

Skin: Warm, dry, no lesions.  

Neuro: AOx3, CN II‑XII grossly intact.  

LABS (drawn 01/05/3080 08:45):  
CBC: WBC 13.2 K/µL, Hgb 13.1 g/dL, Hct 39.2 %, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 24 mmol/L, BUN 16 mg/dL, Cr 0.9 mg/dL, Glu 112 mg/dL  
ABG (on BiPAP): pH 7.31, PaCO2 62 mmHg, PaO2 68 mmHg, HCO3‑ 30 mmol/L, SaO2 92%  
CRP 58 mg/L, Procalcitonin 0.12 ng/mL  

IMAGING:  
CXR (01/05/3080 07:55): Hyperinflated lungs, flattened diaphragms, right lower lobe infiltrate consistent with bacterial pneumonia superimposed on COPD.  

CT CHEST (non‑contrast, 01/05/3080 09:10): No PE, confirms right lower lobe consolidation, diffuse emphysematous changes, mild bronchial wall thickening.  

ASSESSMENT/PLAN:  
1. COPD exacerbation, GOLD D, with acute bacterial pneumonia (right lower lobe).  
   - Continue BiPAP, titrate to SpO2 >90%.  
   - IV methylpred 40 mg q8h x 5 d then taper oral prednisone 40 mg daily taper over 7 d.  
   - IV ceftriaxone 1 g q24h + azithromycin 500 mg q24h x 5 d.  
   - Continue home tiotropium and albuterol/ipratropium; add nebulized ipratropium q6h.  
   - Consider inhaled steroids (fluticasone/salmeterol) after stabilization.  

2. Atrial fibrillation, rate control:  
   - Continue apixaban (hold if INR/anti‑Xa concerns).  
   - Add diltiazem infusion 5 mg/h, transition to oral metoprolol succinate 25 mg daily once HR <100.  

3. Hypertension:  
   - Continue lisinopril 20 mg daily; monitor K and renal function.  

4. Hyperlipidemia:  
   - Continue atorvastatin 40 mg daily.  

5. DVT prophylaxis:  
   - SQ enoxaparin 40 mg SC daily.  

6. Nutrition:  
   - Diet regular, encourage high‑protein, low‑salt.  

7. Monitoring:  
   - Telemetry for arrhythmia, q4 vitals, daily BMP, CBC.  
   - Repeat CXR in 48 h.  

8. Disposition:  
   - Admit to Med‑Surg floor with telemetry.  
   - Anticipate LOS 4‑5 d pending response.  

Patient and spouse educated on COPD action plan, inhaler technique, and signs of worsening.  

Lena K. Voss, MD  
Attending Hospitalist  
Pager 22458');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (87, 87, 76591484048, 76591484048, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Michael “Mike” Thorne
DOB: 02/14/3015
MRN: 98765432
PCP: Dr. Linda Sample, MD

Date of Admission: 10/05/3063
Time: 09:38
Location: MED01 – 4th Floor
Attending Provider: Dr. Samuel Real, MD
Admitting Intern: Dr. Jenna Example, MD
Code Status: Full Code (Presumed)

Chief Complaint:
Shortness of breath (SOB) and increased sputum production x3 days.

History of Present Illness:
48yo M with h/o COPD (GOLD 3, chronic bronchitis), HTN, prior 30‑pack‑yr smoker (quit 5 y ago) p/w 3 d worsening dyspnea, productive cough now thick yellow sputum, low‑grade fever (~38.2 °C), pleuritic chest pain R side, and mild ankle edema. Symptoms began after a cold front; he used albuterol inhaler PRN with minimal relief. Yesterday he presented to urgent care, received oral steroids (prednisone 40 mg PO x5 d) and azithromycin 500 mg x1 d, but dyspnea progressed, O2 sat dropped to 86 % on room air, prompting EMS call. EMS gave 2 L O2, nebulized albuterol/ipratropium, and transported to ED. In ED vitals: T 38.4 °C, HR 112, RR 24, BP 138/78, SpO2 88 % on RA. CXR showed hyperinflated lungs with bibasilar infiltrates. Labs: WBC 14.2 K, CRP 8.5 mg/dL. He was placed on non‑rebreather, started on IV methylpred 40 mg q8h, and admitted for COPD exacerbation with possible bacterial infection. He denies chest pain at rest, palpitations, calf pain, recent travel, or sick contacts. No recent steroid bursts beyond today.

Past Medical History:
• COPD (diagnosed 2018, on home tiotropium, albuterol PRN)
• Hypertension
• Hyperlipidemia
• GERD

Past Surgical History:
• Appendectomy – 2020 (laparoscopic)
• Right knee arthroscopy – 2025

Family History:
Father – CAD, died 2045 MI age 68
Mother – HTN, alive 88
Sister – asthma
No known hereditary lung disease.

Social History:
Tobacco: Former smoker, 30‑pack‑yr, quit 5 y ago
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives alone in apartment, works as HVAC technician (exposure to dust/fume)
Occupational exposure: Frequent inhalation of aerosolized chemicals
Marital status: Single
Physical activity: Limited by dyspnea, uses walker outdoors.

Allergies:
No known drug allergies (NKDA).

Medications Prior to Admission:
tiotropium inhaler 18 mcg inhalation daily
albuterol inhaler 90 mcg inhalation q4h PRN
lisinopril 20 mg PO daily
atorvastatin 40 mg PO nightly
omeprazole 20 mg PO daily
acetaminophen 500 mg PO q6h PRN pain/fever

Review of Systems:
Constitutional: Fever, fatigue, mild weight loss 2 lb past week.
HEENT: No sore throat, sinus congestion.
Cardiovascular: No chest pain at rest, no palpitations, no edema except mild ankles.
Respiratory: Dyspnea at rest, productive cough, wheezing, pleuritic chest pain R.
GI: No nausea, vomiting, abdominal pain.
GU: No dysuria, frequency.
Musculoskeletal: Mild ankle swelling, no joint pain.
Neurologic: No headache, dizziness, syncope.
Psychiatric: No anxiety/depression.
Skin: No rashes.

Physical Examination:
Vital Signs:
Temp 38.3 °C
HR 108 bpm
RR 22 breaths/min
BP 136/80 mmHg
SpO2 89 % on room air (improved to 94 % on 2 L NC)
Weight 84 kg (185 lb)

General: Alert, in mild respiratory distress, using accessory muscles.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Diffuse wheezes bilaterally, coarse rhonchi R lower lobe, decreased breath sounds at bases, no egophony.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: Warm, no cyanosis, mild 1+ pitting edema ankles bilat.
Skin: No rashes, no lesions.
Neuro: AOx3, grossly non‑focal.

Data/Results:
Laboratory:
CBC: WBC 14.2 K, Hgb 13.1 g/dL, Hct 39 %, Plt 312 K
BMP: Na 138, K 4.3, Cl 102, CO2 22, BUN 16, Cr 0.9, Glucose 112
CRP: 8.5 mg/dL
Procalcitonin: 0.42 ng/mL
ABG (room air): pH 7.32, PaCO2 58 mmHg, PaO2 58 mmHg, HCO3‑ 28
Arterial lactate: 1.2 mmol/L

Imaging:
Chest X‑ray (10/05/3063): Marked hyperinflation, flattened diaphragms, bibasilar infiltrates suggestive of infectious bronchitis/pneumonia.
CT chest (pending) – ordered.

Microbiology:
Sputum Gram stain: many neutrophils, gram‑positive cocci in pairs (presumed S. pneumoniae) – pending culture.
Respiratory viral panel: pending.

Assessment and Plan:
48yo M with COPD exacerbation secondary to likely bacterial infection (presumed pneumococcal) and acute hypercapnic respiratory failure, HTN, hyperlipidemia.

1. COPD Exacerbation:
   • Continue nebulized albuterol/ipratropium q4h + PRN.
   • Add IV methylprednisolone 40 mg q8h; transition to PO prednisone 40 mg daily on day 3.
   • Start empiric antibiotics: ceftriaxone 2 g IV q24h + azithromycin 500 mg IV q24h for 5 days.
   • Initiate non‑invasive positive pressure ventilation (BiPAP) if PaCO2 >55 mmHg or worsening dyspnea.
   • O2 target 88‑92 % via nasal cannula or venturi mask.
   • Incentive spirometry qhourly, chest physiotherapy.

2. Hypertension:
   • Hold lisinopril while on steroids; resume when BP <140/90.
   • Monitor BP q4h.

3. Hyperlipidemia:
   • Continue atorvastatin 40 mg PO nightly.

4. GERD:
   • Continue omeprazole 20 mg PO daily.

5. DVT Prophylaxis:
   • SQ enoxaparin 40 mg SC daily (adjust for renal function).

6. Fluid Management:
   • Maintain euvolemia; IVF 0.9% NS 1 L bolus then maintenance 75 mL/hr; monitor I/O.

7. Labs/Imaging Follow‑up:
   • CBC, BMP, ABG q12h until stable.
   • Repeat CXR q48h.
   • Review sputum culture results; de‑escalate antibiotics if appropriate.

8. Disposition:
   • Admit to telemetry floor for close monitoring of respiratory status.
   • Anticipate discharge in 4‑5 days with home oxygen titrated to 2 L/min PRN, pulmonary rehab referral, smoking‑exposure counseling, and follow‑up with pulmonology in 1 week.

9. Education:
   • Discuss inhaler technique, importance of adherence, signs of worsening dyspnea, when to call 911.

10. Code Status:
    • Full Code (Presumed) confirmed with patient.

Prepared by: Dr. Jenna Example, MD
Pager #: 22457
Date/Time: 10/05/3063 09:45');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (88, 88, 10626072533, 10626072533, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Hospital Admission History and Physical  

Patient: Miguel Alvarez  
DOB: 11/03/3045  
MRN: 98765432  
PCP: Dr. Elena Rivera, MD  

Date of Admission: 02/20/3078 17:53  
Location: MED01  
Attending Provider: Dr. Samuel Kline, MD  

Chief Complaint: Fever, chills, and right forearm erythema  

History of Present Illness:  
58yo M with h/o chronic hepatitis C (treated), IV drug use (heroin, last use 2 days ago), prior IE (aortic valve) s/p valve replacement 3 y ago, and COPD presents to ED w/ 3‑day hx of progressive right forearm pain, swelling, erythema, and low‑grade fever up to 38.7 °C. Pt reports injecting heroin into right antecubital fossa daily for past 6 months; last injection was “just before bed” 2 days ago and he noticed a “big bump” that turned red and painful. Over the past 24 h he’s had chills, night sweats, nausea, and decreased appetite. Denies SOB, chest pain, cough, dysuria, or recent travel. He was seen at an urgent care 1 day ago, given oral clindamycin, but symptoms worsened, prompting ED visit. In ED vitals: T 38.9 °C, HR 112, BP 118/72, RR 22, SpO2 96% RA. Labs showed leukocytosis 15.2 K, CRP 12 mg/dL. Bedside US of forearm showed a 3 cm hypoechoic collection suggestive of abscess. He was started on IV vancomycin and cefepime, and surgical consult placed for possible I&D.  

Past Medical History:  
• Chronic hepatitis C (RNA negative, SVR 2025)  
• COPD, GOLD stage II, on tiotropium inhaler  
• Aortic valve replacement (mechanical) 03/12/3075  
• Hypertension  

Past Surgical History:  
Procedure Laterality Date  
• Aortic valve replacement – Right – 03/12/3075  
• Appendectomy – N/A – 06/15/3048  

Family History:  
Father – HTN, died 2070 MI  
Mother – Alive, DM2  
Sister – Healthy  

Social History:  
Tobacco Use: Smokes ½ pack/day since age 20, currently 5 cigs/day.  
Alcohol Use: Social, 1‑2 drinks/week.  
Illicit Drug Use: Active IV heroin use, last use 2 days ago; shares needles intermittently.  
Housing: Lives in transitional housing, single.  
Employment: Unemployed, receives disability benefits.  

Review of Systems:  
Constitutional: Positive for fever, chills, night sweats, fatigue.  
HEENT: No sore throat, no visual changes.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: Dyspnea on exertion baseline COPD, no new cough.  
GI: Nausea, no vomiting, no abdominal pain.  
GU: No dysuria, no flank pain.  
Musculoskeletal: Right forearm pain, swelling, erythema; no other joint pain.  
Skin: Localized erythema right forearm, no other rashes.  
Neurologic: No headache, no focal deficits.  
Psychiatric: Mood “okay,” reports anxiety about infection.  

Prior to Admission Medications:  
Medication Sig  
tiotropium inhaler 18 mcg inhalation BID  
lisinopril 20 mg PO daily  
amlodipine 5 mg PO daily  
warfarin 5 mg PO daily (INR target 2.5‑3.5)  
metoprolol succinate 50 mg PO daily  
acetaminophen 500 mg PO q6h PRN pain  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs: Temp 38.9 °C, HR 112, RR 22, BP 118/72, SpO2 96% RA, Weight 82 kg, Height 175 cm, BMI 26.8  

General: Alert, oriented x3, appears mildly ill, in mild distress due to forearm pain.  

HEENT: Normocephalic, atraumatic, PERRLA, mucous membranes moist.  

Neck: Supple, no JVD, no lymphadenopathy.  

Cardiovascular: Regular rate and rhythm, mechanical click audible, no murmurs, peripheral pulses 2+ bilat.  

Respiratory: Bilateral breath sounds clear, mild wheeze on forced expiration, no rales.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Right forearm swollen, erythematous, warm, fluctuance noted ~3 cm, limited range of motion due to pain. No cellulitis elsewhere. No edema of lower extremities.  

Skin: No petechiae, no Janeway lesions.  

Neurologic: Grossly non‑focal, strength 5/5 upper extremities except pain‑limited right forearm.  

Psychiatric: Cooperative, mood neutral.  

Labs and Imaging:  
CBC: WBC 15.2 K, Hgb 13.1 g/dL, Plt 210 K  
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 14, Cr 0.9, Glu 112  
CRP: 12 mg/dL (elevated)  
Procalcitonin: 1.8 ng/mL  
INR: 2.8 (therapeutic)  
Blood cultures x2: pending  
Forearm US: 3 cm hypoechoic collection with peripheral hyperemia, compatible with abscess.  
Chest X‑ray: No infiltrates, cardiac silhouette normal size.  

Assessment and Plan:  
58yo M with active IV drug use presenting with right forearm abscess secondary to injection site infection, systemic inflammatory response (fever, leukocytosis), and chronic hepatitis C.  

1. Right forearm abscess – surgical I&D scheduled within next 4 h; obtain intra‑op cultures; continue empiric IV vancomycin + cefepime pending culture sensitivities.  
2. Bacteremia risk – obtain repeat blood cultures q48 h; monitor for endocarditis signs; TEE to be considered if fevers persist >48 h.  
3. Chronic hepatitis C – SVR confirmed, continue routine monitoring; no antiviral therapy needed now.  
4. Mechanical aortic valve – maintain therapeutic INR; hold warfarin 24 h pre‑op, bridge with IV heparin per protocol.  
5. COPD – continue tiotropium; add short‑acting bronchodilator PRN; monitor O2 sat, keep SpO2 >92%.  
6. Hypertension – continue lisinopril and amlodipine; monitor BP.  
7. Pain control – acetaminophen 650 mg PO q6h PRN, consider IV morphine PRN after surgery.  
8. Substance use – consult addiction medicine for MAT (buprenorphine) initiation; arrange needle‑exchange counseling.  
9. DVT prophylaxis – SQ low‑molecular‑weight heparin q24h.  
10. Diet – regular, cardiac‑appropriate.  
11. Code status – Full Code (Presumed).  

Disposition: Admit to Med‑Surg floor, telemetry for arrhythmia monitoring due to mechanical valve. Follow‑up labs q24 h, wound check post‑op day 1.  

Samuel Kline, MD  
Attending Hospitalist  
Pager 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (89, 89, 88882927178, 88882927178, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Michael Doe  
DOB: 02/15/3015  
MRN: 98765432  
PCP: Dr. Jane Sample, MD  

Date of Admission: 08/04/3052 10:46  
Location: EXAMP03  
Attending Provider: Dr. Samuel Realname, MD  

Chief Complaint: SOB, increased sputum production  

History of Present Illness:  
68yo M with h/o COPD (GOLD D, home O2 2Lpm), HTN, DM2 (A1c 8.1%), chronic bronchitis, and prior intubation 2 y ago, presents w/ acute worsening dyspnea x3 days. Pt reports “can’t catch my breath” after climbing a single flight of stairs, now at rest. Sputum turned thick yellow‑green, volume ↑ to ~30 mL/qh, associated with low‑grade fever (Tmax 38.2 °C at home) and pleuritic chest pain R lower lobe. Denies hemoptysis. Pt was seen at outside ED 08/02/3052, received albuterol/ipratropium nebulizers, IV methylpred 40 mg, and a dose of ceftriaxone 1 g. CXR read “possible right lower lobe infiltrate vs atelectasis.” He was discharged on oral levofloxacin 750 mg daily and prednisone 40 mg PO daily with plan to follow‑up, but symptoms progressed, prompting return. Pt reports compliance with home O2 2 Lpm nocturnally, now using 4 Lpm continuously. No recent travel. No known sick contacts.  

Past Medical History:  
• COPD (GOLD D) – diagnosed 2008  
• Hypertension – diagnosed 2010  
• Type 2 Diabetes Mellitus – diagnosed 2015  
• Hyperlipidemia  
• GERD  

Past Surgical History:  
• Appendectomy – 2002  
• Right knee arthroscopy – 2018  

Family History:  
Father: HTN, died MI age 68  
Mother: COPD, alive 82  
Sister: DM2  

Social History:  
Tobacco Use: 1 pack/day since age 18, quit 5 y ago (30‑pack‑year history)  
Alcohol: Social, 1‑2 drinks/week  
Illicit Drugs: Denies  
Living Situation: Lives alone in apartment, uses home health aide 3×/wk for O2 checks  
Occupational: Retired electrician  

Review of Systems:  
Constitutional: Positive for fatigue, low‑grade fever; negative for chills, weight loss.  
HEENT: Negative for sore throat, sinus pain.  
Respiratory: Positive for dyspnea at rest, increased sputum, pleuritic chest pain; negative for wheeze (subjective).  
Cardiovascular: Negative for chest pressure, palpitations.  
GI: Negative for nausea, vomiting, abdominal pain.  
GU: Negative for dysuria, hematuria.  
Neuro: Negative for headache, dizziness.  
Skin: No rashes.  
Psych: Mood stable, no SI/HI.  

Prior to Admission Medications:  
metformin 500 mg PO BID  
lisinopril 20 mg PO daily  
atorvastatin 40 mg PO nightly  
albuterol inhaler 2 puffs q4h PRN  
ipratropium inhaler 2 puffs q4h PRN  
tiotropium 18 mcg inhaled daily  
fluticasone/salmeterol 250/50 mcg inhaled BID  
home O2 2 Lpm nocturnal  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs:  
Temp 37.9 °C (100.2 °F)  
HR 112 bpm (irregularly irregular)  
RR 24 breaths/min  
BP 138/78 mmHg  
SpO2 88 % on room air, 94 % on 4 Lpm O2 nasal cannula  
Weight 92 kg (202 lb)  

General: Alert, in mild respiratory distress, using accessory muscles.  
HEENT: Normocephalic, atraumatic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Irregularly irregular rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Diffuse wheezes bilaterally, rhonchi R lower zone, decreased breath sounds R lower lobe.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: No edema, pulses 2+ bilat.  
Skin: Warm, dry.  
Neuro: AOx3, no focal deficits.  

Labs (drawn 08/04/3052):  
CBC: WBC 14.2 K/µL (neut 82%), Hgb 13.1 g/dL, Hct 39 %, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.5 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 18 mg/dL, Cr 0.9 mg/dL, Glu 162 mg/dL  
ABG on 4 L O2: pH 7.32, PaCO2 58 mmHg, PaO2 68 mmHg, HCO3‑ 28 mmol/L (acute on chronic resp acidosis)  
CRP 12 mg/L (elevated)  
Procalcitonin 0.45 ng/mL  

Imaging:  
Chest X‑ray 08/04/3052: Right lower lobe infiltrate vs atelectasis, hyperinflated lungs, flattened diaphragms.  
CT chest (non‑contrast) pending.  

Assessment and Plan:  
68yo M with severe COPD (GOLD D) and acute on chronic respiratory acidosis, likely COPD exacerbation secondary to bacterial infection (right lower lobe infiltrate) and possible viral trigger.  

1. COPD Exacerbation:  
   • Continue nebulized albuterol/ipratropium q4h, add IV methylpred 40 mg q12h.  
   • Start systemic steroids: methylpred 60 mg IV q24h → PO prednisone taper 40 mg daily x5 days then taper.  
   • Initiate broad‑spectrum antibiotics: ceftriaxone 1 g IV q24h + azithromycin 500 mg IV daily for 5 days (cover atypicals).  
   • Continue home inhalers, add short‑acting bronchodilator as needed.  
   • Maintain O2 target 88‑92 % (adjust flow as needed).  

2. Possible Pneumonia:  
   • Obtain sputum culture, blood cultures x2.  
   • Monitor procalcitonin; de‑escalate antibiotics if low.  

3. Hyperglycemia:  
   • Hold metformin (renal function OK but risk of lactic acidosis with hypoxia).  
   • Start sliding‑scale insulin infusion targeting 140‑180 mg/dL.  

4. Hypertension:  
   • Hold lisinopril while on steroids; resume when BP stable.  

5. DVT Prophylaxis:  
   • SQ enoxaparin 40 mg SC daily (adjust for Cr).  

6. Code Status: Full Code (Presumed).  

7. Monitoring:  
   • Admit to telemetry floor, continuous pulse oximetry.  
   • Repeat ABG q6h until stable.  
   • Follow CBC, BMP daily.  

8. Disposition:  
   • Anticipate 4‑5 day stay, reassess for step‑down to general floor once respiratory status improves and O2 ≤ 2 L/min.  

9. Education:  
   • Discuss smoking cessation reinforcement (though quit), inhaler technique, sick‑day plan.  

10. Follow‑up:  
    • Pulmonology consult within 24 h.  
    • Endocrinology consult for DM management if hyperglycemia persists.  

Prepared by: Dr. Samuel Realname, MD  
Pager: 67890  
Date/Time: 08/04/3052 11:12');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (90, 90, 96535159240, 96535159240, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 07/21/3072  
Time: 06:39  

Patient: Miguel Alvarez  
DOB: 02/14/3035  
MRN: 98765432  
PCP: Dr. Lila Moreno, MD  

Chief Complaint: Right foot ulcer with increasing pain and purulent drainage  

History of Present Illness:  
58yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, CKD stage 3, HTN, and prior left transmetatarsal amputation p/w R foot ulcer now s/p 2 wk of worsening erythema, foul drainage, and throbbing pain radiating to the calf. Patient reports the ulcer began as a small blister after a minor abrasion while gardening 3 weeks ago. He self‑treated with OTC bacitracin and kept the foot in a sandal. Over the past 5 days the area became increasingly red, swollen, and now has yellow‑green exudate. He notes low‑grade fevers up to 38.2°C at home, chills, and a new onset of malaise. Denies any recent travel, sick contacts, or new footwear. He was seen at an urgent care on 07/15; wound cultures were taken and he was prescribed oral clindamycin 300 mg q6h and instructed to follow‑up. He took 2 doses then stopped due to GI upset. He presented to the ED on 07/20 because pain became intolerable, he could no longer bear weight, and the swelling extended to the mid‑calf. In the ED vitals: T 38.4°C, HR 112, BP 138/78, RR 22, SpO2 96% RA. Labs showed WBC 14.2, CRP 12.5 mg/dL. Bedside Doppler revealed absent dorsalis pedis pulses on the right. X‑ray of the foot showed soft‑tissue swelling without osteolysis. He was started on IV vancomycin and cefepime, received 1 L NS, and was admitted for IV antibiotics, possible surgical debridement, and glycemic optimization.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2008  
• Peripheral Arterial Disease – bilateral, diagnosed 2019  
• Hypertension – diagnosed 2010  
• Chronic Kidney Disease – stage 3 (eGFR 48 mL/min)  
• Hyperlipidemia  
• Obesity (BMI 34)  

Past Surgical History:  
• Left transmetatarsal amputation – 06/12/3065  
• Cholecystectomy – 09/03/3050  

Family History:  
Father – HTN, MI at 62  
Mother – DM2, CKD  
Sister – healthy  

Social History:  
Tobacco Use – Former smoker, 10 pack‑years, quit 5 y ago  
Alcohol – Social, 1‑2 drinks/week  
Illicit Drugs – Denies  
Occupation – Warehouse supervisor, standing >8 h/day  
Living Situation – Lives with spouse, owns home, has private insurance  

Review of Systems:  
Constitutional – Positive for fever, chills, fatigue; negative for weight loss.  
HEENT – Negative.  
Cardiovascular – Negative for chest pain, palpitations.  
Respiratory – Negative for cough, dyspnea.  
Gastrointestinal – Negative for N/V/D.  
Genitourinary – Negative.  
Musculoskeletal – Positive for right foot pain, swelling; negative for other joint pain.  
Neurologic – Negative for weakness, numbness beyond ulcer area.  
Skin – Positive for right foot ulcer with purulent drainage; negative for rashes elsewhere.  
Psychiatric – Negative.  

Prior to Admission Medications:  
Metformin 1000 mg PO BID  
Insulin glargine 30 U SC nightly  
Lisinopril 20 mg PO daily  
Atorvastatin 40 mg PO nightly  
Aspirin 81 mg PO daily  
Clopidogrel 75 mg PO daily  
Amlodipine 10 mg PO daily  
Omeprazole 20 mg PO daily  

Allergies:  
Penicillin – rash  

Physical Examination:  
Vital Signs: Temp 38.3 °C, HR 110, RR 21, BP 136/80, SpO2 96% RA, Weight 112 kg, Height 1.78 m, BMI 35.3  

General: Alert, in mild distress due to pain, NAD otherwise.  

HEENT: Normocephalic, atraumatic, mucous membranes moist.  

Neck: Supple, no JVD.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.  

Abdomen: Soft, non‑tender, normoactive bowel sounds.  

Extremities: Right foot – 5 cm x 4 cm ulcer over plantar surface of the 2nd metatarsal head, undermined edges, yellow‑green purulent drainage, surrounding erythema extending to mid‑calf, warmth, edema +2, tenderness to palpation. No crepitus. Dorsalis pedis pulse absent on right, present on left. No other edema.  

Skin: No rashes elsewhere.  

Neurologic: Grossly intact, sensation decreased over the ulcer area, otherwise normal.  

Laboratory Data (07/21/3072):  
CBC: WBC 14.2 K/µL, Hgb 12.8 g/dL, Hct 38.5%, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 23 mmol/L, BUN 22 mg/dL, Cr 1.4 mg/dL (eGFR 48), Glu 212 mg/dL  
CRP: 12.5 mg/dL  
Procalcitonin: 0.9 ng/mL  
HbA1c (3 mo prior): 9.4%  

Microbiology:  
Wound culture (ED) – pending (preliminary Gram stain: Gram‑positive cocci in clusters, Gram‑negative rods).  

Imaging:  
Foot X‑ray (07/20) – soft‑tissue swelling, no obvious osteomyelitis, no fracture.  
Duplex US of right lower extremity – arterial flow severely reduced, no DVT.  

Assessment and Plan:  
58yo M with poorly controlled T2DM, PAD, and a right foot ulcer now complicated by cellulitis, possible early osteomyelitis, and systemic signs of infection.  

1. Diabetic foot infection – moderate‑severe (IDSA grade 3). Start IV vancomycin 15 mg/kg q12h (adjust for Cr) and cefepime 2 g q8h. Obtain MRI of the foot within 24 h to rule out osteomyelitis. Consult podiatry for bedside debridement; likely OR debridement tomorrow.  
2. Glycemic control – continue insulin glargine, add insulin lispro sliding scale qAC and qprn hyperglycemia. Target glucose 140‑180 mg/dL.  
3. CKD stage 3 – adjust vancomycin dosing, monitor Cr q24h. Hold metformin while inpatient.  
4. PAD – vascular surgery consult for possible revascularization if imaging shows critical ischemia.  
5. Pain – acetaminophen 1 g PO q6h PRN, consider low‑dose morphine PCA if needed.  
6. DVT prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  
7. Nutrition – diabetic diet, protein‑rich, monitor intake.  
8. Disposition – Admit to medicine floor with telemetry for arrhythmia monitoring (HTN, CAD risk). Anticipate 5‑7 day IV antibiotic course, then transition to oral based on culture results and clinical response.  

Code Status: Full Code (Presumed)  
Level of Care: Acute Care Medicine  

Signature:  
Dr. Elena V. Ramos, MD  
Hospitalist Attending  
Pager 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (91, 91, 14965032931, 14965032931, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
09/17/3098 00:24  

Patient: Marcus L. Whitaker  
DOB: 04/02/3065  
PCP: Dr. Eleanor V. Kline, MD  

Chief Complaint: Low back pain, worsening over 3 days  

History of Present Illness:  
58yo M with h/o HTN, CKD stage 3 (eGFR 48), chronic low back pain s/p L4‑L5 discectomy 2019, and recent UTI treated with ciprofloxacin presents w/ acute exacerbation of lumbar pain radiating to left buttock and posterior thigh. Patient reports “sharp, burning” pain that started 3 days ago after lifting a 30 lb box at work (warehouse associate). Initially intermittent, now constant, 8/10 at rest, 10/10 with ambulation. Denies any recent trauma, falls, or MVC. Reports new numbness in left great toe, occasional tingling in L5 dermatome, but no weakness. He notes that pain is partially relieved by lying supine and worsened by standing or sitting >30 min. He took ibuprofen 600 mg q6h PRN with minimal relief, and used his home baclofen 10 mg tid, also minimal effect. He went to an urgent care on 09/14; they gave a steroid tapere (prednisone 20 mg x5 days) and ordered plain X‑ray which was read as “degenerative changes, no acute fracture.” Pain persisted, so he presented to ED. In ED vitals: T 37.2 °C, HR 102, RR 20, BP 148/86, SpO2 97% RA. Labs: WBC 9.8, Cr 1.4 (baseline 1.3), BUN 22. CT lumbar spine without contrast showed L4‑L5 disc protrusion with mild central canal stenosis, no fracture. No epidural abscess. He was given IV ketorolac 30 mg q6h and morphine 2 mg q2h PRN, with modest relief. He was admitted for pain control, possible epidural steroid injection, and further work‑up of possible radiculopathy.  

Past Medical History:  
• Hypertension (diagnosed 3070)  
• Chronic kidney disease stage 3 (eGFR 48)  
• Chronic low back pain, s/p L4‑L5 microdiscectomy 2019  
• Type 2 diabetes mellitus (A1c 7.1% 09/01/3097)  
• Hyperlipidemia  

Past Surgical History:  
Procedure Laterality Date  
• L4‑L5 microdiscectomy – Right – 06/12/3019  
• Appendectomy – N/A – 02/05/3045  

Family History:  
Father – HTN, MI at 62  
Mother – CKD secondary to diabetes, deceased 3092  
Brother – Healthy  

Social History:  
Marital Status: Married, spouse Jane Whitaker (employed teacher)  
Children: 2 (ages 12 and 9)  
Occupation: Warehouse associate, lifts up to 40 lb regularly  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Owns single‑family home, no pets  

Review of Systems:  
Constitutional: Negative for fever, chills, weight loss.  
HEENT: No visual changes, hearing normal.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No dyspnea, cough.  
GI: No nausea, vomiting, abdominal pain.  
GU: No dysuria, hematuria.  
Musculoskeletal: Positive for low back pain radiating to left lower extremity, numbness L5 distribution; denies swelling, joint pain elsewhere.  
Neurologic: Negative for weakness, gait instability.  
Skin: No rashes.  
Psych: No depression or anxiety reported.  

Prior to Admission Medications:  
Medication Sig  
lisinopril 20 mg PO daily  
metformin 1000 mg PO BID  
atorvastatin 40 mg PO nightly  
baclofen 10 mg PO TID  
ibuprofen 600 mg PO q6h PRN pain  
omeprazole 20 mg PO daily  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs: Temp 36.9 °C, HR 98, RR 18, BP 146/84, SpO2 98% RA, Weight 92 kg, Height 178 cm, BMI 29.0  

General: Alert, oriented x3, in mild distress due to pain, lying supine.  
HEENT: Normocephalic, atraumatic, PERRLA, mucous membranes moist.  
Neck: Supple, no lymphadenopathy.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Back: Inspection – mild lumbar lordosis, no bruising. Palpation – tenderness over L4‑L5 spinous processes, paraspinal muscle spasm. Range of motion – limited flexion due to pain, extension limited. Straight leg raise left positive at 45°, right negative.  
Extremities: No edema, pulses 2+ bilaterally.  
Neurologic: Motor 5/5 in all extremities, sensation decreased to light touch over left L5 dermatome, reflexes 2+ symmetric, Babinski negative.  
Skin: Warm, dry, no lesions.  

Laboratory Data (09/17/3098):  
CBC: WBC 9.8 K/µL, Hgb 13.2 g/dL, Hct 39.5%, Plt 242 K/µL  
BMP: Na 138 mmol/L, K 4.3 mmol/L, Cl 102 mmol/L, CO2 24 mmol/L, BUN 22 mg/dL, Cr 1.4 mg/dL, Glu 138 mg/dL, Ca 9.1 mg/dL  
CRP: 4.2 mg/L (elevated)  
ESR: 28 mm/hr  

Imaging:  
CT Lumbar Spine (non‑contrast) 09/16/3098: L4‑L5 disc protrusion with mild central canal stenosis, left foraminal narrowing, no acute fracture, no epidural collection.  

Assessment and Plan:  
58yo M with chronic low back pain s/p discectomy now presenting with acute radiculopathy secondary to recurrent L4‑L5 disc protrusion causing left L5 radiculopathy. Pain is severe, functional limitation, and not adequately controlled with oral NSAIDs and baclofen.  

Plan:  
1. Pain Management – Continue IV ketorolac 30 mg q6h PRN, add oral oxycodone 5 mg q4h PRN (max 30 mg/day). Consider patient‑controlled analgesia if pain persists.  
2. Neurosurgery consult for possible epidural steroid injection vs. repeat decompression; obtain MRI lumbar spine if neurosurgery recommends.  
3. Physical Therapy – Initiate bedside PT for gentle lumbar mobilization and core strengthening once pain controlled.  
4. Renal: Monitor Cr and electrolytes q24h; hold NSAIDs if Cr rises >1.6 mg/dL.  
5. Diabetes: Continue metformin; check fasting glucose qam, adjust if >180 mg/dL.  
6. Hypertension: Continue lisinopril, monitor BP q8h.  
7. DVT prophylaxis – SQ low‑molecular‑weight heparin 40 mg SC daily.  
8. GI prophylaxis – Continue omeprazole 20 mg daily.  
9. Diet – Regular, low sodium, renal‑friendly.  
10. Disposition – Admit to medical floor, telemetry not required. Anticipate discharge in 3‑4 days pending pain control and neurosurgery decision.  

Code Status: Full Code (Presumed)  

Attending: Dr. Victor H. Alvarez, MD  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (92, 92, 23868081900, 23868081900, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'EXAMPLE HOSPITALIST ADMISSION HISTORY AND PHYSICAL

01/24/3076 01:25

Patient: Miguel Alvarez
DOB: 03/12/3038
MRN: 98765432
PCP: Dr. Lucia Ramos, MD

CHIEF COMPLAINT: Right foot ulcer with increasing drainage

HISTORY OF PRESENT ILLNESS:
58yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, CKD stage 3, HTN, and prior left BKA presents w/ R foot infection x5d. Pt reports a 2cm ulcer on plantar aspect of R hallux that he noticed after a minor blister while gardening. Initially painless, but over past 48h drainage turned purulent, erythema spread to midfoot, increased warmth, throbbing pain worsened with ambulation. Pt admits he “skipped” insulin doses last week due to travel to sister’s house (out of state) and has been using OTC ibuprofen for pain. He was seen at an outside urgent care 2d ago, received a single dose of IM ceftriaxone and was told to follow up with PCP; PCP advised ED if worsening – which it did. Pt denies fever, chills, SOB, chest pain, dysuria, or new GI symptoms. No recent trauma, no known sick contacts. He reports baseline neuropathy in both feet, but this ulcer is new. He has been non‑compliant with wound care (no daily dressing changes) due to limited dexterity from diabetic neuropathy. He is currently on insulin glargine 30U qHS and lispro 8U TID PRN, metformin 1000mg BID, lisinopril 20mg daily, atorvastatin 40mg nightly, aspirin 81mg daily. No known drug allergies.

Outside Hospital Course: At urgent care, CBC showed WBC 12.3, CRP 8.2. He was given ceftriaxone 250mg IM and instructed to start oral TMP‑SMX if discharge. He left without antibiotics due to insurance issues. No imaging performed.

MEDICAL & SURGICAL HX:

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2005
• Peripheral Arterial Disease – diagnosed 2018
• Chronic Kidney Disease – stage 3 (baseline Cr 1.6)
• Hypertension
• Hyperlipidemia
• Diabetic Neuropathy

Past Surgical History:
Procedure Laterality Date
• RIGHT FOOT DEBRIDEMENT – Right – 02/15/3065
• LEFT BELOW‑KNEE AMPUTATION – Left – 06/03/3052

FAMILY HX:
Problem Relation Age of Onset
• CAD Father 55
• DM Mother 48
• Hypertension Sister 42

SOCIAL HX:
Marital Status: Married
Spouse: Ana Alvarez
Children: 2 (ages 12 and 9)
Employment: Construction foreman (full‑time)
Tobacco Use: Never smoker
Alcohol Use: Social – 1‑2 beers/week
Illicit Drugs: Denies
Living Situation: Own home, single‑story, wheelchair accessible
Transportation: Drives himself, uses cane

REVIEW OF SYSTEMS:
Constitutional: Negative for fever, chills, weight loss.
HEENT: No visual changes, no sore throat.
Cardiovascular: No chest pain, no palpitations.
Respiratory: No cough, dyspnea.
GI: No nausea, vomiting, abdominal pain.
GU: No dysuria, no flank pain.
MSK: Right foot ulcer with purulent drainage, mild edema.
Neuro: Known peripheral neuropathy, no new weakness.
Skin: Right hallux ulcer, erythema to midfoot.
Psych: Mood stable, denies depression or anxiety.

PRIOR TO ADMISSION MEDICATIONS:
Medication Sig
insulin glargine (LANTUS) 30 Units subcut QHS
insulin lispro (HUMALOG) 8 Units subcut TID PRN
metformin 1000 mg tablet PO BID
lisinopril 20 mg tablet PO daily
atorvastatin 40 mg tablet PO nightly
aspirin 81 mg EC tablet PO daily
vitamin D3 2000 IU PO daily

Allergies:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 37.8°C (100.0°F)
Heart Rate: 102 bpm
Respiratory Rate: 20/min
Blood Pressure: 138/78 mmHg
SpO2: 96% RA
Weight: 92 kg (202 lb)

General: Alert, appears his stated age, mild distress due to foot pain.
HEENT: Normocephalic, atraumatic, PERRLA, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.
Abdomen: Soft, non‑tender, normoactive bowel sounds.
Extremities: Right foot – 2 cm ulcer on plantar hallux with purulent yellow drainage, surrounding erythema ~5 cm, warmth, mild edema; no crepitus. Left foot – healed BKA stump, no infection. Peripheral pulses diminished bilaterally (dorsalis pedis +1). No cyanosis.
Skin: Warm, dry, no rashes elsewhere.
Neurologic: Alert ×3, grossly non‑focal, decreased sensation to monofilament in both feet.
Psych: Cooperative, appropriate affect.

LABS & IMAGING (preliminary):
CBC: WBC 13.1 K/µL, Hgb 12.2 g/dL, Hct 36%, Plt 312 K/µL
BMP: Na 138, K 4.5, Cl 102, CO2 23, BUN 28, Cr 1.7 (eGFR ~38), Glucose 212 mg/dL
CRP: 12.4 mg/dL
ESR: 45 mm/hr
HbA1c: 9.4% (from 3 mo prior)
Lactate: 1.2 mmol/L
Procalcitonin: 0.28 ng/mL
Blood cultures: x2 pending
Wound culture: obtained – pending
Plain X‑ray R foot: No osteomyelitis evident, soft tissue swelling.
MRI R foot (ordered): pending – to rule out osteomyelitis.

IMPRESSION/PLAN:
58yo M with poorly controlled T2DM, PAD, CKD3 presenting with acute right foot ulcer complicated by purulent cellulitis, possible early osteomyelitis.

1. DIABETIC FOOT INFECTION:
   • Start IV vancomycin 15 mg/kg q12h (adjust for Cr) + cefepime 2 g q8h.
   • Obtain orthogonal MRI of foot within 12 h.
   • Admit to telemetry floor for close glucose and vitals monitoring.
   • Wound care consult for daily debridement and dressing changes.
   • Infectious Diseases consult for antibiotic stewardship.

2. GLUCOSE MANAGEMENT:
   • Switch to basal‑bolus insulin regimen: glargine 35 U qHS, lispro 4 U qAC + correction scale 1 U per 30 mg/dL >180.
   • Check finger‑stick q4h, adjust per protocol.

3. CKD & HYPERTENSION:
   • Hold ACE‑I today (creatinine up), re‑evaluate tomorrow.
   • Maintain MAP >65 mmHg; continue lisinopril once Cr stable.

4. CARDIOVASCULAR:
   • Continue aspirin 81 mg PO daily, atorvastatin 40 mg nightly.
   • Telemetry for arrhythmia surveillance (baseline tachycardia).

5. VTE PROPHYLAXIS:
   • SQ enoxaparin 40 mg SC daily (adjust for Cr).

6. NUTRITION:
   • Diabetic diet – carbohydrate consistent, protein 1.2 g/kg.
   • Encourage fluid intake 2 L/day unless contraindicated.

7. PATIENT EDUCATION:
   • Discuss foot care, daily inspection, proper footwear.
   • Emphasize adherence to insulin and wound care regimen.

8. DISPOSITION:
   • Admit to Medicine service, floor bed with telemetry.
   • Anticipated LOS 5‑7 days pending MRI results and response to antibiotics.

Signature:
Dr. Elena Marquez, MD
Hospitalist
Pager # 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (93, 93, 66484486724, 66484486724, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
Date of Admission: 04/09/3078 15:10  
Location: MED01  
Attending: Dr. Evelyn Hartwell, MD  
Primary Care Provider: Dr. Lionel Finch, MD  

Patient: Marcus L. Whitaker  
DOB: 02/14/3048  
MRN: 98765432  

Chief Complaint: Cough, dyspnea, fever  

History of Present Illness:  
58yo M with h/o HTN, T2DM (A1c 8.1% 02/3077), CKD stage 3, and recent right‑sided CAP p/w fever, productive cough, SOB presents today after 5‑day course of oral azithro completed at outside urgent care. He reports that symptoms initially started 7 days ago with low‑grade fever (max 101°F) and a dry cough while he was on a business trip to New Berlin. Returned home, saw urgent care, was given azithro 500 mg PO daily x3 and albuterol inhaler PRN. Over the next 48 h cough became productive of yellow‑green sputum, dyspnea worsened to dyspnea on exertion (NYHA II), and he noted pleuritic chest pain left lower chest. He also reports chills, night sweats, and decreased appetite. Denies hemoptysis, wheezing, orthopnea, PND, leg swelling. No recent travel outside the region, no known sick contacts. He was evaluated in the ED of St. Mercy on 04/07/3078 where vitals showed T 38.9 °C, HR 112, RR 24, SpO2 92% RA, BP 138/78. Labs then: WBC 14.2 K with left shift, BMP normal, lactate 1.2. CXR showed left lower lobe infiltrate. He was given IV ceftriaxone 1 g q24h and azithro 500 mg IV q24h, plus 2 L NS. He was observed 12 h, but remained febrile and tachypneic, so was transferred to our facility for further management.  

Past Medical History:  
• Hypertension – diagnosed 04/3065, on lisinopril 20 mg daily  
• Type 2 Diabetes Mellitus – on metformin 1000 mg BID, insulin glargine 30 U qHS  
• Chronic Kidney Disease stage 3 (eGFR 48 mL/min) – stable  
• Hyperlipidemia – on rosuvastatin 10 mg daily  
• GERD – on omeprazole 20 mg daily  

Past Surgical History:  
• Appendectomy – 03/3050, laparoscopic  
• Right knee arthroscopy – 06/3062  

Family History:  
Father – HTN, MI at 62, deceased 3072  
Mother – DM2, alive 78y  
Brother – healthy  

Social History:  
Marital status: Married, spouse works as teacher  
Children: 2 (ages 12 and 9)  
Occupation: Software engineer, works from home but occasional site visits  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living situation: Single‑family home, no pets  

Review of Systems:  
Constitutional – fever, chills, fatigue, weight loss ~3 lb.  
HEENT – mild sore throat, no sinus pain.  
Respiratory – productive cough, pleuritic chest pain, dyspnea on exertion, no wheezes.  
Cardiovascular – denies chest pressure, palpitations.  
GI – N/V negative, mild anorexia.  
GU – no dysuria, no flank pain.  
Musculoskeletal – mild myalgias, no joint swelling.  
Neurologic – headache mild, no focal deficits.  
Skin – no rashes.  
Psych – mild anxiety about illness.  

Medications Prior to Admission:  
lisinopril 20 mg PO daily  
metformin 1000 mg PO BID  
insulin glargine 30 U SC qHS  
rosuvastatin 10 mg PO daily  
omeprazole 20 mg PO daily  
albuterol inhaler 2 puffs PRN  
azithromycin 500 mg PO daily x3 (completed)  

Allergies:  
No known drug allergies (NKDA)  

Physical Examination:  
Vital Signs: Temp 38.4 °C, HR 108, RR 22, BP 136/80, SpO2 94% on RA, Weight 92 kg (202 lb).  

General: Alert, appears mildly ill, in no acute distress.  

HEENT: Normocephalic, oropharynx erythematous, no exudates.  

Neck: Supple, no JVD, no cervical LAD.  

Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  

Respiratory: Diminished breath sounds left lower zone, crackles coarse, no wheezes, mild use of accessory muscles.  

Abdomen: Soft, non‑tender, bowel sounds present, no hepatosplenomegaly.  

Extremities: Warm, no edema, pulses 2+ bilaterally.  

Skin: No rashes, no lesions.  

Neuro: AOx3, CN II‑XII grossly intact, no focal deficits.  

Laboratory Data (most recent):  
CBC: WBC 13.8 K, Neut 84%, Lymph 10%, Hgb 13.2 g/dL, Plt 312 K.  
BMP: Na 138, K 4.3, Cl 102, CO2 24, BUN 18, Cr 1.4 (eGFR 45).  
CRP: 12.5 mg/dL (elevated).  
Procalcitonin: 0.42 ng/mL.  
Lactate: 1.1 mmol/L.  
Blood cultures: pending.  

Imaging:  
Chest X‑ray (04/07/3078): Left lower lobe consolidation with air bronchograms, no effusion.  
CT Chest (04/08/3078): Consolidation LLL with surrounding ground‑glass opacity, small right pleural effusion, no cavitation.  

Assessment and Plan:  
58yo M with HTN, DM2, CKD3 and recent community‑acquired pneumonia now admitted for IV antibiotics and close monitoring.  

1. Community‑acquired pneumonia, likely bacterial (Strep pneumoniae vs H. influenzae) with left lower lobe consolidation.  
   • Continue ceftriaxone 1 g IV q24h + azithromycin 500 mg IV q24h for total 5‑day course.  
   • Re‑evaluate cultures at 48 h; de‑escalate based on sensitivities.  
   • Monitor vitals q4h, repeat CBC and BMP daily.  
   • Incentive spirometry qhourly, early ambulation.  

2. Diabetes mellitus, type 2, currently hyperglycemic (BG 210‑250).  
   • Hold metformin (CKD).  
   • Continue insulin glargine 30 U qHS, add sliding scale regular insulin qac for BG >180.  

3. Hypertension – continue lisinopril 20 mg PO daily; monitor BP, hold if AKI develops.  

4. CKD stage 3 – avoid nephrotoxic agents, adjust ceftriaxone dose if Cr >2.0 (not needed now).  

5. VTE prophylaxis – SQ enoxaparin 40 mg SC daily (adjust for Cr).  

6. Fluid management – 1 L NS bolus day 1, then maintenance 80 mL/hr; monitor I/O.  

7. Diet – Diabetic, low sodium, regular.  

8. Code status – Full Code (Presumed).  

9. Disposition – Anticipate 4‑5 day stay, reassess for step‑down to oral antibiotics if afebrile >48 h, stable O2 <94% on RA, and improving labs.  

Consults: Infectious Diseases (for possible atypical coverage), Nephrology (CKD medication review).  

Prepared by: Dr. Evelyn Hartwell, MD  
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (94, 94, 46299007126, 46299007126, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Medicine Admission History and Physical  
05/31/3050 18:55  

Patient: Marcus L. Whitaker  
DOB: 02/14/3015  
MRN: 44782219  
PCP: Dr. Elaine V. Kline, MD  

Admitting Attending: Dr. Samuel R. Ortega, MD  
Location: MED01 – 3rd Floor  
Service: Hospital Medicine  

Chief Complaint: Fever, chills, malaise  

History of Present Illness:  
58yo M with h/o T2DM (A1c 9.2%), CKD stage 3 (eGFR 48), HTN, and recent right knee arthroplasty (D+7) p/w non‑localizing fever x4 days. Pt reports Tmax 102.5°F at home, associated with chills, night sweats, diffuse myalgias, and mild headache. Denies cough, dyspnea, dysuria, abdominal pain, rash, or focal pain. He was discharged from an outside orthopedic hospital 2 days ago after uncomplicated TKA; received peri‑op cefazolin and was on PO cefdinir 300 mg BID for presumed SSI prophylaxis. Since discharge, he has been ambulating with walker, but feels “run down” and noted that his glucose has been 180‑210 mg/dL despite usual basal insulin glargine 30 U qd. He took acetaminophen 650 mg PRN with minimal relief. No recent travel, no known sick contacts. No change in diet or fluid intake.  

ED Course (outside hospital): Vitals on arrival: T 101.8°F, HR 112, RR 20, BP 138/84, SpO2 98% RA. Labs: WBC 13.2 K/µL (neut 84%), Cr 1.4 mg/dL (baseline 1.2), lactate 1.2 mmol/L. CXR unremarkable. Blood cultures drawn, started on IV ceftriaxone 1 g q24h and vancomycin 1 g q12h. Transferred to our facility for continued care and orthopedic follow‑up.  

Since transfer, fever persists (T 101‑102°F q6‑8h). Pt reports mild nausea, no vomiting. No new focal findings on exam.  

Past Medical History:  
• Type 2 Diabetes Mellitus – diagnosed 2012  
• Hypertension – diagnosed 2008  
• Chronic Kidney Disease stage 3 – diagnosed 2025  
• Osteoarthritis – bilateral knees  
• Hyperlipidemia  

Past Surgical History:  
• Right Total Knee Arthroplasty – 05/24/3050 (right)  
• Left Knee Arthroscopy – 03/12/3048  

Family History:  
Father – HTN, MI at 62  
Mother – DM2, CKD  
Sister – healthy  

Social History:  
Marital Status: Married  
Occupation: Retired electrician  
Tobacco: Never smoker  
Alcohol: Social, 1‑2 drinks/week  
Illicit drugs: Denies  
Living Situation: Lives with spouse in single‑family home, owns a dog  

Review of Systems:  
Constitutional: Positive for fever, chills, fatigue, night sweats. Negative for weight loss.  
HEENT: Negative for sore throat, ear pain, visual changes.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea, sputum.  
Gastrointestinal: Negative for abdominal pain, diarrhea, vomiting (except occasional nausea).  
Genitourinary: Negative for dysuria, flank pain.  
Musculoskeletal: Right knee surgical site healing, no erythema, no drainage.  
Neurologic: Negative for headache (except mild), dizziness.  
Skin: No rash.  
Psychiatric: No anxiety/depression reported.  

Prior to Admission Medications:  
Medication – Sig  
Metformin 500 mg PO BID  
Glargine insulin 30 U SC qd  
Lisinopril 20 mg PO qd  
Atorvastatin 40 mg PO qhs  
Aspirin 81 mg PO qd  
Cefdinir 300 mg PO BID (started 05/24/3050)  

Allergies: No known drug allergies  

Physical Examination:  
Vital Signs:  
Temp 101.4°F (38.6°C)  
HR 108 bpm  
RR 18/min  
BP 132/78 mmHg  
SpO2 97% RA  

General: Alert, oriented x3, appears mildly ill, no acute distress.  
HEENT: Normocephalic, atraumatic, mucous membranes moist, oropharynx clear.  
Neck: Supple, no JVD, no lymphadenopathy.  
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Extremities: Right knee surgical dressing intact, no erythema, no drainage, mild swelling, ROM limited by pain. No edema elsewhere.  
Skin: Warm, dry, no rashes.  
Neurologic: AOx3, CN II‑XII grossly intact, strength 5/5 UE, 4/5 LE (right knee limited).  

Laboratory Results (most recent):  
CBC: WBC 12.8 K/µL, Hgb 13.2 g/dL, Hct 39.5%, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.6 mmol/L, Cl 102 mmol/L, CO2 24 mmol/L, BUN 22 mg/dL, Cr 1.5 mg/dL (baseline 1.2), Glu 192 mg/dL  
CRP: 8.4 mg/dL (elevated)  
Procalcitonin: 0.12 ng/mL (low)  
Blood cultures: pending (drawn 05/30)  
Urinalysis: Clear, no leukocyte esterase, no nitrites, <5 WBC/hpf  

Imaging:  
Chest X‑ray (05/31): No infiltrates, cardiac silhouette normal.  
Right knee AP/Lateral X‑ray (05/30): Prosthesis in good position, no peri‑prosthetic lucency, mild soft‑tissue swelling.  

Assessment and Plan:  
58yo M with recent right TKA, CKD3, DM2, presenting with persistent non‑localizing fever x4d, likely postoperative infectious work‑up pending. Differential includes early prosthetic joint infection (PJI) vs. urinary/respiratory source vs. drug fever vs. postoperative inflammatory response.  

1. Infectious work‑up:  
   • Continue IV ceftriaxone 1 g q24h and vancomycin (adjusted for CrCl) pending cultures.  
   • Add oral rifampin 600 mg qd for possible PJI coverage if cultures grow gram‑positive organisms.  
   • Repeat blood cultures q24h x2.  
   • Obtain joint aspiration of right knee tomorrow (orthopedics) for cell count, Gram stain, culture.  

2. Diabetes management:  
   • Hold metformin (eGFR <45).  
   • Switch to insulin sliding scale: regular insulin 4 U qAC PRN for glucose >180.  
   • Continue basal glargine 30 U qd.  

3. Renal function:  
   • Monitor Cr and electrolytes q12h.  
   • Adjust vancomycin dosing per trough.  

4. Hypertension:  
   • Continue lisinopril 20 mg qd; hold if K >5.5.  

5. Analgesia:  
   • Acetaminophen 650 mg PO q6h PRN (max 3 g/day).  
   • Consider low‑dose oxycodone 5 mg PO q6h PRN for breakthrough pain after orthopedic consult.  

6. VTE prophylaxis:  
   • SQ enoxaparin 40 mg SC daily (adjust for CrCl).  

7. Fluid & electrolytes:  
   • Maintain NPO except meds; IVF 0.9% NS 75 mL/hr to keep euvolemia.  

8. Monitoring:  
   • Telemetry not required.  
   • q8h vitals, q12h labs (CBC, BMP, CRP).  

9. Disposition:  
   • Admit to Med‑Surg floor, continue close orthopedic follow‑up.  
   • Anticipate possible transfer to orthopedic service if aspiration confirms PJI.  

Code Status: Full Code (Presumed)  
Diet: Regular, diabetic‑appropriate  
Activity: Ambulate with walker as tolerated, PT consult.  

Prepared by: Dr. Samuel R. Ortega, MD  
Pager: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (95, 95, 61732488894, 61732488894, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Evelyn Hartwell
MRN: 84276109
DOB: 04/22/2989
PCP: Dr. Lionel Marquez, MD

Date of Admission: 12/30/3054
Time: 16:36
Location: CARDIO01
Attending Provider: Dr. Selene K. Voss, MD

Chief Complaint: Dyspnea on exertion, orthopnea, lower extremity edema

History of Present Illness:
58yo F with h/o HFrEF (EF 32% on echo 03/3054), CAD s/p PCI to RCA 02/3052, HTN, CKD stage 3, and recent admission for decompensated HF 12/10/3054 now presents with 2‑wk progressive SOB, NYHA class III→IV, PND 2‑3×/wk, orthopnea requiring 3 pillows, and 1+ pitting edema to mid‑calves. She reports “feeling like her heart is going to stop” after climbing a single flight of stairs. Denies chest pain, palpitations, syncope. She was discharged 20 days ago after 4‑day IV diuresis (furosemide 80 mg IV q8h) and transition to oral bumetanide 1 mg daily; she was instructed to weigh daily and limit fluids to 1.5 L. Since discharge she has been non‑adherent to fluid restriction (estimated intake ~2.5 L/day) and missed two doses of bumetanide due to “forgetting”. She also reports a recent upper respiratory infection 5 days ago with mild cough, no fever. No recent travel. No known sick contacts.

Past Medical History:
- Heart Failure, HFrEF (EF 32%) – diagnosed 01/3050
- Coronary Artery Disease, s/p PCI (RCA) 02/3052
- Hypertension
- Chronic Kidney Disease, stage 3 (baseline Cr 1.6 mg/dL)
- Hyperlipidemia
- Atrial Fibrillation, paroxysmal, on apixaban

Past Surgical History:
- Cholecystectomy 07/3045
- Right knee arthroscopy 09/3048

Family History:
Father: HTN, MI at 62
Mother: DM2, CKD
Sister: Alive, no major illness

Social History:
Marital Status: Married
Occupation: Retired schoolteacher
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit Drugs: Denies
Living Situation: Lives with husband, two adult children visit weekly
Support: Husband assists with meds

Review of Systems:
Constitutional: +fatigue, +weight gain ~4 lb; -fever, -chills
Cardiovascular: +DOE, +PND, +orthopnea, +edema; -chest pain, -palpitations
Respiratory: +dyspnea on exertion; -cough, -hemoptysis
GI: -nausea, -vomiting, -abdominal pain
GU: -dysuria, -hematuria
Neuro: -dizziness, -syncope
Musculoskeletal: -joint pain
Skin: -rashes
Psych: +anxiety about health; -depression

Prior to Admission Medications:
Medication                     Sig
Lisinopril 20 mg PO daily
Metoprolol succinate 100 mg PO daily
Amlodipine 5 mg PO daily
Furosemide 40 mg PO daily
Bumetanide 1 mg PO daily
Spironolactone 25 mg PO daily
Apixaban 5 mg PO BID
Atorvastatin 40 mg PO nightly
Carvedilol 12.5 mg PO BID
Levothyroxine 75 mcg PO daily
Vitamin D3 2000 IU PO daily

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: T 36.8 °C (98.2 °F), HR 102 bpm, RR 22/min, BP 148/86 mmHg, SpO2 94 % on room air, Weight 84 kg (185 lb), Height 165 cm, BMI 30.9 kg/m²
General: Alert, mildly dyspneic, in mild distress, sitting upright with 3 pillows.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: JVD present (+), no thyromegaly.
Cardiovascular: Irregularly irregular rhythm, S1 S2 normal, S3 present, no murmurs, no rubs.
Respiratory: Bilateral basilar crackles up to mid‑lung fields, decreased breath sounds at bases, no wheezes.
Abdomen: Soft, non‑tender, +ascites mild, no hepatosplenomegaly.
Extremities: 2+ pitting edema to mid‑calves bilaterally, warm, pulses 2+.
Skin: No rashes, no ulcerations.
Neuro: AOx3, grossly non‑focal.

Laboratory Data (most recent):
CBC: WBC 7.8 K/µL, Hgb 12.1 g/dL, Hct 36 %, Plt 210 K/µL
BMP: Na 138 mmol/L, K 5.2 mmol/L, Cl 102 mmol/L, CO2 22 mmol/L, BUN 28 mg/dL, Cr 1.8 mg/dL (eGFR 38 mL/min), Glucose 112 mg/dL
BNP: 1,420 pg/mL
Troponin I: <0.01 ng/mL
LFTs: AST 28 U/L, ALT 32 U/L, ALP 78 U/L, Total bili 0.8 mg/dL
ABG (room air): pH 7.36, PaCO2 38 mmHg, PaO2 68 mmHg, HCO3‑ 22 mmol/L
ECG: Atrial fibrillation with rapid ventricular response ~110 bpm, QRS 96 ms, no ST‑T changes.
Chest X‑ray: Cardiomegaly, pulmonary venous congestion, bilateral interstitial edema, small pleural effusions.
Echocardiogram (03/3054): LVEF 32 %, LVEDD 6.2 cm, moderate MR, mild TR, RV systolic pressure 45 mmHg.

Assessment and Plan:
58yo F with known HFrEF (EF 32%) now presenting with acute decompensated heart failure secondary to fluid overload and suboptimal diuretic adherence.

1. Acute Decompensated HF:
   - Continue IV furosemide 80 mg bolus then infusion 10 mg/hr, titrate to net negative 1‑1.5 L/24 h.
   - Add IV metolazone 5 mg q24h for diuretic synergy.
   - Hold bumetanide while on IV loop diuretic; restart oral bumetanide 0.5 mg BID when euvolemic.
   - Monitor electrolytes q6h, replace K+ as needed (KCl oral 20 mEq q8h to keep K 4.0‑4.5).
   - Continue ACE‑I (lisinopril) and beta‑blocker (metoprolol) once BP stable >110/70.
   - Add low‑dose spironolactone 12.5 mg PO daily (already on 25 mg, consider reduction if hyperkalemia).
   - Daily weights, strict fluid restriction 1.5 L/day, sodium <2 g.

2. Atrial Fibrillation with RVR:
   - Rate control with metoprolol uptitration to 125 mg PO BID as tolerated.
   - Continue apixaban 5 mg BID (Cr 1.8, dose appropriate).

3. CKD stage 3:
   - Adjust diuretic dosing, avoid nephrotoxic agents.
   - Monitor Cr and BUN daily; hold metolazone if Cr >2.0 mg/dL.

4. Hypertension:
   - Optimize lisinopril dose; consider adding hydralazine if needed after volume status improved.

5. Education:
   - Reinforce fluid restriction, daily weight, medication adherence.
   - Arrange home health nurse for daily weight checks and medication administration.
   - Discuss advanced HF therapies (ICD/CRT) at outpatient follow‑up.

6. Disposition:
   - Admit to Cardiology Service, telemetry floor.
   - DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
   - Stress ulcer prophylaxis: PO pantoprazole 40 mg daily.
   - Diet: Low‑sodium (2 g), fluid‑restricted.
   - Code Status: Full Code (Presumed).

Follow‑up labs in 24 h, repeat BMP, BNP, and chest X‑ray if clinically indicated.  

Selene K. Voss, MD
Attending Cardiologist
Pager 8421');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (96, 96, 33707928009, 33707928009, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Patient: Marcus L. Whitaker
DOB: 04/12/3045
MRN: 98765432
PCP: Elaine Rivers, MD

Date of Admission: 11/23/3085
Time of Admission: 18:15
Location: MED01
Attending: Dr. Victor H. Kline, MD
Admitting Resident: Dr. Nina S. Patel, MD

Chief Complaint: Right foot pain, swelling, black discoloration

History of Present Illness:
40yo M with h/o T2DM (A1c 9.1% 3mo ago), PAD, HTN, CKD stage 3, and recent ulcer on R great toe p/w worsening pain, edema, and blackening over 48h. Pt reports that 2 days ago he noticed a small ulcer on the plantar surface after a fall from a ladder at work; he cleaned it with water, applied OTC bacitracin, and kept it covered. Over the past 24h the area became increasingly painful, now throbbing, with foul odor. He also notes numbness distal to the ulcer, coldness of the foot, and difficulty moving the toes. Yesterday EMS was called by his wife when he could not bear weight; he was taken to outside hospital (St. Mercy) where bedside Doppler showed absent pulses in the right dorsalis pedis and posterior tibial arteries. He received IV cefazolin 1g q8h and was transferred for higher level care and possible surgical intervention. He denies fever, chills, chest pain, SOB, N/V/D, or recent travel. He reports compliance with insulin glargine 30U nightly and metformin 1000mg BID, but admits occasional missed doses due to foot pain. No known drug allergies.

Past Medical History:
• Type 2 Diabetes Mellitus – diagnosed 2015
• Peripheral Arterial Disease – diagnosed 2020
• Hypertension – diagnosed 2018
• Chronic Kidney Disease Stage 3 – baseline Cr 1.6 mg/dL
• Hyperlipidemia
• GERD

Past Surgical History:
• Right transmetatarsal amputation – 02/3083 (complication of ulcer)
• Laparoscopic cholecystectomy – 07/3079

Family History:
Father – HTN, MI at 62
Mother – DM2, CKD
Sister – healthy
No known hereditary disorders.

Social History:
Marital Status: Married
Occupation: Construction foreman (frequent heavy lifting, occasional barefoot work)
Tobacco: Smokes 1 pack/day for 22y, currently 0.5 pack/day (reduced after diagnosis)
Alcohol: 2–3 beers/week, no binge
Illicit Drugs: Denies
Living Situation: Lives with spouse, two teenage children, owns home.

Review of Systems:
Constitutional – Negative for fever, chills, weight loss.
HEENT – No visual changes, hearing intact.
Cardiovascular – No chest pain, palpitations, orthopnea.
Respiratory – No cough, dyspnea.
Gastrointestinal – No nausea, vomiting, abdominal pain.
Genitourinary – No dysuria, hematuria.
Musculoskeletal – Right foot pain, swelling, black discoloration; denies other joint pain.
Neurologic – Numbness distal to ulcer, no headache, no dizziness.
Skin – Ulcer with black eschar on R great toe, foul odor.
Psychiatric – Mood stable, no depression.

Prior to Admission Medications:
Medication                Sig
Insulin glargine          30 Units subcut nightly
Metformin                 1000 mg PO BID
Lisinopril                20 mg PO daily
Atorvastatin              40 mg PO nightly
Aspirin                   81 mg PO daily
Gabapentin                300 mg PO TID PRN neuropathic pain
Omeprazole               20 mg PO daily

Allergies:
No known drug allergies.

Physical Examination:
Vital Signs: Temp 37.8°C (100.0°F), HR 112 bpm, RR 22/min, BP 148/86 mmHg, SpO2 96% RA, Weight 112 kg (247 lb)

General: Alert, in moderate distress due to pain, NAD otherwise.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no JVD.
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs, rubs, gallops.
Respiratory: Clear to auscultation bilaterally, no wheezes, no rales.
Abdomen: Soft, non-tender, normoactive bowel sounds.
Extremities:
  Right foot: Marked edema, black eschar covering ~3x2 cm area over plantar great toe, surrounding erythema, foul odor, absent dorsalis pedis and posterior tibial pulses by palpation. Warm proximally, cool distal to eschar. No crepitus. No ulcer on left foot.
  Left foot: No lesions, pulses 2+ bilaterally.
Skin: No rashes elsewhere.
Neurologic: Grossly non-focal, decreased sensation to light touch distal R foot, intact sensation elsewhere, strength 5/5 in all extremities.
Psych: Cooperative, oriented x3.

Laboratory Data (drawn on admission):
CBC:
WBC 14.2 x10^3/µL
Hgb 11.3 g/dL
Hct 34%
Plt 312 x10^3/µL

BMP:
Na 138 mmol/L
K 4.6 mmol/L
Cl 102 mmol/L
CO2 22 mmol/L
BUN 28 mg/dL
Cr 1.8 mg/dL (baseline 1.6)
Glucose 312 mg/dL

Inflammatory Markers:
CRP 12.4 mg/dL
ESR 48 mm/hr
Procalcitonin 1.8 ng/mL

Coagulation:
PT 13.1 sec
INR 1.1
aPTT 32 sec

Arterial Blood Gas (room air):
pH 7.32, pCO2 28, pO2 78, HCO3- 15

Microbiology:
Wound culture pending.
Blood cultures x2 drawn.

Imaging:
X-ray Right foot (AP/Lateral): No overt fracture, soft tissue swelling, gas not visualized.
Duplex Ultrasound Right lower extremity: No flow in dorsalis pedis and posterior tibial arteries; monophasic flow in posterior tibial stump; suggestive of critical limb ischemia.
CT Angiography (pending) – ordered to delineate proximal arterial disease.

Assessment and Plan:
58yo M with T2DM, PAD, CKD3, now presenting with acute gangrene of right great toe secondary to critical limb ischemia and superimposed infection.

1. Critical Limb Ischemia with Gangrene – Vascular Surgery consult emergently for possible revascularization vs. amputation. Keep NPO, IV access, monitor limb.
2. Soft Tissue Infection – Start broad-spectrum IV antibiotics: Piperacillin‑tazobactam 4.5 g q6h and Vancomycin dosed per renal function. Adjust per cultures.
3. Diabetes – Sliding scale insulin infusion to maintain glucose 140‑180 mg/dL; continue basal glargine at reduced dose.
4. Hypertension – Continue lisinopril; monitor BP.
5. CKD – Adjust antibiotics for renal function; monitor electrolytes and urine output.
6. Pain Management – IV morphine 2‑4 mg q1‑2h PRN, consider addition of gabapentin for neuropathic component.
7. DVT Prophylaxis – SQ low‑molecular‑weight heparin 40 mg daily (adjust for Cr).
8. Wound Care – Daily dressing changes, wound vac considered post‑operatively.
9. Labs – CBC, BMP, CRP q12h, blood cultures q12h, repeat wound cultures in 48h.
10. Imaging – Complete CT angiography within 12h; repeat duplex after any revascularization attempt.
11. Code Status – Full code (presumed); discuss goals of care with patient and family.
12. Disposition – Anticipate ICU level monitoring pending surgical decision; otherwise step‑down telemetry.

Patient and family educated on severity, need for possible amputation, and importance of tight glycemic control. Consent obtained for vascular surgery evaluation.

Victor H. Kline, MD
Attending Physician
Pager 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (97, 97, 75956140538, 75956140538, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
06/11/3089  
20:21  

Patient: Miguel Alvarez  
DOB: 02/14/3055  
PCP: Dr. Lila Ortega, MD  

CHIEF COMPLAINT: Redness, drainage, and pain at recent laparoscopic cholecystectomy incision  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o HTN, T2DM (A1c 8.7%), CKD stage 3, obesity (BMI 34), and recent laparoscopic cholecystectomy p/w SSI presents w/ progressive erythema, purulent drainage, and increasing pain over the RUQ port site for 4 days. Pt reports that on POD #2 he noted mild serous ooze, was told it was normal. By POD #4 the drainage became thick, yellow-green, foul smelling, and the surrounding skin turned bright red, warm, and tender. He has low‑grade fevers up to 38.3°C at home, chills, and decreased appetite. Denies nausea, vomiting, abdominal distention, or changes in bowel habits. He was discharged from outside hospital on 06/05/3089 after an uncomplicated surgery; received a single dose of IV cefazolin intra‑op and was prescribed oral amoxicillin‑clavulanate 875/125 mg BID for 5 days, which he completed on 06/09/3089. He stopped meds on 06/09 due to “feeling better,” but symptoms worsened after. He presented to ED on 06/10/3089, vitals: T 38.2°C, HR 102, BP 138/84, RR 20, SpO2 98% RA. Labs showed WBC 14.2 with left shift. CT abdomen/pelvis with contrast demonstrated a 2.3 cm fluid collection adjacent to the right subcostal port site with surrounding fat stranding, no intra‑abdominal abscess. He was started on IV piperacillin‑tazobactam 4.5 g q6h and taken to OR for incision and drainage (I&D) on 06/10/3089. Intra‑op cultures grew mixed gram‑positive cocci; wound was loosely approximated with absorbable sutures, wound vac placed. Pt now admitted for IV antibiotics, wound monitoring, and glycemic control.  

MEDICAL & SURGICAL HISTORY:  

Past Medical History:  
• Hypertension – diagnosed 2015, on lisinopril 20 mg daily  
• Type 2 Diabetes Mellitus – diagnosed 2018, on metformin 1000 mg BID, insulin glargine 20 U qHS  
• Chronic Kidney Disease stage 3 – baseline Cr 1.6 mg/dL, eGFR ~45 mL/min/1.73 m²  
• Obesity (BMI 34)  

Past Surgical History:  
• Laparoscopic cholecystectomy – 06/05/3089 (RUQ 5 mm port, epigastric 10 mm port)  
• Appendectomy – 3020 (open)  

FAMILY HISTORY:  
Father – HTN, MI at 62; Mother – DM2, CKD; Sister – healthy  

SOCIAL HISTORY:  
Marital Status: Married, spouse works as school teacher  
Children: 2 (ages 12, 9)  
Employment: Warehouse supervisor, shift work, occasional overtime  
Tobacco: Never smoker  
Alcohol: Social, 1–2 drinks/week, no binge  
Illicit Drugs: Denies  
Living Situation: Owns single‑family home, no pets  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills, fatigue; negative for weight loss.  
HEENT: Negative.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea.  
GI: Positive for RUQ pain at incision site; negative for nausea, vomiting, melena.  
GU: Negative.  
Musculoskeletal: Negative.  
Neurologic: Negative.  
Skin: Positive for erythema, drainage at surgical site; negative elsewhere.  
Psych: Negative.  

PRIOR TO ADMISSION MEDICATIONS:  

Medication Sig  
lisinopril 20 MG tablet TAKE 1 TABLET BY MOUTH DAILY  
metformin 1000 MG tablet TAKE 1 TABLET BY MOUTH BID  
insulin glargine (LANTUS) 100 UNITS/ML injection INJECT 20 UNITS SUBCUTANEOUS QHS  
aspirin 81 MG EC tablet TAKE 1 TABLET BY MOUTH DAILY  
omeprazole 20 MG capsule TAKE 1 CAPSULE BY MOUTH DAILY  

Allergies:  
No known drug allergies (NKDA)  

PHYSICAL EXAMINATION:  

Temperature: 37.9 °C (100.2 °F)  
Heart Rate: 100 bpm  
Respiratory Rate: 18/min  
Blood Pressure: 135/82 mmHg  
SpO2: 98% RA  
General: Alert, appears mildly ill, in mild discomfort due to wound pain.  
HEENT: Normocephalic, atraumatic, oropharynx clear.  
Neck: Supple, no JVD.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales.  
Abdomen: Soft, mild tenderness to palpation over RUQ port site, no rebound, no guarding.  
Surgical Wound (right subcostal 10 mm port): 4 cm erythematous area, purulent drainage noted, wound vac in place, surrounding induration.  
Extremities: No edema, pulses 2+ bilaterally.  
Skin: Warm, no other lesions.  
Neuro: AOx3, grossly non‑focal.  

LABS AND IMAGING:  

CBC: WBC 14.2 K/µL (neutrophils 82%), Hgb 13.1 g/dL, Plt 312 K/µL  
BMP: Na 138 mmol/L, K 4.5 mmol/L, Cl 102 mmol/L, CO2 24 mmol/L, BUN 22 mg/dL, Cr 1.7 mg/dL (baseline 1.6), Glu 182 mg/dL  
CRP: 12.5 mg/dL (elevated)  
Procalcitonin: 0.68 ng/mL  
Blood Cultures: No growth at 48 h  
Wound Culture: Mixed gram‑positive cocci, susceptible to penicillins  
CT Abdomen/Pelvis w/ contrast (06/10/3089): 2.3 cm fluid collection adjacent to right subcostal port site with fat stranding, no intra‑abdominal abscess.  

ASSESSMENT AND PLAN:  
58yo M with HTN, DM2, CKD3, recent laparoscopic cholecystectomy now w/ surgical site infection (SSI) of right subcostal port, purulent drainage, cellulitis, and small peri‑incisional fluid collection.  

1. Surgical Site Infection – continue IV piperacillin‑tazobactam 4.5 g q6h; reassess cultures at 48 h for de‑escalation. Keep wound vac, daily dressing changes, monitor for expansion.  
2. Diabetes – target glucose 140‑180 mg/dL; continue insulin glargine, add sliding scale regular insulin qac PRN.  
3. Hypertension – continue lisinopril 20 mg daily; monitor BP.  
4. CKD – maintain fluids, avoid nephrotoxic agents, monitor Cr daily.  
5. Pain – acetaminophen 650 mg q6h PRN; consider low‑dose IV morphine q4h PRN if needed.  
6. DVT prophylaxis – SQ enoxaparin 40 mg subcut daily (adjust for Cr).  
7. Diet – Diabetic/renal appropriate, low sodium, moderate protein.  
8. Activity – ambulate as tolerated, encourage incentive spirometry.  
9. Disposition – Admit to Med‑Surg floor, telemetry not required unless arrhythmia develops.  
10. Education – wound care teaching, signs of worsening infection, glucose monitoring.  

Code Status: Full Code (Presumed)  
Level of Care: Acute care admission  

Miguel Alvarez, MD  
Hospitalist  
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (98, 98, 74752567173, 74752567173, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospital Admission History and Physical  
08/10/3076 22:05  

Patient: Michael Turner  
DOB: 02/14/3048  
PCP: Linda Harper, MD  

CHIEF COMPLAINT: Low back pain, radiating to left lower extremity  

HISTORY OF PRESENT ILLNESS:  
28yo M with h/o lumbar disc herniation (L4‑L5) s/p micro‑discectomy 2 y ago, chronic intermittent low back pain, presents w/ acute worsening of low back pain x 3 days. Pt reports a mechanical fall on 08/07/3076 while lifting a 30 lb box at work; landed on his right side, immediate “pop” sensation in low back, then progressive dull‑achy pain radiating down the posterior left thigh to the calf, numbness to the dorsum of the left foot, and difficulty ambulating >50 ft. Denies bowel or bladder incontinence, but notes occasional “pins‑and‑needles” in left foot when standing. Pt went to urgent care on 08/08/3076, received plain radiographs (read as “degenerative changes, no acute fracture”), prescribed ibuprofen 600 mg TID PRN and cyclobenzaprine 10 mg qHS. No relief, pain now 8/10 at rest, 10/10 with movement. Pt reports prior episodes of similar pain that resolved with rest and NSAIDs. No recent travel, no sick contacts.  

PAST MEDICAL HISTORY:  
• Lumbar disc herniation (L4‑L5) – 2024, micro‑discectomy 2024  
• Hypertension – controlled on lisinopril  
• Seasonal allergic rhinitis  

PAST SURGICAL HISTORY:  
Procedure Laterality Date  
• MICRO‑DISCECTOMY L4‑L5 Right 03/12/3044  

FAMILY HISTORY:  
Father – HTN, MI @ 58 y  
Mother – DM2, CKD stage 3  
Sister – healthy  

SOCIAL HISTORY:  
Marital Status: Single, lives alone in apartment  
Occupation: Warehouse associate, lifts moderate loads daily  
Tobacco Use: Never smoker  
Alcohol Use: Social, 1‑2 beers/week  
Illicit Drugs: Denies  
Sexual Activity: Heterosexual, monogamous, uses condoms intermittently  

REVIEW OF SYSTEMS:  
Constitutional: Negative for fever, chills, weight loss.  
HEENT: Negative for visual changes, sinus pain.  
Cardiovascular: No chest pain, palpitations.  
Respiratory: No cough, dyspnea.  
GI: No N/V, no change in bowel habits.  
GU: No dysuria, no hematuria.  
Musculoskeletal: Positive for low back pain radiating to left leg, numbness left foot.  
Neurologic: Negative for headache, dizziness, seizures.  
Psychiatric: No depression or anxiety noted.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
lisinopril 10 mg tablet TAKE 1 tablet by mouth daily  
ibuprofen 600 mg tablet TAKE 1 tablet by mouth every 6 hr PRN pain  
cyclobenzaprine 10 mg tablet TAKE 1 tablet by mouth at bedtime PRN muscle spasm  

ALLERGIES:  
No known drug allergies (NKDA)  

PHYSICAL EXAMINATION:  
Temperature: 36.8 °C (98.2 °F)  
Heart Rate: 88 bpm  
Respiratory Rate: 16/min  
Blood Pressure: 132/78 mmHg  
SpO₂: 98% RA  

General: Alert, oriented x3, in mild distress due to pain, ambulating with assistance.  
HEENT: Normocephalic, atraumatic, PERRLA, EOMI, oropharynx clear.  
Neck: Supple, no meningismus.  
Cardiovascular: RRR, S1 S2 normal, no murmurs, rubs, gallops.  
Respiratory: Clear to auscultation bilaterally, no wheezes, rales, or rhonchi.  
Abdomen: Soft, non‑tender, normoactive bowel sounds.  
Back: Tender to palpation over L4‑L5, decreased lumbar flexion, positive straight‑leg raise left at 45°, reproduces radicular pain.  
Extremities: No edema, pulses 2+ bilaterally.  
Neurologic: Motor 5/5 UE, 5/5 LE except left ankle dorsiflexion 4/5. Sensation decreased to light touch over left L5 dermatome. Reflexes 2+ patellar bilaterally, left Achilles 1+. No Babinski.  
Skin: Warm, dry, no rashes.  

RECENT LABS:  
CBC – WBC 9.2 K/µL, Hgb 14.1 g/dL, Hct 42%, Plt 250 K/µL  
BMP – Na 138 mmol/L, K 4.1 mmol/L, Cl 102 mmol/L, CO₂ 24 mmol/L, BUN 14 mg/dL, Cr 0.9 mg/dL, Glu 112 mg/dL, Ca 9.2 mg/dL  
CRP 4.2 mg/dL (elevated)  
ESR 22 mm/hr  

IMAGING:  
MRI Lumbar Spine (08/09/3076) – L4‑L5 disc protrusion with left foraminal stenosis, mild central canal compromise, no epidural abscess or fracture.  

ASSESSMENT / PLAN:  
1. Acute low back pain with left L5 radiculopathy secondary to L4‑L5 disc protrusion – admit for pain control, monitor neuro status, and consider early epidural steroid injection if no improvement with conservative measures.  
   • Initiate IV ketorolac 15 mg q6h PRN, PO acetaminophen 650 mg q6h PRN.  
   • Start oral gabapentin 300 mg TID for neuropathic component.  
   • Physical therapy consult – bedside ROM and gentle mobilization day 1.  
   • Orthopedic spine consult – evaluate need for surgical decompression vs. injection.  
   • Keep NPO until cleared for oral meds, then advance diet as tolerated.  

2. Hypertension – continue lisinopril 10 mg daily, monitor BP q8h.  

3. DVT prophylaxis – SQ enoxaparin 40 mg subcut daily.  

4. Fall risk – place on fall precautions, ensure bedside commode, assist with ambulation.  

5. Labs – repeat CBC, BMP, CRP q24h; obtain serum electrolytes if gabapentin started.  

6. Disposition – anticipate discharge to home with outpatient PT and spine follow‑up if stable in 48‑72 h; otherwise consider transfer to step‑down unit for continued pain management.  

CODE STATUS: Full Code (Presumed)  

Attending Provider: Samuel Ortiz, MD  
Pager #: 84231');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (99, 99, 69569725915, 69569725915, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, '02/03/3078 01:25

PATIENT: Miguel Alvarez
DOB: 07/14/3045
MRN: 98765432
PCP: Dr. Elena Rivera, MD

CHIEF COMPLAINT: Dysuria, suprapubic pain, and fever

HISTORY OF PRESENT ILLNESS:
58yo M with h/o HTN, CKD stage 3 (baseline Cr 1.6), DM2 (A1c 8.7%), BPH, and recent Foley catheter placement p/w dysuria, urgency, suprapubic tenderness, and chills x 48h. Patient reports that 3 days ago he was discharged from an outside hospital after a 2‑day stay for elective TURP; Foley was removed on day 1 post‑op but re‑inserted on day 2 due to urinary retention. Since removal he has had burning on micturition, cloudy urine, and low‑grade fevers up to 38.4°C. Denies flank pain, hematuria, or incontinence. He took acetaminophen PRN with minimal relief. He reports increased urinary frequency (Q8‑10min) and nocturia x3. No recent sexual activity. No known drug allergies. He was given a 5‑day course of ciprofloxacin at discharge but stopped after 2 days because of nausea. He now presents to our ED for worsening symptoms. Vitals on arrival: T 38.6°C, HR 112, BP 138/78, RR 20, SpO2 97% RA. Physical exam noted suprapubic tenderness, no CVA tenderness. Labs drawn, UA sent, and renal US ordered.

PAST MEDICAL HISTORY:
• Hypertension – diagnosed 2015, on lisinopril 20 mg daily
• Type 2 Diabetes Mellitus – on metformin 1000 mg BID, insulin glargine 30 units qHS
• Chronic Kidney Disease stage 3 – baseline Cr 1.6 mg/dL
• Benign Prostatic Hyperplasia – on tamsulosin 0.4 mg daily
• Hyperlipidemia – on rosuvastatin 10 mg daily

PAST SURGICAL HISTORY:
• TURP – 02/01/3078 (outside hospital)
• Appendectomy – 3032
• Right inguinal hernia repair – 3048

FAMILY HISTORY:
Father – HTN, died MI age 68
Mother – DM2, alive 84
Brother – CKD stage 4
No known hereditary renal disease.

SOCIAL HISTORY:
Marital status: Married
Occupation: Maintenance supervisor at a manufacturing plant
Tobacco: Never smoker
Alcohol: Social, 1‑2 drinks/week
Illicit drugs: Denies
Living situation: Lives with spouse, two adult children; stable housing.
Travel: No recent travel outside state.
Sexual activity: Heterosexual, monogamous, last activity 2 weeks ago; uses condoms inconsistently.

REVIEW OF SYSTEMS:
Constitutional: Positive for fever, chills, fatigue. Negative for weight loss.
HEENT: Negative.
Cardiovascular: Negative for chest pain, palpitations.
Respiratory: Negative for cough, dyspnea.
GI: Negative for nausea, vomiting, abdominal pain.
GU: Positive for dysuria, urgency, suprapubic pain. Negative for hematuria, flank pain, incontinence.
Musculoskeletal: Negative.
Neurologic: Negative.
Psychiatric: Negative.

PRIOR TO ADMISSION MEDICATIONS:
Medication                Sig
lisinopril 20 MG tablet   TAKE 1 TAB BY ORAL DAILY
metformin 1000 MG tablet TAKE 1 TAB BY ORAL BID
insulin glargine 100 UNITS/ML injection 30 UNITS SC QHS
tamsulosin 0.4 MG capsule TAKE 1 CAP BY ORAL DAILY
rosuvastatin 10 MG tablet TAKE 1 TAB BY ORAL DAILY
ciprofloxacin 500 MG tablet TAKE 1 TAB BY ORAL BID (stopped after 2 days)

ALLERGIES:
No known drug allergies.

PHYSICAL EXAMINATION:
Temperature: 38.6°C
Heart Rate: 112 bpm
Respiratory Rate: 20/min
Blood Pressure: 138/78 mmHg
SpO2: 97% RA
General: Alert, appears mildly ill, in no acute distress.
HEENT: Normocephalic, atraumatic, mucous membranes moist.
Neck: Supple, no lymphadenopathy.
Cardiovascular: Regular rate and rhythm, S1 S2 normal, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.
Abdomen: Soft, mildly tender suprapubic region, no rebound, no guarding, no CVA tenderness.
Genitourinary: External genitalia normal, no discharge. Foley present, draining clear urine.
Extremities: No edema, pulses 2+ bilaterally.
Skin: Warm, dry, no rashes.
Neuro: Alert and oriented x3, no focal deficits.

LABS:
CBC:
WBC 14.2 x10^3/µL (neutrophils 84%)
Hgb 13.1 g/dL
Hct 39%
Plt 312 x10^3/µL

BMP:
Na 138 mmol/L
K 4.5 mmol/L
Cl 102 mmol/L
CO2 23 mmol/L
BUN 28 mg/dL
Cr 1.8 mg/dL (up from baseline 1.6)
Glucose 212 mg/dL

UA:
Color yellow, cloudy
Specific gravity 1.020
pH 6.0
Leukocyte esterase +++
Nitrites positive
WBC 45/hpf, RBC 5/hpf, bacteria many

Blood cultures: x2 sets pending
Urine culture: sent

Imaging:
Renal ultrasound (02/03/3078): Kidneys normal size, no hydronephrosis, bladder wall mildly thickened, Foley in place.

ASSESSMENT/PLAN:
58yo M with h/o HTN, CKD3, DM2, recent TURP with Foley, now presenting with acute uncomplicated cystitis likely secondary to ESBL‑producing E. coli, complicated by mild AKI (Cr rise to 1.8). Plan:
1. Start empiric IV ceftriaxone 2 g q24h pending urine culture sensitivities; consider step‑down to oral TMP‑SMX if susceptible and renal function stable.
2. Continue insulin glargine; add correctional sliding scale regular insulin qAC for hyperglycemia.
3. Hold lisinopril today (prerenal concern), re‑evaluate tomorrow.
4. Maintain Foley; plan removal in 48 h if output adequate and no obstruction.
5. IV fluids: 0.9% NS 1 L bolus then maintenance 75 mL/hr, monitor intake/output.
6. Pain control: acetaminophen 650 mg PO q6h PRN; avoid NSAIDs given CKD.
7. DVT prophylaxis: SQ enoxaparin 40 mg SC daily.
8. Education: increase oral fluid intake, complete full antibiotic course, monitor for fever or flank pain.
9. Disposition: Admit to Med‑Surg floor, telemetry not required, monitor labs q24h, reassess renal function and culture results.

CODE STATUS: Full Code (Presumed)

FOLLOW‑UP: Infectious Diseases consult if no improvement by day 3 or culture shows resistant organism.

Prepared by: Dr. Samuel K. Patel, MD
Attending Hospitalist
Pager # 84219');
INSERT INTO public.llacie_notes (id, "FK_episode_id", "NoteID", "PatientEncounterID", "InpatientNoteTypeDSC", "CurrentAuthorID", "AuthorServiceDSC", "AuthorProviderTypeDSC", "CreateDTS", "DateOfServiceDTS", "LastFiledDTS", "EDWLastModifiedDTS", "NoteFiledDTS", "ContactDateRealNBR", "NoteCSNID", note_text) VALUES (100, 100, 41443257973, 41443257973, 'H&P', NULL, NULL, NULL, NULL, '2025-11-19 06:07:13.035833+00', NULL, NULL, NULL, NULL, NULL, 'Example Hospitalist Admission History and Physical  
11/01/3095  
02:43  

Patient: Miguel Alvarez  
DOB: 04/22/3065  
PCP: Dr. Lila Mendoza, MD  

CHIEF COMPLAINT: Right foot ulcer with increasing drainage  

HISTORY OF PRESENT ILLNESS:  
58yo M with h/o T2DM (A1c 9.4% 3mo ago), PAD, CKD stage 3, and prior left transmetatarsal amputation p/w R foot ulcer x2 wks, now worsening erythema, purulent drainage, foul odor, and mild fevers. Patient reports that ulcer began as a small blister after stepping on a construction nail 10 days ago while working on a roof repair. He initially self‑treated with OTC bacitracin and kept foot elevated. Over the past 48 h he noted increased swelling, throbbing pain radiating to the calf, and a temperature of 101.2 °F at home. He denied any recent travel, sick contacts, or new shoes. He presented to an outside urgent care on 10/28 where a wound culture was taken (results pending) and he was given a single dose of IM ceftriaxone and instructed to follow‑up. He left against medical advice because he felt “better” but the pain returned and the drainage became copious. EMS was called by his wife on 11/01 after she found the dressing soaked. In the ambulance he was noted to be tachycardic (HR 112) and mildly hypotensive (BP 98/62). He reports baseline insulin glargine 30 U nightly and lispro sliding scale, but admits he missed several doses over the past week due to “feeling too sick to inject.” He denies chest pain, SOB, dysuria, or GI symptoms.  

PAST MEDICAL HISTORY:  
• Type 2 Diabetes Mellitus – diagnosed 2015  
• Peripheral Arterial Disease – bilateral, intermittent claudication  
• Chronic Kidney Disease – stage 3 (eGFR 48)  
• Hypertension – controlled on lisinopril  
• Hyperlipidemia  

PAST SURGICAL HISTORY:  
Procedure Laterality Date  
• LEFT TRANSMETATARSAL AMPUTATION – LEFT – 09/15/3092  
• APPENDECTOMY – NONE – 07/03/3070  

FAMILY HISTORY:  
Father – HTN, died MI age 68  
Mother – DM2, alive 82  
Sister – healthy  

SOCIAL HISTORY:  
Marital Status: Married  
Occupation: Roofer / construction laborer (full‑time)  
Tobacco Use: Smoker, 1 pack/day for 30 yr, currently ½ pack/day  
Alcohol Use: Social, 2‑3 beers weekends  
Illicit Drugs: Denies  
Living Situation: Lives with spouse, two adult children, owns home  

REVIEW OF SYSTEMS:  
Constitutional: Positive for fever, chills, fatigue.  
HEENT: Negative.  
Cardiovascular: Negative for chest pain, palpitations.  
Respiratory: Negative for cough, dyspnea.  
GI: Negative for N/V/D.  
GU: Negative.  
Musculoskeletal: Positive for right foot pain, swelling, drainage.  
Skin: Positive for ulcer, erythema, foul odor.  
Neuro: Negative.  
Psych: Negative.  

PRIOR TO ADMISSION MEDICATIONS:  
Medication Sig  
insulin glargine (LANTUS) 30 U subcut nightly  
insulin lispro (HUMALOG) sliding scale qac PRN  
lisinopril 20 mg PO daily  
atorvastatin 40 mg PO nightly  
aspirin 81 mg PO daily  
metformin 1000 mg PO BID (held on admission)  
furosemide 20 mg PO daily  

ALLERGIES:  
No known drug allergies  

PHYSICAL EXAMINATION:  
Temperature: 38.9 °C (102 °F)  
Heart Rate: 108 bpm  
Respiratory Rate: 22/min  
Blood Pressure: 96/58 mmHg (orthostatic)  
SpO2: 96% RA  

General: Alert, appears uncomfortable, diaphoretic, NAD otherwise.  
HEENT: Normocephalic, mucous membranes moist.  
Neck: Supple, no JVD.  
Cardiovascular: Tachycardic, regular rhythm, S1 S2 normal, no murmurs.  
Respiratory: Clear to auscultation bilaterally, mild tachypnea, no wheezes.  
Abdomen: Soft, non‑tender, BS +.  
Extremities: Right foot – 5 cm x 4 cm ulcer over plantar surface of 2nd metatarsal head, deep, with necrotic base, purulent yellow‑green drainage, surrounding erythema extending to mid‑foot, warmth, edema. No crepitus. Pedal pulses diminished bilaterally, cap refill >3 sec. Left foot – well healed amputation stump, no infection.  
Skin: No rashes elsewhere.  
Neuro: Grossly intact, AAOx3.  

LABS (STAT):  
CBC – WBC 16.2 K (neut 84%), Hgb 11.2 g/dL, Plt 312 K  
BMP – Na 138, K 4.6, Cl 102, CO2 22, BUN 22, Cr 1.4 (eGFR 45)  
Glucose 312 mg/dL  
CRP 12.8 mg/dL  
ESR 48 mm/hr  
Procalcitonin 0.9 ng/mL  
HbA1c 9.4% (from 3 mo prior)  

Blood cultures x2 – pending  
Wound culture – sent to microbiology (preliminary: gram‑positive cocci in clusters)  

IMAGING:  
X‑ray Right foot – soft tissue swelling, no obvious osteomyelitis, no gas.  
MRI Right foot (ordered) – pending, to evaluate for osteomyelitis.  

ASSESSMENT AND PLAN:  
58yo M with poorly controlled T2DM, PAD, CKD3, now presenting with right foot ulcer complicated by cellulitis, possible early osteomyelitis, and sepsis.  

1. Diabetic foot infection – start empiric IV vancomycin 15 mg/kg q12h and cefepime 2 g q8h after cultures. Adjust per sensitivities.  
2. Sepsis – aggressive fluid resuscitation 30 mL/kg NS bolus, monitor MAP, start norepinephrine infusion if MAP <65 after fluids.  
3. Glycemic control – insulin drip (IV regular insulin) titrated to 140‑180 mg/dL, resume basal glargine when stable.  
4. CKD – adjust cefepime dose for eGFR, monitor renal function q12h.  
5. PAD – vascular surgery consult for possible revascularization if osteomyelitis confirmed.  
6. Wound care – daily dressing changes, debridement by podiatry tomorrow.  
7. DVT prophylaxis – SQ enoxaparin 40 mg daily (adjust for renal).  
8. Cardiac – continue lisinopril, hold ACEI today due to hypotension, re‑evaluate.  
9. Nutrition – diabetic diet, consult dietitian.  
10. Disposition – admit to telemetry floor, monitor vitals q1h, labs q12h, consider ICU if hemodynamic instability worsens.  

CODE STATUS: Full Code (Presumed)  
LEVEL OF CARE: Telemetry  

Patient and spouse counseled on seriousness of infection, need for IV antibiotics, possible amputation if progression. They verbalized understanding and consented to plan.  

“Portion of this record may have been generated with voice recognition; please verify all entries for accuracy.”  

Miguel Alvarez, MD  
Pager # 84231');


--
-- Data for Name: llacie_strategies; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_strategies (id, "FK_task_id", name, "desc", version, last_updated) VALUES (1, 1, 'section.hpi_short.regex', 'Attempts to extract the `hpi_short` section using regular expressions
to find most likely beginning and ending delimiters within each note.
', '0.0.1', '2025-11-19 06:07:14.599634+00');
INSERT INTO public.llacie_strategies (id, "FK_task_id", name, "desc", version, last_updated) VALUES (2, 2, 'feature.presenting_sx.llama3_8b', 'Attempts to extract the `presenting_sx` feature using Llama 3 Instruct 8B model,
an 8B parameter model in the Llama family released by Meta in April 2024. 

This uses the original weights casted to torch.float16, because the Tesla V100s that we can 
run this on in ERISXdl do not support bfloat16. 
https://huggingface.co/meta-llama/Meta-Llama-3-8B-Instruct

Also uses the `hpi_short` sections created by the section.hpi_short.regex strategy.
', '0.0.1', '2025-11-19 06:07:16.166645+00');


--
-- Data for Name: llacie_tasks; Type: TABLE DATA; Schema: public; Owner: llacie
--

INSERT INTO public.llacie_tasks (id, output_type, name, "desc") VALUES (1, 'section', 'hpi_short', 'Simplest version of the HPI extractable from an H&P or ED note,
starting with the summary statement and **not** including the ED course,
A&P, any SmartText''ed ED data or findings, medications, A&P, ROS, 
PMH, Impression, or other similar sections of the note.

This may include the Onc history or descriptions of recent hospitalizations
if they are included before the ED course or other sections as listed above.

For now, we focus on H&Ps rather than the ED notes. We also don''t consider
Consult notes, although they''d probably work OK as well.
');
INSERT INTO public.llacie_tasks (id, output_type, name, "desc") VALUES (2, 'feature', 'presenting_sx', 'Presenting symptoms found in the `hpi_short` section of a note.

Limited to H&P notes only, for patients with suspected infection,
and applying the exclusions listed in Pak et al. CID 2023:
https://pubmed.ncbi.nlm.nih.gov/37531612/
');


--
-- Name: llacie_annotators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_annotators_id_seq', 1, false);


--
-- Name: llacie_cohorts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_cohorts_id_seq', 100, true);


--
-- Name: llacie_episode_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_episode_labels_id_seq', 1, false);


--
-- Name: llacie_episodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_episodes_id_seq', 100, true);


--
-- Name: llacie_note_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_note_features_id_seq', 2, true);


--
-- Name: llacie_note_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_note_sections_id_seq', 100, true);


--
-- Name: llacie_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_notes_id_seq', 100, true);


--
-- Name: llacie_strategies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_strategies_id_seq', 2, true);


--
-- Name: llacie_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: llacie
--

SELECT pg_catalog.setval('public.llacie_tasks_id_seq', 2, true);


--
-- Name: llacie_annotators llacie_annotators_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_annotators
    ADD CONSTRAINT llacie_annotators_pkey PRIMARY KEY (id);


--
-- Name: llacie_annotators llacie_annotators_username_key; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_annotators
    ADD CONSTRAINT llacie_annotators_username_key UNIQUE (username);


--
-- Name: llacie_cohorts llacie_cohorts_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_cohorts
    ADD CONSTRAINT llacie_cohorts_pkey PRIMARY KEY (id);


--
-- Name: llacie_episode_labels llacie_episode_labels_episode_feat_strategy_label_key; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT llacie_episode_labels_episode_feat_strategy_label_key UNIQUE ("FK_episode_id", "FK_task_id", "FK_strategy_id", "FK_human_annotator", label_name);


--
-- Name: llacie_episode_labels llacie_episode_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT llacie_episode_labels_pkey PRIMARY KEY (id);


--
-- Name: llacie_episodes llacie_episodes_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episodes
    ADD CONSTRAINT llacie_episodes_pkey PRIMARY KEY (id);


--
-- Name: llacie_note_features llacie_note_features_note_feat_strategy_key; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_features
    ADD CONSTRAINT llacie_note_features_note_feat_strategy_key UNIQUE ("FK_note_id", feature_name, "FK_strategy_id");


--
-- Name: llacie_note_features llacie_note_features_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_features
    ADD CONSTRAINT llacie_note_features_pkey PRIMARY KEY (id);


--
-- Name: llacie_note_sections llacie_note_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_sections
    ADD CONSTRAINT llacie_note_sections_pkey PRIMARY KEY (id);


--
-- Name: llacie_notes llacie_notes_NoteID_key; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_notes
    ADD CONSTRAINT "llacie_notes_NoteID_key" UNIQUE ("NoteID");


--
-- Name: llacie_notes llacie_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_notes
    ADD CONSTRAINT llacie_notes_pkey PRIMARY KEY (id);


--
-- Name: llacie_strategies llacie_strategies_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_strategies
    ADD CONSTRAINT llacie_strategies_pkey PRIMARY KEY (id);


--
-- Name: llacie_tasks llacie_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_tasks
    ADD CONSTRAINT llacie_tasks_pkey PRIMARY KEY (id);


--
-- Name: llacie_cohorts_FK_episode_id_key; Type: INDEX; Schema: public; Owner: llacie
--

CREATE INDEX "llacie_cohorts_FK_episode_id_key" ON public.llacie_cohorts USING btree ("FK_episode_id");


--
-- Name: llacie_note_features_FK_strategy_id_key; Type: INDEX; Schema: public; Owner: llacie
--

CREATE INDEX "llacie_note_features_FK_strategy_id_key" ON public.llacie_note_features USING btree ("FK_strategy_id");


--
-- Name: llacie_notes_FK_episode_id_key; Type: INDEX; Schema: public; Owner: llacie
--

CREATE INDEX "llacie_notes_FK_episode_id_key" ON public.llacie_notes USING btree ("FK_episode_id");


--
-- Name: llacie_cohorts llacie_cohorts_FK_episode_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_cohorts
    ADD CONSTRAINT "llacie_cohorts_FK_episode_id_fk" FOREIGN KEY ("FK_episode_id") REFERENCES public.llacie_episodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_episode_labels llacie_episode_labels_FK_episode_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT "llacie_episode_labels_FK_episode_id_fk" FOREIGN KEY ("FK_episode_id") REFERENCES public.llacie_episodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_episode_labels llacie_episode_labels_FK_human_annotator_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT "llacie_episode_labels_FK_human_annotator_fk" FOREIGN KEY ("FK_human_annotator") REFERENCES public.llacie_annotators(username) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_episode_labels llacie_episode_labels_FK_note_feature_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT "llacie_episode_labels_FK_note_feature_id_fk" FOREIGN KEY ("FK_note_feature_id") REFERENCES public.llacie_note_features(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_episode_labels llacie_episode_labels_FK_strategy_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT "llacie_episode_labels_FK_strategy_id_fk" FOREIGN KEY ("FK_strategy_id") REFERENCES public.llacie_strategies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_episode_labels llacie_episode_labels_FK_task_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_episode_labels
    ADD CONSTRAINT "llacie_episode_labels_FK_task_id_fk" FOREIGN KEY ("FK_task_id") REFERENCES public.llacie_tasks(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_note_features llacie_note_features_FK_note_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_features
    ADD CONSTRAINT "llacie_note_features_FK_note_id_fk" FOREIGN KEY ("FK_note_id") REFERENCES public.llacie_notes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_note_features llacie_note_features_FK_note_section_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_features
    ADD CONSTRAINT "llacie_note_features_FK_note_section_id_fk" FOREIGN KEY ("FK_note_section_id") REFERENCES public.llacie_note_sections(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_note_features llacie_note_features_FK_strategy_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_features
    ADD CONSTRAINT "llacie_note_features_FK_strategy_id_fk" FOREIGN KEY ("FK_strategy_id") REFERENCES public.llacie_strategies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_note_sections llacie_note_sections_FK_note_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_sections
    ADD CONSTRAINT "llacie_note_sections_FK_note_id_fk" FOREIGN KEY ("FK_note_id") REFERENCES public.llacie_notes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_note_sections llacie_note_sections_FK_strategy_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_note_sections
    ADD CONSTRAINT "llacie_note_sections_FK_strategy_id_fk" FOREIGN KEY ("FK_strategy_id") REFERENCES public.llacie_strategies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_notes llacie_notes_FK_episode_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_notes
    ADD CONSTRAINT "llacie_notes_FK_episode_id_fk" FOREIGN KEY ("FK_episode_id") REFERENCES public.llacie_episodes(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: llacie_strategies llacie_strategies_FK_task_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: llacie
--

ALTER TABLE ONLY public.llacie_strategies
    ADD CONSTRAINT "llacie_strategies_FK_task_id_fk" FOREIGN KEY ("FK_task_id") REFERENCES public.llacie_tasks(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--